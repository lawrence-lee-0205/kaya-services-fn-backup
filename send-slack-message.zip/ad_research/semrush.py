import requests
from typing import List


def query_semrush(url):
    response = requests.get(url)
    results = _parse_semrush_response(response.content)
    return results


def _parse_semrush_response(data) -> List:
    results = []
    data = data.decode("unicode_escape")
    if "ERROR" in data.upper():
        raise ValueError(f"Error in response: {data}")

    lines = data.split("\r\n")
    lines = list(filter(bool, lines))
    columns = lines[0].split(";")

    for line in lines[1:]:
        result = {}
        split_values = line.split('";"')
        for i, datum in enumerate(split_values):
            # print(i)
            if i == 0:
                datum = datum[1:]
            elif i == len(split_values) - 1:
                datum = datum[:-1]
            # print("  ", datum)
            result[columns[i]] = datum.strip('"\n\r\t')
        results.append(result)
    return results
