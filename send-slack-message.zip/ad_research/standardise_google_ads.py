import uuid
import pandas as pd
from typing import List
from datetime import datetime
import numpy as np


_CHANNEL_MAPPING = {
    "text": ["search"],
    "videos": ["youtube"],
    "images": ["display"],
}
_FORMAT_MAPPING = {
    "videos": "video",
    "images": "image_single",
}
_PLATFORM = "google_ads"

_CURRENT_DATE = datetime.now().strftime("%Y%m%d")


def process_google_ads(google_ads_payload, proposal_company_id, proposal_id, **kwargs):
    google_ads = []

    if "copies" in google_ads_payload:
        ads = google_ads_payload.get("copies", [])
        google_ads += _process_spyfu_sem(ads, proposal_company_id, proposal_id)

    for f in ["text", "videos", "images"]:
        ads = google_ads_payload.get(f, [])
        if not ads:
            continue

        google_ads += _process_google_transparency_center(
            ads, f, proposal_company_id, proposal_id
        )
    return google_ads


def _process_spyfu_sem(ads, proposal_company_id, proposal_id) -> List:
    # process first and last seen
    ad_seen_dict = process_first_last_seen_dates(ads)

    sem_ads = []
    for ad in ads:
        ad_id = str(ad["adId"]).replace("-", "")

        ad_d = ad_seen_dict.get(ad_id, {})
        first_seen = ad_d.get("first_seen")
        last_seen = ad_d.get("last_seen")
        days_active = ad_d.get("days_active")

        d = {
            "platform": _PLATFORM,
            "ad_id": ad_id,
            "channels": ["search"],
            "format": "text",
            "first_seen": first_seen,
            "last_seen": last_seen,
            "days_active": days_active,
            "uuid": str(uuid.uuid4()),
            "landing_page_url": ad.get("url"),
            "objectID": _PLATFORM + "_" + ad_id,
            "proposal_company_id": proposal_company_id,
            "proposal_id": proposal_id,
            "headline": ad.get("title"),
            "body": ad.get("body"),
            "keywords": ad.get("keywords"),
            "position": ad.get("position"),
        }
        sem_ads.append(d)

    return sem_ads


def _process_google_transparency_center(
    ads, ad_format, proposal_company_id, proposal_id
) -> List:
    processed_ads = []
    for ta in ads:
        ad_id = ta["ad_creative_id"]
        first_seen = ta.get("first_seen")
        last_seen = ta.get("last_seen")
        days_active = ta.get("days_active")

        d = {
            "platform": _PLATFORM,
            "channels": _CHANNEL_MAPPING[ad_format],
            "format": _FORMAT_MAPPING.get(ad_format, ad_format),
            "advertiser_social_id": ta.get("advertiser_id", ""),
            "advertiser_name": ta.get("advertiser", ""),
            "ad_id": ad_id,
            "image_url": ta.get("image"),
            "video_url": ta.get("preview"),
            "first_seen": first_seen,
            "last_seen": last_seen,
            "days_active": days_active,
            "uuid": str(uuid.uuid4()),
            "landing_page_url": ta.get("url"),
            "objectID": _PLATFORM + "_" + ad_id,
            "proposal_company_id": proposal_company_id,
            "proposal_id": proposal_id,
        }
        processed_ads.append(d)

    return processed_ads


def process_first_last_seen_dates(ads):
    ads_df = pd.DataFrame(ads)
    ads_df["ad_id"] = ads_df["adId"].astype(str).str.replace("-", "")
    ads_df["headline_body"] = ads_df["title"] + " // " + ads_df["body"]

    # groupby headline and body copies to find min and max search date
    processed_df = ads_df.groupby("headline_body").agg(
        first_seen=("searchDateId", "min"),
        last_seen=("searchDateId", "max"),
        ad_ids=("ad_id", "unique"),
    )

    # impute current month if first_ and last_seen date are the same
    processed_df["last_seen"] = np.where(
        processed_df["last_seen"] == processed_df["first_seen"],
        _CURRENT_DATE,
        processed_df["last_seen"],
    )

    # calculate days_active
    processed_df["last_seen"] = pd.to_datetime(
        processed_df["last_seen"], format="%Y%m%d"
    )
    processed_df["first_seen"] = pd.to_datetime(
        processed_df["first_seen"], format="%Y%m%d"
    )
    processed_df["days_active"] = (
        processed_df["last_seen"] - processed_df["first_seen"]
    ).dt.days

    # process to str format
    processed_df["last_seen"] = processed_df["last_seen"].dt.strftime("%Y-%m-%d")
    processed_df["first_seen"] = processed_df["first_seen"].dt.strftime("%Y-%m-%d")

    # process df into dict format
    processed_df = processed_df[
        ["ad_ids", "first_seen", "last_seen", "days_active"]
    ].reset_index(drop=True)

    processed_df = processed_df.explode("ad_ids")
    processed_df = processed_df.rename(columns={"ad_ids": "ad_id"})
    processed_df = processed_df.set_index("ad_id")

    ad_seen_dict = processed_df.to_dict("index")

    return ad_seen_dict


if __name__ == "__main__":
    google_ads_payload = {
        "copies": [
            {
                "keywords": ["performance management software"],
                "position": 2,
                "searchDateId": 20240401,
                "title": "#1 Performance Management Tool",
                "body": "People Enablement Platform — Goals & OKRs, Performance Reviews and 360s, Engagement Surveys, 1:1 Meetings and More.",
                "url": "http://leapsome.com/",
                "adId": 1323420897,
            },
            {
                "keywords": ["performance management software"],
                "position": 2,
                "searchDateId": 20240601,
                "title": "#1 Performance Management Tool",
                "body": "People Enablement Platform — Goals & OKRs, Performance Reviews and 360s, Engagement Surveys, 1:1 Meetings and More.",
                "url": "http://leapsome.com/",
                "adId": 1323420898,
            },
            {
                "keywords": ["employee evaluation"],
                "position": 2,
                "searchDateId": 20240401,
                "title": "#1 Employee Review System",
                "body": "Award-Winning Platform — OKRs & Goals, Performance Reviews, Feedback, 1:1 Meetings, Engagement Surveys. Demo Now",
                "url": "http://leapsome.com/",
                "adId": -1257680841,
            },
        ],
        "images": [
            {
                "advertiser_id": "AR07985341838267514881",
                "advertiser": "Leapsome GmbH",
                "ad_creative_id": "CR14330771463915700225",
                "format": "image",
                "target_domain": "leapsome.com",
                "first_seen": "2024-06-05",
                "last_seen": "2024-06-25",
                "days_active": 19,
                "image": "https://s0.2mdn.net/simgad/15996083318285727455",
            },
            {
                "advertiser_id": "AR07985341838267514881",
                "advertiser": "Leapsome GmbH",
                "ad_creative_id": "CR07362796842792255489",
                "format": "image",
                "target_domain": "leapsome.com",
                "first_seen": "2024-06-06",
                "last_seen": "2024-06-24",
                "days_active": 18,
                "image": "https://s0.2mdn.net/simgad/14727109272614441823",
            },
        ],
    }

    proposal_company_id = "dummy_pc_id"
    proposal_id = "dummy_p_id"

    out = process_google_ads(google_ads_payload, proposal_company_id, proposal_id)
    print("out: ", out)


# if __name__ == "__main__":
#     from ad_research.consolidate_all_ads import consolidate_single_company
#     from ad_research.load_ads_from_storage_to_algolia import (
#         load_single_company_to_algolia,
#     )

#     proposal_company_id = "9X54Q9NUWD8faPJaLKLf"
#     proposal_id = "roSs4DvgGMavK0W0Ao5m"

#     consolidate_single_company(proposal_company_id, proposal_id)
#     load_single_company_to_algolia(proposal_company_id)
