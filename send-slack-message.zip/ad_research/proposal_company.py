import json

from storage.query_bucket import list_blob
from storage.download_blob import download_blob_into_string
from firestore import FirestoreClient
from enums.ad_platform import AdPlatform

_FS = FirestoreClient()


class ProposalCompany:
    def __init__(self, proposal_company_id, proposal_id):
        self.proposal_company_id = proposal_company_id
        self.proposal_id = proposal_id
        self.doc = _FS.get_single_document("proposal_companies", proposal_company_id)

        self.business_name = self.doc.get("company_info", {}).get("name", "").title()
        self.domain = self.doc.get("company_info", {})["domain"]
        self.industry = (
            self.doc.get("company_info", {}).get("category", {}).get("industry", "")
        )
        self.sub_industry = (
            self.doc.get("company_info", {}).get("category", {}).get("sub_industry", "")
        )
        self.description = self.doc.get("company_info", {}).get("description", {})
        self.tags = self.doc.get("company_info", {}).get("tags", [])

        # TODO: How might we identify companies with presence in multiple companies?
        # This data is needed to search for tiktok ads, which is only available for EU countries
        self.country = self.doc.get("country", "")

        self.bucket = "kaya-ads-research"
        self.all_ads_by_channel = self._get_ads_from_storage()

        # social media handles
        self.linkedin_ad_library_url = self.doc.get("linkedin_ad_library_url")
        self.facebook_handle = self.doc.get("facebook_handle")
        self.tiktok_search_terms = self.doc.get("tiktok_search_terms", [])
        self.bing_search_terms = self.doc.get("bing_search_terms", [])

        # TODO: These checks work by checking raw files in GCS and are often inaccurate
        # Do we still need this? Why not just check from Algolia?
        self._channel_with_ads = []
        self.has_google_ads = self._check_has_google_ads()
        self.has_meta_ads = self._check_has_meta_ads()
        self.has_linkedin_ads = self._check_has_linkedin_ads()
        self.has_bing_ads = self._check_has_bing_ads()
        self.has_tiktok_ads = self._check_has_tiktok_ads()

    @property
    def channel_with_ads(self):
        return list(set(self._channel_with_ads))

    def _get_ads_from_storage(self):
        """
        Get raw data from Storage
        """
        # find available files
        blobs = list_blob(
            self.bucket, prefix=f"{self.proposal_company_id}/", delimiter="/"
        )
        files = [
            blob.replace(f"{self.proposal_company_id}/", "")
            for blob in blobs
            if "all_ads" not in blob and "consolidated_ads" not in blob
        ]
        print(files)

        ads_by_channel = {}
        for f in files:
            channel = f.replace(".json", "")
            channel = (
                AdPlatform.GOOGLE.var_name if channel == "google_data" else channel
            )
            ads_by_channel[channel] = json.loads(
                download_blob_into_string(
                    self.bucket, f"{self.proposal_company_id}/{f}"
                )
            )
        return ads_by_channel

    def _check_has_google_ads(self):
        if AdPlatform.GOOGLE.var_name not in self.all_ads_by_channel:
            return False

        for lookup in ["copies", "keywords", "videos", "images"]:
            if (
                len(self.all_ads_by_channel[AdPlatform.GOOGLE.var_name].get(lookup, []))
                > 0
            ):
                self._channel_with_ads.append(AdPlatform.GOOGLE)
                return True
        return False

    def _check_has_meta_ads(self):
        # return false if no file in storage
        if AdPlatform.META.var_name not in self.all_ads_by_channel:
            return False

        if len(self.all_ads_by_channel[AdPlatform.META.var_name].get("items", [])) > 0:
            self._channel_with_ads.append(AdPlatform.META)
            return True
        else:
            return False

    def _check_has_linkedin_ads(self):
        if AdPlatform.LINKEDIN.var_name not in self.all_ads_by_channel:
            return False

        if len(self.all_ads_by_channel[AdPlatform.LINKEDIN.var_name]) > 0:
            self._channel_with_ads.append(AdPlatform.LINKEDIN)
            return True
        else:
            return False

    def _check_has_bing_ads(self):
        if AdPlatform.BING.var_name not in self.all_ads_by_channel:
            return False

        if len(self.all_ads_by_channel[AdPlatform.BING.var_name]) > 0:
            self._channel_with_ads.append(AdPlatform.BING)
            return True
        else:
            return False

    def _check_has_tiktok_ads(self):
        if AdPlatform.TIKTOK.var_name not in self.all_ads_by_channel:
            return False

        if len(self.all_ads_by_channel[AdPlatform.TIKTOK.var_name]) > 0:
            self._channel_with_ads.append(AdPlatform.TIKTOK)
            return True
        else:
            return False
