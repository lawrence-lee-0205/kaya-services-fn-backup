import requests

from ad_research.ad_utils import write_json_to_bucket
from ad_research.test_ad_research.test_get_bing_ads import (
    mock_get_bing_ads_from_ad_lib,
)

from http_function import process_request_inputs, http_function
from common import validate_inputs

from firestore import FirestoreClient


_FS = FirestoreClient()
BASE_URL = "https://adlibrary.api.bingads.microsoft.com/api/v1"

_RESULT_LIMIT = 12  # default


@http_function
def research_get_bing_ads(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)
    print(data)

    output = execute_get_bing_ads(data["proposal_company_id"], data["env"])
    return output


def execute_get_bing_ads(proposal_company_id, env="dev"):
    ## dev
    if env.upper() == "DEV":
        bing_ads = mock_get_bing_ads_from_ad_lib()

        out = write_json_to_bucket(proposal_company_id, "bing_ads", bing_ads)
        return out

    ## prod
    doc = _FS.get_single_document("proposal_companies", proposal_company_id)

    country = doc.get("country", "")
    if country.upper() == "US":
        write_json_to_bucket(proposal_company_id, "bing_ads", {})
        print("Bing ad library doesn't handle US. Skipping...")
        return {}

    bing_search_terms = doc.get("bing_search_terms", [])
    if len(bing_search_terms) == 0:
        write_json_to_bucket(proposal_company_id, "bing_ads", {})
        print("Bing search terms not available. Skipping...")
        return {}

    # get ads
    bing_ads = get_bing_ads_from_ad_lib(bing_search_terms)

    # write to cloud storage
    if not bing_ads:
        write_json_to_bucket(proposal_company_id, "bing_ads", {})
        print("Bing ad not available in ad library. Skipping...")
        return {}

    out = write_json_to_bucket(proposal_company_id, "bing_ads", bing_ads)
    return out


def query_advertisers(search_term):
    params = {"searchText": search_term}

    endpoint = "Advertisers"
    response = requests.get(f"{BASE_URL}/{endpoint}", params=params)
    response.raise_for_status()

    advertisers_list = response.json()["value"]

    advertiser_ids = [ad["AdvertiserId"] for ad in advertisers_list]

    return advertiser_ids


def query_ads(advertiser_id):
    params = {"advertiserId": advertiser_id, "top": _RESULT_LIMIT}

    endpoint = "Ads"
    response = requests.get(f"{BASE_URL}/{endpoint}", params=params)

    response.raise_for_status()

    ads_list = response.json()["value"]

    return ads_list


def get_bing_ads_from_ad_lib(bing_search_terms):
    bing_ads = []
    for term in bing_search_terms:
        # Get advertisers based on search keywords
        advertiser_ids = query_advertisers(term)
        print("advertiser_ids: ", advertiser_ids)

        # Get ads based on advertisers
        for adv_id in advertiser_ids:
            ads = query_ads(adv_id)
            bing_ads.extend(ads)

    return bing_ads


if __name__ == "__main__":
    proposal_company_id = "testleadcompany"
    bing_search_terms = ["amazon", "kfc"]
    env = "dev"

    all_ads = execute_get_bing_ads(proposal_company_id, bing_search_terms, env)
    print("all_ads: ", all_ads)
