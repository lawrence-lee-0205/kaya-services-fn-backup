from firestore import FirestoreClient
from ad_research.get_google_ads import execute_get_google_ads
from ad_research.get_meta_ads import execute_get_meta_ads
from ad_research.get_tiktok_ads import execute_get_tiktok_ads
from ad_research.get_bing_ads import execute_get_bing_ads
from ad_research.get_linkedin_ads import execute_get_linkedin_ads
from ad_research.consolidate_all_ads import consolidate_single_company
from ad_research.load_ads_from_storage_to_algolia import load_single_company_to_algolia
from ad_research.proposal_company import ProposalCompany

_FS = FirestoreClient()

if __name__ == "__main__":
    proposal_id = "QPcpxNMA9PVfLQJJrKuH"
    force_overwrite = True

    p = _FS.get_single_document("proposal", proposal_id)
    proposal_company_ids = list(p["competitors"].values()) + [p["proposal_company_id"]]
    # proposal_company_ids = [
    #     # "b2G0cM2D7TVttQnF95hC",
    #     "bNS4lEy4qgRtE0f52MGG",
    #     "vBF7qP9p9NZjYKqEc3WU",
    #     "FD4QnLlQ5SET2vUM3MYv",
    # ]

    print(proposal_company_ids)

    for pc_id in proposal_company_ids:
        pc_obj = ProposalCompany(pc_id, proposal_id)

        pc_doc = _FS.get_single_document("proposal_companies", pc_id)
        company_name = pc_obj.business_name

        scraped_channels = pc_obj.channel_with_ads

        print("\n\n💞 Processsing ", pc_id, " ", company_name, " ", pc_obj.domain)
        # check if exists
        if force_overwrite or "google_ads" not in scraped_channels:
            execute_get_google_ads(pc_id, p["country"])
        else:
            print("Google ads already scraped. Skipping...")

        # check if exists
        if force_overwrite or "linkedin_ads" not in scraped_channels:
            li_handle = (
                pc_doc.get("company_info", {}).get("linkedin", {}).get("handle", "")
            )
            if li_handle and len(li_handle) > 0:
                li_handle = li_handle.replace("company/", "")
                li_ad_library_url = f"https://www.linkedin.com/ad-library/search?accountOwner={li_handle}&countries={p['country']}"
                execute_get_linkedin_ads(li_ad_library_url, pc_id)
            else:
                li_ad_library_url = input("Enter Li ad_library_url for company: ")
                li_ad_library_url = li_ad_library_url.strip()
                if len(li_ad_library_url) > 0:
                    _FS.update_document(
                        "proposal_companies",
                        pc_id,
                        {"company_info.linkedin.ad_library_url": li_ad_library_url},
                    )
                    execute_get_linkedin_ads(li_ad_library_url, pc_id)
                else:
                    print("No Li ad_library_url provided. Skipping...")
        else:
            print("LI ads already scraped. Skipping...")

        b_search_term = input(
            f"Default search term is {company_name}. Enter to continue or insert new search term for B: "
        )
        if b_search_term == "":
            b_search_term = company_name
        execute_get_bing_ads(b_search_term, pc_id)

        if force_overwrite or "meta_ads" not in scraped_channels:
            fb_handle = (
                pc_doc.get("company_info", {}).get("facebook", {}).get("handle", "")
            )
            if fb_handle and len(fb_handle) > 0:
                execute_get_meta_ads(fb_handle, pc_id)
            else:
                fb_handle = input("Enter Facebook handle for company: ")
                if len(fb_handle) > 0:
                    _FS.update_document(
                        "proposal_companies",
                        pc_id,
                        {"company_info.facebook.handle": fb_handle},
                    )
                    execute_get_meta_ads(fb_handle, pc_id)
                else:
                    print("No Facebook handle provided. Skipping...")
        else:
            print("Meta ads already scraped. Skipping...")

        if company_name:
            execute_get_tiktok_ads(company_name, pc_id)
        else:
            search_term = input("Enter search term for TT: ")
            if len(search_term) > 0:
                execute_get_tiktok_ads(search_term, pc_id)
            else:
                print("No TT search_term provided. Skipping...")

        consolidate_single_company(pc_id, proposal_id)
        load_single_company_to_algolia(pc_id)

        print("-------------------\n\n")
