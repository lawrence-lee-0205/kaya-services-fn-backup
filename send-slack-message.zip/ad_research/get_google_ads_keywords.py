import json
import pandas as pd
from datetime import datetime

from common import validate_inputs
from http_function import http_function, process_request_inputs

from firestore import FirestoreClient
from storage.download_blob import download_blob_into_string

from gsheets.gsheet import GSheet

_BUCKET = "kaya-ads-research"
_FS = FirestoreClient()

_COLS_TO_EXPORT = [
    "domain",
    "keyword",
    "searchVolume",
    "rankingDifficulty",
    "totalMonthlyClicks",
    "percentSearchesNotClicked",
    "percentPaidClicks",
    "percentOrganicClicks",
    "broadCostPerClick",
    "phraseCostPerClick",
    "exactCostPerClick",
    "broadMonthlyClicks",
    "phraseMonthlyClicks",
    "exactMonthlyClicks",
    "broadMonthlyCost",
    "phraseMonthlyCost",
    "exactMonthlyCost",
    "paidCompetitors",
    "distinctCompetitors",
    "rankingHomepages",
    "serpFeaturesCsv",
    "serpFirstResult",
]


@http_function
def research_consolidate_gad_keywords_to_gsheet(request_json={}, request_args={}):
    mandatory_fields = ["proposal_id"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    res = consolidate_gad_keywords_to_gsheet(proposal_id=data["proposal_id"])
    return res


def export_gad_keywords_to_gsheet(lead_domain, keyword_df):
    filename = f"GAds Keywords for {lead_domain} v{datetime.now().strftime('%Y%m%d')}"
    print("filename: ", filename)

    # create gsheet
    gsheet = GSheet()
    gsheet.create(filename)

    # add ad keywords
    uniq_tab_name = "ad_keywords"
    gsheet.add_tab(
        uniq_tab_name,
        rows=keyword_df.shape[0],
    )
    gsheet.write_dataframe_to_tab(keyword_df.fillna(""), uniq_tab_name)

    # share access to public
    gsheet.share_public(role="writer")

    return gsheet.url


def consolidate_gad_keywords_to_gsheet(proposal_id):
    p = _FS.get_single_document("proposal", proposal_id)
    pc_dict = {v: k.replace("/", "") for k, v in p["competitors"].items()}
    pc_dict[p["proposal_company_id"]] = p["domain"]

    print("pc_dict: ", pc_dict)

    proposal_company_ids = list(pc_dict.keys())

    print(proposal_company_ids)

    keyword_dfs = []
    for pc_id in proposal_company_ids:
        print("Processing ", pc_id)

        try:
            payload = json.loads(
                download_blob_into_string(_BUCKET, f"{pc_id}/google_ads.json")
            )
            keywords = payload.get("keywords", [])

            if keywords:
                keyword_df = pd.DataFrame(keywords)
                keyword_df["domain"] = pc_dict[pc_id]
                keyword_dfs.append(keyword_df)

            else:
                print("no keywords")

        except Exception as e:
            print(e)
            continue

    # process dfs
    if len(keyword_dfs) > 0:
        concat_keyword_df = pd.concat(keyword_dfs, ignore_index=True)

        # process for different competitors
        unique_companies = list(
            {
                competitor
                for competitor_list in concat_keyword_df["distinctCompetitors"]
                for competitor in competitor_list
            }
        )
        unique_companies.sort()
        company_cols = [
            pd.Series(
                [
                    1 if comp in x else 0
                    for x in concat_keyword_df["distinctCompetitors"]
                ]
            )
            for comp in unique_companies
        ]

        # concat to original df
        concat_keyword_df_col_list = list(concat_keyword_df.columns)

        final_keyword_df = pd.concat([concat_keyword_df, *company_cols], axis=1)
        final_keyword_df.columns = concat_keyword_df_col_list + unique_companies

        # transform list col to str col
        final_keyword_df["distinctCompetitors"] = [
            ", ".join(map(str, l)) for l in final_keyword_df["distinctCompetitors"]
        ]

        # drop duplicates
        final_keyword_df = final_keyword_df.drop_duplicates()

        # rearrange company sequence to prioritise for proposal companies
        # proposal_companies = list(pc_dict.values())

        # proposal_companies.remove(p["domain"])
        # proposal_companies.sort()
        # proposal_companies.insert(0, p["domain"])

        # filtered_companies = [
        #     c for c in unique_companies if c not in proposal_companies
        # ]
        # sorted_companies = [*proposal_companies, *filtered_companies]

        # final_keyword_df = final_keyword_df[
        #     [*concat_keyword_df_col_list, *sorted_companies]
        # ]
        final_keyword_df = final_keyword_df.sort_values(
            by="searchVolume", ascending=False
        )

        print(final_keyword_df.head())
        print(final_keyword_df.shape)

        # export to gsheet
        gsheet_url = export_gad_keywords_to_gsheet(
            p["domain"],
            final_keyword_df[_COLS_TO_EXPORT],
        )

        print("gsheet_url: ", gsheet_url)

        # write to firestore
        # proposal companies
        pc_ids = list(pc_dict.keys())
        for pc_id in pc_ids:
            _FS.update_document(
                "proposal_companies",
                pc_id,
                {"google_ads.keyword_gsheet_url": gsheet_url},
            )
            print(f"firestore updated for proposal_company_id {pc_id}")

        # proposal
        _FS.update_document("proposal", proposal_id, {"keyword_gsheet_url": gsheet_url})
        print(f"firestore updated for proposal_id {proposal_id}")

    else:
        print(f"no available keywords for companies in proposal {proposal_id}")


if __name__ == "__main__":
    proposal_id = "y6p7eNt4LZwlhAifQ24m"

    consolidate_gad_keywords_to_gsheet(proposal_id)
