import json
from os import environ
from typing import List, Dict

from common import validate_inputs
from http_function import http_function, process_request_inputs

from algoliasearch.search_client import SearchClient
from storage.download_blob import download_blob_into_string

_BUCKET = "kaya-ads-research"
_ALGOLIA_CLIENT = SearchClient.create("9UOFA9X1DB", environ["ALGOLIA_API_KEY"])
_ALGOLIA_INDEX = _ALGOLIA_CLIENT.init_index("ad_research_sample")


@http_function
def algolia_partial_update_objects(request_json={}, request_args={}):
    mandatory_fields = ["obj_list"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    res = partial_update_algolia_objects(obj_list=data["obj_list"])
    return res


def filter_algolia_objects(filter: dict):
    # set up filter parameters
    filters = [f"({k}:'{v}')" for k, v in filter.items()]

    filter_param = " AND ".join(filters)

    param = {
        "attributesToRetrieve": ["objectID"],
        "filters": filter_param,
        "typoTolerance": False,
    }

    # browse objects
    res = _ALGOLIA_INDEX.browse_objects(param)

    return res


def delete_algolia_objects(filter: dict):
    """
    Browse and delete Algolia objects by specific filter field(s) and user confirmation (Y/N).

    Searchable filter attributes include:
    proposal_id, proposal_company_id, channel, format, platform, is_asset_error, objectId

    The filter has to be a facet attribute for it to work; can be set as not searchable.
    If more than one filter is provided, the function combines them with AND boolean operator.

    Sample browse index output:
    res = index.browse_objects(param)
    out = [{'objectID': 'linkedin_ads_383534536'}, {'objectID': 'linkedin_ads_383534537'}]
    """

    delete_objects = []
    res = filter_algolia_objects(filter)

    delete_objects = [item["objectID"] for item in res]
    n_delete_objects = len(delete_objects)

    check_delete = input(
        f"{n_delete_objects} objects found. Are you sure you want to delete them from Algolia? (Y/N)"
    )

    if check_delete.upper() == "Y":
        _ALGOLIA_INDEX.delete_objects(delete_objects)

        print(f"{n_delete_objects} objects deleted from Algolia")

    else:
        print(f"{n_delete_objects} objects not deleted from Algolia")


def partial_update_algolia_objects(obj_list: List[Dict]):
    res = _ALGOLIA_INDEX.partial_update_objects(obj_list)
    print("res: ", res)
    print(f"{len(obj_list)} updated at algolia!")

    return "Success"


# if __name__ == "__main__":
#     import time

#     start_time = time.time()

#     proposal_id = "JNEP6ktzpCRmO3bX2N7Q"

#     p = _FS.get_single_document("proposal", proposal_id)
#     proposal_company_ids = [p["proposal_company_id"]] + list(p["competitors"].values())

#     for pc_id in proposal_company_ids:
#         try:
#             load_single_company_to_algolia(pc_id)
#         except Exception as e:
#             print(e)

#     print("--- %s seconds ---" % (time.time() - start_time))


# if __name__ == "__main__":
#     proposal_id = "Z9ED7j0E86Got8K4tJvJ"

#     p = _FS.get_single_document("proposal", proposal_id)
#     proposal_company_ids = [p["proposal_company_id"]] + list(p["competitors"].values())

#     proposal_company_ids = [
#         # "T4vMjy8RYq26pMuWXkdy",
#         "VVG732SukzlQ8gXLL9HW",
#         # "iIcxooJOFdhB6RnJkkXl",
#         # "YT22pJo6TtughUHAEOjF",
#     ]

#     for pc_id in proposal_company_ids:
#         load_single_company_to_algolia(pc_id)


# if __name__ == "__main__":
#     filter = {
#         "proposal_company_id": "9X54Q9NUWD8faPJaLKLf",
#         # "proposal_id" : "testproposal",
#         # "platform": "google_ads",
#         # "channels": "youtube",
#         # "format": "image_carousel",
#         # "is_asset_error": True,
#         # "objectID": "meta_ads_120208899228830577",
#         "platform": "bing_ads",
#     }

#     out = delete_algolia_objects(filter=filter)
#     print("out: ", out)

if __name__ == "__main__":
    obj_list = [
        {
            "objectID": "meta_ads_6605594785130",
            "tags": [
                "B2C",
                "Health Care",
                "Medical Device",
                "mHealth",
                "Mobile Apps",
                "test",
            ],
        }
    ]

    out = partial_update_algolia_objects(obj_list)
    print("out: ", out)
