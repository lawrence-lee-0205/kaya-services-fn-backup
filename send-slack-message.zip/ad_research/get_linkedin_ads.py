import pandas as pd
from os import environ

from ad_research.ad_utils import write_json_to_bucket
from ad_research.test_ad_research.test_get_linkedin_ads import (
    mock_get_linkedin_ads_from_apify,
)

from apify_client import ApifyClient
from firestore import FirestoreClient
from http_function import process_request_inputs, http_function
from common import validate_inputs

_FS = FirestoreClient()
_APIFY_CLIENT = ApifyClient(environ["APIFY_API_KEY"])
_APIFY_ACTOR_ID = "AdwCDVyhFcWXQF9tg"
_RESULT_LIMIT = 5000


@http_function
def research_get_linkedin_ads(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)
    print(data)

    output = execute_get_linkedin_ads(data["proposal_company_id"], data["env"])
    return output


def execute_get_linkedin_ads(proposal_company_id, env="dev"):
    ## dev
    if env.upper() == "DEV":
        linkedin_ads = mock_get_linkedin_ads_from_apify()
        print("linkedin_ads: ", linkedin_ads)

        out = write_linkedin_ads_to_bucket(proposal_company_id, linkedin_ads)
        return out

    ## prod
    doc = _FS.get_single_document("proposal_companies", proposal_company_id)

    ad_library_url = doc.get("linkedin_ad_library_url")

    if not ad_library_url:
        write_json_to_bucket(proposal_company_id, "linkedin_ads", {})
        print("LinkedIn ad library url not available. Skipping...")
        return {}

    # get ads
    linkedin_ads = get_linkedin_ads_from_apify(ad_library_url)

    # write to cloud storage
    if not linkedin_ads:
        write_json_to_bucket(proposal_company_id, "linkedin_ads", {})
        print("LI ad not available in Apify. Skipping...")
        return {}

    out = write_linkedin_ads_to_bucket(proposal_company_id, linkedin_ads)
    return out


def get_linkedin_ads_from_apify(ad_library_url):
    print(ad_library_url)
    run_input = {
        "startUrls": [{"url": ad_library_url}],
        "resultsLimit": _RESULT_LIMIT,
        "proxyConfiguration": {
            "apifyProxyGroups": [],
            "useApifyProxy": True,
        },
    }
    # Run the Actor and wait for it to finish
    run = _APIFY_CLIENT.actor(_APIFY_ACTOR_ID).call(run_input=run_input)
    # Fetch and print Actor results from the run's dataset (if there are any)
    linkedin_ads = [
        item for item in _APIFY_CLIENT.dataset(run["defaultDatasetId"]).iterate_items()
    ]

    print("Ads found: ", len(linkedin_ads))

    return linkedin_ads


def write_linkedin_ads_to_bucket(proposal_company_id, linkedin_ads):
    # process for aggregation calc
    for item in linkedin_ads:
        landing_page_url = item.get("clickUrl")
        if landing_page_url:
            landing_page_url = landing_page_url.split("?")[0]
        item["landing_page_url"] = landing_page_url

    li_df = pd.DataFrame(linkedin_ads)
    count_by_format = (
        pd.pivot_table(li_df, index="format", aggfunc="count", values="adId")
        .fillna(0)
        .to_dict()["adId"]
    )

    count_by_lp = (
        pd.pivot_table(li_df, index="landing_page_url", aggfunc="count", values="adId")
        .fillna(0)
        .to_dict()["adId"]
    )

    output = {
        "items": linkedin_ads,
        "breakdown_by_format": count_by_format,
        "breakdown_by_landing_page": count_by_lp,
    }

    # content_to_save = {"linkedin_ads": output}
    # update_firestore_doc("proposal_companies", firestore_id, content_to_save)
    # print(output)

    # Write to cloud storage
    write_json_to_bucket(proposal_company_id, "linkedin_ads", output)

    # Store breakdown_by_format to proposal_companies collection
    _FS.update_document(
        "proposal_companies",
        proposal_company_id,
        {
            "linkedin_ads.breakdown_by_format": count_by_format,
            "linkedin_ads.breakdown_by_landing_page": count_by_lp,
        },
    )

    return {
        "status": "success",
        "has_linkedin_ads": True,
    }


# if __name__ == "__main__":
#     proposal_company_id = "testleadcompany"
#     env = "dev"
#     output = execute_get_linkedin_ads(proposal_company_id, env)
#     print(output)
#     print("Done")

# ad_library_url = (
#     "https://www.linkedin.com/ad-library/search?accountOwner=duolingo&countries=US"
# )

if __name__ == "__main__":
    proposal_company_id = "testleadcompany"
    env = "prod"
    
    output = execute_get_linkedin_ads(proposal_company_id, env)
    print(output)
    print("Done")
