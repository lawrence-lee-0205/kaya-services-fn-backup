import re
import datetime as dt
from datetime import date, timedelta
from os import environ

from ad_research.ad_utils import write_json_to_bucket
from ad_research.spyfu import get_spyfu_gads_copies, get_spyfu_gads_keywords
from ad_research.test_ad_research.test_get_google_ads import (
    mock_get_ads_from_transparency_center,
    mock_get_gads_copies_from_spyfu,
    mock_get_gads_keywords_from_spyfu,
)

# from ad_research.semrush import query_semrush
# SEMRUSH_API_KEY = environ["SEMRUSH_API_KEY"]
# _SEMRUSH_RESULT_LIMIT = 1000

from common import validate_inputs
from http_function import process_request_inputs, http_function

from utils.request import call_api
from firestore import FirestoreClient


_FS = FirestoreClient()


@http_function
def research_get_google_ads(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)
    print(data)

    output = execute_get_google_ads(
        proposal_company_id=data["proposal_company_id"],
        env=data["env"],
    )
    return output


def execute_get_google_ads(proposal_company_id, env="dev", channel_params={}):
    ## dev
    if env.upper() == "DEV":
        ads = mock_get_ads_from_transparency_center()
        copies = mock_get_gads_copies_from_spyfu()
        keywords = mock_get_gads_keywords_from_spyfu()

        # write to cloud storage
        out = write_google_ads_to_bucket(proposal_company_id, ads, copies, keywords)
        return out

    ## prod
    proposal_company_doc = _FS.get_single_document(
        "proposal_companies", proposal_company_id
    )
    domain = proposal_company_doc["domain"]
    country = proposal_company_doc.get("country", "")

    # get ads from transparency center
    ads = _get_ads_from_transparency_center(domain, country)
    print("len ads: ", len(ads))
    print("ads: ", ads)

    # always run SpyFu as transparency center dont always show all ads
    try:
        copies = {}
        keywords = {}
        spyfu_terms_to_search = channel_params.get("spyfu_terms_to_search")
        spyfu_incl_any = channel_params.get("spyfu_incl_any")

        print("spyfu_terms_to_search: ", spyfu_terms_to_search)
        print("spyfu_incl_any: ", spyfu_incl_any)

        copies = get_spyfu_gads_copies(domain, country)
        keywords = get_spyfu_gads_keywords(
            domain, country, spyfu_terms_to_search, spyfu_incl_any
        )

        print("Done getting data from SpyFu")
        print("Len copies: ", len(copies))
        print("Len keywords: ", len(keywords))

    except Exception as e:
        print("Failed to get data from SpyFu: ", e)

    # write to cloud storage
    if not any([ads, copies, keywords]):
        write_json_to_bucket(proposal_company_id, "google_ads", {})
        print(
            "Google ads not available in Google Transparency Center and SpyFu. Skipping..."
        )
        return {}

    out = write_google_ads_to_bucket(proposal_company_id, ads, copies, keywords)
    return out


def write_google_ads_to_bucket(proposal_company_id, ads, copies, keywords):
    content_to_save = {
        "copies": copies,
        "keywords": keywords,
        "videos": [
            {**a, "preview": _extract_google_ads_video_preview(a["link"])}
            for a in ads
            if a["format"] == "video"
        ],
        "images": [a for a in ads if a["format"] == "image"],
        "text": [a for a in ads if a["format"] == "text"],
        "platform": "google",
    }

    # write to cloud storage
    write_json_to_bucket(proposal_company_id, "google_ads", content_to_save)

    return {
        "status": "success",
        "has_google_ads": True,
    }


def _get_ads_from_transparency_center(domain, country):
    region = None
    if country == "US":
        region = "2840"
    elif country == "GB":
        region = "2826"
    elif country == "CA":
        region = "2124"
    else:
        raise ValueError(f"Country {country} not supported")

    print("Searching transparency center...")

    # Get one year dates
    today = date.today()
    start_date = today - timedelta(days=365)

    # Format the dates as YYYYMMDD
    end_date = int(today.strftime("%Y%m%d"))
    start_date = int(start_date.strftime("%Y%m%d"))

    params = {
        "api_key": environ["SERP_API_KEY"],
        "engine": "google_ads_transparency_center",
        "text": domain,
        "num": 100,
        "start_date": start_date,
        "end_date": end_date,
    }
    if region:
        params["region"] = region

    results = call_api("https://serpapi.com/search.json?", params=params)
    all_results = []
    while True:
        if "error" in results:
            print(results["error"])
            break

        all_results += results["ad_creatives"]

        if "next" in results.get("serpapi_pagination", {}):
            results = call_api(results["serpapi_pagination"]["next"], params=params)
        else:
            break

    print("Len of results", len(all_results))
    ads = []
    for res in all_results:
        if res["target_domain"] != domain:
            continue

        first_shown = dt.datetime.utcfromtimestamp(res["first_shown"])
        last_shown = dt.datetime.utcfromtimestamp(res["last_shown"])

        days_active = (last_shown - first_shown).days
        ads.append(
            {
                "advertiser_id": res["advertiser_id"],
                "advertiser": res["advertiser"],
                "ad_creative_id": res["ad_creative_id"],
                "format": res["format"],
                "target_domain": res["target_domain"],
                "first_seen": first_shown.strftime("%Y-%m-%d"),
                "last_seen": last_shown.strftime("%Y-%m-%d"),
                "days_active": days_active,
                "image": res.get("image"),
                "link": res.get("link"),
            }
        )
    print("Len of processed ads: ", len(ads))
    return ads


## semrush version of get_spyfu_gads_keywords
# def get_gads_keywords(domain, country):
#     # acceptable country list: https://www.spyfu.com/api/v2#?route=get-/apis/keyword_api/v2/ppc/getMostSuccessful
#     print("Getting data from spyfu for country ", country)

#     keywords = []
#     for yyyymm in range(202401, 202404):
#         display_date = f"{yyyymm}15"
#         semrush_q = f"https://api.semrush.com/?type=domain_adwords&key={SEMRUSH_API_KEY}&display_limit={_SEMRUSH_RESULT_LIMIT}&display_date={display_date}&export_columns=Ph,Po,Pp,Pd,Nq,Cp,Vu,Tr,Tc,Co,Nr,Tdt&domain={domain}&database={country.lower()}&export_escape=1&display_sort=cg_desc"
#         keywords += query_semrush(semrush_q)
#     # semrush_q = f"https://api.semrush.com/?type=domain_adwords&key={SEMRUSH_API_KEY}&display_limit={_SEMRUSH_RESULT_LIMIT}&domain={domain}&database={country.lower()}&export_escape=1"
#     # keywords = query_semrush(semrush_q)
#     return keywords


## semrush version of get_spyfu_gads_copies
# def get_gads_copies(domain, country):
#     # acceptable country list: https://www.spyfu.com/api/v2#?route=get-/apis/keyword_api/v2/ppc/getMostSuccessful
#     print("Getting data from spyfu for country ", country)
#     semrush_q = f"https://api.semrush.com/?type=domain_adwords_unique&key={SEMRUSH_API_KEY}&display_limit={_SEMRUSH_RESULT_LIMIT}&export_columns=Un,Tt,Ds,Vu,Ur,Pc,Ts,Dt&domain={domain}&database={country.lower()}&export_escape=1"
#     copies = query_semrush(semrush_q)
#     return copies


def _extract_google_ads_video_preview(js_link):
    # Send a GET request to the URL
    if js_link is None:
        return None

    url = js_link  #  v['link']

    try:
        video_js_content = call_api(url, output_fmt="text")
        url_pattern = r"previewservice.insertPreviewImageContent\([^)]*?'https://[^']+'"
        # Search for the URL in the file content
        match = re.search(url_pattern, video_js_content)

        # Check if a match was found
        if match:
            # Extract the URL from the matched string
            # The URL is assumed to be the first 'https://' occurrence until the next single quote
            url_match = re.search(r"https://[^']+", match.group())
            if url_match:
                return url_match.group()
            else:
                print("URL pattern found, but specific URL extraction failed.")
        else:
            print("No URL found in the content.")
    except Exception as e:
        print(f"Failed to fetch the content. Error: {e}")
    return None


if __name__ == "__main__":
    proposal_company_id = "test_competitor_everlywell"
    env = "dev"
    channel_params = {
        "spyfu_terms_to_search": "check1",
        "spyfu_incl_any": "check2",
    }
    output = execute_get_google_ads(proposal_company_id, env, channel_params)
    print(output)
    print("Done")

    # o = get_spyfu_gads_copies("dailybot.com", "us")
    # print(o)
