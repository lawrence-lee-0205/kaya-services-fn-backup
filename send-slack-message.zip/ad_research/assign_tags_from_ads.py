from os import environ
import queue

from common import validate_inputs
from http_function import http_function, process_request_inputs
from google.cloud_functions.call_cloud_function import call_cloud_function

from algoliasearch.search_client import SearchClient
from ad_research.ad_utils import tags_keywords_mapping_dict

BUCKET = "kaya-ads-research"
_ALGOLIA_CLIENT = SearchClient.create("9UOFA9X1DB", environ["ALGOLIA_API_KEY"])


@http_function
def research_assign_tags_with_algolia(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    res = assign_tags_from_algolia(proposal_company_id=data["proposal_company_id"])

    if not res:
        print("no tags to be assigned")
        return None

    # update algolia
    endpoint = "/algolia-partial-update-objects"
    params = {"obj_list": res}
    out = call_cloud_function(endpoint, params)
    print("out: ", out)

    return out


def get_objects_with_tags(index, proposal_company_id):
    param = {
        "attributesToRetrieve": [
            "objectID",
            "tags",
            "format",
            "is_asset_error",
            "original_image_url",
            "video_url",
        ],
        "filters": f"proposal_company_id:'{proposal_company_id}'",
        "typoTolerance": False,
    }

    res = index.browse_objects(param)

    if not res:
        print(f"No results for proposal_company_id {proposal_company_id}")
        return {}, []

    # filter for objects
    obj_tag_dict = {}
    unfeatured_obj_list = []
    for obj in res:
        object_id = obj["objectID"]
        obj_tags = obj.get("tags", [])

        if obj_tags:
            obj_tag_dict[object_id] = obj_tags

        # check for image and video validity
        if obj["format"] in ["image_carousel", "image_single"]:
            if obj.get("is_asset_error", False) or not (
                obj.get("original_image_url", "")
            ):
                unfeatured_obj_list.append(object_id)
        elif obj["format"] == "video":
            if (
                obj.get("is_asset_error", False)
                or not (obj.get("original_image_url", ""))
                or not (obj.get("video_url", ""))
            ):
                unfeatured_obj_list.append(object_id)

    return obj_tag_dict, unfeatured_obj_list


def search_objects_by_keyword(index, keywords, proposal_company_id):
    # search by keywords, filter for objects by proposal_company_id
    res = index.search(
        keywords,
        {
            "attributesToRetrieve": ["objectID"],
            "filters": f"proposal_company_id:'{proposal_company_id}'",
            "optionalWords": keywords,
            "typoTolerance": False,
        },
    )

    if not res:
        print(
            f"No results for proposal_company_id {proposal_company_id} / keywords {keywords}"
        )
        return []

    # filter for objects
    objects = res["hits"]
    obj_ids = []
    for obj in objects:
        object_id = obj["objectID"]
        obj_ids.append(object_id)

    return obj_ids


def assign_tags_from_algolia(proposal_company_id):
    # initialize index
    algolia_index = "ad_research_sample"
    index = _ALGOLIA_CLIENT.init_index(algolia_index)

    # search by keywords, map to tags for object_ids
    obj_tag_dict, unfeatured_obj_list = get_objects_with_tags(
        index, proposal_company_id
    )

    for tag in tags_keywords_mapping_dict.keys():
        print("------ tag: ", tag, "------")

        keywords = tags_keywords_mapping_dict[tag]

        print("--- keywords: ", keywords, "---")

        obj_ids = search_objects_by_keyword(index, keywords, proposal_company_id)

        # check if obj is in dict, else assign empty tag list
        # append tag to tag list, then reassign back
        # expected output {"obj_id":["tag1", "tag2"]}
        if not obj_ids:
            print("No obj_ids")
            continue

        for obj_id in obj_ids:
            tag_list = obj_tag_dict.get(obj_id, [])
            tag_list.append(tag)
            obj_tag_dict[obj_id] = tag_list

        print("\n")

    # preprocess to list
    if not obj_tag_dict:
        print("No obj_tag_dict")
        return []

    obj_tag_list = []
    for obj_id, tag_list in obj_tag_dict.items():
        num_tags = len(tag_list)
        if num_tags > 1 and (obj_id not in unfeatured_obj_list):
            is_featured = True
        else:
            is_featured = False

        obj_tag = {
            "objectID": obj_id,
            "tags": tag_list,
            "num_tags": num_tags,
            "is_featured": is_featured,
        }
        obj_tag_list.append(obj_tag)

    print(f"Done assigning tags for {len(obj_tag_list)} objects.")

    return obj_tag_list


if __name__ == "__main__":
    import time

    start_time = time.time()

    proposal_company_id = "test_competitor_everlywell"

    output = assign_tags_from_algolia(proposal_company_id)

    print("output: ", output)
    print("--- %s seconds ---" % (time.time() - start_time))

    ## sample output
    # [
    #     {
    #         "objectID":"linkedin_ads_349476193",
    #         "tags":[
    #             "Product Launch"
    #         ]
    #     },
    #     {
    #         "objectID":"linkedin_ads_358980373",
    #         "tags":[
    #             "Product Launch",
    #             "Lead Generation",
    #             "Testimonial"
    #         ]
    #     }
    # ]

# if __name__ == "__main__":
#     # initialize index
#     algolia_index = "ad_research_sample"
#     index = _ALGOLIA_CLIENT.init_index(algolia_index)

#     proposal_company_id = "testleadcompany"

#     get_objects_with_tags(index, proposal_company_id)
