import os
import json

from common import validate_inputs
from http_function import http_function, process_request_inputs
from google.cloud_functions.call_cloud_function import call_cloud_function

from urllib.parse import urlparse
from storage.upload_blob import upload_blob_from_string
from storage.download_blob import download_blob_into_string
from utils.request import call_api
from storage.query_bucket import list_blob, check_blob_exist

_BUCKET = "kaya-ads-research"
_IMAGE_STORAGE_BUCKET = "kaya-ads-research-images"

MIME_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".tif": "image/tiff",
    ".tiff": "image/tiff",
    ".ico": "image/x-icon",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
}


@http_function
def research_upload_ads_images(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "channel"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    proposal_company_id = data["proposal_company_id"]
    channel = data["channel"]

    # check if file exists
    if not check_blob_exist(
        _BUCKET, f"{proposal_company_id}/consolidated_{channel}.json"
    ):
        print(f"no {channel} found")
        return None

    # upload ads images if exists
    res = upload_ads_images(
        proposal_company_id=proposal_company_id,
        channel=channel,
    )

    if not res:
        print(f"no {channel} images to be uploaded")
        return None

    # update algolia
    endpoint = "/algolia-partial-update-objects"
    params = {"obj_list": res}
    out = call_cloud_function(endpoint, params)
    print("out: ", out)

    return out


def _get_existing_image_gcs_url(blob_list, proposal_company_id, ad_id):
    for blob_name in blob_list:
        # Get the file name without the extension
        root_name, ext = os.path.splitext(blob_name)
        # ext contains "."
        if root_name == f"{proposal_company_id}/{ad_id}":
            return f"https://storage.googleapis.com/{_IMAGE_STORAGE_BUCKET}/{root_name}{ext}"
    return None


def _upload_img_to_bucket(ori_url, proposal_company_id, ad_id):
    if not ori_url:
        return None

    else:
        try:
            resp = call_api(ori_url, output_fmt="raw")

            if resp.status_code == 200:
                image_data = resp.content

                # Upload the image to Google Cloud Storage
                bucket = "kaya-ads-research-images"
                file_extension = _get_extension_from_url(ori_url)
                mime = get_mime_type(file_extension)
                new_image_url = upload_blob_from_string(
                    bucket,
                    image_data,
                    mime,
                    f"{proposal_company_id}/{ad_id}{file_extension}",
                    is_public=True,
                )
                print("new_image_url: ", new_image_url)
                return new_image_url

            else:
                print("resp.status_code: ", resp.status_code)
                return None

        except Exception as e:
            print("Failed to download the image.", ori_url)
            return None


def _get_extension_from_url(url):
    """Extract the file extension from a URL."""
    # Parse the URL to get the path
    parsed_url = urlparse(url)
    # Extract the file extension
    extension = os.path.splitext(parsed_url.path)[1]

    if not extension:
        extension = ".jpg"

    return extension


def get_mime_type(file_extension):
    """Return the MIME type for a given file extension."""
    # Normalize the file extension to ensure it starts with a dot
    if not file_extension.startswith("."):
        file_extension = "." + file_extension

    # Retrieve the MIME type from the dictionary, defaulting to 'application/octet-stream' if unknown
    return MIME_TYPES.get(file_extension.lower(), "application/octet-stream")


def upload_image_to_bucket(proposal_company_id, ad_id, image_url):
    if image_url is None or len(image_url) == 0:
        print("No FB image for ad", ad_id)
        new_image_url = None
        is_asset_error = True

        return new_image_url, is_asset_error

    else:
        # check for existing image first
        # if no existing image found, upload image
        new_image_url = _get_existing_image_gcs_url(
            list_blob(
                _IMAGE_STORAGE_BUCKET, prefix=f"{proposal_company_id}/", delimiter="/"
            ),
            proposal_company_id,
            ad_id,
        )

        if new_image_url is None:
            new_image_url = _upload_img_to_bucket(image_url, proposal_company_id, ad_id)

        # assign is_asset_error value
        is_asset_error = not new_image_url

        return new_image_url, is_asset_error


def process_image_url(original_image_url):
    # all ad formats need to have original_image_url and image_url fields in the payload
    # this function ensures the fields are standardised across all ad formats
    has_image_url = original_image_url is not None and original_image_url != ""

    return {
        "original_image_url": original_image_url,
        "image_url": original_image_url,
        "has_image_url": has_image_url,
    }


# TODO: review the logic here as there are multiple nested if and if-else
# sign of convoluted logic / structure
def upload_ads_images(proposal_company_id, channel):
    # filter for objects by proposal_company_id and platform
    records = json.loads(
        download_blob_into_string(
            _BUCKET, f"{proposal_company_id}/consolidated_{channel}.json"
        )
    )

    # filter for platform ads with image url that is valid
    _ads = [
        ad
        for ad in records
        if ad.get("platform") == channel
        and (ad.get("original_image_url", "") or ad.get("original_image_urls", []))
    ]

    if len(_ads) == 0:
        print("no ads with image url!")

        return []

    # filter and upload images that are not in bucket
    # at this point we have _ads with image urls
    obj_img_list = []
    for obj in _ads:
        ad_id = obj.get("ad_id", "")

        obj_img_dict = {}
        if obj["format"] in ("image_single", "video"):
            obj_img_dict["objectID"] = obj.get("objectID", "")
            new_image_url, is_asset_error = upload_image_to_bucket(
                proposal_company_id, ad_id, obj.get("original_image_url", "")
            )

            # process in dict for algolia
            if new_image_url:
                obj_img_dict["image_url"] = new_image_url
            else:
                obj_img_dict["is_asset_error"] = True

            if obj["format"] == "video":
                is_video_asset_error = obj.get("is_video_asset_error", False)
                if is_asset_error or is_video_asset_error:
                    obj_img_dict["is_asset_error"] = True

            obj_img_list.append(obj_img_dict)

        elif obj["format"] in ("image_carousel", "video_carousel"):
            obj_img_dict["objectID"] = obj.get("objectID", "")

            is_error_flags = 0
            for idx, s in enumerate(obj["slides"]):
                new_image_url, is_asset_error = upload_image_to_bucket(
                    proposal_company_id,
                    f"{ad_id}_{idx}",
                    s.get("original_image_url", ""),
                )

                if new_image_url:
                    s["image_url"] = new_image_url
                else:
                    is_error_flags += 1
                    continue

            # process in dict for algolia
            if is_error_flags > 0:
                obj_img_dict["is_asset_error"] = True

            elif obj["format"] == "video_carousel":
                is_video_asset_error = obj.get("is_video_asset_error", False)

                if is_video_asset_error:
                    obj_img_dict["is_asset_error"] = True
                else:
                    obj_img_dict["slides"] = obj["slides"]

            else:
                obj_img_dict["slides"] = obj["slides"]

            obj_img_list.append(obj_img_dict)

    return obj_img_list


if __name__ == "__main__":
    proposal_company_id = "test_competitor_klarify"
    channel = "meta_ads"

    out = upload_ads_images(proposal_company_id, channel)
    print("out: ", out)
