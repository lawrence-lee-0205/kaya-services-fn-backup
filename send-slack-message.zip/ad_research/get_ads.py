import json
import random

from setup import setup
from common import validate_inputs
from firestore import FirestoreClient
from storage.download_blob import download_blob_into_string

BUCKET = "kaya-ads-research"
_FS = FirestoreClient()


@setup
def research_get_ads(data: dict) -> dict:
    mandatory_fields = ["auth_user_id"]
    validate_inputs(data, mandatory_fields)

    if "page_number" in data and "is_random" in data:
        raise ValueError("page_number and is_random cannot be used together")

    if "proposal_company_id" in data:
        out = execute_single_company(**data)
    else:
        out = execute_all_companies(**data)
    return out


def _get_data_for_single_proposal_company(proposal_company_id):
    data = json.loads(
        download_blob_into_string(
            BUCKET, f"{proposal_company_id}/consolidated_ads.json"
        )
    )

    return data


def _filter_data(data, filters):
    for f in filters:
        field = f["field"]
        operator = f["operator"]
        value = f["value"]

        if operator == "eq":
            data = [d for d in data if d.get(field) == value]
        elif operator == "contains":
            data = [d for d in data if value in d.get(field)]
        elif operator == "gt":
            data = [d for d in data if d.get(field) > value]
        elif operator == "lt":
            data = [d for d in data if d.get(field) < value]
        elif operator == "gte":
            data = [d for d in data if d.get(field) >= value]
        elif operator == "lte":
            data = [d for d in data if d.get(field) <= value]
        else:
            raise ValueError(f"Operator {operator} not supported")
    return data


def distribute_random_elements(
    filtered_data_all_companies, total_items_to_return, total_items_across_companies
):
    lists = [lst for _, lst in filtered_data_all_companies.items()]
    # Create a final list to hold the elements
    final_list = []
    counts = [0] * len(lists)  # Track how many items we have taken from each list

    # Calculate initial ideal counts
    ideal_counts = [
        total_items_to_return * len(lst) // total_items_across_companies
        for lst in lists
    ]

    # Distribute elements
    while len(final_list) < total_items_to_return:
        # Iterate over each list and their ideal counts
        for i, (lst, ideal_count) in enumerate(zip(lists, ideal_counts)):
            # Check if we can take more items from this list
            print("here")
            while (
                counts[i] < ideal_count
                and len(lst) > 0
                and len(final_list) < total_items_to_return
            ):
                final_list.append(lst.pop(0))
                counts[i] += 1
            # Recalculate ideal counts dynamically based on remaining items and needed elements
            remaining_total = sum(len(lst) for lst in lists)
            remaining_needed = total_items_to_return - len(final_list)
            ideal_counts = [
                (
                    remaining_needed * len(lst) // remaining_total
                    if remaining_total > 0
                    else 0
                )
                for lst in lists
            ]

    return final_list


def execute_all_companies(proposal_id, **kwargs):
    p = _FS.get_single_document("proposal", proposal_id)
    proposal_company_ids = [p["proposal_company_id"]] + list(p["competitors"].values())
    num_companies = len(proposal_company_ids)

    filtered_data_all_companies = {}
    data_count_all_companies = {}
    total_num_before_filter = 0
    num_items_after_filter = 0
    for pcid in proposal_company_ids:
        try:
            # skip if no data
            data = _get_data_for_single_proposal_company(pcid)
        except Exception as e:
            print(e)
            continue

        total_num_before_filter += len(data)

        if "filters" in kwargs:
            filters = kwargs["filters"]
            """example filters = [
                {"field": "platform", "operator": "eq", "value": "linkedin_ads"},
                {"field": "tags", "operator": "contains", "value": ["is_longest_serving"]},
            ]
            """
            data = _filter_data(data, filters)
            num_items_after_filter += len(data)

            if "is_random" in kwargs and kwargs["is_random"]:
                random.shuffle(data)
        else:
            num_items_after_filter = total_num_before_filter

        data = [{"proposal_company_id": pcid, **d} for d in data]
        data_count_all_companies[pcid] = len(data)
        filtered_data_all_companies[pcid] = data

    if "page_number" in kwargs and "items_per_page" in kwargs:
        num_items_per_company = kwargs["items_per_page"] // num_companies
        page_number = kwargs["page_number"]

        data_for_single_page = []
        for _, data_i in filtered_data_all_companies.items():
            data_for_single_page += paginate_list(
                data_i, page_number, num_items_per_company
            )
        return {
            "items": data_for_single_page,
            "num_items": total_num_before_filter,
            "num_items_after_filter": num_items_after_filter,
        }
    elif (
        "items_per_page" in kwargs
        and "is_random" in kwargs
        and kwargs["is_random"]
        and num_items_after_filter > kwargs["items_per_page"]
    ):
        # want random values
        total_items_to_return = kwargs["items_per_page"]
        print(f"Returning random {total_items_to_return} items across all companies..")

        # randomised_data = distribute_random_elements(
        #     filtered_data_all_companies, total_items_to_return, num_items_after_filter
        # )
        all_ads = _get_data_all_companies(filtered_data_all_companies)
        randomised_data = random.sample(all_ads, total_items_to_return)
        return {
            "items": randomised_data,
            "num_items": total_num_before_filter,
            "num_items_after_filter": num_items_after_filter,
            "items_per_page": total_items_to_return,
        }
    else:
        print("Return all data..")
        # return all data
        all_data = _get_data_all_companies(filtered_data_all_companies)
        return {
            "items": all_data,
            "num_items": total_num_before_filter,
            "num_items_after_filter": num_items_after_filter,
        }


def _get_data_all_companies(filtered_data_all_companies):
    all_data = []
    for _, data_i in filtered_data_all_companies.items():
        all_data += data_i
    return all_data


def execute_single_company(proposal_company_id, **kwargs):
    output = {}
    data = _get_data_for_single_proposal_company(proposal_company_id)
    output["num_items"] = len(data)

    if "filters" in kwargs:
        filters = kwargs["filters"]
        """example filters = [
            {"field": "platform", "operator": "eq", "value": "linkedin_ads"},
            {"field": "tags", "operator": "contains", "value": ["is_longest_serving"]},
        ]
        """
        data = _filter_data(data, filters)
        output["num_items_after_filter"] = len(data)

    data = [{"proposal_company_id": proposal_company_id, **d} for d in data]

    if "is_random" in kwargs and kwargs["is_random"]:
        random.shuffle(data)

        if "items_per_page" in kwargs:
            items_per_page = kwargs["items_per_page"]
            print(f"Returning random {kwargs['items_per_page']} items..")
            output["items"] = data[:items_per_page]
            output["items_per_page"] = items_per_page
            return output
        else:
            print(f"Returning all items in randomised order..")
            output["items"] = data
            return output

    if "page_number" in kwargs and "items_per_page" in kwargs:
        page_number = kwargs["page_number"]
        items_per_page = kwargs["items_per_page"]

        last_page_number = output["num_items"] // items_per_page + 1

        data = paginate_list(data, page_number, items_per_page)

        output["next_page_number"] = (
            page_number + 1 if page_number < last_page_number else None
        )
        output["current_page_number"] = page_number
        output["items_per_page"] = items_per_page

    output["items"] = data
    return output


def paginate_list(items, page, per_page):
    """
    Paginate a list of items.
    :param items: List of items to paginate.
    :param page: Current page number (1-indexed).
    :param per_page: Number of items per page.
    :return: A slice of the list representing the requested page.
    """
    start = (page - 1) * per_page
    end = start + per_page
    return items[start:end]


if __name__ == "__main__":
    data = {
        "proposal_id": "Z9ED7j0E86Got8K4tJvJ",
        "items_per_page": 100,
        "filters": [],
        "is_random": True,
    }
    if "page_number" in data and "is_random" in data:
        raise ValueError("page_number and is_random cannot be used together")

    if "proposal_company_id" in data:
        out = execute_single_company(**data)
    else:
        out = execute_all_companies(**data)

    print(out)


# def execute(business_id, **kwargs):
#     mock = [
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "image_single",
#             "landing_page_url": "https://view.rippling.com/viewer/65d7c18e30ce4f2bef507215",
#             "headline": "Slash operations costs using Rippling",
#             "image_url": "https://media.licdn.com/dms/image/C4D10AQE8GydyeOvpNA/image-shrink_1280/0/1678137941477/u-forrester-tei-v1-1x1png?e=2147483647&v=beta&t=dKNpCgEtoKRDmL0WiRRdh4DeU9pVyMNdCPcvy2BXx3k",
#             "ctas": ["Learn more"],
#             "advertiser_name": "Rippling",
#             "body": "Drive ROI using Rippling. Automate the manual HR, payroll, & IT ops work and focus your team on growing the business.",
#             "ad_id": "381555533",
#             "advertiser_social_url": "https://www.linkedin.com/company/17988315",
#             "is_featured": True,
#             "tags": ["is_longest_serving", "is_shortest_serving"],
#         },
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "image_single",
#             "landing_page_url": "https://culture-rh.com/indicateurs-rh-2024-kpis",
#             "headline": "T\u00e9l\u00e9charger maintenant: Les indicateurs RH Cl\u00e9s en 2024",
#             "image_url": "https://media.licdn.com/dms/image/D4D10AQF5SxzPnaVqoA/image-shrink_1280/0/1711492298763/032124_CultureRHBook_Promotion_V2_Imagepng?e=2147483647&v=beta&t=B2oVnm4VAzcwAAmjK1zeZz46v5YcWS60NBVhSUk2eoM",
#             "ctas": ["Download"],
#             "advertiser_social_url": "https://www.linkedin.com/company/17988315",
#             "metrics": [{"name": "impressions", "values": "1k-5k"}],
#             "audience_targeting": {"language": "English", "location": "France"},
#             "first_seen": "2024-03-31",
#             "last_seen": "2024-03-27",
#             "days_active": 10,
#             "advertiser_name": "Rippling",
#             "body": "40% des responsables RH se disent mal \u00e0 l'aise avec l'utilisation des KPI pour g\u00e9rer leurs op\u00e9rations\u2026 heureusement nous sommes l\u00e0 pour vous aider \ud83d\udcca\n\nNous avons collabor\u00e9 avec @Culture RH pour cr\u00e9er un ebook qui couvre la valeur des KPI, les principaux indicateurs \u00e0 garder \u00e0 l'esprit, et des conseils pour tout g\u00e9rer \ud83d\udc47",
#             "ad_id": "385352693",
#             "is_featured": True,
#             "tags": ["is_longest_serving", "is_shortest_serving"],
#         },
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "video",
#             "landing_page_url": "https://www.rippling.com/en-GB/global",
#             "video_url": "https://dms.licdn.com/playlist/vid/D4D10AQF9xivfISimlw/progressive-servable-video/0/1690935181306/Rippling_OnePlace_Thirty-logo_30_16x9_24fps_webmp4?e=2147483647&v=beta&t=9tBxyo131u1f4CjlHnHbNTayjx0gU4e0RjCagA_HvY4",
#             "headline": "Global HR, IT, & Finance | Rippling",
#             "ctas": ["Learn more"],
#             "advertiser_name": "Rippling",
#             "body": "Scaling your workforce around the world? Rippling gives you one place to run your HR, IT, and Finance. Globally.",
#             "ad_id": "380021933",
#             "advertiser_social_url": "https://www.linkedin.com/company/17988315",
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "image_carousel",
#             "advertiser_social_url": "https://www.linkedin.com/company/17988315",
#             "landing_page_url": "",
#             "ctas": [],
#             "advertiser_name": "Rippling",
#             "body": "Drive ROI using Rippling. Automate the manual HR, payroll, & IT ops work and focus your team on growing the business.",
#             "ad_id": "381678633",
#             "slides": [
#                 {
#                     "image_url": "https://media.licdn.com/dms/image/D4D1DAQHf0hEhVcbldQ/ssu-carousel-card-image_lax_1200_1200/0/1709840301823?e=1712674800&v=beta&t=g7n20ZlbxoLm1TRjAhCk2wGwRz1iJF-cjanRy-KkAG4"
#                 },
#                 {
#                     "image_url": "https://media.licdn.com/dms/image/D4D1DAQFoMKM71n743Q/ssu-carousel-card-image_lax_1200_1200/0/1709840301845?e=1712674800&v=beta&t=yD6KoZkF_NdN0oZ_bod8URQivDmS49QYcpfDR5y6LUE"
#                 },
#             ],
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "message",
#             "landing_page_url": "",
#             "ctas": [],
#             "advertiser_name": "Rippling",
#             "body": "Hi %FIRSTNAME% - As %JOBTITLE%, I know you want to focus on building your business and spend less time on annoying busywork like payroll and tax compliance.\u00a0\n\nI work at Rippling, and our platform helps companies automate their payroll, tax calculations, benefits admin, and much more. Companies that use Rippling free up over 30 hours/month (& save money by consolidating software costs, too). That\u2019s why USA Today named us the best overall Payroll Software for 2024.\n\nAny interest in learning more? I\u2019ll send you a $100 gift card to Amazon or donation via CharityChoice after for your time.",
#             "advertiser_social_url": "https://www.linkedin.com/company/17988315",
#             "ad_id": "382100093",
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "video",
#             "utms": {
#                 "source": "linkedin",
#                 "medium": "paid_social",
#                 "campaign": "rl_emea_video_views",
#                 "content": "rl_1223_emea_video_views_pt_b2c_ecomm_invv2",
#                 "term": "15s_16:9_paidsocial_algoliabythenumbers_EN",
#             },
#             "metrics": [
#                 {"name": "impressions", "values": "1k-5k"},
#                 {
#                     "name": "impressions_breakdown_by_country",
#                     "values": [
#                         {"impressions": "21%", "country": "United Arab Emirates"},
#                         {"impressions": "10%", "country": "France"},
#                         {"impressions": "10%", "country": "United Kingdom"},
#                         {"impressions": "7%", "country": "Singapore"},
#                         {"impressions": "6%", "country": "Netherlands"},
#                         {"impressions": "6%", "country": "Spain"},
#                         {"impressions": "5%", "country": "Hong Kong SAR China"},
#                         {"impressions": "5%", "country": "Italy"},
#                         {"impressions": "4%", "country": "Japan"},
#                         {"impressions": "4%", "country": "Sweden"},
#                         {"impressions": "4%", "country": "Germany"},
#                         {"impressions": "4%", "country": "Denmark"},
#                         {"impressions": "4%", "country": "Finland"},
#                         {"impressions": "3%", "country": "Switzerland"},
#                         {"impressions": "2%", "country": "Belgium"},
#                         {"impressions": "2%", "country": "Ireland"},
#                         {"impressions": "1%", "country": "Austria"},
#                         {"impressions": "1%", "country": "Norway"},
#                         {"impressions": "1%", "country": "Luxembourg"},
#                     ],
#                 },
#             ],
#             "landing_page_url": "https://www.algolia.com/",
#             "video_url": "https://dms.licdn.com/playlist/vid/D4E10AQFqzxu0_vG3kw/progressive-servable-video/0/1711146810757/15s_169_paidsocial_algoliabythenumbers_ENmp4?e=2147483647&v=beta&t=Xy-XhyMwfjUOFIL48k75OfCycRNBGN476seh_CDdQKc",
#             "headline": "Trust Algolia AI Search to boost ROI",
#             "ctas": ["Learn more"],
#             "advertiser_social_url": "https://www.linkedin.com/company/2728700",
#             "audience_targeting": {
#                 "language": "English",
#                 "location": "Hong Kong SAR, Italy and France, Sweden, Luxembourg, Ireland, United Arab Emirates, Belgium, Norway, Spain, Finland, Germany, Switzerland, Netherlands, Denmark, Singapore, Austria, Japan, United Kingdom",
#             },
#             "first_seen": "2024-03-26",
#             "last_seen": "2024-03-23",
#             "days_active": 10,
#             "advertiser_name": "Algolia",
#             "body": "1.75 trillion search requests a year; 99.999% API uptime \u2014 the numbers speak for themselves.",
#             "ad_id": "382208974",
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "platform": "google_ads",
#             "channels": ["display"],
#             "format": "image_single",
#             "image_url": "https://tpc.googlesyndication.com/archive/simgad/8746796160851054669",
#             "ad_id": "CR05167262543793618945",
#             "advertiser_social_id": "AR08372371271274463233",
#             "landing_page_url": "rippling.com",
#             "advertiser_name": "People Center INC",
#             "first_seen": "2024-01-28",
#             "last_seen": "2024-02-07",
#             "days_active": 10,
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "platform": "google_ads",
#             "channels": ["search"],
#             "format": "text",
#             "advertiser_social_id": "AR17828074650563772417",
#             "advertiser_name": "Tesla Inc.",
#             "ad_creative_id": "CR04179139827687489537",
#             "image_url": "https://tpc.googlesyndication.com/archive/simgad/11385273875406013460",
#             "image_width": 380,
#             "image_height": 239,
#             "first_seen": "2024-01-28",
#             "last_seen": "2024-02-07",
#             "days_active": 10,
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "platform": "google_ads",
#             "channels": ["display"],
#             "format": "image_single",
#             "image_url": "https://tpc.googlesyndication.com/archive/simgad/1988871679457668088",
#             "ad_id": "CR18127038974621908993",
#             "advertiser_social_id": "AR08372371271274463233",
#             "landing_page_url": "rippling.com",
#             "advertiser_name": "People Center INC",
#             "first_seen": "2024-01-28",
#             "last_seen": "2024-02-06",
#             "days_active": 8,
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "platform": "meta_ads",
#             "channels": ["facebook", "instagram"],
#             "format": "image_single",
#             "video_hd_url": "",
#             "link_description": "",
#             "metrics": [
#                 {"name": "spend", "values": "1k-5k"},
#                 {"name": "impressions", "values": "1k-5k"},
#                 {"name": "reach_estimate", "values": "1k-5k"},
#             ],
#             "watermarked_video_sd_url": "",
#             "landing_page_url": "https://www.algolia.com/search-audit/?utm_source=facebook&utm_medium=paid_social&utm_campaign=rl_emea_gated_offer_clicks&utm_content=rl_1223_emea_gated_offer_clicks_rt_b2c_ecomm&utm_term=rt_searchaudit_recommendations&utm_camp_parent=b2c_ecomm&utm_model=cpc&utm_region=emea&utm_goal=eng&utm_ag=rl",
#             "utms": {
#                 "source": "facebook",
#                 "medium": "paid_social",
#                 "campaign": "rl_emea_gated_offer_clicks",
#                 "content": "rl_1223_emea_gated_offer_clicks_rt_b2c_ecomm",
#                 "term": "rt_searchaudit_recommendations",
#             },
#             "ctas": ["Learn more"],
#             "video_url": "",
#             "caption": "",
#             "original_image_url": "https://scontent-ord5-1.xx.fbcdn.net/v/t39.35426-6/406798374_374439755024268_2303847608609559114_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=vZOO66oBfUYAX_5LMQT&_nc_ht=scontent-ord5-1.xx&oh=00_AfBegzAGWk7YOQTycK44xTZkEvkqr_OaNNXIzCqx7jVi2Q&oe=6609E0EC",
#             "watermarked_video_hd_url": "",
#             "ad_id": "6507833872529",
#             "watermarked_resized_image_url": "",
#             "image_url": "https://scontent-ord5-2.xx.fbcdn.net/v/t39.35426-6/406741539_1080261566545927_7129674993827938437_n.jpg?stp=dst-jpg_s600x600&_nc_cat=104&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=u08grnwZg80AX9SUswv&_nc_ht=scontent-ord5-2.xx&oh=00_AfBr31cZOdpjG366fIa4RDIvGawqsOPe9kJn5zi7TRa2UA&oe=6609B6C3",
#             "ad_library_page_targeting_insight": "",
#             "headline": "Discover missed opportunities",
#             "video_preview_image_url": "",
#             "image_crops": "",
#             "body": "Whether you\u2019re looking to improve conversions or reduce bounce rate, we can help identify gaps in your site search strategy.",
#             "first_seen": "2024-02-15",
#             "last_seen": "2024-03-27",
#             "is_featured": False,
#             "tags": [],
#         },
#         {
#             "ad_id": "120208403657520577",
#             "platform": "meta_ads",
#             "channels": ["facebook", "instagram"],
#             "format": "image_carousel",
#             "slides": [
#                 {
#                     "body": "Lower your risk and costs while expanding into new global markets with a single, centralized platform for your whole team.",
#                     "caption": "deel.com",
#                     "ctas": ["Learn more"],
#                     "headline": "Onboard global talent in minutes",
#                     "link_description": "",
#                     "landing_page_url": "https://www.deel.com/case-studies/nium",
#                     "original_image_url": "https://scontent-iad3-1.xx.fbcdn.net/v/t39.35426-6/435107300_282900064759029_4152858345181332831_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=RnL6dlM_5dMAb6auqmc&_nc_ht=scontent-iad3-1.xx&oh=00_AfClThrKbhCO0b1V5VPrwmzTOIHGFvs1_lszv8UzpQlydw&oe=66189757",
#                     "image_url": "https://scontent-iad3-1.xx.fbcdn.net/v/t39.35426-6/435240394_942628754258080_4703204764981091323_n.jpg?stp=dst-jpg_s600x600&_nc_cat=107&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=d5fPe1XMafgAb7MfUFa&_nc_ht=scontent-iad3-1.xx&oh=00_AfCoLWVqJd4-KHn2jtL-gn1iqA6EfPSzmxSAAMD6Hpm1OA&oe=66189CBB",
#                     "video_hd_url": "",
#                     "video_url": "",
#                     "video_preview_image_url": "",
#                 },
#                 {
#                     "body": "Lower your risk and costs while expanding into new global markets with a single, centralized platform for your whole team.",
#                     "caption": "deel.com",
#                     "ctas": ["Learn more"],
#                     "headline": "Onboard global talent in minutes",
#                     "link_description": "",
#                     "landing_page_url": "https://www.deel.com/case-studies/nium",
#                     "original_image_url": "https://scontent-iad3-1.xx.fbcdn.net/v/t39.35426-6/435107300_282900064759029_4152858345181332831_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=RnL6dlM_5dMAb6auqmc&_nc_ht=scontent-iad3-1.xx&oh=00_AfClThrKbhCO0b1V5VPrwmzTOIHGFvs1_lszv8UzpQlydw&oe=66189757",
#                     "image_url": "https://scontent-iad3-1.xx.fbcdn.net/v/t39.35426-6/435240394_942628754258080_4703204764981091323_n.jpg?stp=dst-jpg_s600x600&_nc_cat=107&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=d5fPe1XMafgAb7MfUFa&_nc_ht=scontent-iad3-1.xx&oh=00_AfCoLWVqJd4-KHn2jtL-gn1iqA6EfPSzmxSAAMD6Hpm1OA&oe=66189CBB",
#                     "video_hd_url": "",
#                     "video_url": "",
#                     "video_preview_image_url": "",
#                 },
#             ],
#             "caption": "deel.com",
#             "ctas": ["Learn more"],
#             "metrics": [
#                 {"name": "spend", "values": "1k-5k"},
#                 {"name": "impressions", "values": "1k-5k"},
#                 {"name": "reach_estimate", "values": "1k-5k"},
#             ],
#             "channels": ["facebook", "instagram", "audience_network", "messenger"],
#             "last_seen": "2024-04-07",
#             "first_seen": "2024-04-06",
#         },
#         {
#             "platform": "meta_ads",
#             "format": "video",
#             "ad_id": "120204468273320577",
#             "first_seen": "2024-03-19",
#             "channels": ["facebook", "instagram", "audience_network", "messenger"],
#             "metrics": [
#                 {"name": "spend", "values": "1k-5k"},
#                 {"name": "impressions", "values": "1k-5k"},
#                 {"name": "reach_estimate", "values": "1k-5k"},
#             ],
#             "last_seen": "2024-04-06",
#             "headline": "Global payroll and HR for teams today",
#             "body": "Deel's one global platform for HR, payroll, employees, contractors, immigration, and so much more.",
#             "caption": "deel.com",
#             "ctas": ["Learn More"],
#             "link_description": "Get well-researched answers to hiring questions, dig deeper into workforce data, and make smarter business decisions fast with Deel IQ.",
#             "landing_page_url": "https://www.deel.com/",
#             "original_image_url": "",
#             "image_url": "",
#             "video_hd_url": "https://video-dfw5-2.xx.fbcdn.net/v/t42.1790-2/418103724_370557998763581_4660245427756984430_n.?_nc_cat=100&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=PGgtohAZMpIAb6zAiKb&_nc_ht=video-dfw5-2.xx&oh=00_AfCf1aqPhGp7Sj7clnTy-wXh61DWUAjOEayyFauIleX-9A&oe=66189ACE",
#             "video_url": "https://video-dfw5-2.xx.fbcdn.net/v/t42.1790-2/416174367_1511415899624696_1843017294872695293_n.mp4?_nc_cat=106&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=rcK1AhZUH1cAb50ofDB&_nc_ht=video-dfw5-2.xx&oh=00_AfB-KxtS0VY1C90KdG1RbnKDj0AFh-NyqL9mIl7y7cG3AA&oe=66189D46",
#             "video_preview_image_url": "https://scontent-dfw5-1.xx.fbcdn.net/v/t39.35426-6/418499711_1728282597679102_697218207066217137_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=zKsdTACEZa8Ab7jHTYv&_nc_ht=scontent-dfw5-1.xx&oh=00_AfAHzvEfkAFAn_213FT-vOZTbxSuTVp7AvLOancyXOVmqw&oe=661896B4",
#         },
#         {
#             "platform": "meta_ads",
#             "format": "document",
#             "metrics": [
#                 {"name": "spend", "values": "1k-5k"},
#                 {"name": "impressions", "values": "1k-5k"},
#                 {"name": "reach_estimate", "values": "1k-5k"},
#             ],
#             "ad_id": "120208031229440577",
#             "first_seen": "2024-03-28",
#             "channels": ["facebook", "instagram", "audience_network", "messenger"],
#             "last_seen": "2024-04-07",
#             "body": "Interested in how your team could benefit from using a single global payroll provider? Explore advantages with this free resource from Deel. We\u2019ll cover why companies consolidate their payroll (and when it makes sense to), key considerations to make, provider comparisons, and more.",
#             "caption": "deel.com",
#             "ctas": ["Download"],
#             "headline": "The case for global payroll consolidation | Get the guide",
#             "link_description": "",
#             "landing_page_url": "https://www.deel.com/resources/global-payroll-consolidation",
#             "original_image_url": "https://scontent-ord5-2.xx.fbcdn.net/v/t39.35426-6/434295506_351618977798701_269020222249479810_n.jpg?_nc_cat=102&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=CcajeN9U4XIAb7Bubty&_nc_ht=scontent-ord5-2.xx&oh=00_AfAakOQwcoN2mvvqNb1kSipKEVXOqMNW1kq56w-RVebujA&oe=6618A743",
#             "image_url": "https://scontent-ord5-1.xx.fbcdn.net/v/t39.35426-6/433194565_949828253354641_7843604654607702238_n.jpg?stp=dst-jpg_s600x600&_nc_cat=109&ccb=1-7&_nc_sid=c53f8f&_nc_ohc=WXtMN2zIpxQAb6kVeCh&_nc_ht=scontent-ord5-1.xx&oh=00_AfAq5T-DQHGgtEb3RSXticoNnOEzLCidPfiNnXxAt57PjQ&oe=6618AB95",
#             "video_hd_url": "",
#             "video_url": "",
#             "video_preview_image_url": "",
#         },
#         {
#             "platform": "google_ads",
#             "channels": ["youtube"],
#             "format": "video",
#             "image_single": "",
#             "ad_id": "CR09132590618789281793",
#             "video_url": "https://i.ytimg.com/vi/HYCbB_EypBQ/hqdefault.jpg",
#             "advertiser_social_id": "AR16241592552661188609",
#             "last_seen": "2023-10-31",
#             "landing_page_url": "algolia.com",
#             "advertiser": "ALGOLIA INC",
#             "first_seen": "2023-09-30",
#             "days_active": 31,
#             "is_featured": True,
#             "tags": [],
#         },
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "document",
#             "metrics": [
#                 {"name": "spend", "values": "1k-5k"},
#                 {"name": "impressions", "values": "1k-5k"},
#                 {
#                     "name": "impressions_breakdown_by_country",
#                     "values": [
#                         {"impressions": "82%", "country": "United Kingdom"},
#                         {"impressions": "18%", "country": "Ireland"},
#                     ],
#                 },
#             ],
#             "landing_page_url": "",
#             "headline": "The state of global payroll in 2024 | Download now",
#             "ctas": [],
#             "image_urls": [
#                 "https://media.licdn.com/dms/image/D4D10AQEjpI1qUBy3Jw/ads-document-images_1920/1/1711555566231?e=1712793600&v=beta&t=d_pdwfQ2G-RPQ11p1AigCc0yBDiuJL6EX-moVogPnek"
#             ],
#             "advertiser_social_url": "https://www.linkedin.com/company/18922914",
#             "document_url": "https://media.licdn.com/dms/document/media/D4D10AQEjpI1qUBy3Jw/document-sliced-pdf_multiton/B4DY6AtbYJGwAQ-/0/1711556376290?e=1712793600&v=beta&t=qjhM3-CDxVewWP1zMlXedMyCb7-_YBSELoy7T_QRfjk",
#             "format": "document",
#             "audience_targeting": {
#                 "language": "English",
#                 "location": "Ireland, United Kingdom",
#             },
#             "last_seen": "2024-03-31",
#             "first_seen": "2024-03-27",
#             "days_active": 10,
#             "advertiser_name": "Deel",
#             "body": "Forrester surveyed payroll professionals to better understand today\u2019s global payroll systems. Get the study to explore:\n\n- Fragmented vs. unified global payroll\n- The hidden costs of scattered payroll\n- Inconsistent employee experiences\n",
#             "ad_id": "385551373",
#             "is_featured": True,
#             "tags": ["industry_report"],
#         },
#         {
#             "platform": "linkedin_ads",
#             "channels": ["linkedin"],
#             "format": "text",
#             "metrics": [{"name": "impressions", "values": "1k-5k"}],
#             "landing_page_url": "",
#             "ctas": [],
#             "last_seen": "2024-03-31",
#             "first_seen": "2024-02-21",
#             "audience_targeting": {
#                 "language": "English",
#                 "location": "Italy, France and Sweden, Ireland, Belgium, Norway, Spain, Portugal, Finland, Germany, Switzerland, Netherlands, Denmark, United Kingdom",
#             },
#             "advertiser_name": "Deel",
#             "advertiser_social_url": "https://www.linkedin.com/company/18922914",
#             "ad_id": "364951653",
#             "is_featured": True,
#             "tags": [],
#         },
#     ]
#     return mock
