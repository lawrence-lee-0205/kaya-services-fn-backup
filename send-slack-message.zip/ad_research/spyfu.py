from os import environ

from utils.request import call_api


def _query_spyfu_ads_copies_api(domain, country, num_ads=10):
    is_us = "true" if country == "US" else "false"

    spyfu = f"https://www.spyfu.com/apis/ad_history_api/domain_ad_history_json?d={domain}&r={num_ads}&s=0&isUs={is_us}&api_key={environ['SPYFU_API_KEY']}"
    spyfu_output = call_api(spyfu)
    return spyfu_output


def get_spyfu_gads_copies(domain, country):
    spyfu_output = _query_spyfu_ads_copies_api(domain, country)
    if len(spyfu_output) == 0:
        return {}
    return spyfu_output


def get_spyfu_gads_keywords(
    domain, country, spyfu_terms_to_search=None, spyfu_incl_any=None
):
    # acceptable country list: https://www.spyfu.com/api/v2#?route=get-/apis/keyword_api/v2/ppc/getMostSuccessful
    _country = "UK" if country == "GB" else country
    print("Getting data from spyfu for country ", country)
    num_spyfu_rows = 150

    spyfu = f"https://www.spyfu.com/apis/keyword_api/v2/ppc/getMostSuccessful?query={domain}&sortBy=TotalMonthlyClicks&sortOrder=Descending&startingRow=1&countryCode={_country}&adultFilter=true&pageSize={num_spyfu_rows}&api_key={environ['SPYFU_API_KEY']}&sortBy=SearchVolume&sortOrder=Descending"
    if spyfu_terms_to_search and len(spyfu_terms_to_search) > 0:
        spyfu += f"&includeTerms={spyfu_terms_to_search}"
    if spyfu_incl_any:
        spyfu += f"&includeAnyTerm={spyfu_incl_any}"

    spyfu += "&excludeTerms=intext&searchVolume.min=10"
    spyfu_output = call_api(spyfu)["results"]

    if len(spyfu_output) == 0:
        return {}
    return spyfu_output


if __name__ == "__main__":
    domain = "dailybot.com"
    country = "us"
    out = get_spyfu_gads_copies(domain, country)

    print("out: ", out)
