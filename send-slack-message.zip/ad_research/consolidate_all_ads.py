from firestore import FirestoreClient
from common import validate_inputs
from http_function import http_function, process_request_inputs

from ad_research.proposal_company import ProposalCompany

from ad_research.ad_utils import write_json_to_bucket

from ad_research.get_google_ads import execute_get_google_ads
from ad_research.get_meta_ads import execute_get_meta_ads
from ad_research.get_tiktok_ads import execute_get_tiktok_ads
from ad_research.get_bing_ads import execute_get_bing_ads
from ad_research.get_linkedin_ads import execute_get_linkedin_ads

from ad_research.standardise_meta_ads import process_meta_ads
from ad_research.standardise_google_ads import process_google_ads
from ad_research.standardise_linkedin_ads import process_linkedin_ads
from ad_research.standardise_tiktok_ads import process_tiktok_ads
from ad_research.standardise_bing_ads import process_bing_ads

_FS = FirestoreClient()

_GET_ADS_FUNC_MAPPING = {
    "google_ads": execute_get_google_ads,
    "meta_ads": execute_get_meta_ads,
    "linkedin_ads": execute_get_linkedin_ads,
    "tiktok_ads": execute_get_tiktok_ads,
    "bing_ads": execute_get_bing_ads,
}

_PROCESS_ADS_FUNC_MAPPING = {
    "google_ads": process_google_ads,
    "meta_ads": process_meta_ads,
    "linkedin_ads": process_linkedin_ads,
    "tiktok_ads": process_tiktok_ads,
    "bing_ads": process_bing_ads,
}


@http_function
def research_process_ads(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "proposal_id", "channel"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    res = process_ads(
        proposal_company_id=data["proposal_company_id"],
        proposal_id=data["proposal_id"],
        channel=data["channel"],
    )
    return res


def consolidate_all_companies(proposal_id):
    p = _FS.get_single_document("proposal", proposal_id)
    proposal_company_ids = [p["proposal_company_id"]] + list(p["competitors"].values())

    for pc_id in proposal_company_ids:
        print("Processing ", pc_id)
        consolidate_single_company(pc_id, proposal_id)
    return None


def consolidate_single_company(proposal_company_id, proposal_id):
    proposal_company = ProposalCompany(proposal_company_id, proposal_id)

    all_ads = []
    for ch, payload in proposal_company.all_ads_by_channel.items():
        # try:
        print("Processing ", ch)

        all_ads += _PROCESS_ADS_FUNC_MAPPING[ch](
            payload,
            proposal_company_id=proposal_company_id,
            proposal_id=proposal_id,
        )
        print("Done\n\n")
        # except Exception as e:
        #     print(e)

    # add data to each ad
    for ad in all_ads:
        ad["business_name"] = proposal_company.business_name
        ad["domain"] = proposal_company.domain
        ad["industry"] = proposal_company.industry
        ad["sub_industry"] = proposal_company.sub_industry
        ad["description"] = proposal_company.description
        ad["tags"] = proposal_company.tags

    print(len(all_ads))

    write_json_to_bucket(proposal_company_id, f"consolidated_ads", all_ads)

    return None


def process_ads(proposal_company_id, proposal_id, channel):
    proposal_company = ProposalCompany(proposal_company_id, proposal_id)

    payload = proposal_company.all_ads_by_channel.get(channel)

    all_ads = []
    all_ads += _PROCESS_ADS_FUNC_MAPPING[channel](
        payload,
        proposal_company_id=proposal_company_id,
        proposal_id=proposal_id,
    )
    print("Done\n\n")

    # add data to each ad
    for ad in all_ads:
        ad["business_name"] = proposal_company.business_name
        ad["domain"] = proposal_company.domain
        ad["industry"] = proposal_company.industry
        ad["sub_industry"] = proposal_company.sub_industry
        ad["description"] = proposal_company.description
        ad["tags"] = proposal_company.tags

    print(len(all_ads))

    write_json_to_bucket(proposal_company_id, f"consolidated_{channel}", all_ads)

    return {"status": "success", f"processed_{channel}": True}


def get_and_process_ads(proposal_company_id, proposal_id, channel, env="dev"):
    try:
        # get ads
        channel_params = {}
        if channel == "google_ads":
            channel_params = {
                "spyfu_terms_to_search": None,
                "spyfu_incl_any": None,
            }

        get_ads_res = _GET_ADS_FUNC_MAPPING[channel](proposal_company_id, env, **channel_params)

        print(f"Get {channel}:", get_ads_res)

        # process ads
        process_ads_res = process_ads(proposal_company_id, proposal_id, channel)
        print(f"Process {channel}:", process_ads_res)

    except Exception as e:
        print(f"Error retrieving '{channel}': {e}")
        return {}

    return {"status": "success", f"get_and_process_{channel}": True}


# if __name__ == "__main__":
# proposal_id = "25rsMXf1R7KrQYTQRGYO"
# consolidate_all_companies(proposal_id)

# if __name__ == "__main__":
#     proposal_id = "testproposal"
#     proposal_company_id = "test_competitor_everlywell"
#     consolidate_single_company(proposal_company_id, proposal_id)

# if __name__ == "__main__":
#     proposal_company_id = "testleadcompany"
#     proposal_id = "testproposal"
#     channel = "linkedin_ads"
#     ad_library_url = (
#         "https://www.linkedin.com/ad-library/search?accountOwner=duolingo&countries=US"
#     )
#     params = {channel: ad_library_url}
#     env = "prod"

#     get_and_process_ads(proposal_company_id, proposal_id, channel, params, env)

if __name__ == "__main__":
    proposal_company_id = "testleadcompany"
    proposal_id = "testproposal"
    channel = "bing_ads"
    env = "dev"

    get_and_process_ads(proposal_company_id, proposal_id, channel, env)
