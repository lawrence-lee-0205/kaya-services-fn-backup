import pandas as pd
from dateutil.relativedelta import relativedelta
from storage.upload_blob import upload_blob



def count_max_active_ads_per_month(df, **kwargs):
    # Create a monthly date range from the minimum start_date to maximum end_date
    start_min = df['first_seen_dt'].min()
    end_max = df['last_seen_dt'].max()

    # Create a date object for the first day of start_date and end_date month
    start_min_month = start_min.replace(day=1)
    end_max_month = end_max.replace(day=1)

    months = pd.date_range(start=start_min_month, end=end_max_month, freq='MS')

    # Initialize a dictionary to hold the count of active ads for each month
    active_ads_count = {month.strftime('%Y-%m'): 0 for month in months}

    # Check each ad against each month
    active_ads_count = []
    for month in months:
        month_end = month + pd.offsets.MonthEnd()
        active_ads_df = df[(df['first_seen_dt'] <= month_end) & (df['last_seen_dt'] >= month)]
        
        if len(active_ads_df) > 0:
            # if in a given month, we saw ads that have definite first and last seen (ie probability = 1), assign probability = 1
            active_ads_probability = active_ads_df['probability'].max()
            
            active_ads_count.append(
                {'month': month.strftime('%Y-%m'), 'count': active_ads_df.shape[0], 'probability': active_ads_probability, **kwargs}
            )

    return active_ads_count


def count_active_ads_per_month(df, **kwargs):
    # Create a monthly date range from the minimum start_date to maximum end_date
    start_min = df['first_seen_dt'].min()
    end_max = df['last_seen_dt'].max()

    # Create a date object for the first day of start_date and end_date month
    start_min_month = start_min.replace(day=1)
    end_max_month = end_max.replace(day=1)

    months = pd.date_range(start=start_min_month, end=end_max_month, freq='MS')

    # Check each ad against each month
    active_ads_count = []
    for month in months:
        month_end = month + pd.offsets.MonthEnd()
        active_ads_df = df[(df['first_seen_dt'] <= month_end) & (df['last_seen_dt'] >= month)]
        if len(active_ads_df) > 0:
            # if in a given month, we saw most ads that have definite first and last seen (ie probability = 1), assign probability = 1
            # alternatively, if most first and last seen are imputed due to unavailable data (ie probability = 0.5), probability = 0.5
            active_ads_probability = active_ads_df['probability'].mode()[0]

            count = df.apply(
                lambda x: x['first_seen_dt'] <= month_end and x['last_seen_dt'] >= month, axis=1
            ).sum()

            active_ads_count.append({'month': month.strftime('%Y-%m'), 'count': count, 'probability': active_ads_probability, **kwargs})

    return active_ads_count


def months_between_dates(start_date, end_date):
    """
    Generate a DataFrame with a row for each month between two dates.
    
    Parameters:
    - start_date (str): The start date in "YYYY-MM-DD" format.
    - end_date (str): The end date in "YYYY-MM-DD" format.
    
    Returns:
    - pd.DataFrame: A DataFrame with a single column, 'Month', listing months between the start and end date.
    """
    start = pd.to_datetime(start_date)
    end = pd.to_datetime(end_date)
    
    # Generate the month range
    total_months = lambda dt: dt.month + 12 * dt.year
    months = [start + relativedelta(months=+i) for i in range(total_months(end) - total_months(start) + 1)]
    
    # Format the months and create the DataFrame
    months_str = [dt.strftime('%Y-%m') for dt in months]
    df = pd.DataFrame(months_str, columns=['month'])
    
    return df


def get_index_with_highest_value(df, column_name):
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' does not exist in the DataFrame")

    try:
        return df[column_name].idxmax()
    except TypeError:
        df[column_name] = df[column_name].astype(float)
        return df[column_name].idxmax()


def get_index_with_lowest_value(df, column_name):
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' does not exist in the DataFrame")

    try:
        return df[column_name].idxmax()
    except TypeError:
        df[column_name] = df[column_name].astype(float)
        return df[column_name].idxmax()


def save_and_upload_fig(fig, filename_with_ext, proposal_id, proposal_company_id, _image_bucket):
    fig.write_image(filename_with_ext)

    filename = filename_with_ext.replace('/tmp/', '')

    storage_url = upload_blob(
        _image_bucket, 
        source_file_name=filename_with_ext, 
        destination_blob_name=f"proposal/{proposal_id}/{proposal_company_id}/{filename}", 
        is_public=True
    )
    return storage_url
