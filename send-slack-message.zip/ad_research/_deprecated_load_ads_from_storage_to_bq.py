import pandas as pd
import json

from google.cloud import bigquery
from storage.download_blob import download_blob_into_string

_BUCKET = "kaya-ads-research"


if __name__ == "__main__":
    proposal_company_id = "testleadcompany"

    data = json.loads(
        download_blob_into_string(
            _BUCKET, f"{proposal_company_id}/consolidated_ads.json"
        )
    )
    df = pd.DataFrame(data["data"])

    cols = [
        "cta_text",
        "days_active",
        "num_variants",
        "is_dco",
        "audience_targeting",
        "metrics",
        "tags",
        "channels",
        "ctas",
        "slides",
    ]

    client = bigquery.Client()

    schema = [
        bigquery.SchemaField(name="platform", field_type="STRING"),
        # bigquery.SchemaField(name="channels", field_type="STRING", mode="REPEATED"),
        bigquery.SchemaField(name="format", field_type="STRING"),
        bigquery.SchemaField(name="advertiser_social_id", field_type="STRING"),
        bigquery.SchemaField(name="advertiser_name", field_type="STRING"),
        bigquery.SchemaField(name="ad_id", field_type="STRING"),
        bigquery.SchemaField(name="image_url", field_type="STRING"),
        bigquery.SchemaField(name="video_url", field_type="STRING"),
        bigquery.SchemaField(name="first_seen", field_type="DATE"),
        bigquery.SchemaField(name="last_seen", field_type="DATE"),
        bigquery.SchemaField(name="uuid", field_type="STRING"),
        bigquery.SchemaField(name="landing_page_url", field_type="STRING"),
        bigquery.SchemaField(name="headline", field_type="STRING"),
        bigquery.SchemaField(name="body", field_type="STRING"),
        # bigquery.SchemaField(name="tags", field_type="STRING", mode="REPEATED"),
        bigquery.SchemaField(name="landing_page_full_url", field_type="STRING"),
        # bigquery.SchemaField(name="ctas", field_type="STRING", mode="REPEATED"),
        # bigquery.SchemaField(
        #     name="audience_targeting",
        #     field_type="RECORD",
        #     mode="REPEATED",
        #     fields=(
        #         bigquery.SchemaField("name", "STRING"),
        #         bigquery.SchemaField("values", "STRING"),
        #     ),
        # ),
        # bigquery.SchemaField(
        #     name="metrics",
        #     field_type="RECORD",
        #     mode="REPEATED",
        #     fields=(
        #         bigquery.SchemaField("name", "STRING"),
        #         bigquery.SchemaField("values", "STRING"),
        #     ),
        # ),
        bigquery.SchemaField(name="image_urls", field_type="STRING"),
        bigquery.SchemaField(name="document_url", field_type="STRING"),
        # bigquery.SchemaField(name="num_variants", field_type="NUMERIC"),
        bigquery.SchemaField(name="link_description", field_type="STRING"),
        # bigquery.SchemaField(name="is_dco", field_type="BOOLEAN"),
        bigquery.SchemaField(name="caption", field_type="STRING"),
        bigquery.SchemaField(
            name="slides",
            field_type="RECORD",
            mode="REPEATED",
            fields=(
                bigquery.SchemaField("body", "STRING"),
                bigquery.SchemaField("caption", "STRING"),
                bigquery.SchemaField("ctas", "STRING"),
                bigquery.SchemaField("headline", "STRING"),
                bigquery.SchemaField("link_description", "STRING"),
                bigquery.SchemaField("landing_page_url", "STRING"),
                bigquery.SchemaField("landing_page_full_url", "STRING"),
                bigquery.SchemaField("original_image_url", "STRING"),
                bigquery.SchemaField("image_url", "STRING"),
                bigquery.SchemaField("video_hd_url", "STRING"),
                bigquery.SchemaField("video_url", "STRING"),
                bigquery.SchemaField("video_preview_image_url", "STRING"),
                bigquery.SchemaField("tags", "STRING"),
            ),
        ),
    ]

    job_config = bigquery.LoadJobConfig(
        schema=schema,
        create_disposition="CREATE_NEVER",
        write_disposition="WRITE_APPEND",
        autodetect=False,
        source_format=bigquery.SourceFormat.CSV,
    )

    job = client.load_table_from_dataframe(
        df, "kaya-apps-00.src_ad_research.all_ads_raw", job_config=job_config
    )  # Make an API request.
    job.result()  # Wait for the job to complete.

    # table = bigquery.Table("kaya-apps-00.src_ad_research.all_ads_raw", schema=schema)
    # client.create_table(table)

    # print(df.head().T)
    # errors = client.insert_rows_from_dataframe(table, df)
    # for chunk in errors:
    #     print(f"encountered {len(chunk)} errors: {chunk}")

    # process CTAs
    ad_cta_map_df = (
        df[["ad_id", "ctas"]].set_index("ad_id").explode("ctas").reset_index().dropna()
    )
    ad_cta_map_df.to_gbq(
        "src_ad_research.ad_ctas",
        "kaya-apps-00",
        if_exists="append",
    )

    # process channels
    ad_channel_map_df = (
        df[["ad_id", "channels"]].set_index("ad_id").explode("channels").reset_index()
    )
    ad_channel_map_df.to_gbq(
        "src_ad_research.ad_channels",
        "kaya-apps-00",
        if_exists="append",
    )

    # process metrics
    ad_metrics_df = (
        df[["ad_id", "metrics"]]
        .set_index("ad_id")
        .explode("metrics")
        .reset_index()
        .dropna()
    )
    ad_metrics_df[["metric_name", "metric_value"]] = ad_metrics_df["metrics"].apply(
        lambda x: pd.Series([x["name"], x["values"]])
    )
    ad_channel_map_df.to_gbq(
        "src_ad_research.ad_metrics",
        "kaya-apps-00",
        if_exists="append",
    )

    # process audience
    # flattened_data = []
    # for item in data:
    #     flattened_dict = {
    #         "ad_id": item["ad_id"],
    #         "location": item.get("audience_targeting", {}).get("location"),
    #         "language": item.get("audience_targeting", {}).get("language"),
    #     }
    #     flattened_data.append(flattened_dict)
    # ad_audience_df = pd.DataFrame(flattened_data).dropna()

    print(df[~df["audience_targeting"].isnull()].shape)
    ad_audience_df = (
        df[["ad_id", "audience_targeting"]]
        .set_index("ad_id")
        .explode("audience_targeting")
        .reset_index()
        .dropna()
    )

    ad_audience_df[["name", "values"]] = ad_audience_df["audience_targeting"].apply(
        lambda x: pd.Series([x["name"], x["values"]])
    )
    ad_audience_df.to_gbq(
        "src_ad_research.ad_audiences",
        "kaya-apps-00",
        if_exists="append",
    )
