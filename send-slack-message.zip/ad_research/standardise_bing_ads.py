import uuid
import json
from typing import List

_CHANNEL_MAPPING = {
    "text": ["search"],
    "videos": ["display"],
    "images": ["display"],
}
_FORMAT_MAPPING = {
    "videos": "video",
    "images": "image_single",
}
_PLATFORM = "bing_ads"


def process_bing_ads(
    bing_ads_payload, proposal_company_id, proposal_id
) -> List:
    # assign default values first
    image_url = None
    video_url = None

    bing_ads = []
    for ad in bing_ads_payload:
        if len(ad["AssetJson"]) == 0:
            ad_format = "text"
            
        else:
            try:
                asset_data = json.loads(ad["AssetJson"])

                if len(asset_data) == 1:
                    asset = asset_data[0]
                    if asset["AssetType"] == "Image":
                        ad_format = "images"
                        image_url = asset["AssetUrl"]

            except json.JSONDecodeError:
                print("Error: Invalid JSON format in AssetJson")
    
        ad_id = str(ad.get("AdId"))
        bing_ads.append(
            {
                "platform": _PLATFORM,
                "channels": _CHANNEL_MAPPING[ad_format],
                "format": _FORMAT_MAPPING.get(ad_format, ad_format),
                "advertiser_social_id": str(ad.get("AdvertiserId")),
                "advertiser_name": ad.get("AdvertiserName"),
                "ad_id": ad_id,
                "image_url": image_url,
                "video_url": video_url,
                "first_seen": None,
                "last_seen": None,
                "days_active": None,
                "uuid": str(uuid.uuid4()),
                "landing_page_url": ad.get("DestinationUrl"),
                "objectID": _PLATFORM + "_" + ad_id,
                "proposal_company_id": proposal_company_id,
                "proposal_id": proposal_id,
            }
        )
    return bing_ads


if __name__ == "__main__":
    import json
    from storage.download_blob import download_blob_into_string

    proposal_id = "testproposal"
    proposal_company_id = "testleadcompany"

    payload = json.loads(
        download_blob_into_string(
            "kaya-ads-research", f"{proposal_company_id}/bing_ads.json"
        )
    )

    bing_ads = process_bing_ads(payload, proposal_company_id, proposal_id)

    print("bing_ads: ", bing_ads)
