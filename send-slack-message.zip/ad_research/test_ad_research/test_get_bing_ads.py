def mock_get_bing_ads_from_ad_lib():
    return [
        {
            "AdId": 80401974811251,
            "AdvertiserName": "Amazon Europe Core S.à r.l",
            "AdvertiserId": 4295023783,
            "Title": "JETech Coque Mat pour iPhone XR 6,1 Pouces, Protection Antichoc Qualité Militaire, Étui Housse Arrière Translucide Givrée, Anti-Empreintes Digitales",
            "Description": "11.99 EUR",
            "DisplayUrl": "Amazon FR",
            "DestinationUrl": "https://www.amazon.fr/JETech-Protection-Militaire-Translucide-Anti-Empreintes/dp/B0BX2YK729?source=ps-sl-shoppingads-lpcontext&ref_=bing_fplfs&psc=1",
            "AssetJson": '[{"AssetType":"Image","AssetUrl":"https://m.media-amazon.com/images/I/61lrdIv+YaL.jpg"}]',
        },
        {
            "AdId": 80126967116319,
            "AdvertiserName": "Amazon Europe Core S.à r.l",
            "AdvertiserId": 4295023783,
            "Title": "Eucerin Anti-pigment Day Cream Spf30 50ml",
            "Description": "20.25 GBP",
            "DisplayUrl": "Amazon UK",
            "DestinationUrl": "https://www.amazon.co.uk/Eucerin-Anti-Pigment-Cream-50ml-effective/dp/B07KB1PV1L?source=ps-sl-shoppingads-lpcontext&ref_=bing_fplfs&psc=1",
            "AssetJson": '[{"AssetType":"Image","AssetUrl":"https://m.media-amazon.com/images/I/51K6WSpr+WL.jpg"}]',
        }
    ]