def mock_get_meta_ads_from_apify():
    return [
        {
            "pageInfo.page.name": "Fortress Power",
            "pageInfo.page.about.text": "Discover the future of energy with Fortress Power. 💡 Global leaders in all-in-one solutions based in Langhorne, PA, with offices in PR, MX, CA. Join 25,000+ satisfied users with our high-quality systems.",
            "totalCount": 7,
            "snapshot.title": "{{product.name}}",
            "snapshot.display_format": "dco",
            "snapshot.effective_authorization_category": "NONE",
            "isActive": True,
            "spend": None,
            "reachEstimate": None,
            "publisherPlatform": [
                "facebook",
                "instagram",
                "audience_network",
                "messenger",
            ],
            "startDateFormatted": "2024-06-21T07:00:00.000Z",
            "endDateFormatted": "2024-07-07T07:00:00.000Z",
        },
        {
            "pageInfo.page.name": "Fortress Power",
            "pageInfo.page.about.text": "Discover the future of energy with Fortress Power. 💡 Global leaders in all-in-one solutions based in Langhorne, PA, with offices in PR, MX, CA. Join 25,000+ satisfied users with our high-quality systems.",
            "totalCount": 7,
            "snapshot.title": "{{product.name}}",
            "snapshot.display_format": "dco",
            "snapshot.effective_authorization_category": "NONE",
            "isActive": True,
            "spend": None,
            "reachEstimate": None,
            "publisherPlatform": ["facebook", "instagram", "audience_network"],
            "startDateFormatted": "2024-06-17T07:00:00.000Z",
            "endDateFormatted": "2024-07-07T07:00:00.000Z",
        },

    ]
