def mock_get_tiktok_ads_from_apify():
    return [
        {
            "adId": "1801023205466114",
            "advertiserName": "Zalando Marketing Services GmbH",
            "adTitle": "Zalando Marketing Services GmbH",
            "adImpressions": "500K-600K",
            "adVideoUrl": "https://library.tiktok.com/api/v1/cdn/1720782167/video/aHR0cHM6Ly92MTZtLnRpa3Rva2Nkbi5jb20vZjlkOTEyMWIxNjNkZWYwMWI0MThjZDY4YWE3ZWFiOTkvNjY5MTYxYzUvdmlkZW8vdG9zL2FsaXNnL3Rvcy1hbGlzZy12ZS0wMDUxYzAwMS1zZy9vd2pnM01nWWZBSUxGSUpNUURObXVsQlRVRUJRRkR4dHJGQkV6Zi8=/091d5c60-32bd-4e97-acb5-33c18a9d30d5?a=475769&bti=PDU2NmYwMy86&ch=0&cr=0&dr=1&cd=0%7C0%7C0%7C0&cv=1&br=2066&bt=1033&cs=0&ds=1&ft=.NpOcInz7ThoJafrXq8Zmo&mime_type=video_mp4&qs=0&rc=ZWk4aTM8N2ZkNzk0OTM6NkBpamZodXk5cmc4czMzODYzNEAvLWBhNDZhNjUxMi5gLTYuYSM2bmhpMmRzMWRgLS1kMC1zcw%3D%3D&vvpl=1&l=20240712110246A376BB2CD9CDDC1F81B1&btag=e00088000&cc=3",
        },
        {
            "adId": "1802834284597249",
            "advertiserName": "NIKE (UK) LIMITED",
            "adTitle": "NIKE (UK) LIMITED",
            "adImpressions": "10K-100K",
            "adVideoUrl": "https://library.tiktok.com/api/v1/cdn/1720782167/video/aHR0cHM6Ly92NzcudGlrdG9rY2RuLmNvbS8zYTllMGE3YTFjODkzYWY2YWUxOWE3ODc5YmY2ZGRjYy82NjkxNjFjNi92aWRlby90b3MvYWxpc2cvdG9zLWFsaXNnLXZlLTAwNTFjMDAxLXNnL29zeEQ1a0RkRkIxQWVyNjFZYjlnQUNlRzk0ZElFZ1FmQU1xOE5FLw==/fa796b1d-5201-4c60-82e9-bd679203c134?a=475769&bti=PDU2NmYwMy86&ch=0&cr=0&dr=1&cd=0%7C0%7C0%7C0&cv=1&br=1512&bt=756&cs=0&ds=1&ft=.NpOcInz7ThoJafrXq8Zmo&mime_type=video_mp4&qs=0&rc=M2RkOTZkOWhnZzZnZmk4N0BpM291aXY5cmpkczMzODYzNEA2YV42Mi8wNTUxLmAzNGIwYSNkcWVjMmQ0cHFgLS1kMC1zcw%3D%3D&vvpl=1&l=20240712110246507B6C7E0D8DFC1E61A4&btag=e00088000&cc=13",
        },
    ]
