from os import environ

from ad_research.ad_utils import write_json_to_bucket
from ad_research.test_ad_research.test_get_tiktok_ads import (
    mock_get_tiktok_ads_from_apify,
)

from apify_client import ApifyClient
from firestore import FirestoreClient

from common import validate_inputs
from http_function import process_request_inputs, http_function


_FS = FirestoreClient()
_APIFY_CLIENT = ApifyClient(environ["APIFY_API_KEY"])
_APIFY_ACTOR_ID = "60AtqWgevwexQsFPw"


@http_function
def research_get_tiktok_ads(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)
    print(data)

    output = execute_get_tiktok_ads(data["proposal_company_id"], data["env"])
    return output


def execute_get_tiktok_ads(proposal_company_id, env="dev"):
    ## dev
    if env.upper() == "DEV":
        tiktok_ads = mock_get_tiktok_ads_from_apify()

        out = write_json_to_bucket(proposal_company_id, "tiktok_ads", tiktok_ads)
        return out

    ## prod
    doc = _FS.get_single_document("proposal_companies", proposal_company_id)

    country = doc.get("country", "")
    if country.upper() == "US":
        write_json_to_bucket(proposal_company_id, "tiktok_ads", {})
        print("TikTok ad library doesn't handle US. Skipping...")
        return {}

    tt_search_terms = doc.get("tiktok_search_terms", [])
    if len(tt_search_terms) == 0:
        write_json_to_bucket(proposal_company_id, "tiktok_ads", {})
        print("TikTok search terms not available. Skipping...")
        return {}

    # get ads
    tiktok_ads = get_tiktok_ads_from_apify(tt_search_terms)

    if not tiktok_ads:
        write_json_to_bucket(proposal_company_id, "tiktok_ads", {})
        print("TikTok ad not available in Apify. Skipping...")
        return {}

    # write to cloud storage
    out = write_json_to_bucket(proposal_company_id, "tiktok_ads", tiktok_ads)
    return out


def get_tiktok_ads_from_apify(tt_search_terms):
    tiktok_ads = []
    for term in tt_search_terms:
        # Prepare the Actor input
        run_input = {
            "query": term,
        }

        # Run the Actor and wait for it to finish
        run = _APIFY_CLIENT.actor(_APIFY_ACTOR_ID).call(run_input=run_input)

        for item in _APIFY_CLIENT.dataset(run["defaultDatasetId"]).iterate_items():
            tiktok_ads.append(item)

    return tiktok_ads


if __name__ == "__main__":
    tt_search_terms = ["mcdonald", "kfc"]
    output = get_tiktok_ads_from_apify(tt_search_terms)
    print("final output:", output)
    print("Done")

# if __name__ == "__main__":
#     proposal_company_id = "testleadcompany"
#     env = "dev"

#     output = execute_get_tiktok_ads(proposal_company_id, env)
#     print("final output:", output)
#     print("Done")
