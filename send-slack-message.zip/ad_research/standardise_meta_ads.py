import uuid
import multiprocessing

from utils.request import call_api
from utils.url import get_url_without_params
from utils.string_ops import convert_to_snake_case
from ad_research.upload_ads_images_to_storage import process_image_url

_PLATFORM = "meta_ads"


def _get_video_asset_validity(url_dict):
    ad_format = url_dict.get("format", "")

    if ad_format == "video":
        video_url = url_dict.get("video_url", "")

        try:
            resp = call_api(video_url, output_fmt="raw")

            if resp.status_code != 200:
                url_dict["is_video_asset_error"] = True

        except Exception as e:
            print("Failed to open page.", video_url)
            url_dict["is_video_asset_error"] = True

    elif ad_format == "video_carousel":
        is_error_flags = 0
        for s in url_dict["slides"]:
            try:
                resp = call_api(s["video_url"], output_fmt="raw")

                if resp.status_code != 200:
                    is_error_flags += 1
                    continue

            except Exception as e:
                print("Failed to open page.", s["video_url"])

        if is_error_flags > 0:
            url_dict["is_video_asset_error"] = True

    else:
        pass

    return url_dict


def process_meta_ads(meta_ads_payload, proposal_company_id, proposal_id):
    meta_ad_items = meta_ads_payload.get("items", [])
    num_items = len(meta_ad_items)

    if num_items == 0:
        return []

    if num_items == 1:
        item = meta_ad_items[0]
        if item.get("totalCount", 0) == 0:
            return []

    meta_ads = []
    for idx, ma in enumerate(meta_ad_items):
        if idx % 5 == 0:
            print(f"Processing ad number {idx}, out of {num_items} items")

        # define default
        num_variants = 1

        try:
            snapshot = ma["snapshot"]

            ad_id = snapshot["ad_creative_id"]
            print("ad_id: ", ad_id)
            cards = snapshot["cards"]
            display_format = snapshot["display_format"]

            format_specific_d = {}
            if display_format == "carousel":
                # carousel can be image or video
                print("Fix carousel")

                slides = []
                original_image_urls = []
                for card in cards:
                    landing_page_full_url = card.get("link_url")
                    landing_page_url = (
                        get_url_without_params(landing_page_full_url)
                        if landing_page_full_url is not None
                        else None
                    )

                    ad_body = card.get("body", "")
                    ad_body = "" if ad_body is None else ad_body
                    tags = []

                    original_image_url = card.get("original_image_url", "")
                    video_url = card.get("video_sd_url", card.get("video_hd_url", ""))
                    video_preview_image_url = card.get("video_preview_image_url", "")

                    if original_image_url:
                        ad_format = "image_carousel"
                        original_image_urls.append(original_image_url)

                    elif video_url:
                        ad_format = "video_carousel"
                        original_image_url = video_preview_image_url
                        original_image_urls.append(original_image_url)

                    else:
                        print("image and video urls for carousel not available!")

                    image_url_d = process_image_url(original_image_url)
                    slide = {
                        "body": ad_body,
                        "caption": card.get("caption", ""),
                        "ctas": [card.get("cta_text", "")],
                        "headline": card.get("title", ""),
                        "link_description": card.get("link_description", ""),
                        "landing_page_url": landing_page_url,
                        "landing_page_full_url": landing_page_full_url,
                        "video_hd_url": video_url,
                        "video_url": video_url,
                        "video_preview_image_url": video_preview_image_url,
                        "tags": tags,
                        **image_url_d,
                    }

                    slides.append(slide)

                format_specific_d["slides"] = slides
                format_specific_d["original_image_urls"] = original_image_urls

            elif display_format in ["dco", "dpa"]:
                # TODO: DCO has multiple images but we only process the first image now. Need to process all images in the future
                ad_format = "image_single"
                num_variants = len(cards)
                format_specific_d["is_dco"] = True

                # for DCO, the ad body in screenshot will be gibberish
                default_card = cards[0]

                landing_page_full_url = default_card.get("link_url")
                landing_page_url = (
                    get_url_without_params(landing_page_full_url)
                    if landing_page_full_url is not None
                    else None
                )

                ad_body = default_card["body"]
                ad_body = "" if ad_body is None else ad_body
                tags = []

                format_specific_d["headline"] = default_card["title"]
                format_specific_d["body"] = ad_body
                format_specific_d["tags"] = tags
                format_specific_d["caption"] = default_card["caption"]
                format_specific_d["cta_text"] = default_card["cta_text"]
                format_specific_d["landing_page_url"] = landing_page_url
                format_specific_d["landing_page_full_url"] = landing_page_full_url

                image_url_d = process_image_url(default_card.get("original_image_url"))
                format_specific_d = {**format_specific_d, **image_url_d}

            elif display_format == "image":
                print("Fix image_single")
                ad_format = "image_single"
                image_payload = snapshot["images"][0]

                if len(snapshot["images"]) > 1:
                    print(ma)
                    raise Exception("type = images and has multiple videos")

                num_variants = max(len(cards), 1)

                image_url_d = process_image_url(image_payload.get("original_image_url"))
                format_specific_d = {**format_specific_d, **image_url_d}

            elif display_format == "video":
                print("Fix video")
                ad_format = "video"
                video_payload = snapshot["videos"][0]

                format_specific_d["video_url"] = video_payload.get(
                    "video_sd_url", video_payload.get("video_hd_url")
                )

                image_url_d = process_image_url(
                    video_payload.get("video_preview_image_url")
                )
                format_specific_d = {**format_specific_d, **image_url_d}

                if len(snapshot["videos"]) > 1:
                    print(ma)
                    raise Exception("type = video and has multiple videos")

                if len(cards) > 0:
                    print(ma)
                    raise Exception("type = video and has multiple cards")

            elif display_format == "page_like":
                # TODO
                print("Fix page_like")
                ad_format = "page_like"

            else:
                raise Exception("display_format not seen: ", display_format)

            # process metrics
            metrics = []
            for m in ["spend", "impressions", "reach_estimate"]:
                if ma.get(m):
                    metrics.append(
                        {"name": convert_to_snake_case(m), "values": ma.get(m)}
                    )

            ad_body = snapshot.get("body", {}).get("markup", {}).get("__html")
            ad_body = "" if ad_body is None else ad_body
            tags = []

            # process audience targeting
            audience_targeting = []
            aaa_info = ma.get("ad_details", {}).get("aaa_info")
            if aaa_info is not None:
                locations_list = []
                excluded_locations_list = []
                countries_raw = aaa_info.get("location_audience", [])
                if len(countries_raw) > 0:
                    locations_list = [
                        c["name"] for c in countries_raw if not c["excluded"]
                    ]
                    audience_targeting.append(
                        {"name": "geography", "values": locations_list}
                    )

                    excluded_locations_list = [
                        c["name"] for c in countries_raw if c["excluded"]
                    ]
                    audience_targeting.append(
                        {
                            "name": "excluded_geography",
                            "values": excluded_locations_list,
                        }
                    )

                if (
                    aaa_info.get("age_audience") is not None
                    and aaa_info.get("age_audience", {}).get("min")
                    and aaa_info.get("age_audience", {}).get("max")
                ):
                    age = f'{aaa_info.get("age_audience").get("min")} - {aaa_info.get("age_audience").get("max")}'
                    audience_targeting.append({"name": "age", "values": age})
                else:
                    age = ""

                if (
                    aaa_info.get("gender_audience") is not None
                    and aaa_info.get("gender_audience") != ""
                ):
                    audience_targeting.append(
                        {
                            "name": "gender",
                            "values": aaa_info.get("gender_audience"),
                        }
                    )

            # process landing page url
            if format_specific_d.get("landing_page_url") is None:
                landing_page_full_url = snapshot.get("link_url")
                landing_page_url = (
                    get_url_without_params(landing_page_full_url)
                    if landing_page_full_url is not None
                    else None
                )

            d = {
                "platform": _PLATFORM,
                "format": ad_format,
                "landing_page_url": landing_page_url,
                "landing_page_full_url": landing_page_full_url,
                "metrics": metrics,
                "ctas": [snapshot.get("cta_text")],
                "ad_id": ad_id,
                "headline": snapshot.get("title"),
                "body": ad_body,
                "tags": tags,
                "first_seen": ma.get("startDateFormatted", "")[:10],
                "last_seen": ma.get("endDateFormatted", "")[:10],
                "num_variants": num_variants,
                "channels": ma.get("publisherPlatform"),
                "link_description": snapshot.get("link_description"),
                "caption": snapshot.get("caption"),
                "audience_targeting": audience_targeting,
                "uuid": str(uuid.uuid4()),
                "objectID": _PLATFORM + "_" + str(ad_id),
                "proposal_company_id": proposal_company_id,
                "proposal_id": proposal_id,
            }
            meta_ads.append({**d, **format_specific_d})
        except Exception as e:
            print(e)

    # multiprocessing to check video url validity
    with multiprocessing.Pool() as pool:
        meta_ads = pool.map(_get_video_asset_validity, meta_ads)

    return meta_ads


# if __name__ == "__main__":
# # use this to test process_meta_ads func
#     import json
#     import time
#     from storage.download_blob import download_blob_into_string

#     start_time = time.time()

#     proposal_id = "tSsv7RBQNHRCG9Goxepk"
#     proposal_company_id = "lo1yVts0PyhCZZ58glho"

#     payload = json.loads(
#         download_blob_into_string(
#             "kaya-ads-research", f"{proposal_company_id}/meta_ads.json"
#         )
#     )

#     # process meta ads
#     meta_ads = process_meta_ads(payload, proposal_company_id, proposal_id)

#     # check for specific card
#     check = [
#         card for card in meta_ads if card["objectID"] == "meta_ads_120209356691390724"
#     ]
#     print("check: ", check)

#     print("-------------------\n\n")
#     print("--- %s seconds ---" % (time.time() - start_time))
