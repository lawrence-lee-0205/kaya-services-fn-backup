import uuid

from typing import List
from ad_research.ad_utils import country_mapping_dict


_FORMAT_MAPPING = {
    "videos": "video",
    "images": "image_single",
}
_PLATFORM = "tiktok_ads"


from datetime import datetime, timezone


def convert_tiktok_date(timestamp_ms):
    try:
        timestamp_seconds = timestamp_ms / 1000
        date_time = datetime.fromtimestamp(timestamp_seconds, timezone.utc)
        return date_time.date()

    except (ValueError, OverflowError):
        print(f"Error converting timestamp: {timestamp_ms}")
        return None


def transform_date_features(start_date, end_date):
    first_seen = convert_tiktok_date(start_date)
    last_seen = convert_tiktok_date(end_date)
    days_active = (last_seen - first_seen).days

    first_seen_str = first_seen.strftime("%Y-%m-%d")
    last_seen_str = last_seen.strftime("%Y-%m-%d")

    return first_seen_str, last_seen_str, days_active


def string_to_int(number_string):
    try:
        # Extract the number part (before the unit)
        number = float(number_string[:-1])

        # Get the unit (case-insensitive)
        unit = number_string[-1].upper()

        # Convert based on the unit
        if unit == "K":
            return int(number * 1000)
        elif unit == "M":
            return int(number * 1000000)
        elif unit == "B":
            return int(number * 1000000000)
        else:
            raise ValueError(f"Invalid unit: {unit}")

    except ValueError:
        raise ValueError(f"Invalid number string format: {number_string}")


def sum_and_format_as_string(number_list):
    total_sum = sum(num for num in number_list if isinstance(num, int))

    print("number_list: ", number_list)
    if total_sum == 0:
        return "0"

    magnitude = 0
    units = ["", "K", "M", "B"]
    while total_sum >= 1000:
        magnitude += 1
        total_sum /= 1000

        print("magnitude: ", magnitude)
        print("total_sum: ", total_sum)

    # Format the output string with one decimal place
    formatted_sum = f"{total_sum:.1f}{units[magnitude]}"
    return formatted_sum


# # before change in apify output
# def process_tiktok_ads(
#     ads, proposal_company_id, proposal_id
# ) -> List:
#     tiktok_ads = []
#     for ad in ads:
#         ad_id = ad.get("adId")
#         ad_format = "videos"

#         # preprocess date features
#         (first_seen, last_seen, days_active) = transform_date_features(
#             ad.get("adStartDate"), ad.get("adEndDate")
#         )

#         # preprocess audience targeting and metrics
#         audience_targeting = []
#         metrics = []

#         targeting_data = ad.get("targetingByLocation", [])
#         if targeting_data:
#             locations_list = []
#             impressions_list = []

#             for c in targeting_data:
#                 # process geography
#                 geography = country_mapping_dict.get(c["region"], c["region"])
#                 locations_list.append(geography)

#                 # process metrics
#                 impression = string_to_int(c["impressions"])
#                 impressions_list.append(impression)

#             # append to audience_targeting
#             audience_targeting.append(
#                 {"name": "geography", "values": locations_list}
#             )

#             # append to metrics
#             impressions_val = sum_and_format_as_string(impressions_list)
#             metrics.append(
#                 {"name": "impressions", "values": impressions_val}
#             )

#         # aggregate all data
#         tiktok_ads.append(
#             {
#                 "platform": _PLATFORM,
#                 "channels": ["tiktok"],
#                 "format": _FORMAT_MAPPING.get(ad_format, ad_format),
#                 "advertiser_social_id": ad.get("advertiserId"),
#                 "advertiser_name": ad.get("advertiserName"),
#                 "ad_id": ad_id,
#                 "image_url": ad.get("adVideoCover"),
#                 "video_url": ad.get("adVideoUrl"),
#                 "first_seen": first_seen,
#                 "last_seen": last_seen,
#                 "audience_targeting": audience_targeting,
#                 "metrics": metrics,
#                 "days_active": days_active,
#                 "uuid": str(uuid.uuid4()),
#                 "landing_page_url": None,
#                 "objectID": _PLATFORM + "_" + ad_id,
#                 "proposal_company_id": proposal_company_id,
#                 "proposal_id": proposal_id,
#             }
#         )
#     return tiktok_ads


def process_tiktok_ads(ads, proposal_company_id, proposal_id) -> List:
    tiktok_ads = []
    for ad in ads:
        ad_id = ad.get("adId")
        ad_format = "videos"

        tiktok_ads.append(
            {
                "platform": _PLATFORM,
                "channels": ["tiktok"],
                "format": _FORMAT_MAPPING.get(ad_format, ad_format),
                "advertiser_social_id": ad.get("advertiserId"),
                "advertiser_name": ad.get("advertiserName"),
                "ad_id": ad_id,
                "video_url": ad.get("adVideoUrl"),
                "uuid": str(uuid.uuid4()),
                "landing_page_url": None,
                "objectID": _PLATFORM + "_" + ad_id,
                "proposal_company_id": proposal_company_id,
                "proposal_id": proposal_id,
            }
        )
    return tiktok_ads


if __name__ == "__main__":
    import json
    from storage.download_blob import download_blob_into_string

    proposal_id = "testproposal"
    proposal_company_id = "test_competitor_klarify"

    # payload = json.loads(
    #     download_blob_into_string(
    #         "kaya-ads-research", f"{proposal_company_id}/tiktok_ads.json"
    #     )
    # )

    # sample data
    # payload = [
    #     {
    #         "adId":"1795230518908945",
    #         "adTitle":"bhnpilatesstudio",
    #         "adType":"2",
    #         "adSpent":"",
    #         "adVideoUrl":"https://library.tiktok.com/api/v1/cdn/1714751118/video/aHR0cHM6Ly92NzcudGlrdG9rY2RuLmNvbS9kMjk4YzExMGQxZWQ0OTkzOWMwM2FmNWM3ZGFjYTg2Zi82NjM1NWIyZC92aWRlby90b3MvdXNlYXN0MmEvdG9zLXVzZWFzdDJhLXZlLTAwNjhjMDAxLWV1dHRwL29vREVtd2dTUUVTb21BTERBRW1FWURmQkRJcmdQYUpmUUFGRndSLw==/c8821feb-fdd5-4e4c-81d4-688bca514755?a=475769&bti=PDU2NmYwMy86&ch=0&cr=0&dr=1&cd=0%7C0%7C0%7C0&cv=1&br=1444&bt=722&cs=0&ds=6&ft=.NpOcInz7ThHRa_rXq8Zmo&mime_type=video_mp4&qs=0&rc=NDY2OTNoM2U1ZTM8aGgzOEBpajxqZnI5cjQzcjMzZjczM0A1MGAuNi0xNWIxYC9eNjZfYSMxbi8uMmQ0ZzNgLS1kMWNzcw%3D%3D&vvpl=1&l=20240503154517C5BE1F0DFBC3A696884B&btag=e00090000&cc=13",
    #         "adVideoCover":"https://p19-vod-sign-useast2a.tiktokcdn-eu.com/tos-useast2a-p-0037-euttp/84db3d2c19fd41b787a640b3574a1f0e_1712065005~tplv-noop.image?x-expires=1714772781&x-signature=HMpHuHS2TM%2BcHiqM3EICot%2FtVc4%3D",
    #         "adStartDate":1712016000000,
    #         "adEndDate":1712102400000,
    #         "advertiserId":"7353264062207344656",
    #         "advertiserName":"bhnpilatesstudio",
    #         "adImpressions":"1K-10K",
    #         "advertiserPaidForBy":"1795230491176974",
    #         "adTotalRegions":1,
    #         "adEstimatedAudience":"1K-10K",
    #         "targetingByLocation":[
    #             {
    #                 "region":"IT",
    #                 "impressions":"6K"
    #             },
    #             {
    #                 "region":"GB",
    #                 "impressions":"6K"
    #             }
    #         ]
    #     }
    # ]
    # print("payload: ", payload)

    payload = [
        {
            "adId": "1801023205466114",
            "advertiserName": "Zalando Marketing Services GmbH",
            "adTitle": "Zalando Marketing Services GmbH",
            "adImpressions": "500K-600K",
            "adVideoUrl": "https://library.tiktok.com/api/v1/cdn/1720782167/video/aHR0cHM6Ly92MTZtLnRpa3Rva2Nkbi5jb20vZjlkOTEyMWIxNjNkZWYwMWI0MThjZDY4YWE3ZWFiOTkvNjY5MTYxYzUvdmlkZW8vdG9zL2FsaXNnL3Rvcy1hbGlzZy12ZS0wMDUxYzAwMS1zZy9vd2pnM01nWWZBSUxGSUpNUURObXVsQlRVRUJRRkR4dHJGQkV6Zi8=/091d5c60-32bd-4e97-acb5-33c18a9d30d5?a=475769&bti=PDU2NmYwMy86&ch=0&cr=0&dr=1&cd=0%7C0%7C0%7C0&cv=1&br=2066&bt=1033&cs=0&ds=1&ft=.NpOcInz7ThoJafrXq8Zmo&mime_type=video_mp4&qs=0&rc=ZWk4aTM8N2ZkNzk0OTM6NkBpamZodXk5cmc4czMzODYzNEAvLWBhNDZhNjUxMi5gLTYuYSM2bmhpMmRzMWRgLS1kMC1zcw%3D%3D&vvpl=1&l=20240712110246A376BB2CD9CDDC1F81B1&btag=e00088000&cc=3",
        },
        {
            "adId": "1802834284597249",
            "advertiserName": "NIKE (UK) LIMITED",
            "adTitle": "NIKE (UK) LIMITED",
            "adImpressions": "10K-100K",
            "adVideoUrl": "https://library.tiktok.com/api/v1/cdn/1720782167/video/aHR0cHM6Ly92NzcudGlrdG9rY2RuLmNvbS8zYTllMGE3YTFjODkzYWY2YWUxOWE3ODc5YmY2ZGRjYy82NjkxNjFjNi92aWRlby90b3MvYWxpc2cvdG9zLWFsaXNnLXZlLTAwNTFjMDAxLXNnL29zeEQ1a0RkRkIxQWVyNjFZYjlnQUNlRzk0ZElFZ1FmQU1xOE5FLw==/fa796b1d-5201-4c60-82e9-bd679203c134?a=475769&bti=PDU2NmYwMy86&ch=0&cr=0&dr=1&cd=0%7C0%7C0%7C0&cv=1&br=1512&bt=756&cs=0&ds=1&ft=.NpOcInz7ThoJafrXq8Zmo&mime_type=video_mp4&qs=0&rc=M2RkOTZkOWhnZzZnZmk4N0BpM291aXY5cmpkczMzODYzNEA2YV42Mi8wNTUxLmAzNGIwYSNkcWVjMmQ0cHFgLS1kMC1zcw%3D%3D&vvpl=1&l=20240712110246507B6C7E0D8DFC1E61A4&btag=e00088000&cc=13",
        },
    ]

    tiktok_ads = process_tiktok_ads(payload, proposal_company_id, proposal_id)

    print("tiktok_ads: ", tiktok_ads)
