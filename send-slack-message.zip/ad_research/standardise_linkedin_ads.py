import uuid
import re

from utils.url import get_url_without_params
from storage.download_blob import download_blob_into_string
from ad_research.upload_ads_images_to_storage import process_image_url

_PLATFORM = "linkedin_ads"


def process_linkedin_ads(
    linkedin_ads_payload, proposal_company_id, proposal_id, **kwargs
):
    raw_linkedin_ads = linkedin_ads_payload.get("items", [])

    linkedin_ads = []
    for la in raw_linkedin_ads:
        l_format_specific_dict = {}
        if la["format"] == "SINGLE_IMAGE":
            ad_format = "image_single"
        elif la["format"] == "DOCUMENT":
            # TODO: Like Meta's DCO and DPA ads
            # LI's Document ads have multiple images but we only process the first image now
            # To either process all images, or single image cover and enable pdf url click
            ad_format = "document"
            la["imageUrl"] = la.get("imageUrls")[0]
            l_format_specific_dict["document_url"] = la.get("documentUrl")
        elif la["format"] == "VIDEO":
            ad_format = "video"
            l_format_specific_dict["video_url"] = la.get("videoUrl")
        elif la["format"] == "MESSAGE":
            ad_format = "message"
        elif la["format"] == "SPOTLIGHT":
            ad_format = "spotlight"
        elif la["format"] == "TEXT":
            ad_format = "text"
        elif la["format"] == "FOLLOW_COMPANY":
            ad_format = "follow"
            #         TODO: FE TO MANAGE
            continue
        elif la["format"] == "CAROUSEL":
            ad_format = "image_carousel"

            slides = []
            original_image_urls = []
            for card in la["slides"]:
                original_image_url = card.get("imageUrl", "")

                if original_image_url:
                    original_image_urls.append(original_image_url)

                slide = process_image_url(original_image_url)
                slide = {**slide}
                slides.append(slide)

            l_format_specific_dict["slides"] = slides
            l_format_specific_dict["original_image_urls"] = original_image_urls

        elif la["format"] == "EVENT":
            ad_format = "event"
        elif la["format"] == "JOB":
            ad_format = "job"
            #         TODO: FE TO MANAGE
            continue
        else:
            print(la)
            raise Exception(la["format"])

        # process image
        image_url_d = process_image_url(la.get("imageUrl"))
        l_format_specific_dict = {**l_format_specific_dict, **image_url_d}

        # process audience
        audience_targeting = []
        if la.get("targeting") is not None:
            # Regex pattern to match and replace "and" with spaces before and after
            pattern = r" (?<!\w)and(?!\w) "

            # process geography
            locations = la["targeting"].get("location", "")
            if len(locations) > 0:
                locations = re.sub(pattern, r", ", locations)
                locations_list = locations.strip().split(", ")

                audience_targeting.append(
                    {"name": "geography", "values": locations_list}
                )

            # process language
            languages = la["targeting"].get("language", "")
            if len(languages) > 0:
                languages = re.sub(pattern, r", ", languages)
                languages_list = languages.strip().split(", ")

                audience_targeting.append(
                    {"name": "language", "values": languages_list}
                )

        # process metrics
        metrics = []
        for m in ["spend", "impressions", "reach_estimate"]:
            if la.get(m) is not None:
                metrics.append({"name": m, "values": la.get(m)})

        # process url
        landing_page_full_url = la.get("clickUrl")
        landing_page_url = (
            get_url_without_params(landing_page_full_url)
            if landing_page_full_url is not None
            else None
        )

        # process final dict
        ad_body = la.get("body", "")
        ad_body = "" if ad_body is None else ad_body
        tags = []

        ad_id = la["adId"]

        lad = {
            "platform": _PLATFORM,
            "channels": ["linkedin"],
            "format": ad_format,
            "headline": la.get("headline"),
            "body": ad_body,
            "tags": tags,
            "advertiser_name": la.get("advertiserName"),
            "ad_id": ad_id,
            "landing_page_url": landing_page_url,
            "landing_page_full_url": landing_page_full_url,
            "ctas": la.get("ctas"),
            "first_seen": la.get("availability", {}).get("start"),
            "last_seen": la.get("availability", {}).get("end"),
            "audience_targeting": audience_targeting,
            "metrics": metrics,
            "uuid": str(uuid.uuid4()),
            "objectID": _PLATFORM + "_" + ad_id,
            "proposal_company_id": proposal_company_id,
            "proposal_id": proposal_id,
        }
        linkedin_ads.append({**lad, **l_format_specific_dict})

    return linkedin_ads


# if __name__ == "__main__":
#     proposal_id = "nbeFPU8sHkFM2yfhliW8"
#     proposal_company_id = "qnsbsbEqB8IHH5YUwNE8"
#     ad_library_url = "https://www.linkedin.com/ad-library/search?companyIds=1512"

#     ## sample payload from func [execute_get_linkedin_ads]
#     # linkedin_ads_payload = execute_get_linkedin_ads(ad_library_url, proposal_company_id)
#     linkedin_ads_payload = {
#         "items":[
#             {
#                 "adId":"350756804",
#                 "clickUrl":"https://www.linkedin.com/company/1512",
#                 "format":"SINGLE_IMAGE",
#                 "impressions":"100k-200k",
#                 "targeting":{
#                     "location":"North America, Asia and Europe, Africa, Oceania, Latin America, Middle East"
#                 },
#                 "landing_page_url":"https://www.linkedin.com/company/1512"
#             },
#             {
#                 "adId":"350756805",
#                 "clickUrl":"https://www.linkedin.com/company/1512",
#                 "impressions":"100k-200k",
#                 "format":"SINGLE_IMAGE",
#                 "targeting":{
#                     "location":"Italy, United States and France, Sweden, Belgium, Norway, Spain, Portugal, Germany, Switzerland, Netherlands, Australia, Denmark, Austria, United Kingdom"
#                 },
#                 "landing_page_url":"https://www.linkedin.com/company/1512"
#             }
#         ]
#     }

#     processed_ads = process_linkedin_ads(linkedin_ads_payload, proposal_company_id, proposal_id)
#     print("processed_ads: ", processed_ads)
#     print("Done!")


if __name__ == "__main__":
    import json
    import time
    import queue
    from storage.download_blob import download_blob_into_string
    from ad_research.consolidate_all_ads import consolidate_single_company

    start_time = time.time()

    proposal_id = "tSsv7RBQNHRCG9Goxepk"
    proposal_company_id = "faNuhdn3cRd0aDoCTCqR"

    payload = json.loads(
        download_blob_into_string(
            "kaya-ads-research", f"{proposal_company_id}/linkedin_ads.json"
        )
    )

    # process meta ads
    linkedin_ads = process_linkedin_ads(payload, proposal_company_id, proposal_id)

    # check for specific card
    check = [
        card for card in linkedin_ads if card["objectID"] == "linkedin_ads_369828576"
    ]
    print("check: ", check)

    print("-------------------\n\n")
    print("--- %s seconds ---" % (time.time() - start_time))

    q = queue.Queue()

    # consolidate across ad platforms
    consolidate_single_company(proposal_company_id, proposal_id)
