import datetime as dt

from firestore import FirestoreClient

_FS = FirestoreClient()


if __name__ == "__main__":
    # https://www.greatplacetowork.com/

    proposal_id = "tSsv7RBQNHRCG9Goxepk"
    domain_to_add = "greatplacetowork.com"
    company_name = "Great Place To Work"
    logo_url = "https://media.licdn.com/dms/image/C560BAQG5SxpXLUl-4g/company-logo_200_200/0/1654722572454/great_place_to_work_us_logo?e=1727308800&v=beta&t=n0-5i2NRqLgDeP_414-MZrzDY2BFfYRNETn4QwWubVo"
    fb_handle = "GreatPlacetoWork"
    linkedin_ad_library_url = (
        "https://www.linkedin.com/ad-library/search?companyIds=28924"
    )

    # create new doc in proposal_companies
    proposal_company_id = _FS.add_document(
        "proposal_companies",
        {
            "domain": domain_to_add,
            "role": "competitor",
            "created_at": dt.datetime.now(),
            "facebook_handle": fb_handle,
            "linkedin_ad_library_url": linkedin_ad_library_url,
            "company_info": {
                "domain": domain_to_add,
                "name": company_name,
                "logo": logo_url,
            },
        },
    )

    # update proposal doc
    competitors_d = _FS.get_single_document("proposal", proposal_id)["competitors"]
    competitors_d[domain_to_add] = proposal_company_id
    _FS.update_document(
        "proposal",
        proposal_id,
        {"competitors": competitors_d},
    )
