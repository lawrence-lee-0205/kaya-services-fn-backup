import datetime as dt

from firestore import FirestoreClient

if __name__ == "__main__":
    _FS = FirestoreClient()
    # _FS.update_document(
    #     collection="proposal_companies",
    #     id="JUBxECgNeTX4P96fAgnz",
    #     content={
    #         "company_info.logo": "https://media.licdn.com/dms/image/C4D0BAQEPrI-RmSi-sw/company-logo_200_200/0/1631338572585?e=1723075200&v=beta&t=Jb0tvPS-bz_ADkPqHMUnnShd_-5JAi4LAEKha6Ir7g8",
    #     },
    # )

    _FS.update_document(
        collection="businesses",
        id="gVUV3Wc2p70PWq7WKXBR",
        content={
            "status_coin": {
                "trial_start_date": dt.datetime.now(),
                "trial_end_date": dt.datetime.now() + dt.timedelta(days=7),
                "is_on_trial": True,
            },
            "is_coin_enabled": True,
        },
    )
