import os

import papermill as pm
from firestore import FirestoreClient

_FS = FirestoreClient()
_CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))

if __name__ == "__main__":
    proposal_id = "IT5SyWDKOrshQEqad9rt"
    country = "us"

    # define param for notebook setup
    google_cred_path = f"{_CURRENT_DIR}/../../.local/kaya-apps-00-prod.json"
    # should point to /services
    system_path = f"{_CURRENT_DIR}/.."

    # define input and output directories
    input_notebook_dir = f"{_CURRENT_DIR}/notebook"
    output_dir = f"{_CURRENT_DIR}/../../.local/papermill/{proposal_id}"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    p = _FS.get_single_document("proposal", proposal_id)
    proposal_company_ids = [p["proposal_company_id"]] + list(p["competitors"].values())
    # proposal_company_ids = proposal_company_ids[:1]
    # proposal_company_ids = ["9YQswVQaDm35dyrh5z8s"]

    print("Lead:\n", p["proposal_company_id"])
    print()
    print("Competitors:\n", p["competitors"])

    #  run notebook for monthly digest
    print("Processing proposal: ", proposal_id)
    pm.execute_notebook(
        f"{input_notebook_dir}/MonthlyDigest_AnalyseSingleCompany.ipynb",
        f"{output_dir}/MonthlyDigest_AnalyseSingleCompany_{proposal_id}.ipynb",
        parameters=dict(
            proposal_id=proposal_id,
            system_path=system_path,
            google_cred_path=google_cred_path,
        ),
    )
