from os import environ

from apify_client import ApifyClient
from firestore import FirestoreClient

from ad_research.ad_utils import write_json_to_bucket
from ad_research.test_ad_research.test_get_meta_ads import mock_get_meta_ads_from_apify

from common import validate_inputs
from http_function import process_request_inputs, http_function


_FS = FirestoreClient()
_APIFY_CLIENT = ApifyClient(environ["APIFY_API_KEY"])
_APIFY_ACTOR_ID = "JJghSZmShuco4j9gJ"

_RESULT_LIMIT = 5000


@http_function
def research_get_meta_ads(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)
    print(data)

    output = execute_get_meta_ads(data["proposal_company_id"], data["env"])
    return output


def execute_get_meta_ads(proposal_company_id, env="dev"):
    ## dev
    if env.upper() == "DEV":
        meta_ads = mock_get_meta_ads_from_apify()

        out = write_json_to_bucket(proposal_company_id, "meta_ads", {"items": meta_ads})
        return out

    ## prod
    doc = _FS.get_single_document("proposal_companies", proposal_company_id)

    fb_handle = doc.get("facebook_handle")

    if not fb_handle:
        write_json_to_bucket(proposal_company_id, "meta_ads", {})
        print("FB handle not available. Skipping...")
        return {}

    # get ads
    meta_ads = get_meta_ads_from_apify(fb_handle)

    if not meta_ads:
        write_json_to_bucket(proposal_company_id, "meta_ads", {})
        print("Meta ad not available in Apify. Skipping...")
        return {}

    # write to cloud storage
    out = write_json_to_bucket(proposal_company_id, "meta_ads", {"items": meta_ads})
    return out


def get_meta_ads_from_apify(fb_handle):
    # RUN FACEBOOK ADS
    url = f"https://www.facebook.com/{fb_handle}/?ref=page_internal"
    print(url)

    # Prepare the Actor input
    run_input = {
        "startUrls": [{"url": url}],
        "resultsLimit": _RESULT_LIMIT,
    }

    # Run the Actor and wait for it to finish
    run = _APIFY_CLIENT.actor(_APIFY_ACTOR_ID).call(run_input=run_input)

    # Fetch and print Actor results from the run's dataset (if there are any)
    meta_ads = [
        item for item in _APIFY_CLIENT.dataset(run["defaultDatasetId"]).iterate_items()
    ]

    return meta_ads


if __name__ == "__main__":
    proposal_company_id = "test_competitor_everlywell"
    env = "dev"
    output = execute_get_meta_ads(proposal_company_id, env)
    print(output)
    print("Done")
