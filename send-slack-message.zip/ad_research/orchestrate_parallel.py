import time
from os import environ
import concurrent.futures
import threading
from firestore import FirestoreClient
from ad_research.consolidate_all_ads import get_and_process_ads
from ad_research.load_ads_from_storage_to_algolia import load_single_company_to_algolia
from ad_research.assign_tags_from_ads import assign_tags_from_algolia
from ad_research.upload_ads_images_to_storage import upload_ads_images
from ad_research.get_google_ads_keywords import consolidate_gad_keywords_to_gsheet
from ad_research.k_algolia import partial_update_algolia_objects
from ad_research.proposal_company import ProposalCompany

from algoliasearch.search_client import SearchClient

_FS = FirestoreClient()
_ENV = "prod"

if __name__ == "__main__":
    if "SPYFU_API_KEY" not in environ or "ALGOLIA_API_KEY" not in environ:
        raise Exception("SPYFU_API_KEY and ALGOLIA_API_KEY not found in env var")

    start_time = time.time()

    proposal_id = "testproposal"
    force_overwrite = True

    # get proposal_company_ids
    p = _FS.get_single_document("proposal", proposal_id)

    proposal_company_ids = list(p["competitors"].values()) + [p["proposal_company_id"]]

    print(p["competitors"])
    print(proposal_company_ids)
    # proposal_company_ids = [
    #     "kBp3uArxJJFXPJprwhq5",
    #     "BDvJvHRaYg9cQRIWGmQO",
    #     "8K2rVbCpFRsBQ0U5sYjT",
    #     "lo1yVts0PyhCZZ58glho",
    #     "5xBhvc5GSjOvC8rCTjZa",
    #     "82XgRRZJWjcBNC9jaP1Z",
    #     "LHmRqQ7HUBvT7kDCb6Wx",
    #     "zIyQu7QzfkcewLcb6mBG",
    #     "bpJUmntv2k9V4eaQhCZV",
    #     "DxSkTmehva9PjIJHN6LI",
    #     "faNuhdn3cRd0aDoCTCqR",
    # ]

    # preprocess ads:
    # get ads from different platforms, check if scraped before
    # stadardise ad formatting
    # load to algolia

    overall_status_tracker = {}

    for pc_id in proposal_company_ids:
        ad_platforms = []

        pc_obj = ProposalCompany(pc_id, proposal_id)

        pc_doc = _FS.get_single_document("proposal_companies", pc_id)
        company_name = pc_obj.business_name
        scraped_channels = pc_obj.channel_with_ads
        company_country = pc_obj.country

        print("\n\n💞 Processsing ", pc_id, " ", company_name, " ", pc_obj.domain)

        # check if exists
        # google
        if force_overwrite or "google_ads" not in scraped_channels:
            ad_platforms.append("google_ads")
        else:
            print("Google ads already scraped. Skipping...")

        # facebook
        if force_overwrite or "meta_ads" not in scraped_channels:
            fb_handle = pc_obj.facebook_handle
            if fb_handle and len(fb_handle) > 0:
                ad_platforms.append("meta_ads")
        else:
            print("Meta ads already scraped. Skipping...")

        # linkedin
        if force_overwrite or "linkedin_ads" not in scraped_channels:
            li_ad_library_url = pc_obj.linkedin_ad_library_url
            if li_ad_library_url and len(li_ad_library_url) > 0:
                ad_platforms.append("linkedin_ads")
        else:
            print("LI ads already scraped. Skipping...")

        # tiktok
        # check if search terms is available and not US
        tt_search_terms = pc_obj.get("tiktok_search_terms", [])
        if len(tt_search_terms) > 0:
            if company_country != "US":
                ad_platforms.append("tiktok_ads")
            else:
                print("TikTok ad library doesn't handle US. Skipping...")
        else:
            print("TikTok search terms not available. Skipping...")

        # bing
        # check if any element in the list is a non-empty string
        bing_search_terms = pc_obj.get("bing_search_terms", [])
        if len(bing_search_terms) > 0:
            if company_country != "US":
                ad_platforms.append("bing_ads")
            else:
                print("Bing ad library doesn't handle US. Skipping...")
        else:
            print("Bing search terms not available. Skipping...")

        # TODO: to handle case for tiktok and bing where company has presence in multiple countries

        # update ad platforms
        overall_status_tracker[pc_id] = ad_platforms
        print(f"{pc_id}: ", overall_status_tracker[pc_id])

        # exit function if no ad platform is associated
        if not ad_platforms:
            print(f"No ads found for {pc_id}. Skipping...")
            continue

        # thread processing by ad platforms
        threads = []
        for platform in ad_platforms:
            thread = threading.Thread(
                target=get_and_process_ads,
                args=(pc_id, proposal_id, platform, _ENV),
            )
            threads.append(thread)
            thread.start()
            print(f"Started thread for platform {platform}")

        if threads:
            for thread in threads:
                thread.join()
            print(f"Joined threads")

        # load to algolia
        load_single_company_to_algolia(pc_id)

        print(f"Done data processing for {pc_id}.")

        time.sleep(2)

    # print("overall_status_tracker for all companies: ", overall_status_tracker)

    # postprocess ads:
    # assign tags at algolia
    # upload meta images to bucket
    # update algolia

    update_algolia_list = []
    for pc_id in proposal_company_ids:

        if not overall_status_tracker[pc_id]:
            continue

        with concurrent.futures.ThreadPoolExecutor() as executor:
            assign_tags = executor.submit(assign_tags_from_algolia, pc_id)
            assign_tags_output = assign_tags.result()
            if assign_tags_output:
                update_algolia_list.extend(assign_tags_output)

            upload_meta_images = executor.submit(upload_ads_images, pc_id, "meta_ads")
            upload_meta_images_output = upload_meta_images.result()
            if upload_meta_images_output:
                update_algolia_list.extend(upload_meta_images_output)

            upload_linkedin_images = executor.submit(
                upload_ads_images, pc_id, "linkedin_ads"
            )
            upload_linkedin_images_output = upload_linkedin_images.result()
            if upload_linkedin_images_output:
                update_algolia_list.extend(upload_linkedin_images_output)

        print(f"Done post-processing data for {pc_id}.")

        time.sleep(2)

    # update algolia
    if update_algolia_list:
        partial_update_algolia_objects(update_algolia_list)

    # upload keywords to gsheet
    unq_platforms = list(set(overall_status_tracker.values()))
    if "google_ads" in unq_platforms:
        consolidate_gad_keywords_to_gsheet(proposal_id)

    print("-------------------\n\n")
    print("--- %s seconds ---" % (time.time() - start_time))
