import re
import json

from storage.upload_blob import upload_blob

_BUCKET = "kaya-ads-research"

tags_keywords_mapping_dict = {
    "Product Launch": [
        "launch",
        "debut",
        "release",
        "unveiling",
        "premiere",
        "announcement",
    ],
    "Seasonal": [
        "Christmas",
        "summer",
        "winter",
        "Easter",
        "holiday",
        "autumn",
        "spring",
        "Halloween",
        "Thanksgiving",
        "seasonal",
    ],
    "Limited Offer": ["exclusive offer", "special offer", "one-time"],
    "Webinar": [
        "webinar",
        "seminar",
        "workshop",
        "livestream",
        "online event",
        "virtual",
        "webcast",
        "tutorial",
        "conference",
        "e-learning",
    ],
    "Event": [
        "event",
        "festival",
        "conference",
        "expo",
        "concert",
        "meetup",
        "seminar",
    ],
    "Promotion": ["discount", "sale", "promotion", "promo", "markdown"],
    "Lead Generation": [
        "subscribe",
        "register",
        "sign up",
        "join",
        "free trial",
        "download",
        "enrollment",
        "opt-in",
        "apply",
        "membership",
    ],
    "Educational": [
        "tutorial",
        "guide",
        "training",
        "workshop",
        "how-to",
        "course",
    ],
    "Testimonial": [
        "testimonial",
        "review",
        "feedback",
        "case study",
        "endorsement",
        "testimony",
    ],
    "Urgency": ["hurry", "urgent", "expiring", "limited-time", "limited time"],
    "Engagement": ["interactive", "contest", "poll", "survey"],
    "Community Building": ["community", "membership", "fellowship", "collective"],
    "Influencer Collaboration": [
        "collaboration",
        "influencer",
        "partner",
        "featuring",
        "guest",
        "celebrity",
        "star",
        "endorsement",
        "ambassador",
        "co-create",
    ],
    "Lead Magnet": [
        "download",
        "access",
        "exclusive",
        "bonus",
        "checklist",
        "cheat Sheet",
        "free guide",
        "ebook",
        "whitepaper",
        "free template",
        "toolkit",
        "webinar",
        "case Study",
        "free report",
        "blueprint",
        "swipe file",
        "masterclass",
        "mini-course",
        "mini course",
        "free pdf",
        "consultation",
        "strategy session",
        "get your free",
        "download now",
        "access now",
        "sign up for free",
        "unlock your free",
        "start your free trial",
        "register now",
        "claim your free",
    ],
}


country_mapping_dict = {
    "AT": "Austria",
    "BE": "Belgium",
    "BG": "Bulgaria",
    "HR": "Croatia",
    "CY": "Republic of Cyprus",
    "CZ": "Czech Republic",
    "DK": "Denmark",
    "EE": "Estonia",
    "FI": "Finland",
    "FR": "France",
    "DE": "Germany",
    "GR": "Greece",
    "HU": "Hungary",
    "IE": "Ireland",
    "IT": "Italy",
    "LV": "Latvia",
    "LT": "Lithuania",
    "LU": "Luxembourg",
    "MT": "Malta",
    "NL": "Netherlands",
    "PL": "Poland",
    "PT": "Portugal",
    "RO": "Romania",
    "SK": "Slovakia",
    "SI": "Slovenia",
    "ES": "Spain",
    "SE": "Sweden",
    "NO": "Norway",
    "IS": "Iceland",
    "LI": "Liechtenstein",
    "GB": "United Kingdom",
    "CH": "Switzerland",
}


def tag_ad_copy(ad_copy):
    # List to store the tags for this ad copy
    tags = []

    # Check each set of keywords and add the corresponding tag if any keyword is found
    for tag, keywords in tags_keywords_mapping_dict.items():
        print("iterating on tags")
        # Create a regular expression pattern to match any of the keywords (case insensitive)
        pattern = (
            r"\b(?:" + "|".join(re.escape(keyword) for keyword in keywords) + r")\b"
        )
        if re.search(pattern, ad_copy, re.IGNORECASE):
            tags.append(tag)

    return tags


def write_json_to_bucket(proposal_company_id, file_name, content):
    tmp_file = f"/tmp/{file_name}.json"
    blob_name = f"{proposal_company_id}/{file_name}.json"

    with open(tmp_file, "w") as file:
        json.dump(content, file)

    upload_blob(_BUCKET, tmp_file, blob_name)

    return {
        "status": "write success",
        "storage_url": _BUCKET + "/" + blob_name,
    }


if __name__ == "__main__":
    pass
