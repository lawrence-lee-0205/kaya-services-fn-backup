import json
from os import environ

from common import validate_inputs
from http_function import http_function, process_request_inputs
from storage.download_blob import download_blob_into_string
from firestore import FirestoreClient
from algoliasearch.search_client import SearchClient


_BUCKET = "kaya-ads-research"
_FS = FirestoreClient()
_ALGOLIA_CLIENT = SearchClient.create("9UOFA9X1DB", environ["ALGOLIA_API_KEY"])


@http_function
def research_load_ads_to_algolia(request_json={}, request_args={}):
    mandatory_fields = ["proposal_company_id", "channel"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    res = execute(
        proposal_company_id=data["proposal_company_id"],
        channel=data["channel"],
    )
    return res


def load_single_company_to_algolia(proposal_company_id):
    # create a new index and add a record
    index = _ALGOLIA_CLIENT.init_index("ad_research_sample")

    # read consolidated_ads.json from bucket
    # upload to algolia
    records = json.loads(
        download_blob_into_string(
            _BUCKET, f"{proposal_company_id}/consolidated_ads.json"
        )
    )
    print(len(records), "records to be uploaded to Algolia.")
    res = index.save_objects(records)
    print(type(res))
    if "unreachable hosts" in str(res):
        raise Exception("🫠 Failed to upload to Algolia.", res)
    print("Done uploading to Algolia.")

    return None


def execute(proposal_company_id, channel):
    # create a new index and add a record
    index = _ALGOLIA_CLIENT.init_index("ad_research_sample")

    # read from bucket then upload to algolia
    records = json.loads(
        download_blob_into_string(
            _BUCKET, f"{proposal_company_id}/consolidated_{channel}.json"
        )
    )
    print(len(records), "records to be uploaded to Algolia.")
    index.save_objects(records)
    print("Done uploading to Algolia.")

    return None


# if __name__ == "__main__":
#     proposal_id = "Z9ED7j0E86Got8K4tJvJ"

#     p = _FS.get_single_document("proposal", proposal_id)
#     proposal_company_ids = [p["proposal_company_id"]] + list(p["competitors"].values())

#     proposal_company_ids = [
#         # "T4vMjy8RYq26pMuWXkdy",
#         "VVG732SukzlQ8gXLL9HW",
#         # "iIcxooJOFdhB6RnJkkXl",
#         # "YT22pJo6TtughUHAEOjF",
#     ]

#     for pc_id in proposal_company_ids:
#         load_single_company_to_algolia(pc_id)


# if __name__ == "__main__":
#     import time
#     from ad_research.consolidate_all_ads import consolidate_single_company

#     start_time = time.time()

#     proposal_id = "uwEFpntcXmq0tkq5jeOU"

#     p = _FS.get_single_document("proposal", proposal_id)
#     proposal_company_ids = [p["proposal_company_id"]] + list(p["competitors"].values())
#     # proposal_company_ids = ["lo1yVts0PyhCZZ58glho"]

#     for pc_id in proposal_company_ids:
#         try:
#             consolidate_single_company(pc_id, proposal_id)
#             load_single_company_to_algolia(pc_id)
#         except Exception as e:
#             print(e)

#     print("--- %s seconds ---" % (time.time() - start_time))


if __name__ == "__main__":
    proposal_company_id = "test_competitor_klarify"
    channel = "google_ads"
    execute(proposal_company_id, channel)
