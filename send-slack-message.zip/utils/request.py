import requests


def call_api(api, headers={}, params={}, output_fmt="json", **kwargs):
    response = requests.get(url=api, headers=headers, params=params, **kwargs)
    if response.status_code != 200:
        print(
            f"Error. Received response when calling {api} ",
            response.status_code,
            response.json,
        )
        raise Exception(
            "Error. Received response ", response.status_code, response.json
        )

    if output_fmt == "text":
        return response.text
    elif output_fmt == "raw":
        return response
    else:
        return response.json()
