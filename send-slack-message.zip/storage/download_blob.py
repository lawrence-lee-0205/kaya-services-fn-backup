import time

from google.cloud import storage
from google.api_core.exceptions import GoogleAPICallError, RetryError

STORAGE_CLIENT = storage.Client()


def _download_file(
    bucket_name, source_blob_name, destination_file_name=None, output_fmt="file"
):
    """Downloads a blob from the bucket."""
    bucket = STORAGE_CLIENT.bucket(bucket_name)
    blob = bucket.blob(source_blob_name)

    try:
        if output_fmt == "file":
            blob.download_to_filename(destination_file_name)
            print(f"File {source_blob_name} downloaded to {destination_file_name}.")
            return destination_file_name
        elif output_fmt == "string":
            content = blob.download_as_string()
            print(
                f"Downloaded storage object {source_blob_name} from bucket {bucket_name} as string"
            )
            return content
    except GoogleAPICallError as e:
        print(f"Failed to download due to an API error: {e}")
        return None
    except RetryError as e:
        print(f"Retry attempts failed: {e}")
        return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None


def retry_download(
    bucket_name,
    source_blob_name,
    destination_file_name=None,
    output_fmt="file",
    max_retries=5,
):
    """Attempt to download a file with retries on failure."""
    attempt = 0
    while attempt < max_retries:
        output = _download_file(
            bucket_name, source_blob_name, destination_file_name, output_fmt=output_fmt
        )
        if output:
            return output
        attempt += 1
        sleep_time = 2**attempt  # Exponential backoff
        print(f"Attempt {attempt}: Retrying in {sleep_time} seconds...")
        time.sleep(sleep_time)
    raise Exception("Failed to download after several retries.")


def download_blob_into_string(bucket_name, blob_name):
    """Downloads a blob into memory."""
    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"

    # The ID of your GCS object
    # blob_name = "storage-object-name"
    content = retry_download(
        bucket_name,
        blob_name,
        destination_file_name=None,
        output_fmt="string",
        max_retries=5,
    )
    return content


def download_blob_to_filename(bucket_name, blob_name, destination_file_name):
    """Downloads a blob into memory."""
    retry_download(
        bucket_name,
        blob_name,
        destination_file_name=destination_file_name,
        output_fmt="file",
        max_retries=5,
    )
    return None


if __name__ == "__main__":
    download_blob_to_filename(
        "kaya-ads-research",
        "c6Yl5sqDNnW332qJSwXQ/google_ads.json",
        "/tmp/c6Yl5sqDNnW332qJSwXQ_google_ads.json",
    )
