from google.cloud import storage

STORAGE_CLIENT = storage.Client()


def list_blob(bucket, prefix, delimiter):
    storage_client = storage.Client()
    blobs = storage_client.list_blobs(bucket, prefix=prefix, delimiter=delimiter)
    blobs = [blob.name for blob in blobs]
    return blobs


def check_blob_exist(bucket_name, blob_name) -> bool:
    bucket = STORAGE_CLIENT.bucket(bucket_name)
    stats = storage.Blob(bucket=bucket, name=blob_name).exists(STORAGE_CLIENT)
    return stats


if __name__ == "__main__":
    name = "testcompetitorcompany/120201854462710577"
    bucket_name = "kaya-ads-research-images"
    is_exist = check_blob_exist(bucket_name, name)
    print(is_exist)
