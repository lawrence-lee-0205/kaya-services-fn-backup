import decimal


def get_emoji(value):
    if not isinstance(value, float) and not isinstance(value, decimal.Decimal):
        return ""

    if value > 0:
        return "▲"
    elif value < 0:
        return "▼"
    elif value == 0:
        return ""


def str_format_kpi(number, metric_name):
    if metric_name in ["cost", "revenue"]:
        return f"${number:,.0f}"
    elif metric_name in ["cost_per_goal", "cost_per_lead", "cost_per_acquisition"]:
        return f"${number:,.2f}"
    elif metric_name in ["roi", "return_on_ads_spend"]:
        return f"{number:.2f}x"
    elif metric_name in ["ctr", "pct_change", "conversion_rate", "bounce_rate"]:
        return f"{number:.2f}%"
    elif metric_name in ["ctr_int", "pct_change_int"]:
        return f"{number:.0f}%"
    elif metric_name in [
        "goal",
        "transactions",
        "num_visitors",
        "num_sessions",
        "num_leads",
        "num_signups",
    ]:
        return f"{number:,.0f}"
    elif metric_name in ["num_page_views_per_session", "avg_session_duration_sec"]:
        return f"{number:,.2f}"
    elif metric_name in ["avg_session_duration_sec"]:
        return f"{number:,.2f}s"
    else:
        raise ValueError(
            f"metric_name provided is not recognised. Received: {metric_name}"
        )
