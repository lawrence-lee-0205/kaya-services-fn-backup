import os
import datetime as dt

from slack_sdk import WebClient
from noloco.request import call_noloco_api
from http_function import http_function, process_request_inputs
from slack_tools.convert_slack_markdown import convert_to_slack_markdown

_SLACK_CLIENT = WebClient(token=os.environ["SLACK_BOT_TOKEN"])
STATUS_NAME_MAPPING = {
    "BACKLOG": "⚪ Backlog",
    "TO_DO": "⚫ Queue",
    "IN_PROGRESS": "🟡 Being Worked On",
    "IN_REVIEW": "🟢 In Review",
    "DONE": "✅ Completed",
}


@http_function
def slack_unfurl_url(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)
    output = execute(data)
    return output


def execute(data):
    if len(data["event"]["links"]) >= 3:
        # do not unfurl if there are more than 3 links
        return None

    unfurls = {}
    for link in data["event"]["links"]:
        # get task metadata
        url = link["url"].replace("'", "")
        task_uuid = url.split("/tasks/")[1].split("?")[0].split("/")[0]

        task_detail = _get_task_detail(task_uuid)

        description = (
            convert_to_slack_markdown(task_detail["description"])
            if len(task_detail["description"]) > 0
            else "_None_"
        )

        status = STATUS_NAME_MAPPING.get(task_detail["status"], task_detail["status"])
        fields = [{"type": "mrkdwn", "text": f"*Status:*\n{status}"}]

        try:
            due_date = task_detail.get("due_date")[:10]
            # parse due date to date object and reformat to MMM DD
            due_date = dt.datetime.strptime(due_date, "%Y-%m-%d").strftime("%b %d")
            fields.append({"type": "mrkdwn", "text": f"*Due:*\n{due_date}"})
        except Exception as e:
            print("Error parsing due date")
            print(e)

        url_with_business_id = f"https://app.usekaya.com/tasks/{task_uuid}?client={task_detail['business_id']}"

        task_content_limit_char = 300
        task_content = f"*{task_detail['name']}*\n{description}"
        # truncate task content if it has more than 100 characters
        if len(task_content) > task_content_limit_char:
            task_content = task_content[:task_content_limit_char] + "..."

        unfurls[url] = {
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": task_content,
                    },
                },
                {"type": "section", "fields": fields},
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"<{url_with_business_id}|View task>",
                    },
                },
            ]
        }

    response = _SLACK_CLIENT.api_call(
        api_method="chat.unfurl",
        params={
            "channel": data["event"]["channel"],
            "ts": data["event"]["message_ts"],
            "unfurls": unfurls,
        },
    )
    print(response)
    return None


def _get_task_detail(task_uuid):
    query = f"""
    query MyQuery {{
        taskCollection(where: {{uuid: {{equals: "{task_uuid}"}}}}) {{
            edges {{
                node {{
                    name
                    dueDate
                    description
                    status
                    company {{
                        fsId
                    }}
                }}
            }}
        }}
    }}
    """
    output = call_noloco_api(query)

    tasks = output["data"]["taskCollection"]["edges"]
    if len(tasks) == 0:
        raise Exception(f"Cannot find task with uuid {task_uuid}")
    elif len(tasks) > 1:
        raise Exception(f"Found more than 1 task with uuid {task_uuid}")

    task = tasks[0]["node"]

    return {
        "name": task["name"],
        "due_date": task["dueDate"],
        "description": task["description"],
        "status": task["status"],
        "business_id": task["company"]["fsId"],
    }


if __name__ == "__main__":
    data = {}
    execute(data)
