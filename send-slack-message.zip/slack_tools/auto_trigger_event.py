import requests

from http_function import http_function_with_header, process_request_inputs
from google.cloud_functions.call_cloud_function import call_cloud_function


@http_function_with_header
def slack_auto_trigger_event(
    request_json=None, request_args=None, request_header=None, *args, **kwargs
):
    # TODO: VALIDATE THAT IT'S COMING FROM SLACK
    """This API is called whenever an event we subscribed to (https://api.slack.com/apps/A02PKPBQWRH/event-subscriptions?) is triggered."""
    data = process_request_inputs(request_json, request_args)

    # print(data)
    if data["type"] == "url_verification":
        return {"challenge": data["challenge"]}

    if data["type"] == "event_callback" and data["event"]["type"] == "link_shared":
        print("Calling slack-unfurl-url")
        _ = requests.post(
            "https://us-central1-kaya-apps-00.cloudfunctions.net/slack-unfurl-url",
            json=data,
        )
        return {"status": "Success"}

    retry_num = request_header.get("X-Slack-Retry-Num", "0")
    print("Retry num: ", retry_num)

    if (
        data["event"]["type"] == "message"
    ):  # and data["event"]["channel_type"] == "im": can't do this as sometimes the notification is sent to channel
        print("Received message event")
        thread_ts = data["event"].get("thread_ts")

        if thread_ts is None:
            print(
                "Thread ts is None. This event is not triggered via a reply in thread. Aborting.."
            )
            return {"status": "Success"}

        message_received_txt = data["event"]["text"]
        sender_slack_id = data["event"]["user"]
        channel = data["event"]["channel"]
        client_msg_id = data["event"]["client_msg_id"]
        print(message_received_txt, sender_slack_id, thread_ts, channel, client_msg_id)

        # add comment back to the tix
        payload = {
            "comment_content": message_received_txt,
            "sender_slack_id": sender_slack_id,
            "thread_ts": thread_ts,
            "retry_num": retry_num,
            "client_msg_id": client_msg_id,
            "channel": channel,
        }
        call_cloud_function("/slack-create-task-comment", payload)
        return {"status": "Success"}

    if (
        data["type"] == "event_callback"
        and data["event"]["type"] == "app_mention"
        # only care about request from #data-report-request
        and data["event"]["channel"] == "C05KE0Y8Y3C"
        # retry num 1 is sent immediately after the 1st proper call. This could cause duplicate messages, so we choose to skip it.
        # https://api.slack.com/apis/connections/events-api#retries
        and retry_num != "1"
    ):
        print("Calling slack-send-report-on-demand")
        _ = requests.post(
            "https://us-central1-kaya-apps-00.cloudfunctions.net/slack-send-report-on-demand",
            json=data,
        )
        return {"status": "Success"}

    return {"status": "Success"}


if __name__ == "__main__":
    d = {
        "event": {
            "client_msg_id": "54f46182-b3df-4e13-94fc-6b33c95894ff",
            "type": "message",
            "text": "test",
            "user": "U02P4RZDN5P",
            "ts": "1700570668.432379",
            "blocks": [
                {
                    "type": "rich_text",
                    "block_id": "gB9fq",
                    "elements": [
                        {
                            "type": "rich_text_section",
                            "elements": [{"type": "text", "text": "test"}],
                        }
                    ],
                }
            ],
            "thread_ts": "1700569803.644639",
            "parent_user_id": "U02PN0WJ2G4",
            "channel": "D02Q9E7JEL8",
            "event_ts": "1700570668.432379",
            "channel_type": "im",
        },
        "type": "event_callback",
    }
