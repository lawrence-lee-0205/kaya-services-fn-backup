from common import validate_and_fix_bid
from constants import MILLION


def convert_to_micro_unit(amount: float, **kwargs) -> int:
    """Convert nominal value to micro unit and
    validate resultant value

    Args:
        amount (float)

    Returns: int
    """
    if not isinstance(amount, float):
        amount = float(amount)

    amount_micros = int(amount * MILLION)
    return validate_and_fix_bid(amount_micros, **kwargs)
