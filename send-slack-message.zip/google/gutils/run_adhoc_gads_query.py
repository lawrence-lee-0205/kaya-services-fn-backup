from google.protobuf import json_format

from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.ads_query import run_ads_query
from http_function import http_function


@http_function
def run_adhoc_gads_query(request_json={}, request_args={}):
    print(request_json)
    print(request_args)
    mandatory_fields = ["business_id", "query"]

    for m in mandatory_fields:
        if m not in request_json:
            raise Exception(f"Expecting {m} to be provided")

    results_raw = execute(request_json["business_id"], request_json["query"])
    results = [json_format.MessageToDict(res._pb) for res in results_raw]
    return results


def execute(business_id, query):
    google_ads_account = GoogleAdsAccount(business_id=business_id)
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )
    return rows


if __name__ == "__main__":
    import pandas as pd

    business_id = "Jr9lVYdpq7fx9N63LbV6"
    start_date = "2023-10-01"
    end_date = "2023-12-01"

    query = f"""
    SELECT 
        search_term_view.search_term, 
        search_term_view.status, 
        metrics.all_conversions,
        metrics.all_conversions_value, 
        metrics.conversions,
        metrics.conversions_value,
        metrics.cost_micros, 
        metrics.impressions,
        metrics.clicks, 
        ad_group.name, 
        campaign.name, 
        segments.keyword.ad_group_criterion, 
        segments.keyword.info.text, 
        segments.keyword.info.match_type 
    FROM search_term_view 
    WHERE segments.keyword.info.text LIKE '%text classification%' 
        AND segments.date <= '{ start_date }' 
        AND segments.date >= '{ end_date }'
    """
    rows = execute(business_id, query)

    output = [json_format.MessageToDict(res._pb) for res in rows]
    print(output)

    outputs = []
    for row in rows:
        print(row)
        out = {
            "search_term": row.search_term_view.search_term,
            "status": row.search_term_view.status.name,
            "all_conversions": row.metrics.all_conversions,
            "all_conversions_value": row.metrics.all_conversions_value,
            "clicks": row.metrics.clicks,
            "conversions": row.metrics.conversions,
            "conversions_value": row.metrics.conversions_value,
            "cost_micros": row.metrics.cost_micros,
            "impressions": row.metrics.impressions,
            "name": row.ad_group.name,
            "name": row.campaign.name,
            "keyword_resource_name": row.segments.keyword.ad_group_criterion,
            "keyword_text": row.segments.keyword.info.text,
            "keyword_match_type": row.segments.keyword.info.match_type.name,
        }
        outputs.append(out)
    output_df = pd.DataFrame(outputs)

    q = f"""
    SELECT 
        search_term_view.search_term, 
        segments.conversion_action_name,
        metrics.all_conversions_value, 
        metrics.all_conversions, 
        metrics.conversions,
        metrics.conversions_value
    FROM search_term_view
    WHERE segments.keyword.info.text LIKE '%text classification%' 
        AND segments.date <= '{ start_date }' 
        AND segments.date >= '{ end_date }'
    """
    rows_q = execute(business_id, q)
    output_q = []
    for row in rows_q:
        print(row)
        out = {
            "search_term": row.search_term_view.search_term,
            "conversion_action_name": row.segments.conversion_action_name,
            "all_conversions_value": row.metrics.all_conversions_value,
            "all_conversions": row.metrics.all_conversions,
            "conversions": row.metrics.conversions,
            "conversions_value": row.metrics.conversions_value,
        }
        output_q.append(out)
    outputq_df = pd.DataFrame(output_q)

    outputq_df.to_csv("outputq_df.csv", index=0)

    # if row.campaign.name == "Security Deposit Alternatives":
    #     print(row)
