import datetime

from firestore import FirestoreClient, DESCENDING

FS = FirestoreClient()


def get_last_google_api_timestamp(service: str):
    collection_ref = FS.get_collection("google_api_requests")
    docs = (
        collection_ref.where("service", "==", service)
        .order_by("created_at", direction=DESCENDING)
        .limit(1)
        .stream()
    )

    timestamps = [doc.to_dict()["created_at"] for doc in docs]
    if len(timestamps) > 0:
        return max(timestamps)

    return None


def insert_last_google_api_timestamp(
    service: str, function: str, num_operations: int = 1
) -> str:
    doc_id = FS.add_document(
        "google_api_requests",
        {
            "created_at": datetime.datetime.utcnow(),
            "function": function,
            "service": service,
            "num_operations": num_operations,
        },
    )
    return doc_id


def get_google_analytics_view_id(business_id: str) -> str:
    """Get Google Analytics' View ID for a specific business

    Args:
        business_id (str): [description]

    Raises:
        KeyError: [description]

    Returns: str
    """
    business = FS.get_single_document("businesses", business_id)
    try:
        view_id = business["google_analytics_view_id"]
    except KeyError:
        raise KeyError(
            f"Business {business_id} does not have 'google_analytics_view_id' set."
        )
    return view_id


################################
#        GOOGLE ACCOUNT        #
################################


def get_google_account(business_id: str) -> dict:
    account_ref = (
        FS.get_collection("google_accounts")
        .where("business_id", "==", business_id)
        .stream()
    )
    gads_accounts = FS.convert_stream_to_list(account_ref, skip_id=True)
    if len(gads_accounts) > 1:
        raise Exception(
            f"More than 1 active G ads account found for business id {business_id} in google_accounts collection"
        )
    elif len(gads_accounts) == 0:
        raise Exception(
            f"No google_account found for in biz {business_id} in google_accounts collection"
        )
    else:
        return gads_accounts[0]


def get_google_account_id(business_id):
    account = get_google_account(business_id)
    return account["client_id"]


def get_google_account_by_client_id(client_id: str):
    docs = (
        FS.get_collection("google_accounts")
        .where("client_id", "==", client_id)
        .stream()
    )
    google_accounts = [{**doc.to_dict()} for doc in docs]

    if len(google_accounts) != 1:
        raise Exception(
            f"Expecting to find 1 google account linked to client_id '{client_id}'. Found {len(google_accounts)} instead."
        )

    return google_accounts[0]


################################
#           AUDIENCE           #
################################


def get_google_audience(audience_id):
    # TODO: ONLY RETURN IF AUDIENCE_ID BELONG UNDER GIVEN BUSINESS_ID

    # TODO: what happen if 1 criteria ID is used in both include n exclude?
    print(f"Getting audience definition for {audience_id}")
    audience_dict = FS.get_single_document("google_audiences", audience_id)
    audience_criteria_docs = FS.get_all_documents_within_subcollection(
        f"google_audiences/{audience_id}/criteria"
    )  # list of dict

    includes, excludes = get_audience_include_exclude_values(audience_criteria_docs)

    audience_dict["includes"] = includes
    audience_dict["excludes"] = excludes
    return audience_dict


def get_location_lang_from_audience(audience_id):
    audience = get_google_audience(audience_id)

    if "includes" in audience:
        includes = audience["includes"]
        incl_locations = includes.get("location", [])
        incl_languages = includes.get("language", [])

    if "excludes" in audience:
        # TODO: IMPLEMENT EXCLUDE FLOW
        pass
    return {"locations": incl_locations, "languages": incl_languages}


def get_audience_include_exclude_values(audience_criteria_docs):
    """
    PROCESS CRITERIA COLLECTIONS TO INCLUDE AND EXCLUDE LIST
    """
    includes = {}
    excludes = {}
    for audience_criteria_doc in audience_criteria_docs:
        criteria = list(audience_criteria_doc.values())
        for criterion in criteria:
            criterion_type = criterion["type"]
            if criterion["is_include"]:
                # Check if the criterion type to add already exists in 'include' dict.
                # If it does, append new values to the list. Otherwise, create new empty list
                values = includes.get(criterion_type, [])
                criteria_ids = criterion["criteria_ids"]
                if not isinstance(criteria_ids, list):
                    raise TypeError(
                        f"Expecting criteria_ids to have type 'list', received {type(criteria_ids)} instead."
                    )
                includes[criterion_type] = values + criteria_ids
            else:
                values = excludes.get(criterion_type, [])
                criteria_ids = criterion["criteria_ids"]
                if not isinstance(criteria_ids, list):
                    raise TypeError(
                        f"Expecting criteria_ids to have type 'list', received {type(criteria_ids)} instead."
                    )
                excludes[criterion_type] = values + criteria_ids

    # remove duplicates in list
    for d in [includes, excludes]:
        for key, value in d.items():
            d[key] = list(set(value))

    return includes, excludes


#################################
#          GEO TARGETS          #
#################################


def get_criteria_id_by_country_code(country_code: str):
    docs = (
        FS.get_collection("google_geo_targets")
        .where("country_code", "==", country_code)
        .where("target_type", "==", "Country")
        .stream()
    )

    output = []
    for doc in docs:
        output.append(str(doc.id))

    if len(output) == 0:
        raise ValueError(f"No doc found with country_code = '{country_code}'")
    elif len(output) > 1:
        raise ValueError(f"More than 1 doc found with country_code = '{country_code}'")

    return output[0]


def get_country_code_by_criteria_id(criteria_id):
    if isinstance(criteria_id, str):
        criteria_id = int(criteria_id)

    # TODO: Replace by querying by ID
    docs = (
        FS.get_collection("google_geo_targets")
        .where("criteria_id", "==", criteria_id)
        .stream()
    )

    output = []
    for doc in docs:
        output.append(doc.to_dict()["country_code"])

    if len(output) > 1:
        raise Exception(
            f"More than 1 doc returned from google_geo_targets collection with criteria id = {criteria_id}"
        )
    elif len(output) == 0:
        raise Exception(
            f"No doc returned from google_geo_targets collection with criteria id = {criteria_id}"
        )
    return output[0]


def get_default_serp_location(country_code):
    from exceptions import NoDefaultSerpLocationError

    collection = FS.get_collection("google_geo_targets")

    docs = (
        collection.where("is_default_serp_location", "==", True)
        .where("country_code", "==", country_code)
        .stream()
    )

    output = []
    for doc in docs:
        output.append(doc.to_dict()["canonical_name"])

    if len(output) > 1:
        raise NoDefaultSerpLocationError(
            f"More than 1 doc returned from google_geo_targets collection where is_default_serp_location is True and country code = {country_code}"
        )
    elif len(output) == 0:
        raise NoDefaultSerpLocationError(
            f"No doc returned from google_geo_targets collection where is_default_serp_location is True and country code = {country_code}"
        )
    return output[0]


if __name__ == "__main__":
    o = get_google_account("vzsuUIgfhKRenZq6I0U5")
    print(o)

    y = get_google_account_id("vzsuUIgfhKRenZq6I0U5")
    print(y)

    print(get_google_account_by_client_id("2855240427"))
