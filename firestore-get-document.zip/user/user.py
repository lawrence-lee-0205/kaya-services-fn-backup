from firestore import FirestoreClient
from exceptions import UserNotFoundException

_COLLECTION = "users"

FS = FirestoreClient()


class User:
    def __init__(
        self, user_id: str = None, firebase_auth_id: str = None, email: str = None
    ) -> None:
        """Represent user record in 'users' collection. Either user_id or firebase_auth_id must be provided.
        If both user_id and firebase_auth_id are provided, user_id will take precendence.

        Args:
            user_id (str, optional): ID of the user document. Defaults to None.
            firebase_auth_id (str, optional): ID created by firebase Auth module. It's a key value pair
                                              within users doc. Defaults to None.
        """
        if (user_id is None) and (firebase_auth_id is None) and (email is None):
            raise Exception(
                "Either user_id or firebase_auth_id or email must be provided."
            )

        if user_id is not None:
            self._data = FS.get_single_document(_COLLECTION, user_id)
            self._user_id = user_id
        elif firebase_auth_id is not None:
            ref = (
                FS.get_collection(_COLLECTION)
                .where("firebase_auth_id", "==", firebase_auth_id)
                .stream()
            )
            users = FS.convert_stream_to_list(ref, skip_id=False)
            if len(users) > 1:
                raise Exception(
                    f"More than 1 users found for given firebase auth id in users collection"
                )
            elif len(users) == 0:
                raise UserNotFoundException(
                    f"No user found for given firebase_auth_id in users collection"
                )

            # validated that there is only 1 element in users variable
            for key, value in users[0].items():
                self._user_id = key
                self._data = value
        elif email is not None:
            ref = FS.get_collection(_COLLECTION).where("email", "==", email).stream()
            users = FS.convert_stream_to_list(ref, skip_id=False)
            if len(users) > 1:
                raise Exception(
                    f"More than 1 users found for given email in users collection"
                )
            elif len(users) == 0:
                raise UserNotFoundException(
                    f"No user found for given email {email} in users collection"
                )

            # validated that there is only 1 element in users variable
            for key, value in users[0].items():
                self._user_id = key
                self._data = value

    @property
    def user_id(self):
        return self._user_id

    @property
    def businesses(self):
        return self._data["businesses"]

    @property
    def slack_id(self):
        try:
            return self._data["slack_id"]
        except KeyError:
            raise KeyError(f"User {self.user_id} does not have slack_id")

    @property
    def has_slack_id(self):
        return "slack_id" in self._data

    @property
    def slack_channel_id(self):
        # slack channel with marketers
        return self._data["slack_channel_id"]

    @property
    def slack_dm_channel(self):
        # slack DM channel between bot and user
        return self._data["slack_dm_channel"]

    @property
    def has_slack_dm_channel(self):
        return "slack_dm_channel" in self._data

    @property
    def first_name(self):
        return self._data["first_name"]

    @property
    def full_name(self):
        return self._data["first_name"] + " " + self._data["last_name"]

    @property
    def email(self):
        return self._data["email"]

    @property
    def role(self):
        if "@marketing.usekaya.com" in self.email:
            return "marketer"
        elif "@usekaya.com" in self.email:
            return "admin"
        else:
            return "client"

    #################################
    #        PUBLIC FUNCTION        #
    #################################

    def has_access(self, business_id):
        if business_id in self.businesses:
            return True
        return False


if __name__ == "__main__":
    user = User(email="kay@marketing.usekaya.com")
    print(user._data)
    print(user.user_id)
    print(user.has_access(""))
