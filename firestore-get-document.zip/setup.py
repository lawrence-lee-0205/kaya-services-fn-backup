from traceback import print_exc
from functools import wraps
from sentry_sdk import capture_exception, flush
from flask import jsonify, make_response

from common import get_main_headers, get_options_headers, validate_auth
from user.user import User


def setup(cloud_func):
    """Setup function to run boilerplate codes for Cloud Func

    Args:
        cloud_func (func): Inner function we would like to execute

    Returns:
        flask response with status code 200 = success, 400 error
    """

    @wraps(cloud_func)
    def wrapper(request, is_auth_required=True, *args, **kwargs):
        """Args:
        request ([type]): raw request object passed from Cloud Func
        is_auth_required (bool, optional): [description]. Defaults to True.
        """
        # PROCESS REQUEST OBJECT
        request_json = request.get_json()

        request_method = request.method
        print(f"Received {request_method} request with input: {request_json}")
        if request_method == "OPTIONS":
            headers = get_options_headers()
            return make_response("", 204, headers)

        headers = get_main_headers()

        if "data" in request_json:
            request_json = request_json["data"]

        try:
            if is_auth_required:
                auth_user_id = validate_auth(request)

                if "business_id" in request_json:
                    user = User(firebase_auth_id=auth_user_id)
                    if not user.has_access(request_json["business_id"]):
                        raise Exception(
                            f"Access to business {request_json['business_id']} denied"
                        )
                request_json["auth_user_id"] = auth_user_id

            output = cloud_func(request_json, *args, **kwargs)
            return make_response(jsonify({"data": output}), 200, headers)
        except Exception as e:
            print(
                f"CAUGHT Exception of type: '{e.__class__.__name__}'",
            )
            print_exc()
            capture_exception(e)
            flush()
            return (str(e), 400, headers)

    return wrapper
