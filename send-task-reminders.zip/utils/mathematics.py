import math
import numpy as np


def calc_pct_change(new, old):
    if (
        (new in ["", None])
        or (old in ["", 0, None])
        or math.isnan(new)
        or math.isnan(old)
        or math.isinf(new)
        or math.isinf(old)
    ):
        return ""

    return 100 * (new - old) / old


def round_to_1_significant_figure(n):
    if n == 0:
        return 0
    elif n < 0:
        sign = -1
        n = -n
    else:
        sign = 1

    # Find the order of magnitude of the number
    order_of_magnitude = len(str(n)) - 1

    # Round the number to one significant figure
    rounded_number = round(n, -order_of_magnitude)

    return sign * rounded_number


def round_to_n_significant_digits(x, n):
    """Round a number x to n significant digits."""
    if x == 0:
        return 0
    else:
        return round(x, n - int(np.floor(np.log10(abs(x)))) - 1)


if __name__ == "__main__":
    print(round_to_1_significant_figure(73))
