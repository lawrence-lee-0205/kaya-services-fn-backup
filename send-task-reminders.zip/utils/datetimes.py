import calendar

from datetime import timedelta, date, datetime
from dateutil.relativedelta import relativedelta


def get_last_day_of_month(year, month):
    # get the last day of the month using calendar library
    last_day = calendar.monthrange(year, month)[1]
    return date(year, month, last_day)


def get_date_betw_dates(
    start_date: date, end_date: date, include_start=True, include_end=True
) -> list:
    """Return list of dates from end_date to start_date

    Args:
        start_date (date): _description_
        end_date (date): _description_

    Returns: list
    """
    init_days_subtract = 0 if include_end else 1

    num_days_to_subtract = (end_date - start_date).days
    if include_start:
        num_days_to_subtract += 1

    return [
        end_date - relativedelta(days=x)
        for x in range(init_days_subtract, num_days_to_subtract)
    ]


def get_week_start_date(input_date: date, start_on: str = "Mon") -> date:
    """Return start date of the week containing 'input_date', based on 'start_on'

    Args:
        input_date (date): [description]
        start_on (str): [description]

    Returns:
        date: [description]
    """
    acceptable_start_on = ["Mon", "Sun"]
    if start_on not in acceptable_start_on:
        raise ValueError(
            f"Invalid valid provided for param 'start_on'. Received '{start_on}', only accepts {acceptable_start_on}"
        )

    delta = input_date.weekday()  # 0-monday 6-sunday
    if (start_on == "Sun") and (delta < 6):
        delta += 1
    elif (start_on == "Sun") and (delta == 6):
        delta = 0

    return input_date - timedelta(days=delta)


def chunk_dates(start: str, end: str, interval: int):
    # end date is exclusive
    start = datetime.strptime(start, "%Y-%m-%d")
    end = datetime.strptime(end, "%Y-%m-%d")

    outputs = []
    while start < end:
        start_plus_interval = start + relativedelta(days=interval)

        if start > end:
            break

        if start_plus_interval < end:
            final_end = start_plus_interval
        else:
            final_end = end

        outputs.append((start, final_end))
        start += relativedelta(days=interval)
    return outputs


def get_period(num_days):
    if (num_days > 30) and (num_days < 30 * 7):
        # if period is more than 30D but less than 30W, aggregate all time data by week
        agg_dates_by = "week"
    elif num_days > 30 * 7:
        # if more than 30 weeks, aggregate data by month
        agg_dates_by = "month"
    else:
        agg_dates_by = "date"
    return agg_dates_by


def get_date_by_name(name, as_string=True, format="%Y-%m-%d"):
    today = date.today()
    yesterday = today - timedelta(days=1)
    prev_month_yesterday = yesterday + relativedelta(months=-1)
    sunday_from_preceding_week = today - timedelta(days=today.weekday() + 1)

    mapping = {
        "start_of_last_month": (today - relativedelta(months=1, day=1)),
        "today": today,
        "7d_ago": (today - timedelta(days=7)),
        "30d_ago": (today - timedelta(days=30)),
        "yesterday": yesterday,
        "this_month_start": today.replace(day=1),
        "this_year_first_monday": date.fromisocalendar(today.year, 1, 1),
        "prev_month_yesterday": yesterday + relativedelta(months=-1),
        "sunday_from_preceding_week": sunday_from_preceding_week,
        # monday from preceding week
        "monday_from_preceding_week": sunday_from_preceding_week - timedelta(days=6),
        "seven_day_before_yesterday": yesterday - relativedelta(days=6),
        "first_day_of_month_yesterday": yesterday + relativedelta(day=1),
        "first_day_of_previous_month": prev_month_yesterday + relativedelta(day=1),
    }
    date_ = mapping[name]
    if as_string:
        date_ = date_.strftime(format)
    return date_


if __name__ == "__main__":
    # for d in range(0, 10):
    #     date_ = date(2022, 1, 23) + timedelta(days=d)
    #     print(date_, " has week start date of")
    #     print(get_week_start_date(date_))
    #     print("--")

    print(get_date_betw_dates(start_date=date(2022, 1, 1), end_date=date(2022, 1, 5)))
    print(
        get_date_betw_dates(
            start_date=date(2022, 1, 1), end_date=date(2022, 1, 5), include_start=False
        )
    )
    print(
        get_date_betw_dates(
            start_date=date(2022, 1, 1), end_date=date(2022, 1, 5), include_end=False
        )
    )
