from string import Formatter


def convert_to_snake_case(name):
    import re

    pattern = re.compile(r"(?<!^)(?=[A-Z])")
    converted = pattern.sub("_", name).lower()
    return converted


def str_format_without_none(template: str, **kwargs):
    # parse template and identify params that are numeric
    numeric_vars = []
    for variable in Formatter().parse(template):
        # variable[1] = variable name, variable[2] = formatting
        if (
            variable[1] != ""
            and variable[1] is not None
            and variable[2] is not None
            and "f" in variable[2]
        ):
            # needs to be a numeric variable
            numeric_vars.append(variable[1])

    new_args = {
        key: value if value is not None else _get_placeholder(key, numeric_vars)
        for key, value in kwargs.items()
    }
    return template.format(**new_args)


def _get_placeholder(var_name: str, numeric_vars: list):
    """If the variable is a numeric variable, return 0 to avoid issue with f formatting"""
    if var_name in numeric_vars:
        return 0
    return ""


def int_to_accounting_format(int_input):
    amount = '{:,}'.format(int_input)
    return amount
