from urllib.parse import urlparse


def get_url_without_params(full_url):
    parsed_url = urlparse(full_url)
    # Construct URL without query parameters or fragment
    url_without_params = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
    return url_without_params
