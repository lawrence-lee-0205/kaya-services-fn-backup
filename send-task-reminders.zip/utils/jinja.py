from jinja2 import Environment, FileSystemLoader
from utils.kaya_yaml import read_yaml_as_str


def render_template(folder, filename, **kwargs) -> str:
    templateLoader = FileSystemLoader(searchpath=folder)
    templateEnv = Environment(loader=templateLoader)
    template = templateEnv.get_template(filename)
    outputText = template.render(**kwargs)
    return outputText


def render_template_as_dict(folder, filename, **kwargs) -> dict:
    templated_str = render_template(folder, filename, **kwargs)
    return read_yaml_as_str(templated_str)


def render_template_from_string(template_str, **kwargs) -> str:
    templateEnv = Environment()
    template = templateEnv.from_string(template_str)
    outputText = template.render(**kwargs)
    return outputText
