from firestore import FirestoreClient
from noloco.request import call_noloco_api

_FS = FirestoreClient()


def update_businesses_col_with_company_ids():
    query = """
    query MyQuery {
        companyCollection {
            edges {
                node {
                    fsId
                    id
                    uuid
                    status
                    picAdmin {
                        firestoreId
                        id
                        uuid
                    }
                }
            }
        }
    }
    """
    output = call_noloco_api(query)
    companies = [out["node"] for out in output["data"]["companyCollection"]["edges"]]

    for co in companies:
        print("Processing ", co)
        if co["fsId"] is None or "placeholder" in co["fsId"]:
            continue
        try:
            _FS.update_document(
                "businesses",
                co["fsId"],
                {
                    "noloco_company_id": co["id"],
                    "noloco_company_uuid": co["uuid"],
                    # "status": co["status"][4:], # use firestore as source of truth
                },
            )
        except Exception as e:
            print(e, co)
            print("**")
    return None


def update_users_collection_with_admin_businesses():
    query = """
    query MyQuery {
        companyCollection {
            edges {
                node {
                    fsId
                    picAdmin {
                        firestoreId
                        id
                        uuid
                    }
                }
            }
        }
    }
    """
    output = call_noloco_api(query)

    admin_businesses = {}
    for out in output["data"]["companyCollection"]["edges"]:
        biz_id = out["node"]["fsId"]

        if biz_id is None or "placeholder" in biz_id or len(biz_id) < 10:
            continue

        admin_fs_id = out["node"]["picAdmin"]["firestoreId"]

        business_ids = admin_businesses.get(admin_fs_id, [])
        business_ids.append(out["node"]["fsId"])
        admin_businesses[admin_fs_id] = business_ids
    print("")
    print(admin_businesses)

    for admin_fs_id, businesses in admin_businesses.items():
        print("Processing ", admin_fs_id, businesses)
        try:
            _FS.update_document("users", admin_fs_id, {"admin_businesses": businesses})
        except Exception as e:
            print(e, admin_fs_id, businesses)
            print("**")
    return None


def update_users_collection_with_noloco_ids():
    query = """
    query MyQuery {
        userCollection {
            edges {
                node {
                    firestoreId
                    id
                    uuid
                }
            }
        }
    }
    """
    output = call_noloco_api(query)
    users = output["data"]["userCollection"]["edges"]
    print(users)
    for user_with_node in users:
        user = user_with_node["node"]
        print("Processing ", user)
        if user["firestoreId"] is None:
            continue

        _FS.update_document(
            "users",
            user["firestoreId"],
            {"noloco_user_id": user["id"], "noloco_user_uuid": user["uuid"]},
        )
    return None


if __name__ == "__main__":
    update_businesses_col_with_company_ids()
