from setup import setup
from common import validate_inputs
from noloco.request import call_noloco_api

_ACCEPTABLE_ACTIONS = [
    "createTask",
    "updateTask",
    "createAppComment",
    "updateCompany",
    "createAppFile",
    "updateAppFile",
    "updateAppComment",
]


@setup
def mutate_noloco(data: dict) -> dict:
    mandatory_fields = ["action", "fields", "return_fields", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    resp = mutate(
        action=data["action"],
        fields=data["fields"],
        return_fields=data["return_fields"],
    )
    return resp


def mutate(action, fields, return_fields):
    if action not in _ACCEPTABLE_ACTIONS:
        raise Exception(f"Action provided {action} is not allowed")

    # format query
    query = f"""
    mutation {{
        {action}({fields}) {{
            {return_fields}
        }}
    }}
    """

    print(query)
    resp = call_noloco_api(query)

    print(resp)
    return resp


if __name__ == "__main__":
    action = "createTask"
    fields = f'name: "Test Task from API 2" \n ownerThatsVisibleOnApp: "Kaya" \n description: "test test" \nstatus: TO_DO \ncompanyId: "2"'

    mutate(
        action=action,
        fields=fields,
        return_fields="id name",
    )

    # query = f"""
    # mutation createTestAPI {{
    #     {action}{collection}(name: "meow3", birthday: "2022-12-21T00:00:00.000Z") {{
    #         id
    #         name
    #         birthday
    #         createdAt
    #         updatedAt
    #         uuid
    #     }}
    # }}
    # """
    # out = execute(body=query)
    # print(out)
