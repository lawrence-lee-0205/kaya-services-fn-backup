import json
import requests
import datetime as dt

from firestore import FirestoreClient
from open_ai.run_chat_completions import run_chat_completions
from noloco.request import call_noloco_api
from slack_tools.slack import SlackMessage
from http_function import http_function, process_request_inputs

from google.cloud.firestore_v1.base_query import FieldFilter


_FS = FirestoreClient()


@http_function
def create_task_in_noloco(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)
    output = execute(data)
    return output


def execute(data):
    channel = data["channel"]["id"]

    # GET ID RELATED TO BUSINESS
    business_ref = (
        _FS.get_collection("businesses")
        .where("slack_channel_id", "==", channel)
        .stream()
    )
    business_fs_noloco_id_lookups = {
        biz.id: biz.to_dict()["noloco_company_id"] for biz in business_ref
    }
    if len(business_fs_noloco_id_lookups) == 0:
        raise Exception(f"Cannot find business with slack_channel_id {channel}")
    elif len(business_fs_noloco_id_lookups) > 1:
        raise Exception(
            f"Found more than 1 business with slack_channel_id {channel}: {business_fs_noloco_id_lookups}"
        )

    business_id = list(business_fs_noloco_id_lookups.keys())[0]
    noloco_company_id = business_fs_noloco_id_lookups[business_id]

    # GET ADMIN DETAILS
    requester_slack_id = data["user"]["id"]
    user_ref = _FS.get_collection("users")
    user_docs = user_ref.where(
        filter=FieldFilter("slack_id", "==", requester_slack_id)
    ).stream()
    owner_firestore_ids = [doc.id for doc in user_docs]

    utc_now_dt = dt.datetime.now(dt.timezone.utc)
    utc_now = utc_now_dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

    message = data["message"]["text"]

    # create task description
    slack_msg_url = f"https://usekaya.slack.com/archives/{data['channel']['id']}/p{data['message_ts'].replace('.', '')}"
    description = (
        "Message received on Slack:\n"
        + message
        + f"\n\nLink to Slack => {slack_msg_url}"
    )
    description = json.dumps(description)

    # define due date (default 3 days from now)
    due_date = utc_now_dt + dt.timedelta(days=3)

    # define task name
    try:
        prompt = f"""
        The following is a message sent from a client to our customer support team. Your task is to suggest task name based on the message.
        {message}
        This is the end of the message.
        Do not include any explanations in your output, only provide a  RFC8259 compliant JSON response following this format without deviation.: {{"task_name": "Your suggested task name"}}
        """
        messages = [
            {"role": "system", "content": "You are a Customer Service agent."},
            {"role": "user", "content": prompt},
        ]
        output = run_chat_completions(messages, output_format="json")
        print(output)
        task_name = json.loads(output)["task_name"]
    except Exception as e:
        print("Error in OpenAI API. Using default task name.")
        print(e)
        task_name = "Request from Slack"

    query = f"""
    mutation MyMutation {{
        createTask(
            channel: OTHERS
            companyId: {noloco_company_id}
            createdAt: "{utc_now}"
            description: {description}
            name: "{task_name}"
            ownerThatsVisibleOnApp: "{owner_firestore_ids}"
            status: TO_DO
            updatedAt: "{utc_now}"
            dueDate: "{due_date.strftime('%Y-%m-%dT00:00:00Z')}"
        ) {{
            uuid
        }}
    }}
    """

    noloco_output = call_noloco_api(query)
    print(noloco_output)
    task_uuid = noloco_output["data"]["createTask"]["uuid"]

    # Method 1: Send DM to admin
    dm_message_to_send = f"You've asked to created a new task from this <{slack_msg_url}|slack message>. Here's the <https://app.usekaya.com/tasks/{task_uuid}?client={business_id}|link to the new task>."

    bot = SlackMessage()
    bot.send_notification(text=dm_message_to_send, channel=requester_slack_id)

    # Method 2: Reply to ori thread
    public_msg_to_send = f"""
🎫 A new task has been created based on the message above:
> {message[:150]}


<https://app.usekaya.com/tasks/{task_uuid}?client={business_id}|Link to the task →>
"""

    input = {
        "text": public_msg_to_send,
        "response_type": "in_channel",
        "replace_original": False,
    }
    if "message_ts" in data:
        input["thread_ts"] = data["message_ts"]

    request_reply_slack = requests.post(
        data["response_url"],
        json=input,
    )
    print(request_reply_slack.text)

    return "Success"


if __name__ == "__main__":
    data = {}
    execute(data)
