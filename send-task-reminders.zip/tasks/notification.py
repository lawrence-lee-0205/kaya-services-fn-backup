import os
import datetime as dt
from typing import List

from users.user import User
from tasks.comment import Comment
from noloco.request import call_noloco_api
from slack_tools.slack import SlackMessage
from slack_tools.convert_slack_markdown import convert_to_slack_markdown
from utils.jinja import render_template_as_dict
from emailer.send_email import send_templated_email


_CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))
_TEMPLATE_FOLDER = _CURRENT_DIR + "/notification_templates"


class Notification:
    def __init__(
        self,
        template: str,
        default_comm_method: str,
        recipient: User,
        comment: Comment,
        all_recipients: List[User],
    ):
        self._template = template
        self.default_comm_method = default_comm_method
        self.recipient = recipient
        self.comment = comment
        self.all_recipients = all_recipients

    @property
    def commenter_name(self):
        # if the recipient is an internal user, show the original commenter name
        if self.recipient.role in ["admin", "marketer"]:
            return self.comment.commenter.full_name

        if self.recipient.role == "client" and self.comment.commenter.role == "client":
            return self.comment.commenter.full_name

        if self.recipient.role == "client" and self.comment.commenter.role in [
            "admin",
            "marketer",
        ]:
            return "Team Kaya"

        raise Exception(
            f"Unable to identify commenter name based on recipient: {self.recipient.role} and commenter: {self.comment.commenter.role}"
        )

    @property
    def task_url(self):
        if self.recipient.role in ["admin", "marketer"]:
            print("Sending slack notification to internal user. Using team app url")
            return self.comment.team_app_task_url
        else:
            print("Using client app url")
            return self.comment.client_app_task_url

    @property
    def all_recipient_names(self):
        return ", ".join([r.full_name for r in self.all_recipients])

    @property
    def comm_method(self):
        if self.recipient.role in ["admin", "marketer"]:
            return "slack"
        else:
            return self.default_comm_method

    @property
    def template_filename(self):
        return f"{self.comm_method}_{self._template}.yml"

    def send(self):
        print("Processing notification for recipient: ", self.recipient.full_name)

        if self.comm_method not in ["email", "slack"]:
            raise Exception(f"Unknown comm_method: {self.comm_method}")

        if self.comm_method == "slack":
            thread_ts = self._send_slack()
        elif self.comm_method == "email":
            self._send_email()
            thread_ts = None
        self._update_noloco_app_comment_notification_col(thread_ts)
        return None

    def _update_noloco_app_comment_notification_col(self, thread_ts=None):
        query = f"""
            mutation MyMutation {{
                createAppCommentNotification(
                    sentVia: "{self.comm_method}"
                    trigger: "TODO"
                    userFirestoreId: "{self.recipient.user_id}"
                    userName: "{self.recipient.full_name}"
                    appCommentId: "{self.comment.id}"
                    createdAt: "{dt.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')}"
                    threadTs: "{thread_ts}"
                ) {{
                    id
                }}
            }}
        """
        try:
            out = call_noloco_api(query)
        except Exception as e:
            print("Error running query: ", query)
            raise e

        print(f"Added rows to noloco_app_comment_notification table. Output:\n{out}")
        return None

    def _send_slack(self):
        comment_content = convert_to_slack_markdown(self.comment.content)

        config_by_role = render_template_as_dict(
            folder=_TEMPLATE_FOLDER,
            filename=self.template_filename,
            commenter_name=self.commenter_name,
            comment_content=comment_content,
            task_url=self.task_url,
            task_name=self.comment.task.name,
            business_name=self.comment.task.business.name,
            all_recipient_names=self.all_recipient_names,
        )
        config_by_role = config_by_role["message"]
        blocks = config_by_role[self.recipient.role]

        slack_message = SlackMessage()
        slack_message.add_list_of_blocks(blocks)
        slack_resp = slack_message.send_notification(channel=self.recipient.slack_id)

        thread_ts = slack_resp["ts"]
        return thread_ts

    def _send_email(self):
        print("Processing email to ", self.recipient.user_id)
        send_templated_email(
            to_emails=[self.recipient.email],
            dynamic_data={
                "name": self.recipient.first_name,
                "comment": self.comment.content,
                "task_title": self.comment.task.name,
                "task_url": self.task_url,  # cannot have https://
            },
            template_id="d-b2adf7c7ae6644b48c1669380e13dc4a",
            subject=f"Task Update: {self.comment.task.name}",
            cc_emails=["jeeyen+notification@usekaya.com"],
        )
        return None
