import ast
from os import environ
from typing import List

from users.user import User
from firestore import FirestoreClient
from businesses.business import Business
from noloco.request import call_noloco_api
from utils.list import remove_duplicates

FS = FirestoreClient()


class Task:
    def __init__(self, uuid: str, business: Business) -> None:
        self.uuid = uuid
        self.business = business

        self._metadata = self._get_task_metadata()
        self._admin_firestore_id = self._metadata["company"]["picAdmin"]["firestoreId"]
        self._watcher_firestore_ids = (
            ast.literal_eval(self._metadata["watchers"])
            if self._metadata["watchers"]
            else []
        )
        self._client_owner_firestore_ids = (
            ast.literal_eval(self._metadata["ownerThatsVisibleOnApp"])
            if self._metadata["ownerThatsVisibleOnApp"]
            else []
        )
        self._internal_owner_firestore_ids = (
            [
                x["node"]["firestoreId"]
                for x in self._metadata["owner"]["edges"]
                if x["node"]["firestoreId"]
            ]
            if self._metadata["owner"]["edges"]
            else []
        )

    @property
    def name(self) -> str:
        # in noloco task name is prefixed with business name, we need to remove it
        name_raw = self._metadata["name"]
        print("self.business.name ", self.business.name)
        prefix_with_biz_name = self.business.name + " - "
        task_name = name_raw.replace(prefix_with_biz_name, "")
        if "PROD" not in environ["ENV"]:
            task_name = task_name + " [TEST]"
        return task_name

    @property
    def id(self) -> int:
        return self._metadata["id"]

    @property
    def visibility(self) -> str:
        if self._metadata["visibility"] == "KAYA_ALL":
            return "internal"
        elif self._metadata["visibility"] == "KAYA_ADMIN":
            return "admin"
        else:
            return "public"

    @property
    def admin(self) -> str:
        return User(user_id=self._admin_firestore_id)

    @property
    def watchers(self) -> List[User]:
        return [User(user_id=fs_id) for fs_id in self._watcher_firestore_ids]

    @property
    def owner_client(self) -> List[User]:
        # owners who are clients
        return [User(user_id=fs_id) for fs_id in self._client_owner_firestore_ids]

    @property
    def owner_internal(self) -> List[User]:
        # owners who are internal users
        return [User(user_id=fs_id) for fs_id in self._internal_owner_firestore_ids]

    @property
    def all_owners(self) -> List[User]:
        return remove_duplicates(self.owner_internal + self.owner_client)

    @property
    def owner_watcher_admin(self) -> List[User]:
        all_fs_ids = list(
            set(
                self._client_owner_firestore_ids
                + self._internal_owner_firestore_ids
                + self._watcher_firestore_ids
                + [self._admin_firestore_id]
            )
        )
        return [User(user_id=fs_id) for fs_id in all_fs_ids]

    @property
    def business_id(self) -> str:
        return self.business.business_id

    @property
    def business_name(self) -> str:
        return self.business.name

    def _get_task_metadata(self):
        query = f"""
        query MyQuery {{
            taskCollection(where: {{uuid: {{equals: "{self.uuid}"}}}}) {{
                edges {{
                    node {{
                        owner{{
                            edges {{
                                node {{
                                    firestoreId
                                }}
                            }}
                        }}
                        id
                        name
                        visibility
                        ownerThatsVisibleOnApp
                        watchers
                        company {{
                            picAdmin {{
                                firestoreId
                            }}
                        }}
                    }}
                }}
            }}
        }}
        """
        output = call_noloco_api(query)
        print(query)
        output_processed = output["data"]["taskCollection"]["edges"][0]["node"]
        print(output_processed)
        return output_processed
