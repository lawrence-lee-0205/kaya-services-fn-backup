import datetime as dt
from os import environ

from firestore import FirestoreClient
from noloco.request import call_noloco_api
from tasks.create_task_comment import create_task_comment
from http_function import process_request_inputs, http_function


_COMMENTER_USER_ID = (
    "0GgKmc6CPLGKQUDSjnmv"
    if "PROD" in environ["ENV"].upper()
    else "yQ2bybPjv54pIFkaM3RO"
)
_CUT_OFF_DAYS = 14
_FS = FirestoreClient()


@http_function
def mark_stale_in_review_to_done(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)
    print(data)

    execute()
    return "Success"


def execute():
    docs = _FS.get_filtered_documents(
        "businesses", [{"field_name": "status", "operator": "==", "value": "ACTIVE"}]
    )
    for doc in docs:
        business_id = list(doc.keys())[0]
        process_single_business(business_id)
    return "Success"


def process_single_business(business_id):
    date_before = dt.date.today() - dt.timedelta(days=_CUT_OFF_DAYS)
    date_before_str = date_before.strftime("%Y-%m-%dT00:00:00Z")

    query_get_in_review_tasks = f"""
    query MyQuery {{
        companyCollection(where: {{fsId: {{equals: "{business_id}"}}}}) {{
            edges {{
                node {{
                    tasksCollection(
                        where: {{status: {{equals: "IN_REVIEW"}}, inReviewDatetime: {{lte: "{date_before_str}"}}}}
                    ) {{
                    edges {{
                        node {{
                                id
                                uuid
                                name
                                appCommentsCollection {{
                                    edges {{
                                        node {{
                                            createdAt
                                            id
                                        }}
                                    }}
                                }}
                            }}
                        }}
                    }}
                }}
            }}
        }}
    }}
    """
    in_review_tasks = call_noloco_api(query_get_in_review_tasks)
    print(in_review_tasks)

    task_output = in_review_tasks["data"]["companyCollection"]["edges"][0]["node"][
        "tasksCollection"
    ]["edges"]
    for task_node in task_output:
        task = task_node["node"]
        process_single_ticket(task, date_before)
    return None


def process_single_ticket(task, date_before):
    task_id = task["id"]

    comment_created_at_lst = [
        comment["node"]["createdAt"]
        for comment in task["appCommentsCollection"]["edges"]
    ]
    last_comment_created_at = (
        dt.datetime.strptime(
            max(comment_created_at_lst), "%Y-%m-%dT%H:%M:%S.%fZ"
        ).date()
        if len(comment_created_at_lst) > 0
        else dt.datetime(1970, 1, 1).date()
    )

    if last_comment_created_at < date_before:
        print(
            f"Updating task {task_id} to DONE. Last comment created at {last_comment_created_at}"
        )
        query_update = f"""
        mutation MyMutation {{
            updateTask(id: "{task_id}", status: DONE) {{
                id
                status
            }}
        }}
        """
        call_noloco_api(query_update)
        print(f"Task {task_id} updated to DONE.")

        create_task_comment(
            "Task status is automatically updated to `Completed` because it has been in review for more than 14 days.",
            commenter_firestore_id=_COMMENTER_USER_ID,
            task_id=task_id,
            skip_notification=True,
        )
        print(f"Comment created for task {task_id}.")
    return None


if __name__ == "__main__":
    # business_id = "dDlnlHVBitdYQB1RbmIj"
    execute()
