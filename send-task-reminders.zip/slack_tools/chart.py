from abc import ABC, abstractmethod
import uuid

import plotly.graph_objects as go
import seaborn as sns

_DEFAULT_TABLE_COL_WIDTH = 600

_TOP_MARGIN = 80
_BOTTOM_MARGIN = 10
_LEFT_RIGHT_MARGIN = 30

_PLOT_BACKGROUND = "rgba(0,0,0,0.05)"
_PAPER_BACKGROUND = "white"

_WHITE_PAPER_BACKGROUND = "white"
_WHITE_PLOT_BACKGROUND = "#F8F8FF"

_MAIN_COLOR = "#5e00ff"
_COLOR_PALETTE = [_MAIN_COLOR, "#A390E4", "#C5D5EA", "#686868"]

_PLOTLY_X_AXES_DEFAULT = {
    "showline": False,
    "linewidth": 1,
    "linecolor": "#d6d3dc",
    "showgrid": False,
    "zeroline": False,
}
_PLOTLY_Y_AXES_DEFAULT = {
    "automargin": True,
    "tickprefix": "  ",
    "gridcolor": "#f6f6f6",
    "gridwidth": 0.5,
    "zeroline": False,
    "nticks": 5,
}


def _convert_rgba_to_sns_color(rgba: str):
    # number_str = rgba.replace("rgba", "").replace(")", "")
    number_str = rgba[rgba.find("(") + 1 : rgba.find(")")]
    numbers = number_str.split(",")

    if len(numbers) != 4:
        raise Exception("Expecting 4 numbers in RGBA string. Received " + rgba)

    colors = tuple(
        float(x) / 255 if idx < 3 else float(x) for idx, x in enumerate(numbers)
    )
    return colors


class Chart(ABC):
    def __init__(self, df, title) -> None:
        self.fig = None
        self.df = df
        self.title = title

        # Default CSS
        self.plot_background = _PLOT_BACKGROUND
        self.paper_background = _PAPER_BACKGROUND
        self.top_margin = _TOP_MARGIN
        self.bottom_margin = _BOTTOM_MARGIN
        self.left_margin = _LEFT_RIGHT_MARGIN
        self.right_margin = _LEFT_RIGHT_MARGIN

        self.dir = "/tmp"  # FIX THIS
        self.filename = f'{title.lower().replace(" ", "_")}_{uuid.uuid4()}.png'
        self.filepath = self.dir + "/" + self.filename

    @abstractmethod
    def plot(self):
        pass

    @abstractmethod
    def write_to_file(self):
        pass

    def _plotly_write_to_file(self):
        print("Writing file to ", self.filepath)
        self.fig.write_image(self.filepath)
        return None


class TableChart(Chart):
    def __init__(self, df, **kwargs) -> None:
        super().__init__(df, kwargs["title"])
        self.fig = go.Figure()
        self.columns = kwargs["columns"]
        self.cell_height = None
        self.ylabel = ""

        # table should have white color by default
        self.paper_background = _WHITE_PAPER_BACKGROUND
        self.plot_background = _WHITE_PLOT_BACKGROUND
        self.line_color = _WHITE_PAPER_BACKGROUND

        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    def _calc_table_height(
        self, base=208, height_per_row=50, char_limit=30, height_padding=20
    ):
        """
        df: The dataframe with only the columns you want to plot
        base: The base height of the table (header without any rows)
        height_per_row: The height that one row requires
        char_limit: If the length of a value crosses this limit, the row's height needs to be expanded to fit the value
        height_padding: Extra height in a row when a length of value exceeds char_limit
        """
        total_height = 0 + base
        for x in range(self.df.shape[0]):
            total_height += height_per_row
        for y in range(self.df.shape[1]):
            if len(str(self.df.iloc[x][y])) > char_limit:
                total_height += height_padding
        return total_height

    def plot(self):
        rename_columns = {}
        columns_to_show = []
        aligns = []
        widths = []
        sort_cols = {}

        for col_config in self.columns:
            if "sort" in col_config:
                sort_cols[col_config["metric"]] = col_config["sort"].lower() == "asc"

            rename_columns[col_config["metric"]] = col_config["name"]
            columns_to_show.append(col_config["name"])
            aligns.append(col_config["align"])
            widths.append(col_config.get("width", _DEFAULT_TABLE_COL_WIDTH))

        self.df.sort_values(
            by=list(sort_cols.keys()), ascending=list(sort_cols.values()), inplace=True
        )
        self.df.rename(columns=rename_columns, inplace=True)

        columnal_data = []
        for col in columns_to_show:
            columnal_data.append(self.df[col].fillna(""))

        cell_params = {}
        if self.cell_height is not None:
            cell_params["height"] = self.cell_height

        height = self._calc_table_height()

        self.fig = go.Figure(
            data=[
                go.Table(
                    header=dict(
                        values=[f"<b>{c}</b>" for c in columns_to_show],
                        fill_color=self.plot_background,
                        align=aligns,
                        line_color=self.line_color,
                    ),
                    cells=dict(
                        values=columnal_data,
                        fill_color=self.plot_background,
                        line_color=self.line_color,
                        align=aligns,
                        **cell_params,
                    ),
                    columnwidth=widths,
                )
            ]
        )

        self.fig.update_layout(
            autosize=False,
            paper_bgcolor=self.paper_background,
            plot_bgcolor=self.plot_background,
            legend=dict(orientation="h", y=-0.1, xanchor="right", x=1),
            title=go.layout.Title(
                text=self.title,
            ),
            height=height,
            width=sum(widths) * 1.05,
            margin=go.layout.Margin(
                l=self.left_margin,  # left margin
                r=self.right_margin,  # right margin
                b=self.bottom_margin,  # bottom margin
                t=self.top_margin,  # top margin,
                pad=10,
            ),
        )
        # self.fig.show()
        return None

    def write_to_file(self):
        self._plotly_write_to_file()
        return None


class PlotlyMultiChart(Chart):
    def __init__(self, df, **kwargs) -> None:
        super().__init__(df, kwargs["title"])

        if "traces" not in kwargs:
            raise Exception("Expecting param 'traces'")

        self.ylabel = kwargs.get("ylabel", "")

        xaxes_input = kwargs.get("update_xaxes", {})
        self.xaxes = {**_PLOTLY_X_AXES_DEFAULT, **xaxes_input}

        yaxes_input = kwargs.get("update_yaxes", {})
        self.yaxes = {
            "title_text": self.ylabel,
            **_PLOTLY_Y_AXES_DEFAULT,
            **yaxes_input,
        }
        self.fig = go.Figure()

        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    def plot(self):
        for idx, trace in enumerate(self.traces):
            type_ = trace["type"]
            x_col = trace["x"]
            y_col = trace["y"]
            name = trace["name"]

            if type_ == "bar":
                self.fig.add_trace(
                    go.Bar(
                        x=self.df[x_col],
                        y=self.df[y_col],
                        name=name,
                        marker_color=_COLOR_PALETTE[idx],
                    )
                )
            elif type_ == "line":
                self.fig.add_trace(
                    go.Scatter(
                        x=self.df[x_col],
                        y=self.df[y_col],
                        name=name,
                        line=dict(color=_COLOR_PALETTE[idx], dash="dash"),
                        mode="lines",
                    )
                )
            else:
                raise NotImplementedError(
                    f"Trace of type {type_} has not been implemented!"
                )

        self.fig.update_layout(
            autosize=False,
            paper_bgcolor=self.paper_background,
            plot_bgcolor=self.plot_background,
            width=600,
            height=450,
            margin=go.layout.Margin(
                l=self.left_margin,  # left margin
                r=self.right_margin,  # right margin
                b=self.bottom_margin,  # bottom margin
                t=self.top_margin,  # top margin,
                pad=4,
            ),
            legend=dict(orientation="h", y=-0.1, xanchor="right", x=1),
            title=go.layout.Title(
                text=self.title,
            ),
        )

        self.fig.update_xaxes(**self.xaxes)
        self.fig.update_yaxes(**self.yaxes)
        # self.fig.show()
        return None

    def write_to_file(self):
        self._plotly_write_to_file()
        return None


class PlotlyLineChart(Chart):
    def __init__(self, df, **kwargs) -> None:
        super().__init__(df, kwargs["title"])
        # mandatory fields
        self.x = kwargs["x"]
        self.y = kwargs["y"]
        self.fig = go.Figure()

        xaxes_input = kwargs.get("update_xaxes", {})
        self.xaxes = {**_PLOTLY_X_AXES_DEFAULT, **xaxes_input}

        self.ylabel = kwargs.get("ylabel", "")
        yaxes_input = kwargs.get("update_yaxes", {})
        self.yaxes = {
            "title_text": self.ylabel,
            **_PLOTLY_Y_AXES_DEFAULT,
            **yaxes_input,
        }

        # optional fields
        self.sort_x_asc = kwargs.get("sort_x_asc", True)
        self.hue = kwargs.get("hue", None)
        self.modes = None
        self.colors = None
        self.fill = None  # "tozeroy" or "tonexty". for area chart
        self.height = kwargs.get("height", 500)
        self.width = kwargs.get("width", 600)
        self.line_width = kwargs.get("line_width", 3)

        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    def plot(self):
        plot_settings = []
        if self.hue is not None:
            # plot multiple series
            unique_series = sorted(self.df[self.hue].unique())
            for idx, h in enumerate(unique_series):
                filter_ = self.df[self.hue] == h
                plot_df = self.df[filter_]
                setting = {
                    "x": plot_df[self.x],
                    "y": plot_df[self.y],
                    "name": h,
                    "line": {"width": self.line_width},
                }

                if self.colors is not None:
                    setting["marker_color"] = self.colors[idx]

                if self.modes is not None:
                    setting["mode"] = self.modes[idx]
                else:
                    setting["mode"] = "lines"

                if self.fill is not None:
                    setting["fill"] = self.fill

                plot_settings.append(setting)
        else:
            # plot single series
            setting = {
                "x": self.df[self.x],
                "y": self.df[self.y],
                "name": self.y,
                "line": {"width": self.line_width},
            }

            if self.colors is not None:
                setting["marker_color"] = self.colors[0]

            # only expect 1 mode to be provided in `modes` since we're plotting a single series
            # If more than 1, use the first one. If none, use "lines"
            if self.modes is not None:
                setting["mode"] = self.modes[0]
            else:
                setting["mode"] = "lines"

            if self.fill is not None:
                setting["fill"] = self.fill

            plot_settings.append(setting)

        for s in plot_settings:
            self.fig.add_trace(go.Scatter(**s))

        self.fig.update_layout(
            autosize=False,
            paper_bgcolor=self.paper_background,
            plot_bgcolor=self.plot_background,
            width=self.width,
            height=self.height,
            margin=go.layout.Margin(
                l=self.left_margin,  # left margin
                r=self.right_margin,  # right margin
                b=self.bottom_margin,  # bottom margin
                t=self.top_margin,  # top margin,
                pad=4,
            ),
            legend=dict(orientation="h", y=-0.1, xanchor="right", x=1),
            title=go.layout.Title(
                text=self.title,
            ),
            font=dict(color="#726784"),
        )
        self.fig.update_xaxes(self.xaxes)
        self.fig.update_yaxes(self.yaxes)
        # self.fig.show()

        return None

    def write_to_file(self):
        self._plotly_write_to_file()
        return None


class FacetplotChart(Chart):
    def __init__(self, df, **kwargs) -> None:
        super().__init__(df, kwargs["title"])
        # mandatory fields
        self.x = kwargs["x"]
        self.y = kwargs["y"]
        self.column = kwargs["column"]

        # optional fields
        self.show_all_x_axis = kwargs.get("show_all_x_axis", True)
        self.sort_x_asc = kwargs.get("sort_x_asc", True)
        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    def plot(self):
        sns.set_theme()
        sns.set_context(context="paper", font_scale=1.5)
        sns.set(
            rc={
                "axes.facecolor": _WHITE_PLOT_BACKGROUND,
                "figure.facecolor": _WHITE_PAPER_BACKGROUND,
            }
        )

        if self.sort_x_asc:
            self.df.sort_values(by=self.x, ascending=True, inplace=True)
        order = self.df[self.x].unique()

        x_label = "\n" + self.x
        y_label = self.y

        g = sns.FacetGrid(
            self.df,
            col=self.column,
            col_wrap=2,
            height=3,
            aspect=3,
            palette=sns.color_palette("pastel"),
        )
        g.map(sns.pointplot, self.x, self.y, order=order, ci=None, color=_MAIN_COLOR)

        # process axis
        g.set_xticklabels(rotation=10)
        g.set_axis_labels(x_label, y_label)
        if self.show_all_x_axis:
            for ax in g.axes.flatten():
                ax.tick_params(labelbottom=True)

        g.set_titles(col_template="{col_name}", row_template="{row_name}")
        g.tight_layout()

        g.fig.subplots_adjust(top=0.90)
        g.fig.suptitle(
            self.title,
            size=20,
        )

        self.fig = g
        return None

    def write_to_file(self):
        print("Writing file to ", self.filepath)
        self.fig.savefig(self.filepath)
        return None


if __name__ == "__main__":
    import pandas as pd

    # test_df = pd.read_csv("campaign_df.csv")
    # chart = FacetplotChart(
    #     df=test_df,
    #     column="name",
    #     x="date",
    #     y="revenue",
    #     title="test",
    #     dir="./",
    # )
    # chart.plot()
    # chart.write_to_file()

    print(_convert_rgba_to_sns_color(rgba="RGBA (12, 50, 196, 0.6)"))
