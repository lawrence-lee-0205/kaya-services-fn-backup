#############################
#      DEPRECATE THIS      #
############################

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

import uuid
import math
from datetime import date, timedelta
from http_function import http_function

from businesses.business import Business
from slack_tools.slack import SlackMessage
from slack_tools.formatting import get_emoji
from utils.mathematics import calc_pct_change
from google.gutils.bigquery import run_query


_DAYS_LOOK_BACK = 30
_TODAY = date.today()
_YESTERDAY = _TODAY - timedelta(days=1)

_FOLDER = "/tmp"
_BUCKET = "public-weekly-slack"
_CHANNEL = "C02PYBMGLL9"


def get_data(sql, **kwargs):
    sql_to_execute = sql.format(**kwargs)
    return run_query(sql_to_execute, "dataframe")


class GoogleAdsData:
    def __init__(self, business_id, sql, days_rolling, end_date=_YESTERDAY) -> None:
        """_summary_

        Args:
            business_id (_type_):
            sql (_type_):
            days_rolling (_type_): num of days required to calculate rolling average
            end_date (_type_, optional): main date to report data on. Defaults to _YESTERDAY.
        """
        self.business_id = business_id
        self.days_rolling = days_rolling
        self.end_date = end_date
        self.df = get_data(sql, business_id=business_id)

    @property
    def _plot_df(self):
        return self.df.iloc[-_DAYS_LOOK_BACK:, :]

    @property
    def day_before_end_date(self):
        return self.end_date - timedelta(days=1)

    @property
    def n_days_before_end_date(self):
        return self.end_date - timedelta(days=self.days_rolling)

    @property
    def first_of_month(self):
        return self.end_date.replace(day=1)

    @property
    def filter_day_before_end_date(self):
        return self.df["date"] == self.day_before_end_date

    @property
    def filter_end_date(self):
        return self.df["date"] == self.end_date

    def calculate_metrics(self):
        self.df.sort_values(by="date", inplace=True)

        self.df["cost_per_conv"] = self.df["cost"] / self.df["conversions"]
        self.df["click_through_rate"] = 100 * self.df["clicks"] / self.df["impressions"]
        self.df["conversion_rate"] = 100 * self.df["conversions"] / self.df["clicks"]

        # CALCULATE ROLLING SUM
        cols_rolling_sum = ["cost", "conversions", "clicks", "impressions"]
        for col in cols_rolling_sum:
            print("Processing ", col)
            self.df[f"{col}_r{self.days_rolling}d_sum"] = (
                self.df[col].fillna(0).rolling(window=self.days_rolling).sum()
            )

        self.df[f"conversions_r{self.days_rolling}d_avg"] = (
            self.df[f"conversions_r{self.days_rolling}d_sum"] / self.days_rolling
        )
        self.df[f"cost_per_conv_r{self.days_rolling}d_avg"] = (
            self.df[f"cost_r{self.days_rolling}d_sum"]
            / self.df[f"conversions_r{self.days_rolling}d_sum"]
        )
        self.df[f"click_through_rate_r{self.days_rolling}d_avg"] = (
            100
            * self.df[f"clicks_r{self.days_rolling}d_sum"]
            / self.df[f"impressions_r{self.days_rolling}d_sum"]
        )
        self.df[f"conversion_rate_r{self.days_rolling}d_avg"] = (
            100
            * self.df[f"conversions_r{self.days_rolling}d_sum"]
            / self.df[f"clicks_r{self.days_rolling}d_sum"]
        )

    def _prepare_annotation(self, new_value, old_value, prefix, suffix):
        annot_lst = []
        if not math.isinf(new_value):
            annot_lst.append(f"Yesterday: {prefix}{new_value:.0f}{suffix}")

        if not math.isinf(old_value):
            annot_lst.append(
                f"{self.days_rolling} days ago: {prefix}{old_value:.0f}{suffix}"
            )

        pct_change_output = calc_pct_change(new_value, old_value)
        annot = ", ".join(annot_lst)
        if isinstance(pct_change_output, float):
            annot += f" ({pct_change_output:.0f}%)"
        return annot

    def plot_bar_and_rolling_avg(
        self, metric_col, metric_name, rolling_col, prefix="", suffix=""
    ):
        try:
            # create filter to filter dataframe on
            filter_last_n_day = self._plot_df["date"] == self.n_days_before_end_date
            filter_day_before_end_date = (
                self._plot_df["date"] == self.day_before_end_date
            )

            # value from the last N days
            lnd_value = self._plot_df.loc[filter_last_n_day, metric_col].values[0]
            # value from yesterday
            ytd_value = self._plot_df.loc[
                filter_day_before_end_date, metric_col
            ].values[0]

            annot = self._prepare_annotation(ytd_value, lnd_value, prefix, suffix)

            # start plotting
            fig = go.Figure()
            fig.add_trace(
                go.Bar(
                    x=self._plot_df["date"],
                    y=self._plot_df[metric_col],
                    name=metric_name,
                    marker_color="#5e00ff",
                )
            )

            fig.add_trace(
                go.Scatter(
                    x=self._plot_df["date"],
                    y=self._plot_df[rolling_col],
                    name=f"Rolling {self.days_rolling}D Average",
                    line=dict(color="#f97a4d", dash="dash"),
                    mode="lines",
                )
            )

            fig.update_layout(
                autosize=False,
                paper_bgcolor="white",
                plot_bgcolor="#f6f3ff",
                width=600,
                height=450,
                margin=dict(l=50, r=50, b=20, pad=4),
                legend=dict(orientation="h", y=-0.1, xanchor="right", x=1),
                title=go.layout.Title(
                    text=f"{metric_name}<br></br><sup>{annot}</sup>",
                ),
            )
            fig.update_xaxes(showline=True, linewidth=1, linecolor="#fdfcff")
            fig.update_yaxes(automargin=True, tickprefix="  ", title_text=prefix)
            fig.show()

            # write to file
            file_name = f"{metric_col}_{self.business_id}_{uuid.uuid4()}.png"
            fig.write_image(f"{_FOLDER}/{file_name}")
            return {"name": metric_name, "file": file_name}
        except Exception as e:
            print(e)
            raise

    @staticmethod
    def _get_anomaly_emoji(pct_diff_anomaly, metric_col):
        metrics_higher_better = ["conversions", "conversion_rate", "click_through_rate"]

        if abs(pct_diff_anomaly) > 50:
            if pct_diff_anomaly > 0 and metric_col in metrics_higher_better:
                # if metrics are in the list above, we want
                is_anomaly = ":tada:"
            elif pct_diff_anomaly < 0 and metric_col in metrics_higher_better:
                is_anomaly = ":eyes:"
            elif pct_diff_anomaly > 0 and metric_col not in metrics_higher_better:
                # lower better
                is_anomaly = ":eyes:"
            elif pct_diff_anomaly < 0 and metric_col not in metrics_higher_better:
                is_anomaly = ":tada:"
            else:
                raise Exception(
                    f"Unhandled for inputs: {pct_diff_anomaly}, {metric_col}"
                )
        else:
            is_anomaly = ""
        return is_anomaly

    def _get_single_metric_summary(self, metric_col, text_after_metric):
        # what is the rolling N days average from previous day
        prev_rolling_avg_metric = self.df.loc[
            self.filter_day_before_end_date, f"{metric_col}_r{self.days_rolling}d_avg"
        ].values[0]
        ytd_metric = self.df.loc[self.filter_end_date, metric_col].values[0]

        # process anomaly logic
        pct_diff_anomaly = calc_pct_change(ytd_metric, prev_rolling_avg_metric)
        if not isinstance(pct_diff_anomaly, float):
            return f"*{ytd_metric:.0f}{text_after_metric}*"

        is_anomaly = self._get_anomaly_emoji(pct_diff_anomaly, metric_col)
        arrow = get_emoji(pct_diff_anomaly)

        stats_summary = f"*{ytd_metric:.0f}{text_after_metric}*, {arrow}{abs(pct_diff_anomaly):.0f}% vs L7D average {is_anomaly}"
        return stats_summary

    def generate_summary(self):
        ytd_cost = self.df.loc[self.filter_end_date, "cost"].values[0]
        mtd_cost = self.df.loc[self.df["date"] >= self.first_of_month, "cost"].sum()

        ytd_summaries = [
            f"> {self._get_single_metric_summary('conversions', ' conversions')}",
            f"*${ytd_cost:.0f} spent*, bringing this month total to ${mtd_cost:.0f}",
            f"> ${self._get_single_metric_summary('cost_per_conv', ' per conversion')}",
            f"> {self._get_single_metric_summary('conversion_rate', '% conversion rate')}",
            f"> {self._get_single_metric_summary('click_through_rate', '% click through rate')}",
        ]
        return ytd_summaries


def main(business_id, days_rolling=7):
    sql = f"""
    select 
        date, 
        sum(cost) as cost, 
        sum(impressions) as impressions, 
        sum(clicks) as clicks,
        sum(conversions) as conversions
    FROM `m_google_ads.campaign_stats_daily` 
    where business_id = '{business_id}'
        and date >= current_date - 30
        and date < current_date
    group by 1
    """

    biz = Business(business_id)

    google_data = GoogleAdsData(business_id, sql, days_rolling)
    google_data.calculate_metrics()

    cpconv_file = google_data.plot_bar_and_rolling_avg(
        "cost_per_conv", "Cost Per Conversion", "cost_per_conv_r7d_avg", " &#36;"
    )
    conv_file = google_data.plot_bar_and_rolling_avg(
        "conversions", "Conversions", "conversions_r7d_avg"
    )
    conversion_rate_file = google_data.plot_bar_and_rolling_avg(
        "conversion_rate", "Conversion Rate", "conversion_rate_r7d_avg", suffix="%"
    )
    click_through_rate_file = google_data.plot_bar_and_rolling_avg(
        "click_through_rate",
        "Click Through Rate",
        "click_through_rate_r7d_avg",
        suffix="%",
    )

    summaries = google_data.generate_summary()

    bucket_path = f"{_BUCKET}/{business_id}/{_TODAY}"
    title = f"G Ads Report for {biz.name}"

    slack = SlackMessage()
    slack.create_header_block(text=title)
    slack.create_divider_block()
    for summary in summaries:
        slack.create_section_block(text=summary)
    slack.create_plain_text(title)
    slack_response = slack.send_notification(channel=_CHANNEL)

    slack_in_thread = SlackMessage()
    slack_in_thread.create_plain_text(title)
    for f in [conv_file, cpconv_file, conversion_rate_file, click_through_rate_file]:
        if f is None:
            continue
        slack_in_thread.create_image_block(
            source_folder=_FOLDER,
            bucket=bucket_path,
            filename=f["file"],
            alt_text=f["name"],
        )
    slack_in_thread.send_notification(
        channel=_CHANNEL, thread_ts=slack_response.get("ts")
    )
    return slack_response


@http_function
def execute_http(request_json={}, request_args={}):
    business_id = "vzsuUIgfhKRenZq6I0U5"

    main(business_id, days_rolling=7)
    return "Success"


if __name__ == "__main__":
    main(business_id="vzsuUIgfhKRenZq6I0U5", days_rolling=7)
