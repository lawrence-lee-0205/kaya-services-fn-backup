import requests
import json

from http_function import slack_http_function


def process_create_task(payload):
    input = {
        "text": "Thanks for your message. We're creating a task to look into your request. The link to the task will be posted here shortly.",
        "response_type": "in_channel",
        "replace_original": False,
    }
    if "message_ts" in payload:
        input["thread_ts"] = payload["message_ts"]

    # REPLY TO THREAD FROM WHICH THE MESSAGE ACTION WAS TRIGGERED
    # request_reply_slack = requests.post(
    #     payload["response_url"],
    #     json=input,
    # )
    # print(request_reply_slack.text)

    request_create_ticket = requests.post(
        "https://us-central1-kaya-apps-00.cloudfunctions.net/create-task-in-noloco",
        json=payload,
    )
    return "Success"


@slack_http_function
def trigger_slack_event(payload={}):
    # print(f"payload:\n{payload}")
    if isinstance(payload, str):
        payload = json.loads(payload)

    for k, v in payload.items():
        print(f"{k}: {v}")

    if payload.get("callback_id") == "create-task":
        _ = process_create_task(payload)

    return {"status": "Success"}
