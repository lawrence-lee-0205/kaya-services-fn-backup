import os
import uuid
import datetime
import dateutil
import pandas as pd
import plotly.graph_objects as go
from typing import List

from utils.list import chunk_list
from utils.kaya_yaml import read_yaml
from http_function import http_function
from utils.jinja import render_template
from utils.datetimes import get_date_by_name
from google.gutils.bigquery import run_query
from slack_tools.slack import SlackMessage
from slack_tools.formatting import get_emoji, str_format_kpi
from slack_tools.chart import (
    FacetplotChart,
    PlotlyMultiChart,
    TableChart,
    PlotlyLineChart,
)
from storage.upload_blob import upload_blob


_FILE_DIR = "/tmp"
if os.environ["ENV"].upper() == "PROD":
    _CONFIG_DIR = "slack_tools/pulses_config/"
else:
    _CONFIG_DIR = "./pulses_config/"


def _create_context_block(rows, business_id):
    elements = []
    for row in rows:
        params = row.get("params", [])
        payload = _get_params(params, business_id)

        text = row["text"].format(**payload)

        elements.append({"type": "mrkdwn", "text": text})
    block = {"type": "context", "elements": elements}
    return [block]


def _create_fields(rows, business_id, variant="simple"):
    fields = []
    for row in rows:
        sql_raw = row["sql"]

        params = row.get("params", [])
        payload = _get_params(params, business_id)

        sql = sql_raw.format(**payload)
        df = run_query(sql, "dataframe")

        if len(df) > 2:
            raise Exception(f"Query returns {len(df)} rows. Expecting 2 rows or less.")

        comparison_dict = _get_metric_with_comparison(df)

        metric_name = row["metric_name"]

        emoji = get_emoji(comparison_dict["pct_change"])
        metric_formatted = str_format_kpi(comparison_dict["current"], metric_name)
        pct_formatted = str_format_kpi(
            abs(comparison_dict["pct_change"]), "pct_change_int"
        )

        if variant == "full":
            previous_metric_formatted = str_format_kpi(
                comparison_dict["previous"], metric_name
            )
            fields += [
                {
                    "type": "mrkdwn",
                    "text": f"{row['text']}:",
                },
                {
                    "type": "plain_text",
                    "text": f"{metric_formatted}, was {previous_metric_formatted}, {emoji}{pct_formatted}",
                    "emoji": True,
                },
            ]
        elif variant == "simple":
            fields += [
                {
                    "type": "mrkdwn",
                    "text": f"{row['text']}:",
                },
                {
                    "type": "plain_text",
                    "text": f"{metric_formatted} :: {emoji}{pct_formatted}",
                    "emoji": True,
                },
            ]
        else:
            raise ValueError("Only accept variant as 'full' or 'simple'.")

    if len(fields) > 10:
        chunked_list = chunk_list(fields, 10)
        blocks = [{"type": "section", "fields": chunk} for chunk in chunked_list]
    else:
        blocks = [{"type": "section", "fields": fields}]
    return blocks


def _create_templated_fields(rows: List[dict], business_id: str, variant="two_columns"):
    """_summary_

    Args:
        rows (List[dict]): _description_
        business_id (str): _description_
        variant (str, optional): _description_. Defaults to "simple".

    Raises:
        Exception: _description_
        ValueError: _description_

    Returns:
        _type_: _description_
    """

    fields = []
    for row in rows:
        sql_raw = row["sql"]

        params = row.get("params", [])
        payload = _get_params(params, business_id)

        sql = sql_raw.format(**payload)
        sql_output_lst = run_query(sql)

        if len(sql_output_lst) > 1:
            raise Exception(
                f"Query returns {len(sql_output_lst)} rows. Expecting 1 row or less."
            )
        elif len(sql_output_lst) == 0:
            if row.get("if_error", "raise").lower() == "coerce":
                continue
            raise Exception("No result returned from query!")

        data = sql_output_lst[0]
        populated_text = _populate_template(data, **row["template"])
        if variant == "two_columns":
            fields += [
                {
                    "type": "mrkdwn",
                    "text": f"{row['text']}:",
                },
                {
                    "type": "plain_text",
                    "text": populated_text,
                    "emoji": True,
                },
            ]
        elif variant == "single":
            print(populated_text)
            fields.append(
                {
                    "type": "mrkdwn",
                    "text": populated_text,
                }
            )

    if len(fields) > 10:
        chunked_list = chunk_list(fields, 10)
        blocks = [{"type": "section", "fields": chunk} for chunk in chunked_list]
    else:
        blocks = [{"type": "section", "fields": fields}]
    return blocks


def _populate_template(data: dict, **config):
    # list of fields to add arrows
    template_text = config["text"]
    fields_to_add_arrow = config.get("fields_to_add_arrow", [])
    include_anomaly_emoji = config.get("include_anomaly_emoji", False)

    # TODO: can check for anomaly_emoji INSTEAD OF USING include_anomaly_emoji
    if include_anomaly_emoji:
        # add new key value pair to template payload with emoji for anomaly
        # sql result must contain mandatory cols
        if ("anomaly_emoji_value" not in data) or (
            "anomaly_emoji_celebrate_direction" not in data
        ):
            raise Exception(
                "anomaly_emoji_value and anomaly_emoji_celebrate_direction must be returned from query to work in order to determine anomaly emoji"
            )

        if data["anomaly_emoji_celebrate_direction"].lower() == "none":
            data["anomaly_emoji"] = ""

        data["anomaly_emoji"] = _get_anomaly_emoji(
            value=data["anomaly_emoji_value"],
            celebrate_direction=data["anomaly_emoji_celebrate_direction"],
            threshold=data.get("anomaly_emoji_threshold", 50),
        )

    if len(fields_to_add_arrow) > 0:
        for field in fields_to_add_arrow:
            if field not in data:
                raise Exception(
                    f"Supposed to add arrow to '{field}', but '{field}' doesn't exist in query output"
                )

            if data[field] is None:
                continue

            # overwrite original value with arrow
            arrow = get_emoji(data[field])
            data[field] = f"{arrow}{abs(data[field]):.0f}"

    text = template_text.format(**data)
    return text


def _create_section_with_query_block(business_id, delimiter="\n", **kwargs):
    """Create a block for slack message where the context is populated dynamically based
    on SQL query output

    Args:
        business_id (_type_):
        delimiter (str, optional): If there are multi query records, split the text based on delimiter. Defaults to "\n".
    """
    template_config = kwargs["template"]

    # construct SQL
    sql_params = kwargs["params"]
    sql = kwargs["sql"]
    sql_payload = _get_params(sql_params, business_id)
    sql_filled = sql.format(**sql_payload)
    results = run_query(sql_filled)

    texts = []
    for res in results:
        text = _populate_template(data=res, **template_config)
        texts.append(text)
    text_to_write = delimiter.join(texts)

    block = {
        "type": "section",
        "text": {
            "type": "mrkdwn",
            "text": text_to_write,
        },
    }
    return [block]


def _create_section_with_query_and_image_block(business_id, delimiter="\n", **kwargs):
    """Create a block for slack message where the context is populated dynamically based
    on SQL query output

    Args:
        business_id (_type_):
        delimiter (str, optional): If there are multi query records, split the text based on delimiter. Defaults to "\n".
    """
    # PROCESS TEXT
    text_params = kwargs["text"]
    template_config = text_params["template"]

    # construct SQL
    sql_params = text_params["params"]
    sql = text_params["sql"]
    sql_payload = _get_params(sql_params, business_id)
    sql_filled = sql.format(**sql_payload)
    results = run_query(sql_filled)

    texts = [text_params.get("prefix", "")]
    for res in results:
        text = _populate_template(data=res, **template_config)
        texts.append(text)
    text_to_write = delimiter.join(texts)

    # PROCESS IMAGE
    image_params = kwargs["image"]
    chart_file = _make_chart(business_id, **image_params)
    source = f"{chart_file['source_folder']}/{chart_file['filename']}"
    print(f"Uploading file from {source}")
    file_url = upload_blob(
        bucket_name="kaya-apps-00.appspot.com",
        source_file_name=source,
        destination_blob_name=f"public-weekly-slack/{chart_file['filename']}",
        is_public=True,
    )

    block = {
        "type": "section",
        "text": {
            "type": "mrkdwn",
            "text": text_to_write,
        },
        "accessory": {
            "type": "image",
            "image_url": file_url,
            "alt_text": "alt text for image",
        },
    }
    return [block]


def _make_pivot_table(business_id, **kwargs):
    # TODO: COMBINE WITH CHART?
    sql_params = kwargs["params"]
    sql = kwargs["sql"]
    sql_payload = _get_params(sql_params, business_id)
    sql_filled = sql.format(**sql_payload)
    df = run_query(sql_filled, "dataframe")

    traces = kwargs["traces"]
    # TODO: FIX THIS
    trace = traces[0]

    pivot_params = {
        k: v for k, v in trace.items() if k in ["index", "columns", "values", "aggfunc"]
    }
    pivot_table = pd.pivot_table(df, **pivot_params)
    pivot_table.columns = list(pivot_table.columns.droplevel())
    pivot_table.fillna(0, inplace=True)

    if trace.get("sort_row_desc", False):
        pivot_table.sort_index(inplace=True, ascending=False)

    plotly_data = {
        "z": pivot_table.values,
        "x": pivot_table.columns.tolist(),
        "y": pivot_table.index.tolist(),
    }
    fig = go.Figure(
        data=go.Heatmap(
            plotly_data,
            text=plotly_data["z"],
            texttemplate="%{text}",
            # text_auto=True,
        )
    )
    fig.update_layout(
        coloraxis={"colorscale": "viridis"},
        margin=dict(l=50, r=50, b=20),
        legend=dict(orientation="h", y=-0.1, xanchor="right", x=1),
        title=go.layout.Title(
            text=kwargs.get("title", ""),
        ),
    )
    fig.update_xaxes(side="top")
    fig.update_traces(showscale=False)
    fig.show()
    # write to file
    file_name = f"{kwargs.get('title', '')}_{business_id}_{uuid.uuid4()}.png"
    fig.write_image(f"{_FILE_DIR}/{file_name}")

    return {
        "source_folder": _FILE_DIR,
        "filename": file_name,
        "alt_text": "table",
    }


def _make_chart(business_id, **kwargs):
    sql_params = kwargs["params"]
    sql = kwargs["sql"]
    sql_payload = _get_params(sql_params, business_id)
    sql_filled = sql.format(**sql_payload)
    df = run_query(sql_filled, "dataframe")

    # start plotting
    viz = kwargs["viz"]
    chart_class = {
        "facetplot": FacetplotChart,
        "plotly-multi": PlotlyMultiChart,
        "table": TableChart,
        "plotly-line": PlotlyLineChart,
    }
    chart = chart_class[viz](df, dir=_FILE_DIR, **kwargs["viz_config"])
    chart.plot()
    chart.write_to_file()
    return {
        "source_folder": _FILE_DIR,
        "filename": chart.filename,
        "alt_text": chart.title,
    }


def _get_anomaly_emoji(value, celebrate_direction, threshold):
    if value is None:
        return ""

    if abs(value) < threshold:
        # not an anomaly
        return ""

    # decide which emoji to return now that anomaly is detected
    is_positive_number = value > 0
    celebrate_direction = celebrate_direction.lower()
    if is_positive_number and celebrate_direction == "positive":
        return ":tada:"
    elif not is_positive_number and celebrate_direction == "negative":
        return ":tada:"
    else:
        return ":eyes:"


def _get_metric_with_comparison(df: pd.DataFrame) -> dict:
    df = pd.pivot_table(df, columns="label", aggfunc="sum", values="value")

    # if there is no result for a single period, fill it with 0
    for col in ["current", "previous"]:
        if col not in df.columns:
            df[col] = 0

    df["pct_change"] = 100 * (df["current"] - df["previous"]) / df["previous"]
    output = df.to_dict(orient="index")["value"]
    return output


def _get_params(params: list, business_id: str) -> dict:
    payload = {}
    for param in params:
        if param == "business_id":
            payload["business_id"] = business_id
        elif param == "today_abd":
            payload["today_abd"] = get_date_by_name("today", format="%a, %b %d")
        else:
            try:
                payload[param] = get_date_by_name(param)
            except Exception as e:
                print(e)
                raise NotImplementedError(f"Param {param} has not been implemented!")
    return payload


def send_slack_message(
    channels: list, blocks: list, business_id: str, notification_text: str
):
    message_main = SlackMessage()
    message_in_thread = SlackMessage()
    to_send_thread = False

    for content_config in blocks:
        type_ = content_config["type"]
        is_thread_reply = content_config.get("is_thread_reply", False)

        if is_thread_reply:
            message = message_in_thread
            to_send_thread = True  # TODO: CHECK THIS FROM THE CLASS ITSELF
        else:
            message = message_main

        if type_ == "header":
            params = content_config.get("params", [])
            payload = _get_params(params, business_id)
            text = content_config["text"].format(**payload)
            message.create_header_block(text)
        elif type_ == "divider":
            message.create_divider_block()
        elif type_ == "section":
            params = content_config.get("params", [])
            payload = _get_params(params, business_id)
            text = content_config["text"].format(**payload)
            escape_newline = content_config.get("escape_newline", False)
            message.create_section_block(text, escape_newline)
        elif type_ == "fields":
            block = _create_fields(content_config["rows"], business_id)
            message.add_list_of_blocks(block)
        elif type_ == "fields_full":
            block = _create_fields(content_config["rows"], business_id, variant="full")
            message.add_list_of_blocks(block)
        elif type_ == "fields_templated":
            block = _create_templated_fields(
                content_config["rows"], business_id, variant="two_columns"
            )
            message.add_list_of_blocks(block)
        elif type_ == "fields_templated_single":
            """
            Example:
            - type: fields_templated_single
            rows:
                - template:
                    text: '*CTR*: 5% :: was 4%, :tada:'
                sql: >
                    select
                        count(distinct uuid) as num_tasks
                    from src_noloco.tasks
                    where business_id = 'WEjnxhwjRclMr05ZwcNw'
                    and cast(left(dueDate, 10) as date) >= CURRENT_DATE()
                    and cast(left(dueDate, 10) as date) < CURRENT_DATE() + 7
                - template:
                    text: '*CVR*:\n5% :: was 4%, :tada:'
                sql: >
                    select
                        count(distinct uuid) as num_tasks,
                    from src_noloco.tasks
                    where business_id = 'WEjnxhwjRclMr05ZwcNw'
                    and cast(left(dueDate, 10) as date) < CURRENT_DATE()
                    and status not in ('DONE', 'IN_REVIEW')
            """
            block = _create_templated_fields(
                content_config["rows"], business_id, variant="single"
            )
            message.add_list_of_blocks(block)
        elif type_ == "context":
            block = _create_context_block(content_config["rows"], business_id)
            message.add_list_of_blocks(block)
        elif type_ == "section_with_query":
            block = _create_section_with_query_block(
                business_id,
                **content_config,
            )
            message.add_list_of_blocks(block)
        elif type_ == "section_with_query_and_image":
            block = _create_section_with_query_and_image_block(
                business_id,
                **content_config,
            )
            message.add_list_of_blocks(block)
        elif type_ == "chart":
            chart_file = _make_chart(business_id, **content_config)
            message.create_image_block(
                chart_file["source_folder"],
                bucket="public-weekly-slack",
                filename=chart_file["filename"],
                alt_text=chart_file["alt_text"],
                to_remove_file=True,
            )
        elif type_ == "pivot_table":
            table_file = _make_pivot_table(business_id, **content_config)
            message.create_image_block(
                table_file["source_folder"],
                bucket="public-weekly-slack",
                filename=table_file["filename"],
                alt_text=table_file["alt_text"],
                to_remove_file=True,
            )
        elif type_ == "text_with_button":
            print(content_config["text"])
            params = content_config.get("params", [])
            print(params)
            payload = _get_params(params, business_id)
            text = content_config["text"].format(**payload)

            text = "\n".join(text.split("\n"))

            message.create_text_with_button_block(
                text=text,
                button_text=content_config["button_text"],
                button_value=content_config["button_value"],
                button_url=content_config["button_url"],
                button_action_id=content_config["button_action_id"],
            )
        else:
            raise NotImplementedError(
                f"Slack config of type {type_} has not been implemented."
            )

    message_main.create_plain_text(notification_text)

    for channel in channels:
        resp = message_main.send_notification(channel=channel)

        if to_send_thread:
            _ = message_in_thread.send_notification(
                channel=channel, thread_ts=resp.get("ts")
            )
    return None


def main(config_name, env, config_dir=_CONFIG_DIR):
    if "__template" in config_name:
        output = render_template(config_dir, config_name + ".yml")
        yml_out_filename = config_name.replace("__template", "") + ".yml"
        yml_out_fullpath = _FILE_DIR + "/" + yml_out_filename

        with open(yml_out_fullpath, "w") as f:
            f.write(output)
    else:
        # append / to the end of config_dir if / is not present
        if config_dir[-1] != "/":
            config_dir += "/"

        # append .yml to the end of config_name if .yml is not present
        if config_name[-4:] != ".yml":
            print(f"Appending .yml to the end of config_name {config_name}")
            config_name += ".yml"

        yml_out_fullpath = f"{config_dir}{config_name}"

    print("Processing from", yml_out_fullpath)
    config = read_yaml(yml_out_fullpath)["report"]
    channels = config["channel"] if env.upper() == "PROD" else ["C02PYBMGLL9"]

    # construct slack msg
    send_slack_message(
        channels=channels,
        blocks=config["contents"],
        business_id=config["business_id"],
        notification_text=config["notification_text"],
    )

    return "Success"


@http_function
def send_client_slack_pulse(request_json={}, request_args={}):
    if request_json and "env" in request_json:
        env = request_json["env"]
    elif request_args and "env" in request_args:
        env = request_args["env"]
    else:
        env = "dev"

    if request_json and "name" in request_json:
        name = request_json["name"]
    elif request_args and "name" in request_args:
        name = request_args["name"]
    else:
        raise Exception("Expecting 'name' to be passed into the API call.")

    return main(name, env)


if __name__ == "__main__":
    for c in [
        # "liveflow__template",
        # "basis_google_ads",
        # "billiontoone_google_ads",
        # "fella",
        # "bristle"
        # "bristle_daily",
        # "numero_google_ads",
        # "liveflow_google_ads",
        # "uol_daily",
        # "uol_google_ads",
        # "herondata_daily",
        # "numero_daily",
        # "kaya_google_ads",
        # "sphere_google_ads",
        # "fella_weekly__template",
        # "dailybot_google_ads",
        # "joon_google_ads",
        # "yara_google_ads",
        # "abbot_google_ads_weekly__template",
        # "dailybot_google_ads_weekly__template"
        # "yara_google_ads_weekly__template"
        "wyndly_weekly__template"
    ]:
        main(c, env="dev")
