from firestore import FirestoreClient
from constants import CCY_SYMBOLS

FS = FirestoreClient()


class Business:
    def __init__(self, business_id: str) -> None:
        self.business_id = business_id
        self._data = FS.get_single_document("businesses", business_id)

    @property
    def name(self):
        return self._data["name"]

    @property
    def ccy(self):
        return self._data["ccy"]

    @property
    def home_dashboard_id(self):
        return self._data["home_dashboard_id"]

    @property
    def communication_preference(self):
        return self._data["communication_preference"]

    @property
    def communication_hour_utc(self):
        return self._data["communication_hour_utc"]

    @property
    def slack_channel_id(self):
        return self._data["slack_channel_id"]

    @property
    def ccy(self):
        return self._data["ccy"]

    @property
    def ccy_symbol(self):
        return CCY_SYMBOLS[self.ccy]

    @property
    def kpi_name(self):
        return self._data["kpi_name"]

    @property
    def cost_per_kpi_name(self):
        name = self._data.get("cost_per_kpi_name", "Cost per " + self.kpi_name.title())
        return name

    @property
    def analytic_features(self):
        return self._data.get("analytic_features", {})

    @property
    def noloco_company_id(self):
        return self._data.get("noloco_company_id")

    @property
    def stripe_customer_id(self):
        return self._data.get("stripe_customer_id")

    @property
    def url(self):
        return self._data["url"]

    @property
    def gdrive_url(self):
        return self._data.get("drive_url")

    def get_users(self):
        users_ref = FS.get_collection("users")
        docs = users_ref.where(
            "businesses", "array_contains", self.business_id
        ).stream()
        list_of_dict = [{"id": doc.id, **doc.to_dict()} for doc in docs]
        return list_of_dict

    def get_marketers(self):
        users_ref = FS.get_collection("users")
        docs = (
            users_ref.where("role", "==", "KAYA_INTERNAL")
            .where("businesses", "array_contains", self.business_id)
            .stream()
        )
        list_of_dict = [{"id": doc.id, **doc.to_dict()} for doc in docs]
        return list_of_dict

    def get_admins(self):
        users_ref = FS.get_collection("users")
        docs = (
            users_ref.where("role", "==", "KAYA_ADMIN")
            .where("businesses", "array_contains", self.business_id)
            .stream()
        )
        list_of_dict = [{"id": doc.id, **doc.to_dict()} for doc in docs]
        return list_of_dict


if __name__ == "__main__":
    biz = Business("ghUYDr9B4q1gGk8xuq0b")
    print(biz.get_marketers())
