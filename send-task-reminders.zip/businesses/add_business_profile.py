from firestore import FirestoreClient


if __name__ == "__main__":
    fs = FirestoreClient()
    profile = f"""
MES is an online learning platform designed specifically for children aged between 8 to 18 years. The company provides live interactive lessons through their proprietary platform, where MES teachers engage learners with an interactive and engaging teaching method, led by experienced teachers who were ex-examiners. 

Each course includes:
- live classes where students can interact with the teachers via live chat
- video recordings of the live classes
- exam-style homework
- step-by-step video solutions, and access to the UK's largest student community. They also provide professionally designed workbooks and recording access

Some courses include personal tutor for 1-1 mentoring.
"""
    value_props = f"""
Value for money: Much cheaper than 1-1 tuition
<br />
Quality: Experienced teachers who were ex-examiners
<br />
Convenience: Learn from the comfort of your home
<br />
Engagement: Interactive and engaging teaching method. Teachers are fun and cool.
"""
    fs.update_document(
        collection="businesses",
        id="no2DKxHGYQshKxZAJxmj",
        content={"value_props": value_props, "profile": profile},
    )
