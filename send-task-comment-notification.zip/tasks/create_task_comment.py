import time
import json
import logging
import datetime as dt
from os import environ

import google.cloud.logging

from noloco.request import call_noloco_api
from http_function import http_function, process_request_inputs
from common import validate_inputs
from firestore import FirestoreClient
from google.cloud.firestore_v1.base_query import FieldFilter
from slack_tools.send_ephemeral_message import send_ephemeral_message

if environ.get("ENV") == "PROD":
    log_client = google.cloud.logging.Client()
    log_client.setup_logging()


_FS = FirestoreClient()
_LOG_COLLECTION = "slack_add_thread_to_task_comment_log"

_MAX_RETRY = 3


@http_function
def slack_create_task_comment(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)
    logging.debug(data)
    mandatory_fields = [
        "comment_content",
        "sender_slack_id",
        "thread_ts",
        "retry_num",
        "client_msg_id",
        "channel",
    ]
    validate_inputs(data, mandatory_fields)

    client_msg_id = data["client_msg_id"]
    retry_num = data["retry_num"]

    logging.info(
        f"Received message event with client_msg_id {client_msg_id}. Retry num: {retry_num}"
    )

    if retry_num != "0":
        attempt = 1
        while attempt <= _MAX_RETRY:
            try:
                logging.info(
                    f"Attempt {attempt} to get Firestore log doc for {client_msg_id}"
                )
                log = _FS.get_single_document(_LOG_COLLECTION, data["client_msg_id"])
                break
            except ValueError:
                logging.warn(
                    f"No log found for {client_msg_id}. Previous attempt is probably still in progress. Wait for 1 min."
                )
                time.sleep(30)
                attempt += 1

                if attempt == _MAX_RETRY:
                    logging.info("Max retry reached. Creating new log entry..")
                    _create_new_log_entry(data["client_msg_id"], data)

        if log["status"] == "IN_PROGRESS":
            logging.info(
                "This is a retry. Message is still being processed. Aborting.."
            )
            return {"status": "Success"}
        elif log["status"] == "SUCCESS":
            logging.info("This is a retry. Message has been processed. Aborting..")
            return {"status": "Success"}
        elif log["status"] == "FAILED":
            logging.info(
                "This is a retry. Message failed to process in previous attempt. Retrying.."
            )
    else:
        # first attempt, add to log
        _create_new_log_entry(data["client_msg_id"], data)

    create_task_comment_from_slack(
        sender_slack_id=data["sender_slack_id"],
        thread_ts=data["thread_ts"],
        comment_content=data["comment_content"],
        client_msg_id=data["client_msg_id"],
        channel=data["channel"],
        retry_num=retry_num,
    )
    return {"status": "Success"}


def _create_new_log_entry(client_msg_id, data):
    _FS.add_document(
        _LOG_COLLECTION,
        {"status": "IN_PROGRESS", **data, "created_at": dt.datetime.utcnow()},
        id=client_msg_id,
    )
    return None


def create_task_comment_from_slack(
    sender_slack_id, thread_ts, comment_content, client_msg_id, channel, retry_num
):
    _FS.update_document(
        _LOG_COLLECTION,
        client_msg_id,
        {
            "status": "IN_PROGRESS",
            "updated_at": dt.datetime.utcnow(),
        },
    )
    user_ref = _FS.get_collection("users")
    user_docs = user_ref.where(
        filter=FieldFilter("slack_id", "==", sender_slack_id)
    ).stream()

    commenter_firestore_ids = [doc.id for doc in user_docs]
    if len(commenter_firestore_ids) > 1:
        logging.info(
            f"Multiple user found with slack ID: {sender_slack_id}. Users are {commenter_firestore_ids}"
        )

    task_ids = []
    for commenter_firestore_id in commenter_firestore_ids:
        task_ids += _get_task_id(thread_ts, commenter_firestore_id)
    task_ids = set(task_ids)

    if len(task_ids) == 0:
        logging.warn(f"No task found for this thread_ts: {thread_ts}")
        _FS.update_document(
            _LOG_COLLECTION,
            client_msg_id,
            {
                "status": "FAILED",
                "error": "No task found",
                "updated_at": dt.datetime.utcnow(),
            },
        )
        return None

    for task_id in task_ids:
        try:
            task_comment_id = create_task_comment(
                comment_content=comment_content,
                commenter_firestore_id=commenter_firestore_id,
                task_id=task_id,
            )
            send_ephemeral_message(
                channel_id=channel,
                slack_user_id=sender_slack_id,
                text="🎉 Successfully updated task with your comment",
                thread_ts=thread_ts,
            )
        except KeyError:
            logging.error(f"Error creating task comment for task {task_id}")
            _FS.update_document(
                _LOG_COLLECTION,
                client_msg_id,
                {
                    "status": "FAILED",
                    "error": "Error creating task comment",
                    "updated_at": dt.datetime.utcnow(),
                    "retry_num": retry_num,
                },
            )

            if retry_num == "3":
                # hit max retry, notify user to send comment manually
                send_ephemeral_message(
                    channel_id=channel,
                    slack_user_id=sender_slack_id,
                    text="😵 Failed to add comment to task. Please add comment manually via the app.",
                    thread_ts=thread_ts,
                )
            return None

    _FS.update_document(
        _LOG_COLLECTION,
        client_msg_id,
        {
            "status": "SUCCESS",
            "tasks": task_ids,
            "updated_at": dt.datetime.utcnow(),
            "task_comment_id": task_comment_id,
            "retry_num": retry_num,
        },
    )
    return None


def create_task_comment(
    comment_content,
    commenter_firestore_id,
    task_id,
    owners_to_notify=None,
    skip_notification=False,
) -> None:
    now_str = dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

    additional_q = ""
    if owners_to_notify:
        additional_q += f'customNotificationRecipientIds: "{owners_to_notify}"\n'

    if skip_notification:
        additional_q += "skipNotification: true\n"

    # task comment will be internal by default
    # TODO comment owner should be task creatorpip install --upgrade google-cloud-firestore
    logging.info("Running mutation to create task comment in Noloco")
    content = json.dumps(comment_content)
    q = f"""
        mutation MyMutation {{
            createAppComment(
                commentContent: {content}
                commenterOwnerThatsVisibleInApp: "{commenter_firestore_id}"
                createdAt: "{now_str}"
                isNotReviewed: true
                taskId: "{task_id}"
                {additional_q}
            ){{
                id
            }}
        }}
    """
    o = call_noloco_api(body=q)

    try:
        task_comment_id = o["data"]["createAppComment"]["id"]
        logging.info(f"Task comment ID: {task_comment_id}")
    except KeyError:
        logging.error(o)
        raise KeyError("Task comment ID not found in response")
    return task_comment_id


def _get_task_id(thread_ts, user_firestore_id) -> list:
    q = f"""
    query MyQuery {{
        appCommentNotificationCollection(
            where: {{threadTs: {{equals: "{thread_ts}"}}, userFirestoreId: {{equals: "{user_firestore_id}"}}}}
        ) {{
            edges {{
                node {{
                    appComment {{
                        task {{
                            id
                        }}
                    }}
                }}
            }}
        }}
    }}
    """
    output = call_noloco_api(body=q)["data"]["appCommentNotificationCollection"][
        "edges"
    ]
    if len(output) == 0:
        logging.info(
            f"No task found in appCommentNotificationCollection this thread_ts: {thread_ts} and user: {user_firestore_id}"
        )
        return []
    elif len(output) > 1:
        logging.info(
            f"More than one task found for this thread_ts: {thread_ts} and user: {user_firestore_id}"
        )

    task_ids = [o["node"]["appComment"]["task"]["id"] for o in output]
    logging.info(f"Task ID: {task_ids}")
    return task_ids


if __name__ == "__main__":
    data = {
        "sender_slack_id": "C04LMLPHG3G",
        "thread_ts": "1700572011.984869",
        "comment_content": "from vscode again",
        "channel": "D02Q9E7JEL8",
        "retry_num": "1",
        "client_msg_id": "test",
    }
    create_task_comment_from_slack(**data)
