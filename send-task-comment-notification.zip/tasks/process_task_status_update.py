from http_function import http_function, process_request_inputs
from noloco.request import call_noloco_api


@http_function
def process_task_status_update(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)

    task_id = data["id"]
    new_status = data["status"]
    updated_at = data["updatedAt"]

    # IN_PROGRESS datetime will only be updated once, it cannot be overwritten
    # IN_REVIEW and COMPLETED datetime can be overwritten
    if (new_status == "IN_PROGRESS") and (data.get("inProgressDatetime", None) is None):
        field_to_update = "inProgressDatetime"
    elif new_status == "IN_REVIEW":
        field_to_update = "inReviewDatetime"
    elif new_status == "DONE":
        field_to_update = "completedDatetime"
    else:
        return None

    query = f"""
    mutation MyMutation {{
        updateTask(id: "{task_id}", {field_to_update}: "{updated_at}") {{
            inProgressDatetime
            inReviewDatetime
            completedDatetime
        }}
    }}
    """
    resp = call_noloco_api(query)
    return "Success"
