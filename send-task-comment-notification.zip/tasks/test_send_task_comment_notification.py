# write unit tests to validate list of people who will get notifications
from users.user import User
from tasks.task import Task
from tasks.comment import Comment
from businesses.business import Business

from send_task_comment_notification import get_notification_config

import unittest

# need to run these tests in DEV env


# we can overwrite comment metadata eg:
# content
# is_reviewed
# last_notification_sent_at
class TestComment(unittest.TestCase):
    def setUp(self):
        # true value expected from user doc
        self.public_task_assigned_to_client_uuid = "rec19g613ljzumzzn"
        self.public_task_assigned_to_marketer_uuid = "rec19g613ljzvzwvu"
        self.internal_task_assigned_to_marketer_uuid = "rec19g613ljzjugzt"

        self.business_id = "lyu6tWbXJlYQmfzi6uGg"
        self.client_firestore_id = "sIA5ginaOHcfAUjXh6Sb"
        self.admin_firestore_id = "L2AcOmahqmhNMf7c9sbx"
        self.marketer_firestore_id = "2gG5f6BPFkG2CfcLv3QV"
        self.client_2_firestore_id = "bitnkkYXRExPPj0GCuuD"

    def _execute_test(self, task_uuid, comment_input, expected_recipients):
        business = Business(self.business_id)
        task = Task(uuid=task_uuid, business=business)
        comment = Comment(task=task, **comment_input)

        config = get_notification_config(
            task, business, comment, trigger="is_new_app_comment"
        )
        recipient_firestore_ids = sorted([r.user_id for r in config["recipients"]])
        self.assertEqual(recipient_firestore_ids, expected_recipients)

    def test_reviewed_comment_by_client_on_public_task_assigned_to_client(self):
        # https://teamdev.noloco.co/app-comment/view/rec19g613ljzus84b
        comment_input = {
            "id": 145,
            "content": "this is a comment",
            "is_reviewed": True,
            "last_notification_sent_at": None,
            "commenter_firestore_id": self.client_firestore_id,
        }
        expected_recipients = sorted(
            [
                self.marketer_firestore_id,
                self.client_2_firestore_id,
                self.admin_firestore_id,
                self.client_firestore_id,
            ]
        )
        self._execute_test(
            self.public_task_assigned_to_client_uuid,
            comment_input,
            expected_recipients,
        )

    def test_unreviewed_comment_by_marketer_on_public_task_assigned_client(self):
        comment_input = {
            "id": 145,
            "content": "this is a comment",
            "is_reviewed": False,
            "last_notification_sent_at": None,
            "commenter_firestore_id": self.marketer_firestore_id,
        }
        expected_recipients = sorted(
            [
                self.admin_firestore_id,
                self.marketer_firestore_id,
            ]
        )
        self._execute_test(
            self.public_task_assigned_to_client_uuid,
            comment_input,
            expected_recipients,
        )

    def test_unreviewed_comment_by_marketer_on_public_task_assigned_marketer(self):
        comment_input = {
            "id": 146,
            "content": "this is a comment",
            "is_reviewed": False,
            "last_notification_sent_at": None,
            "commenter_firestore_id": self.marketer_firestore_id,
        }
        expected_recipients = sorted(
            [
                self.admin_firestore_id,
                self.marketer_firestore_id,
            ]
        )
        self._execute_test(
            self.public_task_assigned_to_marketer_uuid,
            comment_input,
            expected_recipients,
        )

    def test_unreviewed_comment_by_marketer_on_internal_task_assigned_internal(self):
        comment_input = {
            "id": 147,
            "content": "this is a comment",
            "is_reviewed": False,
            "last_notification_sent_at": None,
            "commenter_firestore_id": self.marketer_firestore_id,
        }
        expected_recipients = sorted(
            [
                self.admin_firestore_id,
                self.marketer_firestore_id,
            ]
        )
        self._execute_test(
            self.public_task_assigned_to_marketer_uuid,
            comment_input,
            expected_recipients,
        )

    def test_reviewed_comment_by_marketer_on_public_task_assigned_client(self):
        comment_input = {
            "id": 145,
            "content": "this is a comment",
            "is_reviewed": True,
            "last_notification_sent_at": None,
            "commenter_firestore_id": self.marketer_firestore_id,
        }
        expected_recipients = sorted(
            [
                self.marketer_firestore_id,
                self.client_2_firestore_id,
                self.admin_firestore_id,
                self.client_firestore_id,
            ]
        )
        self._execute_test(
            self.public_task_assigned_to_client_uuid,
            comment_input,
            expected_recipients,
        )


if __name__ == "__main__":
    unittest.main()
