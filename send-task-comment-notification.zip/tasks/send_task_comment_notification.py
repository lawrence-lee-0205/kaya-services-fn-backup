import ast
from typing import List

from users.user import User
from tasks.task import Task
from tasks.comment import Comment
from businesses.business import Business
from http_function import http_function, process_request_inputs
from tasks.notification import Notification
import sentry_sdk


@http_function
def send_task_comment_notification(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)
    print(data)
    is_comment_reviewed = not data["isNotReviewed"]

    comment_custom_notification_recipient_ids = data.get(
        "customNotificationRecipientIds", "[]"
    )
    if comment_custom_notification_recipient_ids in ["", "None", " "]:
        comment_custom_notification_recipient_ids = "[]"
    comment_custom_notification_recipient_ids = ast.literal_eval(
        comment_custom_notification_recipient_ids
    )

    if data.get("skipNotification"):
        print("skipNotification is set to true. No notification is sent.")
        return "Success"

    execute(
        trigger=data["trigger"],
        comment_id=data["id"],
        is_comment_reviewed=is_comment_reviewed,
        task_uuid=data["task_uuid"].strip(),
        business_id=data["business_id"].strip(),
        comment_content=data["commentContent"],
        commenter_firestore_id=data["commenterOwnerThatsVisibleInApp"].strip(),
        last_notification_sent_at=data.get("lastNotificationSentAt"),
        comment_custom_notification_recipient_ids=comment_custom_notification_recipient_ids,
    )
    return "Success"


def execute(
    trigger: str,
    comment_id: str,
    is_comment_reviewed: bool,
    task_uuid: str,
    business_id: str,
    comment_content: str,
    commenter_firestore_id: str,
    last_notification_sent_at: str = None,
    comment_custom_notification_recipient_ids: List[str] = [],
    **kwargs,
):
    business = Business(business_id)
    task = Task(uuid=task_uuid, business=business)
    comment = Comment(
        id=comment_id,
        content=comment_content,
        commenter_firestore_id=commenter_firestore_id,
        task=task,
        last_notification_sent_at=last_notification_sent_at,
        is_reviewed=is_comment_reviewed,
        custom_notification_recipient_ids=comment_custom_notification_recipient_ids,
    )
    config = get_notification_config(task, business, comment, trigger)
    _process_notifications(**config)
    return None


def get_notification_config(
    task: Task, business: Business, comment: Comment, trigger: str
):
    if task.visibility not in ["internal", "admin", "public"]:
        raise ValueError(f"Invalid task visibility: {task.visibility}")

    # if notification recipient is explicitly specified, use that instead of the default
    if (
        comment.custom_notification_recipients
        or len(comment.custom_notification_recipients) > 0
    ):
        potential_recipients = comment.custom_notification_recipients
    else:
        potential_recipients = task.owner_watcher_admin

    if task.visibility == "internal":
        recipients_incl_commenter = [
            user for user in potential_recipients if user.role in ["admin", "marketer"]
        ]
        return {
            "template": "new_comment",
            "default_comm_method": "slack",
            "recipients": recipients_incl_commenter,
            "comment": comment,
        }

    if task.visibility == "admin":
        recipients_incl_commenter = [
            user for user in potential_recipients if user.role == "admin"
        ]
        return {
            "template": "new_comment",
            "default_comm_method": "slack",
            "recipients": recipients_incl_commenter,
            "comment": comment,
        }

    # at this point, we're left with task visibility = public
    if comment.is_reviewed:
        # could happen when someone adds a new comment and it's flagged as reviewed immediately or
        # when admin marks an existing comment as reviewed

        # we only want to notify people of the comment once.
        users_notified = comment.get_users_who_were_notified()
        print("these users were notified so they will be skipped: ", users_notified)
        recipients_incl_commenter = [
            user for user in potential_recipients if user.user_id not in users_notified
        ]

        config = {
            "template": "new_comment",
            "default_comm_method": business.communication_preference,
            "recipients": recipients_incl_commenter,
            "comment": comment,
        }
    elif comment.is_reviewed is False and trigger == "is_new_app_comment":
        # hidden comments added by admin or marketer
        recipients_incl_commenter = [
            user for user in potential_recipients if user.role in ["admin", "marketer"]
        ]
        config = {
            "template": "new_comment",
            "default_comm_method": "slack",
            "recipients": recipients_incl_commenter,
            "comment": comment,
        }
    elif comment.is_reviewed is False and trigger == "is_not_reviewed_updated":
        recipients = [task.admin]
        config = {
            "template": "admin_review_comment",
            "default_comm_method": "slack",
            "recipients": recipients,
            "comment": comment,
        }
    else:
        raise ValueError(
            f"Action unknown: {comment.is_reviewed} {comment.last_notification_sent_at} {trigger}"
        )
    return config


def _process_notifications(
    template: str,
    default_comm_method: str,
    recipients: List[User],
    comment: Comment,
    exclude_commenter: bool = True,
):
    if exclude_commenter:
        recipients = [
            user
            for user in recipients
            if user.user_id != comment.commenter_firestore_id
        ]

    for recipient in recipients:
        try:
            notification = Notification(
                template=template,
                default_comm_method=default_comm_method,
                recipient=recipient,
                comment=comment,
                all_recipients=recipients,
            )
            notification.send()
        except Exception as e:
            sentry_sdk.set_tag("service", "send_task_comment_notification")
            print(f"Error sending notification to {recipient.full_name}: {e}")
            raise e
    return None


if __name__ == "__main__":
    pass
