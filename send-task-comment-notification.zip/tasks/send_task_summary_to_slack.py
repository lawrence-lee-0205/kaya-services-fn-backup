import ast
import pandas as pd
import datetime as dt

from common import validate_inputs
from businesses.business import Business
from firestore import FirestoreClient
from slack_tools.slack import SlackMessage
from noloco.request import call_noloco_api
from http_function import http_function, process_request_inputs

_TODAY_DATE = dt.date.today()
_DEV_CHANNEL = "U02P4RZDN5P"
# _DEV_CHANNEL = "C02PYBMGLL9"

_URL = "app.usekaya.com/tasks"
# _URL = "teamdot.noloco.co/task/view"

_FS = FirestoreClient()

_STATUS_MAPPING = {
    "TO_DO": "🔹",
    "IN_PROGRESS": "🔸",
}


@http_function
def send_weekly_task_summary(request_json={}, request_args={}):
    mandatory_fields = ["business_id", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    return execute(data["business_id"], data["env"])


def execute(business_id, env="DEV"):
    if business_id == "all":
        # TODO: get all businesses
        business_ids = ["G28ayyMdb3NpFTpmnDDx"]
        for biz_id in business_ids:
            _process_single_business(biz_id, env)
    else:
        _process_single_business(business_id, env)
    return None


def _process_single_business(business_id, env="DEV"):
    biz = Business(business_id)

    resp = _get_data_from_noloco(business_id)
    tasks_df = _process_tasks(resp)

    if biz.communication_preference == "slack":
        channel = biz.slack_channel_id if env == "PROD" else _DEV_CHANNEL
        _send_task_summary_to_slack(tasks_df, channel, biz.name)
    else:
        raise Exception("Communication preference not supported")

    return None


def _get_data_from_noloco(business_id):
    body = """
    query TaskList {
    companyCollection(where: {fsId: {equals: "{{business_id}}"}}) {
        edges {
        node {
            tasksCollection(where: {status: {in: ["TO_DO", "IN_PROGRESS"]}, isInternal: {equals: false}}) {
            edges {
                node {
                uuid
                status
                ownerThatsVisibleOnApp
                owner {
                    edges {
                    node {
                        id
                        firstName
                    }
                    }
                }
                name
                dueDate
                }
            }
            }
            name
        }
        }
    }
    }
    """

    # QUERY NOLOCO
    resp = call_noloco_api(body.replace("{{business_id}}", business_id))
    return resp


def _process_tasks(raw_data):
    data_companies = raw_data["data"]["companyCollection"]["edges"]
    if len(data_companies) > 1:
        raise Exception("More than one company returned")

    company_name = data_companies[0]["node"]["name"]
    data_task = data_companies[0]["node"]["tasksCollection"]["edges"]

    # CONVERT DATA FROM NOLOCO INTO DATAFRAME
    tasks = []
    for d in data_task:
        task = d["node"]
        try:
            # process single task
            owner_visible_on_app = ""
            if task["ownerThatsVisibleOnApp"]:
                owner_visible_on_app_input = ast.literal_eval(
                    task["ownerThatsVisibleOnApp"]
                )
                if len(owner_visible_on_app_input) > 0:
                    owner_visible_on_app_input = [
                        _get_user_name_from_firestore(o)
                        for o in owner_visible_on_app_input
                    ]
                owner_visible_on_app = ", ".join(owner_visible_on_app_input)

            owner = owner_visible_on_app if owner_visible_on_app != "" else "Kaya"

            name = task["name"].replace(company_name + " - ", "")

            tasks.append(
                {
                    **task,
                    "owner": owner,
                    "company": company_name,
                    "name_processed": name,
                }
            )
        except Exception as e:
            print(f"Error processing task {task['uuid']} {task['name']}")
            raise
    tasks_df = pd.DataFrame(tasks)
    print(f"{tasks_df.shape} rows returned")

    # PROCESS DUE DATE
    tasks_df["today"] = pd.to_datetime("today", utc=True)
    tasks_df["due_date_dt"] = pd.to_datetime(tasks_df["dueDate"], utc=True)
    tasks_df["due_date_str"] = tasks_df["due_date_dt"].dt.strftime("%a, %b %d")

    tasks_df["due_days_from_today"] = (
        tasks_df["due_date_dt"] - tasks_df["today"]
    ).dt.days
    tasks_df["due_date_category"] = tasks_df["due_days_from_today"].apply(
        lambda x: "overdue" if x < 0 else "due this week" if x < 7 else "due later"
    )

    # SORT TASKS
    tasks_df = tasks_df.sort_values(
        ["status", "due_date_dt", "owner"], ascending=[False, True, True]
    )
    return tasks_df


def _convert_df_list_to_str(df: pd.DataFrame, delimiter=""):
    lst = df["summary"].to_list()
    string = f"\n {delimiter}".join(lst)
    return string


def _get_user_name_from_firestore(user_id):
    user_doc = _FS.get_single_document("users", user_id)

    if "slack_id" in user_doc:
        return f'<@{user_doc["slack_id"]}>'
    else:
        return user_doc["first_name"]


def _send_task_summary_to_slack(tasks_df, channel, biz_name):
    # FORMAT TASK INTO A STRING
    tasks_df["summary"] = tasks_df.apply(
        lambda x: f'{_STATUS_MAPPING[x["status"]]} <https://{_URL}/{x["uuid"]}|{x["name_processed"]}> · {x["owner"]} by {x["due_date_str"]}',
        axis=1,
    )

    # CONSTRUCT SLACK MSG
    title = f"Task Summary for {biz_name} w/c {_TODAY_DATE}"
    context_statuses = [
        {
            "type": "plain_text",
            "text": f"{emoji} {s.replace('_', ' ')}",
            "emoji": True,
        }
        for s, emoji in _STATUS_MAPPING.items()
    ]
    context_statuses.append(
        {
            "type": "plain_text",
            "text": "We'll prioritise tasks based on their due dates.",
            "emoji": True,
        }
    )
    context_block = {
        "type": "context",
        "elements": context_statuses,
    }

    bot = SlackMessage()
    bot.create_header_block(title)
    bot.create_divider_block()
    # construct msg for each category
    for category in ["overdue", "due this week", "due later"]:
        tasks_due_this_week_df = tasks_df.loc[tasks_df["due_date_category"] == category]
        num_task_due_this_week = tasks_due_this_week_df.shape[0]

        if num_task_due_this_week == 0:
            continue

        bot.create_section_block(text=f"> {num_task_due_this_week} tasks {category}")

        this_week_str = _convert_df_list_to_str(tasks_due_this_week_df)
        bot.create_section_block(text=f"{this_week_str}")
    bot.create_section_block(text="\n")
    bot.create_section_block(
        text=f"*Action Required*:\nTask owner, please provide updates by adding comment to the task, or changing task status/due date."
    )
    bot.create_divider_block()
    bot.append_block(context_block)
    bot.create_plain_text(text=title)
    bot.send_notification(channel=channel)
    return None


if __name__ == "__main__":
    execute(business_id="G28ayyMdb3NpFTpmnDDx")
