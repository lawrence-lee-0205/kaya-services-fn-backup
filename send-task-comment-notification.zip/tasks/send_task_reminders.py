import json
import pandas as pd
import datetime as dt
from ast import literal_eval

from users.user import User
from firestore import FirestoreClient
from noloco.request import call_noloco_api
from slack_tools.slack import SlackMessage
from http_function import http_function

_FS = FirestoreClient()
_TEAM_APP_TASK_URL = "https://team.usekaya.com/tasks"
_DEV_CHANNEL = "D02Q9E7JEL8"  # default send to JY's DM
_TOMORROW_DATE = (dt.date.today() + dt.timedelta(days=2)).strftime("%Y-%m-%dT00:00:00Z")


@http_function
def send_task_reminders(request_json={}, request_args={}):
    _execute_send_task_reminders(env="prod")
    return "Success"


def _execute_send_task_reminders(env="dev"):
    docs = _FS.get_filtered_documents(
        "businesses",
        [{"field_name": "status", "operator": "==", "value": "ACTIVE"}],
        output_fmt="records",
    )
    business_ids = [doc["id"] for doc in docs]
    business_ids_str = json.dumps(business_ids)
    print(business_ids)

    # GET TASKS
    query = f"""
    query TaskList {{
        companyCollection(where: {{fsId: {{in: {business_ids_str}}}}}) {{
            edges {{
                node {{
                    tasksCollection(
                    where: {{status: {{in: ["TO_DO", "IN_PROGRESS"]}}, dueDate: {{lt: "{_TOMORROW_DATE}"}}}}
                    ) {{
                    edges {{
                        node {{
                            uuid
                            status
                            ownerThatsVisibleOnApp
                            name
                            dueDate
                        }}
                        }}
                    }}
                    name
                    fsId
                }}
            }}
        }}
    }}
    """
    resp = call_noloco_api(query)
    businesses_resp = resp["data"]["companyCollection"]["edges"]

    tasks = []
    for business_node in businesses_resp:
        business_name = business_node["node"]["name"]
        business_id = business_node["node"]["fsId"]
        tasks_collection = business_node["node"]["tasksCollection"]["edges"]
        for task_node in tasks_collection:
            task = task_node["node"]
            task["business_name"] = business_name
            task["business_id"] = business_id
            tasks.append(task)

    # print(tasks)
    tasks_df = pd.DataFrame(tasks)
    tasks_df["ownerThatsVisibleOnApp"] = (
        tasks_df["ownerThatsVisibleOnApp"].fillna("[]").apply(literal_eval)
    )

    # expand each owner into a separate row in the dataframe
    tasks_exploded_df = tasks_df.explode("ownerThatsVisibleOnApp")

    # process due dates
    tasks_exploded_df["dueDate_raw"] = pd.to_datetime(tasks_exploded_df["dueDate"])
    tasks_exploded_df["due_date"] = tasks_exploded_df["dueDate_raw"].dt.date
    tasks_exploded_df["due_date_repr"] = tasks_exploded_df["dueDate_raw"].dt.strftime(
        "%b %d"
    )
    tasks_exploded_df.loc[
        tasks_exploded_df["due_date"] < pd.Timestamp.now().date(), "due_status"
    ] = "OVERDUE"
    tasks_exploded_df.loc[
        tasks_exploded_df["due_date"] == pd.Timestamp.now().date(), "due_status"
    ] = "DUE TODAY"
    tasks_exploded_df.loc[
        tasks_exploded_df["due_date"] > pd.Timestamp.now().date(), "due_status"
    ] = "UPCOMING"

    due_status_order = ["OVERDUE", "DUE TODAY", "UPCOMING"]
    tasks_exploded_df["due_status"] = pd.Categorical(
        tasks_exploded_df["due_status"], categories=due_status_order, ordered=True
    )
    tasks_exploded_df = tasks_exploded_df.sort_values("due_status")

    tasks_exploded_df["days_overdue"] = tasks_exploded_df["due_date"].apply(
        lambda x: (dt.date.today() - x).days
    )

    tasks_exploded_df["msg"] = tasks_exploded_df.apply(
        lambda x: f"• <{_TEAM_APP_TASK_URL}/{x['uuid']}|{x['business_name']} · {x['name']}> · due {x['days_overdue']} days ago",
        axis=1,
    )

    for owner, owner_tasks_df in tasks_exploded_df.groupby("ownerThatsVisibleOnApp"):
        print("Processing ", owner)
        task_list_str = _generate_msg_for_single_owner(owner_tasks_df)
        if len(task_list_str) == 0:
            continue

        # slack has a limit of 3000 characters
        if len(task_list_str) > 3000:
            task_list_str = task_list_str[:2800] + "\n...(truncated)"

        task_owner = User(user_id=owner)
        if task_owner.role not in ["admin", "marketer"]:
            # skip sending to clients
            continue

        try:
            user_name = (
                f"<@{task_owner.slack_id}>"
                if task_owner.slack_id[0] == "U"
                else task_owner.first_name
            )

            if task_owner.slack_id is None:
                SlackMessage().send_notification(
                    text=f"{task_owner.first_name} doesn't have slack_id configured",
                    channel=_DEV_CHANNEL,
                )
                slack_dm_channel = _DEV_CHANNEL
            else:
                slack_dm_channel = task_owner.slack_id

            _send_reminder(user_name, task_list_str, slack_dm_channel, env)

        except Exception as e:
            print(f"Error sending reminder to owner {task_owner.first_name}: {e}")
            _send_reminder(
                f"`Error {task_owner.first_name}`", task_list_str, _DEV_CHANNEL, env
            )
            continue
    return None


def _generate_msg_for_single_owner(owner_tasks_df):
    task_list_str = ""
    for due_status, sub_df in owner_tasks_df.groupby("due_status"):
        if len(sub_df) == 0:
            continue

        sub_df.sort_values("due_date", inplace=True)

        task_plural = "Task" if len(sub_df) == 1 else "Tasks"

        if due_status == "OVERDUE":
            task_list_str += f"\n:fire: *{len(sub_df)} {task_plural} Overdue* :fire:\n"
        else:
            task_list_str += f"\n{len(sub_df)} {task_plural} {due_status.title()}\n"

        task_list_str += "\n".join(sub_df["msg"].unique())
        task_list_str += "\n"
    return task_list_str


def _send_reminder(user_name, task_list_str, channel, env="dev"):
    if env == "dev":
        channel = _DEV_CHANNEL
        user_name = "[DEV] " + user_name

    bot = SlackMessage()
    bot.create_section_block(
        text=f"Hey {user_name}, these tasks require your attention:"
    )
    bot.create_section_block(text=task_list_str)
    bot.create_section_block(text=" ")
    bot.create_divider_block()

    context_block = {
        "type": "context",
        "elements": [
            {
                "type": "plain_text",
                "text": "Update the status to `IN REVIEW` once completed. If you need to extend the due date, please add a comment on the task explaining the reason for extension and update its due date.",
                "emoji": True,
            },
        ],
    }
    bot.append_block(context_block)
    bot.send_notification(channel=channel)
    return None


if __name__ == "__main__":
    env = "dev"
    _execute_send_task_reminders(env)
