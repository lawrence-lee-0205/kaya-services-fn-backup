import os

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

# Initialize a Web client
slack_token = os.environ["SLACK_BOT_TOKEN"]
client = WebClient(token=slack_token)


def send_ephemeral_message(channel_id, slack_user_id, text, thread_ts=None):
    try:
        response = client.chat_postEphemeral(
            channel=channel_id, user=slack_user_id, text=text, thread_ts=thread_ts
        )
        print(response)
    except SlackApiError as e:
        print(f"Error sending ephemeral message: {e}")
