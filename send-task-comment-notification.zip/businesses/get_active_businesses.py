from http_function import http_function, process_request_inputs
from firestore import FirestoreClient

_FS = FirestoreClient()


@http_function
def get_active_business_ids(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)
    resp = get_business_ids_by_status(status=data.get("status", "ACTIVE"))
    return resp


def get_business_ids_by_status(status):
    all_businesses = _FS.get_all_documents_within_collection("businesses")

    businesses = [b["id"] for b in all_businesses if b.get("status") == status]

    return businesses


def _get_active_business_ids(data):
    resp = get_business_ids_by_status(status=data.get("status", "ACTIVE"))
    return resp


if __name__ == "__main__":
    data = {"status": "ACTIVE"}

    o = _get_active_business_ids(data)
    print(o)
