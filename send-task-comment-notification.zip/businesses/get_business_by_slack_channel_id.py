from firestore import FirestoreClient

_FS = FirestoreClient()


def get_business_id_by_slack_channel_id(slack_channel_id: str) -> str:
    business_ref = (
        _FS.get_collection("businesses")
        .where("slack_channel_id", "==", slack_channel_id)
        .stream()
    )

    business_ids = [biz.id for biz in business_ref]
    if len(business_ids) == 0:
        raise Exception(
            f"Cannot find business with slack_channel_id {slack_channel_id}"
        )
    elif len(business_ids) > 1:
        raise Exception(
            f"Found more than 1 business with slack_channel_id {slack_channel_id}: {business_ids}"
        )

    return business_ids[0]


if __name__ == "__main__":
    slack_channel_id = "C063V01L6GG"
    business_id = get_business_id_by_slack_channel_id(slack_channel_id)
    print(business_id)
