from firestore import FirestoreClient

_FS = FirestoreClient()

def get_email_list(business_id):
    users_ref = _FS.get_collection("users")
    docs = users_ref.where(u"businesses", u"array_contains", business_id).stream()

    emails = [doc.to_dict()["email"] for doc in docs]
    return emails


def get_email_user_list(biz_dict):
    business_id = biz_dict.get("business_id", "")

    email_user_list = []
    if business_id:
        users_ref = _FS.get_collection("users")
        docs = users_ref.where(u"businesses", u"array_contains", business_id).stream()

        for doc in docs:
            d = doc.to_dict()

            # exclude kaya emails
            if "usekaya.com" not in d["email"]:
                email_user_dict = {}
                email_user_dict["business_id"] = business_id
                email_user_dict["business_name"] = biz_dict.get("business_name", "")
                email_user_dict["to_email"] = d.get("email", "")
                email_user_dict["first_name"] = d.get("first_name", "")
                email_user_dict["country"] = biz_dict.get("country", "")
                email_user_dict["communication_hour_utc"] = biz_dict.get("communication_hour_utc", "")

                email_user_list.append(email_user_dict)

    else:
        print("business_id is not available!")

    return email_user_list


def get_email_list_by_business_status(business_status):
    """
    business_status values: 
    LEAD, PROPOSAL_REQUESTED, DISQUALIFIED, NEGOTIATION, NURTURE, CLOSED, LOST, ACTIVE

    sample output:
    [
        {
            'business_id': 'xxx', 
            'business_name': 'yyy', 
            'to_email': 'aaa@bbb.com', 
            'first_name': 'Aaa Bbb',
            'country': 'US',
            'communication_hour_utc': 14
        }
    ]
    """

    # filter documents based on business_status
    docs = _FS.get_filtered_documents(
        "businesses", [{"field_name": "status", "operator": "==", "value": business_status}]
    )

    # get business_id and business_name
    full_biz_list = []
    for doc in docs:
        for biz_id, value in doc.items():
            biz_dict = {}
            biz_dict["business_id"] = biz_id
            biz_dict["business_name"] = value.get("name", "")
            biz_dict["country"] = value.get("country", "")
            biz_dict["communication_hour_utc"] = value.get("communication_hour_utc", "")

            full_biz_list.append(biz_dict)

    # get email details based on business_id
    all_email_user_list = []
    for d in full_biz_list:
        biz_email_user_list = get_email_user_list(d)
        all_email_user_list.extend(biz_email_user_list)

    # temp
    # all_email_user_list = [
    #     {
    #         'business_id': 'Jr9lVYdpq7fx9N63LbV6', 
    #         'business_name': 'Kaya', 
    #         'to_email': 'huiwen06@gmail.com', 
    #         'first_name': 'Huiwen',
    #         'country': 'US',
    #         'communication_hour_utc': 14
    #     },
    #     {
    #         'business_id': 'Jr9lVYdpq7fx9N63LbV6', 
    #         'business_name': 'Kaya', 
    #         'to_email': 'huiwen_chong@hotmail.com', 
    #         'first_name': 'Huiwen',
    #         'country': 'UK',
    #         'communication_hour_utc': 7
    #     }
    # ]

    return all_email_user_list


if __name__ == "__main__":
    # print(get_email_list("2ububBhO0RIq0tURuqnY"))
    print(get_email_list_by_business_status("NURTURE"))
