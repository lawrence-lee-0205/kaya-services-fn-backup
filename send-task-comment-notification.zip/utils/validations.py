from typing import Any, List


def validate_is_either(
    params: List[Any],
    names: List[str],
    mandatory: bool = False,
):
    """Ensures no more than 1 param is defined.
    Accepts all None if mandatory is False.

    Args:
        params (List[Any]): [description]
        names (List[str]): [description]
        mandatory (bool, optional): [description]. Defaults to False.

    Raises:
        Exception: [description]
        Exception: [description]
    """
    num_params = len(params)

    # calculate num of none and non-none
    num_not_none = 0
    for param in params:
        if param is not None:
            num_not_none += 1
    num_none = num_params - num_not_none

    if (mandatory) and (num_none == num_params):
        raise Exception(f"One of the fields ({names}) must be not NONE.")

    if num_not_none > 1:
        raise Exception(
            f"Only one of the following fields: {names} needs to be provided."
        )
