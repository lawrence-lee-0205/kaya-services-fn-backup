from os import environ

from users.user import User
from utils.list import chunk_list
from datetime import datetime, date
from noloco.request import call_noloco_api
from slack_tools.slack import SlackMessage
from tasks.tutils import process_task_name
from http_function import http_function, process_request_inputs

_STATUS_MAPPING = {"TO_DO": "🔹", "IN_PROGRESS": "🔸", "IN_REVIEW": "🔘"}
_DEV_SLACK_CHANNEL = "C02PYBMGLL9"

_INCOMPLETE_TASK_STATUS = ["TO_DO", "IN_PROGRESS"]

_KAYA_DOMAIN = (
    "app.usekaya.com" if "PROD" in environ["ENV"] else "kaya-apps-staging.web.app"
)


@http_function
def send_log_reminder(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)

    # convert log_date to date object
    log_date = datetime.strptime(data["log_date"], "%Y-%m-%d").date()

    execute(log_date, env=data["env"])
    print(data)
    return "Success"


def execute(log_date: date, env: str = "DEV"):
    log_day = log_date.strftime("%a")
    log_date_str = log_date.strftime("%Y-%m-%d")

    out = _query_noloco(log_day, log_date_str)

    data_all_companies = out["data"]["companyCollection"]["edges"]
    for data_company in data_all_companies:
        # data_company = data for a single company
        biz_name = data_company["node"]["name"]
        biz_rec_id = data_company["node"]["uuid"]

        tasks_raw = data_company["node"]["tasksCollection"]["edges"]
        num_tasks = len(tasks_raw)
        tasks_by_category = _process_raw_tasks(tasks_raw, biz_name, log_date)

        admin_fs_id = data_company["node"]["picAdmin"]["firestoreId"]
        admin = User(user_id=admin_fs_id)

        marketer_edges = data_company["node"]["picInternal"]["edges"]
        marketer_fs_id_role_mapping = [
            {"fs_id": edge["node"]["firestoreId"], "role": edge["node"]["role"]["name"]}
            for edge in marketer_edges
        ]

        most_recent_logs = _get_latest_log(biz_rec_id)

        # if there is no task for the company, send slack to marketers only asking them to create tasks and write log
        if num_tasks == 0:
            _process_company_with_no_task(
                marketer_fs_id_role_mapping,
                log_day,
                biz_name,
                admin,
                biz_rec_id,
                most_recent_logs,
                env,
            )
        else:
            _process_company_with_many_tasks(
                marketer_fs_id_role_mapping,
                tasks_by_category,
                log_day,
                biz_name,
                admin,
                biz_rec_id,
                most_recent_logs,
                env,
            )


def _process_company_with_no_task(
    marketer_fs_id_role_mapping,
    log_day,
    biz_name,
    admin,
    biz_rec_id,
    most_recent_logs,
    env,
):
    # send slack to marketers only asking them to create tasks and write log
    for marketer_payload in marketer_fs_id_role_mapping:
        marketer_fs_id = marketer_payload["fs_id"]
        marketer = User(user_id=marketer_fs_id)
        if marketer_payload["role"] == "User":
            last_log_date_by_marketer = _get_latest_log_date_by_marketer(
                most_recent_logs, marketer_fs_id
            )

            _send_slack(
                log_due_day=log_day,
                biz_name=biz_name,
                overdue_tasks=[],
                due_soon_tasks=[],
                in_review_tasks=[],
                marketer=marketer,
                admin=admin,
                biz_rec_id=biz_rec_id,
                last_log_date_by_marketer=last_log_date_by_marketer,
                env=env,
            )
            continue
    return None


def _process_company_with_many_tasks(
    marketer_fs_id_role_mapping,
    tasks_by_category,
    log_day,
    biz_name,
    admin,
    biz_rec_id,
    most_recent_logs,
    env,
):
    # if there are tasks, send slack to marketers with their own tasks that are due soon or overdue.for admin, only send the message if they have their own tasks.
    for marketer_payload in marketer_fs_id_role_mapping:
        marketer_fs_id = marketer_payload["fs_id"]
        marketer = User(user_id=marketer_fs_id)
        role = marketer_payload["role"]

        # find tasks that are assigned to the marketer
        task_assigned_overdue = [
            t
            for t in tasks_by_category["overdue"]
            if marketer_fs_id in t["owner_firestore_ids"]
        ]
        task_assigned_due_soon = [
            t
            for t in tasks_by_category["due_soon"]
            if marketer_fs_id in t["owner_firestore_ids"]
        ]
        task_assigned_in_review = [
            t
            for t in tasks_by_category["in_review"]
            if marketer_fs_id in t["owner_firestore_ids"]
        ]

        num_tasks_assigned = len(task_assigned_overdue) + len(task_assigned_due_soon)

        # dont send slack if the person is admin and has no tasks
        if role == "Team Admin" and num_tasks_assigned == 0:
            return None
        else:
            last_log_date_by_marketer = _get_latest_log_date_by_marketer(
                most_recent_logs, marketer_fs_id
            )

            _send_slack(
                log_due_day=log_day,
                biz_name=biz_name,
                overdue_tasks=task_assigned_overdue,
                due_soon_tasks=task_assigned_due_soon,
                in_review_tasks=task_assigned_in_review,
                marketer=marketer,
                admin=admin,
                biz_rec_id=biz_rec_id,
                last_log_date_by_marketer=last_log_date_by_marketer,
                env=env,
            )
    return None


def _process_raw_tasks(tasks_raw, biz_name, log_date):
    overdue_tasks = []
    due_soon_tasks = []
    in_review_tasks = []
    for task_raw in tasks_raw:
        task = task_raw["node"]

        task_name = process_task_name(task["name"], biz_name, env=environ["ENV"])
        task_status = task["status"]
        due_date = datetime.strptime(task["dueDate"], "%Y-%m-%dT%H:%M:%S.%fZ").date()
        owner_firestore_ids = [
            edge["node"]["firestoreId"] for edge in task["owner"]["edges"]
        ]

        t = {
            "name": task_name,
            "description": task["description"],
            "due_date_raw": due_date,
            "due_date": due_date.strftime("%a (%d-%m)"),
            "status": task["status"],
            "uuid": task["uuid"],
            "owner_firestore_ids": owner_firestore_ids,
        }

        if task_status == "IN_REVIEW":
            in_review_tasks.append(t)
        elif task_status in _INCOMPLETE_TASK_STATUS:
            if due_date < log_date:  # check date logic
                overdue_tasks.append(t)
            else:
                due_soon_tasks.append(t)

    return {
        "overdue": overdue_tasks,
        "due_soon": due_soon_tasks,
        "in_review": in_review_tasks,
    }


def _query_noloco(log_day: str, log_date: str):
    """
    log_date needs to be YYYY-MM-DD
    """
    query = f"""
        query MyQuery {{
        companyCollection(where: {{logDay: {{contains: "{log_day}"}}}}) {{
            edges {{
                node {{
                    tasksCollection(
                        where: {{isDone: {{equals: false}}, dueDate: {{lte: "{log_date}T00:00:00.000Z"}}}}
                    ) {{
                    edges {{
                        node {{
                            uuid
                            description
                            dueDate
                            name
                            status
                            owner {{
                                edges {{
                                    node {{
                                        firestoreId
                                    }}
                                }}
                            }}
                            ownerThatsVisibleOnApp
                        }}
                    }}
                    }}
                    uuid
                    name
                    picInternal {{
                        edges {{
                            node {{
                                firestoreId
                                role {{
                                    name
                                }}
                            }}
                        }}
                    }}
                    picAdmin {{
                        firestoreId
                        role {{
                            name
                        }}
                    }}
                }}
            }}
        }}
        }}
    """
    print(query)
    out = call_noloco_api(query)
    return out


def _process_task_list(task_list):
    sorted_lst = sorted(task_list, key=lambda d: d["due_date_raw"])
    task_str_lst = [
        f"{_STATUS_MAPPING[task['status']]} <https://{_KAYA_DOMAIN}/tasks/{task['uuid']}|{task['name']}>, due {task['due_date']}"
        for task in sorted_lst
    ]
    chunked_task_str_lst = chunk_list(task_str_lst, 5)
    chunked_str_list = ["\n".join(chunk) for chunk in chunked_task_str_lst]

    return chunked_str_list


def _send_slack(
    log_due_day,
    biz_name,
    overdue_tasks,
    due_soon_tasks,
    in_review_tasks,
    marketer: User,
    admin: User,
    biz_rec_id,
    last_log_date_by_marketer: datetime.date,
    env="DEV",
):
    slack_channel = (
        marketer.slack_channel_id if "PROD" in env.upper() else _DEV_SLACK_CHANNEL
    )

    log_url = f"https://teamdot.noloco.co/companies/view/{biz_rec_id}/weekly-log"

    # construct sentence for log
    if last_log_date_by_marketer is None:
        last_log_date_str = "a long time ago"
        tag_admin_str = f"😱 <@{admin.slack_id}|cal>"
    else:
        days_since_last_log = (date.today() - last_log_date_by_marketer).days
        last_log_date_str = f'on {last_log_date_by_marketer.strftime("%m-%d")}, {days_since_last_log} days ago'

        tag_admin_str = f"😱 <@{admin.slack_id}|cal>" if days_since_last_log > 8 else "👌"
    log_sentence = f"The last log was provided {last_log_date_str}. {tag_admin_str}"

    # context
    context_statuses = [
        {
            "type": "plain_text",
            "text": f"{emoji} {s.replace('_', ' ')}",
            "emoji": True,
        }
        for s, emoji in _STATUS_MAPPING.items()
    ]
    context_statuses.append(
        {
            "type": "plain_text",
            "text": f"To provide update for a task (eg if you wish to extend due date or need more info), please comment on the respective task on Kaya App and tag {admin.first_name}.",
            "emoji": True,
        }
    )
    context_block = {
        "type": "context",
        "elements": context_statuses,
    }

    bot = SlackMessage()
    bot.create_section_block(
        text=f"*Reminder to add log for {biz_name} by {log_due_day}*"
    )

    if len(overdue_tasks) > 0:
        chunked_str_list = _process_task_list(overdue_tasks)

        bot.create_section_block(text=f"{len(overdue_tasks)} Overdue Tasks")
        for chunk_str in chunked_str_list:
            bot.create_section_block(text=chunk_str)

    if len(due_soon_tasks) > 0:
        chunked_str_list = _process_task_list(due_soon_tasks)

        bot.create_section_block(text=f"{len(due_soon_tasks)} Tasks Due Soon")
        for chunk_str in chunked_str_list:
            bot.create_section_block(text=chunk_str)

    if len(overdue_tasks) == 0 and len(due_soon_tasks) == 0:
        task_next_step = "add tasks for this week"
    else:
        task_next_step = "update all tasks above"

    if len(in_review_tasks) > 0:
        chunked_str_list = _process_task_list(in_review_tasks)

        bot.create_section_block(text=f"{len(in_review_tasks)} Tasks In Review")
        for chunk_str in chunked_str_list:
            bot.create_section_block(text=chunk_str)

    bot.create_section_block(
        text=f"<@{marketer.slack_id}|cal>, please update <{log_url}|log> and {task_next_step}."
    )
    bot.create_section_block(text=log_sentence)
    bot.create_divider_block()
    bot.append_block(context_block)
    bot.send_notification(channel=slack_channel)
    return None


def _get_latest_log(biz_rec_id):
    query = f"""
    query MyQuery {{
        companyCollection(where: {{uuid: {{equals: "{biz_rec_id}"}}}}) {{
            edges {{
            node {{
                logsCollection(first: 5, orderBy: {{direction: DESC, field: "createdAt"}}) {{
                edges {{
                    node {{
                    loggedBy {{
                        firestoreId
                    }}
                    createdAt
                    startDate
                    noteCompletedInternal
                    notePlannedInternal
                    notePerformance
                    endDate
                    }}
                }}
                }}
            }}
            }}
        }}
    }}
    """
    out = call_noloco_api(query)
    most_recent_logs = out["data"]["companyCollection"]["edges"][0]["node"][
        "logsCollection"
    ]["edges"]
    most_recently_logs = _process_logs(most_recent_logs)
    return most_recently_logs


def _process_logs(logs):
    processed_logs = []
    for log_node in logs:
        log = log_node["node"]
        log_by = log["loggedBy"]["firestoreId"]

        if (log["notePlannedInternal"] is None) and (
            (log["noteCompletedInternal"] is None) and (log["notePerformance"] is None)
        ):
            print("empty log")
            continue

        log_processed = {
            "log_by": log_by,
            "created_at": log["createdAt"],
        }

        processed_logs.append(log_processed)
    return processed_logs


def _get_latest_log_date_by_marketer(logs, marketer_fs_id):
    logs_by_marketer = [
        log["created_at"] for log in logs if log["log_by"] == marketer_fs_id
    ]
    if len(logs_by_marketer) == 0:
        return None

    last_log_dt_str = max(logs_by_marketer)
    last_log_date = datetime.strptime(last_log_dt_str, "%Y-%m-%dT%H:%M:%S.%fZ").date()
    return last_log_date


if __name__ == "__main__":
    # TODO: CHECK IF LOG HAS BEEN ADDED

    # get tomorrow's day of the week (e.g. Wed)
    # tomorrow = datetime.today() + timedelta(days=1)
    log_date = date(2023, 6, 28)
    execute(log_date, env="DEV")
