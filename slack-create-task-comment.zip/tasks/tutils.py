def process_task_name(task_name, biz_name, env="DEV"):
    task_name = task_name.replace(biz_name, "")
    task_name = task_name[3:] if task_name.startswith(" - ") else task_name
    if "PROD" not in env.upper():
        task_name = task_name + " [TEST]"
    return task_name
