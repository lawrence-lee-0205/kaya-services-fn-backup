import requests


def call_api(api, headers={}, params={}):
    response = requests.get(url=api, headers=headers, params=params)
    if response.status_code != 200:
        print("Error. Received response ", response.status_code, response.json)
        raise Exception(
            "Error. Received response ", response.status_code, response.json
        )
    response_json = response.json()
    return response_json
