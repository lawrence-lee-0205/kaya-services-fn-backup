from slack_tools.slack import SlackMessage
from businesses.business import Business
from users.user import User

from firestore import FirestoreClient
import datetime as dt

_FS = FirestoreClient()


def send_slack_single_user(user: User):
    print("Processing user ", user.first_name, user.user_id)
    if user.get("slack_onboarding_greeting_sent_at"):
        print(
            f"Skipping {user.first_name}, ID {user.user_id} because greeting was already sent\n"
        )
        return None

    if user.slack_id is None:
        raise (f"User {user.first_name}, ID {user['id']} has no slack ID\n")

    bot = SlackMessage()
    bot.create_section_block(
        text=f"👋 {user.first_name}, from now on, Kayabot will notify you of task updates, including new comments and task assignments. If you have any questions, please reach out to <@U02P4RZDN5P|cal>"
    )
    out = bot.send_notification(channel=user.slack_id)

    _FS.update_document(
        "users",
        user.user_id,
        {
            "slack_onboarding_greeting_sent_at": dt.datetime.utcnow(),
            "slack_dm_channel": out["channel"],
        },
    )
    return None


if __name__ == "__main__":
    business_id = "eJFBvUCjrEYSVFB5Lppz"

    users = Business(business_id).get_users()
    for user in users:
        send_slack_single_user(user)
