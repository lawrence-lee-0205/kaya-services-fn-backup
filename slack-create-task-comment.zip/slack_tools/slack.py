"""In addition to setting up incoming webhooks, 
bot must be added to the channel, in the same way how human accounts are added."""

import os
import datetime as dt
from typing import List
from firestore import FirestoreClient

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

from utils.kaya_yaml import read_yaml
from storage.upload_blob import upload_blob

# WebClient insantiates a client that can call API methods
# When using Bolt, you can use either `app.client` or the `client` passed to listeners.
_CONFIG_FILENAME = os.path.abspath(os.path.dirname(__file__)) + "/slack.yaml"
_CONFIG = read_yaml(_CONFIG_FILENAME)
_ENV = "prod" if os.environ["ENV"].lower() == "prod" else "dev"
_FS = FirestoreClient()


class SlackMessage:
    def __init__(self) -> None:
        self.client = WebClient(token=os.environ["SLACK_BOT_TOKEN"])
        self.blocks = []
        self.text = ""

    ################################
    #       PRIVATE FUNCTION       #
    ################################

    def send_notification(self, **kwargs):
        """Send slack notification. kwargs can be 'blocks', 'text', 'channel'.

        `blocks` and `text` provided via kwargs will override self.blocks and self.text

        Raises:
            Exception: _description_
        """
        try:
            kwargs.setdefault("channel", _CONFIG[_ENV]["channel"])

            # set text and blocks based on kwargs, if not defined, use self.text and self.blocks
            blocks = kwargs["blocks"] if "blocks" in kwargs else self.blocks
            text = kwargs["text"] if "text" in kwargs else self.text

            if blocks == [] and text == "":
                raise Exception(
                    "Either param 'blocks' or 'text' must be defined. Received None."
                )

            params = {k: v for k, v in kwargs.items() if k not in ["blocks", "text"]}
            out = self.client.chat_postMessage(blocks=blocks, text=text, **params)

            # WRITE LOG TO FIRESTORE
            log = {
                "ok": out["ok"],
                "channel": out["channel"],
                "sent_at": dt.datetime.fromtimestamp(float(out["ts"])),
                **out["message"],
            }
            _FS.add_document("slack_messages", log)

            print("Slack message sent!")
            return out
        except SlackApiError as e:
            print(f"Error: {e}")
            raise

    def append_block(self, block: dict):
        self.blocks.append(block)

    def add_list_of_blocks(self, blocks: List[dict]):
        self.blocks += blocks

    def create_divider_block(self):
        self.blocks.append({"type": "divider"})

    def create_header_block(self, text):
        out = {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": text,
                "emoji": True,
            },
        }
        self.blocks.append(out)

    def create_section_block(self, text, escape_newline=False):
        if escape_newline:
            text = text.replace("\\n", "\n")

        out = {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": text,
            },
        }
        self.blocks.append(out)

    def create_image_block(
        self,
        source_folder: str,
        bucket: str,
        filename: str,
        alt_text: str,
        to_remove_file: bool = False,
    ):
        """Create block to enable image to be attached to a slack message

        Args:
            source_folder (str): folder directory that contains the file
            bucket (str): cloud storage bucket path
            filename (str): name of the file
            alt_text (str): alternate text for when the image can't be shown
        """

        source = f"{source_folder}/{filename}"
        print(f"Uploading file from {source}")
        file_url = upload_blob(
            bucket_name="kaya-apps-00.appspot.com",
            source_file_name=source,
            destination_blob_name=f"{bucket}/{filename}",
            is_public=True,
        )

        if to_remove_file:
            if os.path.exists(source):
                os.remove(source)
            else:
                print(f"Failed to remove file. The path {source} does not exist.")

        out = {
            "type": "image",
            "title": {"type": "plain_text", "text": f"click to view {alt_text}"},
            "image_url": file_url,
            "alt_text": alt_text,
        }
        self.blocks.append(out)

    def create_plain_text(self, text):
        self.text += text

    def create_text_with_button_block(
        self, text, button_text, button_value, button_url, button_action_id
    ):
        block = {
            "type": "section",
            "text": {"type": "mrkdwn", "text": text},
            "accessory": {
                "type": "button",
                "text": {"type": "plain_text", "text": button_text, "emoji": True},
                "value": button_value,
                "url": button_url,
                "action_id": button_action_id,
            },
        }
        self.blocks.append(block)


if __name__ == "__main__":
    bot = SlackMessage()
    bot.send_notification(text=":b: player")
