import os
import datetime as dt

from utils.datetimes import get_date_by_name
from utils.jinja import render_template_as_dict

from slack_tools.slack import SlackMessage
from slack_tools.create_pulses import send_slack_message

from firestore import FirestoreClient
from http_function import http_function, process_request_inputs

_DATE_RANGE_MAPPING = {
    "yesterday": "yesterday",
    "last 7 days": "7d_ago",
    "last 30 days": "30d_ago",
    "month to date": "this_month_start",
}
_INPUT_TO_AD_CHANNEL_MAPPING = {
    "blended": "blended",
    "google": "Google CPC",
    "facebook": "Facebook",
    "linkedin": "Linked In",
}

_FS = FirestoreClient()
_EVENT_COLLECTION_NAME = "pulse_on_demand_events"

_CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))


@http_function
def slack_send_report_on_demand(request_json=None, request_args=None):
    data = process_request_inputs(request_json, request_args)

    text = data["event"]["text"]
    inputs = text.split(" | ")
    print(inputs)
    date_range_repr = inputs[0]
    ads_channel = inputs[1].split(" ")[0].lower()
    requester_slack_id = inputs[3]
    slack_channel = inputs[2]

    thread_ts = data["event"]["ts"]
    channel_where_bot_is_mentioned = data["event"]["channel"]

    event_id = data["event_id"]

    output = execute(
        ads_channel,
        date_range_repr,
        slack_channel,
        requester_slack_id,
        thread_ts,
        channel_where_bot_is_mentioned,
        event_id,
    )
    return output


def execute(
    ads_channel,
    date_range_repr,
    slack_channel,
    requester_slack_id,
    thread_ts,
    channel_where_bot_is_mentioned,
    event_id,
):
    status_message = ""

    try:
        event_doc = _get_event_doc(event_id)
        if event_doc is not None:
            print(
                f"Skipping event {event_id} because it's been processed. Last status: {event_doc['status']}"
            )
            return None

        _FS.add_document(
            _EVENT_COLLECTION_NAME,
            {
                "created_at": dt.datetime.utcnow(),
                "status": "created",
                "ads_channel": ads_channel,
                "date_range_repr": date_range_repr,
                "slack_channel": slack_channel,
                "requester_slack_id": requester_slack_id,
                "thread_ts": thread_ts,
                "channel_where_bot_is_mentioned": channel_where_bot_is_mentioned,
            },
            event_id,
        )

        # GET BUSINESS ID FROM SLACK CHANNEL ID
        biz = _get_business_from_slack_channel(slack_channel)
        business_id = biz["id"]
        if business_id == "eJFBvUCjrEYSVFB5Lppz":
            business_id = "no2DKxHGYQshKxZAJxmj"

        # check if current time is before business communication hour
        comm_hour = biz["communication_hour_utc"]
        is_before_comm_hour = True if dt.datetime.utcnow().hour < comm_hour else False

        # get metric info
        metric_config = _FS.get_single_document("pulse_weekly", business_id)

        # calculate dates
        start_date_name = _DATE_RANGE_MAPPING[date_range_repr.lower()]
        start_date = get_date_by_name(start_date_name, as_string=False)
        end_date = get_date_by_name("yesterday", as_string=False)

        days_diff = (end_date - start_date).days + 1
        prev_start_date = start_date - dt.timedelta(days=days_diff)
        prev_end_date = start_date - dt.timedelta(days=1)

        ads_channel_db_name = _INPUT_TO_AD_CHANNEL_MAPPING[ads_channel]
        print("Selected channel: ", ads_channel_db_name)

        config = render_template_as_dict(
            folder=_CURRENT_DIR + "/pulses_template",
            filename="on_demand_default.yml",
            business_id=business_id,
            business_name=biz["name"],
            start_date=start_date.strftime("%Y-%m-%d"),
            end_date=end_date.strftime("%Y-%m-%d"),
            prev_start_date=prev_start_date,
            prev_end_date=prev_end_date,
            requester_slack_id=requester_slack_id,
            is_before_comm_hour=is_before_comm_hour,
            comm_hour=comm_hour,
            ads_channel=ads_channel,
            ads_channel_db_name=ads_channel_db_name,
            date_range_repr=date_range_repr,
            **metric_config,
        )["report"]

        send_slack_message(
            channels=[slack_channel],
            blocks=config["contents"],
            business_id=business_id,
            notification_text=config["notification_text"],
        )
        bot = SlackMessage()
        bot.send_notification(
            text="Report sent successfully",
            channel=channel_where_bot_is_mentioned,
            thread_ts=thread_ts,
        )
        status = "success"
    except Exception as e:
        print(e)
        status_message = f"Error: {e}"
        if is_before_comm_hour and date_range_repr == "yesterday":
            print(
                "Error + Send notification to requester that they can only run report for yesterday after <@U02P4RZDN5P>"
            )
            _send_error_msg_via_dm(
                "yesterday_error",
                comm_hour,
                date_range_repr,
                ads_channel,
                requester_slack_id,
            )
            bot = SlackMessage()
            bot.send_notification(
                text="Sent notification to requester that they can only run report for yesterday after",
                channel=channel_where_bot_is_mentioned,
                thread_ts=thread_ts,
            )
            status = "failed and error notification sent"
        else:
            _send_error_msg_via_dm(
                "unknown_error",
                comm_hour,
                date_range_repr,
                ads_channel,
                requester_slack_id,
            )
            bot = SlackMessage()
            bot.send_notification(
                text="Error :( <@U02P4RZDN5P>",
                channel=channel_where_bot_is_mentioned,
                thread_ts=thread_ts,
            )
            status = "failed and error notification sent"

    _FS.update_document(
        _EVENT_COLLECTION_NAME,
        event_id,
        {
            "status": status,
            "status_message": status_message,
            "updated_at": dt.datetime.utcnow(),
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
            "prev_start_date": prev_start_date.strftime("%Y-%m-%d"),
            "prev_end_date": prev_end_date.strftime("%Y-%m-%d"),
        },
    )
    return None


def _get_business_from_slack_channel(slack_channel) -> dict:
    docs = (
        _FS.get_collection("businesses")
        .where("slack_channel_id", "==", slack_channel)
        .stream()
    )
    businesses = [{"id": doc.id, **doc.to_dict()} for doc in docs]
    if len(businesses) == 0:
        raise ValueError(f"Business with slack channel ID {slack_channel} not found.")
    elif len(businesses) > 1:
        raise ValueError(
            f"Multiple businesses with slack channel ID {slack_channel} found."
        )

    biz = businesses[0]
    return biz


def _get_event_doc(event_id):
    try:
        # check if event was processed before. exist in FS = processed.
        doc = _FS.get_single_document(_EVENT_COLLECTION_NAME, event_id)
        return doc
    except ValueError:
        return None


def _send_error_msg_via_dm(
    error_type, comm_hour, date_range_repr, ads_channel, requester_slack_id
):
    text = (
        f"Sorry, we can only send the report for yesterday after {comm_hour}UTC. Please try again later."
        if error_type == "yesterday_error"
        else "Sorry, we encountered an error. <@U02P4RZDN5P> will look into it and send the report shortly."
    )
    blocks = [
        {"type": "section", "text": {"type": "mrkdwn", "text": text}},
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"You're receiving this notification because you've requested an adhoc report for:\n· Channel: {ads_channel.capitalize()}\n· Date range: {date_range_repr.capitalize()}",
                }
            ],
        },
    ]
    bot = SlackMessage()
    bot.send_notification(
        blocks=blocks,
        channel=requester_slack_id.replace("<", "").replace(">", ""),
    )
    return None


if __name__ == "__main__":
    text = "last 7 days | facebook (All channels) | C03B7MJMZUG | <@U02P4RZDN5P> | @Kayabot"
    inputs = text.split(" | ")
    print(inputs)
    date_range_repr = inputs[0]
    ads_channel = inputs[1].split(" ")[0].lower()
    requester_slack_id = inputs[3]

    # get metadata from business id
    slack_channel = inputs[2]

    thread_ts = "1691436980.812449"
    channel_where_bot_is_mentioned = "C05KE0Y8Y3C"

    execute(
        ads_channel,
        date_range_repr,
        slack_channel,
        requester_slack_id,
        thread_ts,
        channel_where_bot_is_mentioned,
        event_id="test66676wrtereg57yufdf",
    )
