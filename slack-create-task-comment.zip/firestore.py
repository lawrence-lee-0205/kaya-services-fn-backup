import os
import datetime
from typing import List, Union

import firebase_admin
from firebase_admin import credentials, firestore


DESCENDING = firestore.Query.DESCENDING
DELETE_FIELD = firestore.DELETE_FIELD


class FirestoreClient:
    def __init__(self):
        if not firebase_admin._apps:
            print(
                "Initialising Firestore App: ", {os.environ["GCP_PROJECT_NAME"].lower()}
            )
            cred = credentials.ApplicationDefault()
            firebase_admin.initialize_app(
                cred,
                {
                    "projectId": os.environ["GCP_PROJECT_NAME"].lower(),
                },
            )
        self.db = firestore.client()

    @staticmethod
    def convert_stream_to_list(stream_object, skip_id: bool = False):
        if skip_id:
            return [doc.to_dict() for doc in stream_object]
        else:
            return [{doc.id: doc.to_dict()} for doc in stream_object]

    def get_collection(self, collection):
        return self.db.collection(collection)

    def add_document(self, collection, doc, id=None) -> str:
        """If the document does not exist, it will be created.
        If the document does exist, its contents will be OVERWRITTEN
        with the newly provided data. Ie old content will be completely
        removed.

        Args:
            collection ([type]): [description]
            doc ([type]): [description]
            id ([type], optional): [description]. Defaults to None.

        Returns:
            document id
        """
        col = self.db.collection(collection)

        if id is None:
            doc_ref = col.document()
        else:
            doc_ref = col.document(id)

        doc_ref.set(doc)
        id = doc_ref.id
        # print(f"Document {id} is created in {collection} collection")
        return id

    def update_document(
        self, collection: str, id: str, content: dict, skip_updated_at: bool = False
    ) -> None:
        """Update firestore document with content provided

        Args:
            collection (str): collection name
            id (str): document id to update
            content (dict): content to add to existing document

        Returns: None
        """
        if ("updated_at" not in content) and (not skip_updated_at):
            content["updated_at"] = datetime.datetime.utcnow()

        doc_ref = self.get_collection(collection).document(id)
        doc_ref.update(content)
        print(f"Doc {id} updated")
        return None

    def add_subcollection_to_document(
        self, collection, parent_doc_id, subcollection, doc, child_doc_id=None
    ):
        parent_doc_ref = self.db.collection(collection).document(parent_doc_id)

        parent_doc = parent_doc_ref.get()
        if parent_doc.exists:
            child_doc_ref = parent_doc_ref.collection(subcollection).document(
                child_doc_id
            )
            child_doc_ref.set(doc)
            id = child_doc_ref.id
            print(f"Document {id} is created")
        else:
            raise ValueError(
                f"Parent document {parent_doc_id} not found in {collection} collection"
            )
        return id

    def append_list_single_document(self, collection, id, field_name, list_to_add):
        """Add elements from list_to_add to specified field.
        arrayUnion() adds elements to an array but only elements not already present

        Args:
            collection ([type]): [description]
            id ([type]): [description]
            field_name ([type]): [description]
            list_to_add ([type]): [description]

        Returns:
            [type]: [description]
        """
        print(
            f"Adding {list_to_add} to '{field_name}' in doc {id} of collection '{collection}"
        )
        doc_ref = self.db.collection(collection).document(id)

        # Atomically add new value to the given array field.
        doc_ref.update({field_name: firestore.ArrayUnion(list_to_add)})
        print("Successfully")
        return None

    def get_single_document(
        self, collection: Union[str, List[str]], id: Union[str, List[str]]
    ) -> dict:
        """Get content of a document within a collection or subcollection.
        For the latter, provide parent and subcollection names in a list,
        as well as parent and subcollection document id.

        Args:
            collection (Union[str, List[str]]):
                Collection name or list of collection names (parent & subcollection)
            id (Union[str, List[str]]):
                Document id or list of document ids (parent & subcollection)

        Raises:
            ValueError:

        Returns:
            dict: content of the document
        """
        if isinstance(collection, str):
            # only parent document
            doc_ref = self.db.collection(collection).document(id)
        elif isinstance(collection, list):
            if (len(collection) < 2) or (len(id) < 2):
                raise ValueError(
                    f"Expecting 2 element to be provided for 'collection' and 'id' param. Received {collection} and {id} instead."
                )

            doc_ref = (
                self.db.collection(collection[0])
                .document(id[0])
                .collection(collection[1])
                .document(id[1])
            )

        doc = doc_ref.get()
        if doc.exists:
            return doc.to_dict()
        else:
            # TODO: RAISE CUSTOM ERROR
            raise ValueError(f"No such document in {collection}! Doc ID: {id}")

    def get_all_documents_within_collection(self, collection):
        docs = self.db.collection(collection).stream()

        list_of_dict = [{"id": doc.id, **doc.to_dict()} for doc in docs]
        return list_of_dict

    def get_all_documents_within_subcollection(
        self, subcollection_path: str, skip_id: bool = False
    ) -> List[dict]:
        """Returns all document within a subcollection

        Args:
            subcollection_path (str): Eg google_audiences/{audience_id}/criteria
            skip_id (bool, optional): If True, returns a dict where key = id of the criteria doc and value = content.
                                      Defaults to False.

        Returns:
            List[dict]: [description]
        """

        docs = self.db.collection(subcollection_path).stream()

        if skip_id:
            return [doc.to_dict() for doc in docs]
        else:
            return [{doc.id: doc.to_dict()} for doc in docs]

    def check_if_document_exist(self, collection, id):
        doc_ref = self.db.collection(collection).document(id)

        doc = doc_ref.get()
        if doc.exists:
            return True

        return False

    def delete_fields(self, collection: str, id: str, fields_to_delete: list) -> None:
        """Delete a list of field names from a given document

        Args:
            collection (str): collection name
            id (str): document id
            fields_to_delete (list): list of fields to delete

        Returns: None
        """
        doc = self.db.collection(collection).document(id)

        dicts_to_delete = {f: DELETE_FIELD for f in fields_to_delete}
        doc.update(dicts_to_delete)
        print(f"Successfully deleted {fields_to_delete} from doc {id}")
        return None

    def rename_fields(self, collection: str, fields_to_rename: dict) -> None:
        """Rename fields in a collection based on 'fields_to_rename' dict,
        where 'key = old field name' and 'value = new field name'

        if new_field_name doesnt exist in the doc but old_field_name does, copy value
        from old_field_name and save it in new_field_name.

        Args:
            collection (str)
            fields_to_rename (dict): key=old field name and value = new field name

        Returns: None
        """
        docs = self.get_collection(collection).stream()

        for doc in docs:
            id_ = doc.id
            content = doc.to_dict()

            print(f"Processing {id_}")
            dict_to_update = {}
            old_fields_to_delete = []
            for old, new in fields_to_rename.items():
                if (new not in content) and (old in content):
                    # get data with old name
                    value_to_copy = content.get(old)
                    dict_to_update[new] = value_to_copy

                    old_fields_to_delete.append(old)

            if dict_to_update:
                self.update_document(collection, id_, dict_to_update)

            if len(old_fields_to_delete) > 0:
                self.delete_fields(collection, id_, old_fields_to_delete)

        return None


if __name__ == "__main__":
    # ADD G ADS BUSINESS
    fs = FirestoreClient()
    # fs.update_document(
    #     collection="businesses",
    #     id="EC1P1vXE9vR1VrHKvj8x",
    #     content={
    #         "connections": {"google_ads": True},
    #         "disable_channel_comparison": True,
    #         "has_billing": True,
    #         "home_dashboard_id": "google-ads",
    #         "is_onboarded": True,
    #         "kpi": "google_cpc_conversions",
    #     },
    # )

    # fs.get_all_documents_within_collection("businesses")
    # fs.rename_fields(
    #     collection="google_campaigns",
    #     fields_to_rename={"campaign_budget_amount": "campaign_budget"},
    # )

    # fs.update_document(
    #     "test",
    #     "Ojv5fZGEx4HIqrpk6jFg",
    #     {
    #         "campaign_budget_amount": "campaign_budget",
    #         "updated_at": datetime.datetime.utcnow(),
    #     },
    # )

    # gads_ref = fs.get_collection("google_accounts").stream()
    # for acc in gads_ref:
    #     business_id = acc.id
    #     print("Processing ", business_id)
    #     fs.update_document(
    #         collection="google_accounts",
    #         id=business_id,
    #         content={"business_id": business_id},
    #     )
    #     print("--\n")

    # doc = {
    #     "name": "Liveflow",
    #     "ccy_code": "GBP",
    #     "time_zone": "Europe/London",
    #     "ads_manager_id": "6752450493",
    #     "tracking_url": "",
    #     "final_url_suffix": "",
    #     "created_at": datetime.datetime(2022, 4, 15, 19, 44, 48),
    #     "created_by": "RzhWb5JDEE3hlAMk9ZM7",
    #     "client_id": "4698377652",
    #     "status": "INACTIVE",
    #     "business_id": "vzsuUIgfhKRenZq6I0U5",
    # }
    # fs.add_document("google_accounts", doc)

    # print(fs.get_single_document(collection="", id=""))

    # fs.update_document(
    #     collection="users",
    #     id="",
    #     content={}
    # )
