from os import environ

from setup import setup
from common import validate_inputs
from utils.jinja import render_template_from_string
from storage.download_blob import download_blob_into_string
from noloco.request import call_noloco_api

_BUCKET = (
    "kaya-apps-00-noloco" if "PROD" in environ["ENV"] else "kaya-apps-staging-noloco"
)


@setup
def execute_noloco_from_file(data: dict) -> dict:
    mandatory_fields = ["template_filepath", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    resp = execute(
        template_filepath=data["template_filepath"],
        params=data.get("params", {}),
    )
    return resp


@setup
def render_noloco_query_from_file(data: dict) -> dict:
    mandatory_fields = ["template_filepath", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    resp = _render_query(
        template_filepath=data["template_filepath"],
        params=data.get("params", {}),
    )
    return resp


def execute(template_filepath, params):
    query_rendered = _render_query(template_filepath, params)
    out = call_noloco_api(query_rendered)
    return out


def _render_query(template_filepath, params):
    query = download_blob_into_string(_BUCKET, template_filepath).decode("utf-8")

    query_rendered = render_template_from_string(query, **params)
    return query_rendered


if __name__ == "__main__":
    template_filepath = "read/query_log.txt"
    params = {"business_id": "lyu6tWbXJlYQmfzi6uGg"}
    print(execute(template_filepath, params))
