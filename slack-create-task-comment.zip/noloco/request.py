import requests

from os import environ

_NOLOCO_URL = (
    "https://api.portals.noloco.io/data/teamdot"
    if "PROD" in environ["ENV"]
    else "https://api.portals.noloco.io/data/teamdev"
)
_NOLOCO_AUTH = f"Bearer " + environ["NOLOCO_TOKEN"]


def call_noloco_api(body: str):
    print("Executing query...")

    response = requests.post(
        url=_NOLOCO_URL,
        json={"query": body},
        headers={"Authorization": _NOLOCO_AUTH},
    )
    if response.status_code != 200:
        if environ["ENV"] != "PROD":
            print("Query:")
            print(body)
        raise Exception("Error. Received response ", response.status_code)

    print("Query ran successfully")
    return response.json()


if __name__ == "__main__":
    import time

    for id in range(1, 439):
        q = ""
        call_noloco_api(q)
        time.sleep(2)
