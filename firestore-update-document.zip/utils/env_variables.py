import os

from utils.kaya_yaml import read_yaml


def set_env_var_from_yaml(filename):
    env_vars = read_yaml(filename)

    for key, value in env_vars.items():
        os.environ[key] = str(value)
    return None


if __name__ == "__main__":
    set_env_var_from_yaml(
        "/Users/jeeyenpersonal/Documents/kaya-services/.local/google_ads.yaml"
    )
