import math


def calc_pct_change(new, old):
    if (
        (new in ["", None])
        or (old in ["", 0, None])
        or math.isnan(new)
        or math.isnan(old)
        or math.isinf(new)
        or math.isinf(old)
    ):
        return ""

    return 100 * (new - old) / old
