def remove_duplicates(lst: list):
    return list(set(lst))


def chunk_list(lst: list, size: int) -> list:
    """Chunk list into 'list of list' where each sub list has a length of 'size'

    Args:
        lst (list): _description_
        size (int): _description_

    Returns:
        list: _description_
    """

    return [lst[i : i + size] for i in range(0, len(lst), size)]


if __name__ == "__main__":
    lst = ["a", "b", "c"]
    print(chunk_list(lst, 2))
