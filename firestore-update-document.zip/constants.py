import datetime
from dateutil.relativedelta import relativedelta

TODAY = datetime.date.today()
YESTERDAY = TODAY - datetime.timedelta(days=1)
LAST_SUNDAY = TODAY - datetime.timedelta(days=TODAY.weekday() + 1)
DEFAULT_MAPPING = {
    "start_of_last_month": (TODAY - relativedelta(months=1, day=1)).strftime(
        "%Y-%m-%d"
    ),
    "today": TODAY.strftime("%Y-%m-%d"),
    "7d_ago": (TODAY - datetime.timedelta(days=7)).strftime("%Y-%m-%d"),
    "30d_ago": (TODAY - datetime.timedelta(days=30)).strftime("%Y-%m-%d"),
    "yesterday": (TODAY - datetime.timedelta(days=1)).strftime("%Y-%m-%d"),
    "this_month_start": TODAY.replace(day=1).strftime("%Y-%m-%d"),
    "this_year_first_monday": datetime.date.fromisocalendar(TODAY.year, 1, 1),
    # monday from preceding week
    "last_sunday": LAST_SUNDAY,
    "last_monday": LAST_SUNDAY - datetime.timedelta(days=6),
}

MILLION = 1e6

GOOGLE_ADS_MANAGER_ID_PROD = "6752450493"
GOOGLE_ADS_MANAGER_ID_DEV = "4300754090"

MAX_GOOGLE_KEYWORDS_CHAR_COUNT = 80
MAX_GOOGLE_KEYWORDS_WORD_COUNT = 10
MAX_WORDS_IN_KEYWORD = 6

NUM_DAYS_IN_QUARTER = 91
NUM_WEEKS_IN_QUARTER = 13

DATETIME_WITH_DASH = "%Y-%m-%d %H:%M:%S"
DATE_WITH_DASH = "%Y-%m-%d"
DATE_WITHOUT_DASH = "%Y%m%d"

PREFIX_TERMS = [
    "buy",
    "get",
    "affordable",
    "cheap",
    "cheapest",
    "recommend",
    "best",
    "top",
    "how to buy",
    "where to buy",
]
POSTFIX_TERMS = [
    "review",
    "discount",
    "deal",
    "voucher",
    "plans",
    "rates",
    "price",
]

CCY_SYMBOLS = {"GBP": "£", "USD": "$", "INR": "₹", "EUR": "€", "MYR": "RM"}

if __name__ == "__main__":
    print(DEFAULT_MAPPING)
