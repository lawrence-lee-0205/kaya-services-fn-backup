import requests

import google.oauth2.id_token
import google.auth.transport.requests

_HOST = "https://us-central1-kaya-apps-00.cloudfunctions.net"


def _get_bearer_token(audience):
    request = google.auth.transport.requests.Request()
    token = google.oauth2.id_token.fetch_id_token(request, audience)
    bearer = f"Bearer {token}"
    return bearer


def call_cloud_function(endpoint: str, payload: dict):
    audience = _HOST + endpoint
    bearer = _get_bearer_token(audience)

    response = requests.post(
        audience,
        json=payload,
        headers={"Authorization": bearer},
    )

    if response.status_code != 200:
        raise Exception(
            f"Error running {endpoint}. Received response ", response.status_code
        )

    json_response = response.json()
    return json_response["data"]
