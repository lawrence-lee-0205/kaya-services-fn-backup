import requests
import json

from http_function import slack_http_function


@slack_http_function
def trigger_slack_event(payload={}):
    """API is called when a shortcut is used or there is any interactions with shortcuts, modals, or interactive components (such as buttons, select menus, and datepickers).
    https://api.slack.com/apps/A02PKPBQWRH/interactive-messages?
    """
    # print(f"payload:\n{payload}")
    if isinstance(payload, str):
        payload = json.loads(payload)

    if payload.get("callback_id") == "create-task":
        requests.post(
            "https://us-central1-kaya-apps-00.cloudfunctions.net/create-task-in-noloco",
            json=payload,
        )

    return {"status": "Success"}
