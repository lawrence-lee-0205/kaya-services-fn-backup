from common import validate_inputs
from firestore import FirestoreClient
from slack_tools.create_pulses import send_slack_message

from http_function import http_function, process_request_inputs

_FS = FirestoreClient()


@http_function
def send_client_slack_pulse_from_firestore(request_json={}, request_args={}):
    mandatory_fields = ["collection", "id", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    return main(collection=data["collection"], id=data["id"], env=data["env"])


def main(collection, id, env="dev"):
    print("Processing ", id)
    config = _FS.get_single_document(collection, id)
    channels = config["channel"] if env.upper() == "PROD" else ["C02PYBMGLL9"]

    if len(channels) == 0:
        raise ValueError(
            f"No channels found for this business ({config['business_id']}). Please check the document."
        )

    # construct slack msg
    send_slack_message(
        channels=channels,
        blocks=config["contents"],
        business_id=config["business_id"],
        notification_text=config["notification_text"],
    )

    return "Success"


if __name__ == "__main__":
    from utils.kaya_yaml import read_yaml

    # test sending from firestore collection
    main(
        "pulse_weekly_configurations",
        "y6F95PdDgNJ12UhKdnxq_client",
    )
