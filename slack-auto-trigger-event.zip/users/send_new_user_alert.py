from os import environ
from slack_tools.slack import SlackMessage


def send_new_user_alert(data, context):
    """
    Triggered when a document is created in users collection
    """
    trigger_resource = context.resource
    print("Function triggered by change to: %s" % trigger_resource)

    channel = "C03B7MJMZUG" if environ["ENV"].lower() == "prod" else "C02PYBMGLL9"

    name = data["value"]["fields"]["first_name"]["stringValue"]
    email = data["value"]["fields"]["email"]["stringValue"]
    message = f":technologist: Welcome {name}, our new user! {email} :tada:"

    bot = SlackMessage()
    bot.create_plain_text(message)
    bot.send_notification(channel=channel)
    return None
