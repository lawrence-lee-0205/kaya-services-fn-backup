from os import environ
from sentry_sdk import init as sentry_init
from sentry_sdk.integrations.gcp import GcpIntegration

print("Initialising sentry..")
sentry_init(
    dsn="https://4640db45ea5f43fa8032e6b0db627641@o1189223.ingest.sentry.io/6309511",
    integrations=[GcpIntegration(timeout_warning=True)],
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for performance monitoring.
    # We recommend adjusting this value in production.
    traces_sample_rate=1.0,
    environment=environ["ENV"],
)

def firestore_add_document(request):
    from databases.firebase.api import firestore_add_document

    return firestore_add_document(request)