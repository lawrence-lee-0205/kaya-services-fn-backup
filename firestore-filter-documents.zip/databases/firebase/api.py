from common import validate_inputs
from firestore import FirestoreClient
from http_function import http_function, process_request_inputs

FS = FirestoreClient()


@http_function
def firestore_add_document(request_json={}, request_args={}):
    mandatory_fields = ["collection", "doc"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    id = FS.add_document(data["collection"], data["doc"], data.get("id"))
    return {"id": id}


@http_function
def firestore_update_document(request_json={}, request_args={}):
    mandatory_fields = ["collection", "id", "content"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    FS.update_document(data["collection"], data["id"], data["content"])
    return "Success"


@http_function
def firestore_get_document(request_json={}, request_args={}):
    mandatory_fields = ["collection", "id"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    output = FS.get_single_document(data["collection"], data["id"])
    return output


@http_function
def firestore_filter_documents(request_json={}, request_args={}):
    mandatory_fields = ["collection", "filters"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    list_of_docs = FS.get_filtered_documents(
        data["collection"], data["filters"], data.get("orders"), data.get("output_fmt")
    )
    return list_of_docs
