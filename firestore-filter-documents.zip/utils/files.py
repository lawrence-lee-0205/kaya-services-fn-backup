import os


def create_directory_if_not_exists(directory_path):
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)
        print(f"Directory {directory_path} created.")
    else:
        print(f"Directory {directory_path} already exists.")


def list_files(directory_path):
    with os.scandir(directory_path) as entries:
        files = [entry.name for entry in entries if entry.is_file()]
    return files
