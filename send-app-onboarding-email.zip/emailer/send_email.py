import os

from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (
    Mail,
    Cc,
    From,
    ReplyTo,
    TrackingSettings,
    OpenTracking,
    Subject,
)

_FROM_EMAIL = "admin@usekaya.com"


def _process_cc(email, to_emails):
    if email in to_emails:
        raise Exception(
            f"CC Email cannot exist in To Emails. CC email with conflict: {email}"
        )
    return Cc(email=email)


def send_templated_email(
    to_emails: list,
    dynamic_data: dict,
    template_id: str,
    subject: str,
    cc_emails: list = [],
):
    """https://github.com/sendgrid/sendgrid-python/blob/main/use_cases/kitchen_sink.md

    Args:
        to_emails (list): _description_
        dynamic_data (dict): _description_
        template_id (str): _description_
        cc_emails (list, optional): _description_. Defaults to [].
        subject (str, optional): _description_. Defaults to None.

    Raises:
        Exception: _description_

    Returns:
        _type_: _description_
    """
    message = Mail(from_email=From(_FROM_EMAIL, "Kaya"), to_emails=to_emails)
    message.reply_to = ReplyTo(_FROM_EMAIL, "Kaya")
    message.template_id = template_id
    message.dynamic_template_data = dynamic_data

    if len(cc_emails) > 0:
        message.cc = [_process_cc(em, to_emails) for em in cc_emails]

    # TODO: DOESNT WORK ALL THE TIME, CHECK WHY
    message.subject = Subject(subject)

    # add tracking
    tracking_settings = TrackingSettings()
    tracking_settings.open_tracking = OpenTracking(True)
    message.tracking_settings = tracking_settings

    # create our sendgrid client object, pass it our key, then send and return our response objects
    sg = SendGridAPIClient(os.environ["SENDGRID_API_KEY"])
    response = sg.send(message)
    if str(response.status_code)[:1] != "2":
        raise Exception(
            f"Email failure (code {response.status_code}):\n{response.body}"
        )
    return "Success"


def send(from_email, to_emails, subject, html_content):
    """Send basic email with plain text"""
    message = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=html_content,
    )
    try:
        sg = SendGridAPIClient(os.environ.get("SENDGRID_API_KEY"))
        response = sg.send(message)
        print(response.status_code)
        print(response.body)
        print(response.headers)
    except Exception as e:
        print(e.message)
    return None


if __name__ == "__main__":
    # send(message="hello")
    pass
