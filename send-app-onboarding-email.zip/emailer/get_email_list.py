from firestore import FirestoreClient

_FS = FirestoreClient()


def get_email_list(business_id):
    users_ref = _FS.get_collection("users")
    docs = users_ref.where(u"businesses", u"array_contains", business_id).stream()

    emails = [doc.to_dict()["email"] for doc in docs]
    return emails


if __name__ == "__main__":
    print(get_email_list("2ububBhO0RIq0tURuqnY"))
