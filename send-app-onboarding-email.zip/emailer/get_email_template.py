import os

from utils.kaya_yaml import read_yaml

_CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))
_YML_FILEPATH = _CURRENT_DIR + "/dynamic_templates.yml"


def get_email_template(name):
    config = read_yaml(_YML_FILEPATH)["templates"]
    return config[name]


if __name__ == "__main__":
    print(_YML_FILEPATH)
