import functools
from flask import jsonify, make_response

import sentry_sdk


def http_function(cloud_func):
    """Function to run boilerplate codes for Cloud Func invoked by HTTP

    Args:
        cloud_func (func): Inner function we would like to execute

    Returns:
        flask response with status code 200 = success, 400 error
    """

    @functools.wraps(cloud_func)
    def wrapper(request, *args, **kwargs):
        try:
            # when .get_json() fails, API will return 400 error without explanation
            request_json = request.get_json()
        except Exception as e:
            print("Failed to run get_json")
            print(e)
            request_json = {}
        request_args = request.args

        try:
            output = cloud_func(request_json, request_args, *args, **kwargs)
        except Exception as e:
            print(e)
            sentry_sdk.capture_exception(e)
            sentry_sdk.flush()
            raise
        return make_response(jsonify({"data": output}), 200)

    return wrapper


def http_function_with_header(cloud_func):
    """Function to run boilerplate codes for Cloud Func invoked by HTTP

    Args:
        cloud_func (func): Inner function we would like to execute

    Returns:
        flask response with status code 200 = success, 400 error
    """

    @functools.wraps(cloud_func)
    def wrapper(request, *args, **kwargs):
        request_json = request.get_json()
        request_args = request.args
        request_header = dict(request.headers)

        try:
            output = cloud_func(
                request_json, request_args, request_header, *args, **kwargs
            )
        except Exception as e:
            print(e)
            sentry_sdk.capture_exception(e)
            sentry_sdk.flush()
            raise
        return make_response(jsonify({"data": output}), 200)

    return wrapper


def slack_http_function(cloud_func):
    """request.form (and this func) only works for requests with the content type application/x-www-form-urlencoded.

    Args:
        cloud_func (func): Inner function we would like to execute

    Returns:
        flask response with status code 200 = success, 400 error
    """

    @functools.wraps(cloud_func)
    def wrapper(request, *args, **kwargs):
        payload = request.form.get("payload")

        try:
            output = cloud_func(payload, *args, **kwargs)
        except Exception as e:
            print(e)
            sentry_sdk.capture_exception(e)
            sentry_sdk.flush()
            raise
        return make_response(jsonify({"data": output}), 200)

    return wrapper


def process_request_inputs(request_json=None, request_args=None):
    """Combine request_json and request_args passed from API into 1 dict"""
    request_json = {} if request_json is None else request_json
    request_args = {} if request_args is None else request_args

    # raise error if the same key exists in both dict
    overlap = request_json.keys() & request_args.keys()
    if len(overlap) > 0:
        raise Exception(
            f"Found overlapping keys between request_json and request_args: {overlap}"
        )

    return {**request_args, **request_json}


if __name__ == "__main__":
    # this should raise error
    # process_request_inputs(request_json={"a": 1, "b": 2}, request_args={"a": 1, "d": 2})

    # this shouldnt raise error
    process_request_inputs(request_json={"c": 1, "b": 2}, request_args={"a": 1, "d": 2})
