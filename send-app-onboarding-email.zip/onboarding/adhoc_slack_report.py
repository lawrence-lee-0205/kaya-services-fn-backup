import datetime as dt

from businesses.business import Business
from slack_tools.slack import SlackMessage

from firestore import FirestoreClient

_FS = FirestoreClient()

if __name__ == "__main__":
    print()
    print(
        "1. Create a canvas in the Slack Connect channel.\n2. Add the slack connect channel to Workflow permission.\n3. Try sending a report from the Workflow in the Slack Connect channel."
    )
    input("If the report get sent successfully, press Enter to send the announcement.")

    business_id = "05YbIXRfIYlPGCsKW5qe"
    biz = Business(business_id)

    blocks = [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "*New Feature Announcement*",
            },
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "We're excited to introduce a feature that lets you receive reports (like the one above) in this Slack channel, _on demand_  :kitty_spin:",
            },
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "Here's how it works:\n1. Open Canvas and initiate the Get a report workflow. Alternatively, you can activate the workflow by selecting it from the / command.\n2. A form will pop up. Simply select the channel and date range for the report you'd like to receive.\n3. Sit tight! In just a few minutes, you'll receive a pulse like the one above.\n 4. We hope you find this new feature useful. Please don't hesitate to reach out if you have any questions, feedback, or issues. Thank you!",
            },
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "Hope you find this new feature useful. Please don't hesitate to reach out if you have any questions, feedback, or issues. Thank you!",
            },
        },
        {"type": "divider"},
        {
            "type": "image",
            "title": {"type": "plain_text", "text": "How it works", "emoji": True},
            "image_url": "https://storage.googleapis.com/kaya-apps-00-public/public-adhoc/how%20to%20request%20a%20report.gif",
            "alt_text": "marg",
        },
    ]

    bot = SlackMessage()
    bot.send_notification(blocks=blocks, channel=biz.slack_channel_id)

    features = biz.analytic_features
    features["adhoc_slack_workflow"] = {
        "enabled": True,
        "updated": dt.datetime.utcnow(),
    }

    _FS.update_document("businesses", business_id, {"analytic_features": features})
