from firestore import FirestoreClient
from jobs.etl_firebase_to_bq import execute
from google.gutils.bigquery import run_query
from dashboard.deploy_yaml import deploy_yaml_for_home
from custom_reports.add_business_id_to_dashboard import add_business_id_to_dashboard
from custom_reports.deploy_yaml import deploy_yaml_to_storage
from databases.airtable.airtable import Airtable

_FS = FirestoreClient()
_AIRTABLE_DASHBOARD_MAPPING = {
    "google-ads-overview": {
        "airtable_record_id": "recKrZCHDkv981STi",
        "name": "1. Overview",
    },
    "google-ads-keywords": {
        "airtable_record_id": "rec1X1MvqdtBJ3uHR",
        "name": "2. Keyword Analysis",
    },
}


def update_kpi_and_sync_to_bq(business_id: str, kpi: str):
    _FS.update_document(
        "businesses",
        business_id,
        {
            "kpi": kpi,
            "disable_channel_comparison": True,
        },
    )
    execute(collection="businesses")
    sql = f"""
    select 
        kpi
    from kaya-apps-00.staging.stg_firestore__businesses
    where business_id = '{business_id}'
    """
    res = run_query(sql)

    if res[0]["kpi"] != kpi:
        raise ValueError(
            f"KPI for {business_id} is not updated correctly. Please check if Firestore is updated properly."
        )
    print(res)
    return None


def run_dbt_job_to_calculate_kpi(business_id):
    instruction = f"""
    👉 In DBT:
    - Update `dbt_project.yml` and respective schema yml file to process the new schema for this business
    - Create and merge PR into prod
    - Run DBT job `Onboard new client` (https://cloud.getdbt.com/deploy/52310/projects/83498/jobs/378228/settings). 
      Remember to update command to include all schemas (eg Google Ads, FB Ads) that have been updated.
    """

    print(instruction)
    input("Wait for sync to complete, then press Enter to continue...")
    # check if kpi exists in daily_kpi_by_channel
    sql = f"""
    select 
        kpi_name, 
        sum(kpi_value) as kpi_value
    from kaya-apps-00.m_core.daily_kpi_by_channel
    where business_id = '{business_id}'
    group by 1
    """
    res = run_query(sql)
    if len(res) == 0:
        error_msg = f"""
        KPI for {business_id} does not exist in daily_kpi_by_channel table. Please check if DBT job is run properly. 
        Potential reasons:
        - any space or special characters in business ID in Gsheet config?
        - check if data is in `m_google_ads`: select * from kaya-apps-00.staging.campaign_stats_daily where business_id = '{business_id}'
        - if that fails, check if its in `staging`: select * from kaya-apps-00.staging.stg_google_ads__campaign_stats where client_id in (xxx)
        """
        print(error_msg)
        raise ValueError()
    print(res)

    input("If KPI is updated correctly, press Enter to continue...")
    return None


def set_up_for_home_dashboard(dashboard_id: str, business_id: str):
    # deploy home dashboard to bucket
    deploy_yaml_for_home(
        dashboard_id=dashboard_id,
        business_id=business_id,
        env="prod",
    )

    _FS.update_document(
        "businesses",
        business_id,
        {
            "is_onboarded": True,
        },
    )
    print(
        f"\n👉 Visit https://app.usekaya.com?client={business_id} to check if home dashboard is updated."
    )
    return None


def add_dashboard_to_business():
    pass


if __name__ == "__main__":
    # only run this after their campaign data is available on BQ. This can be done after running services/airbyte/create_connection.py
    business_id = "1PWNNsvjAstiS3PkMexb"
    kpi = "total_conversions"
    channels = ["google_ads"]
    home_dashboard_id = "cost-per-conversion-usd"

    update_kpi_and_sync_to_bq(business_id, kpi)
    run_dbt_job_to_calculate_kpi(business_id)
    set_up_for_home_dashboard(home_dashboard_id, business_id)

    airtable_business_dashboard = Airtable(
        table="business_dashboard", base_id="applq0qqCgkEYaxzQ"
    )
    for ch in channels:
        if ch == "google_ads":
            dashboards = [
                "google-ads-overview",
                "google-ads-keywords",
            ]
            for dash in dashboards:
                add_business_id_to_dashboard(dash, business_id)
                input(
                    f"Check if services/dashboard_configs/{dash}.yml is edited correctly. If all good, press Enter to continue..."
                )

                deploy_yaml_to_storage(dash)

                # TODO: CHECK IF THE BUSINESS ALREADY BEEN GRANTED ACCESS TO THIS DASHBOARD ON AIRTABLE
                rec_id = _AIRTABLE_DASHBOARD_MAPPING[dash]["airtable_record_id"]
                name = _AIRTABLE_DASHBOARD_MAPPING[dash]["name"]
                airtable_business_dashboard.table.create(
                    {
                        "business_id": business_id,
                        "category": "📡 Paid Ads",
                        "title": name,
                        "dashboard": [rec_id],
                        "homepage_channel_highlight": "Google CPC",
                        "is_live": True,
                    },
                )
    print(
        "Now you can proceed to services/pulses/ads/create_slack_config.py to create slack pulses"
    )
