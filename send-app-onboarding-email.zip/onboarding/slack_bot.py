import os
import datetime as dt

# Import WebClient from Python SDK (github.com/slackapi/python-slack-sdk)
from slack_sdk import WebClient

from setup import setup
from users.user import User
from common import validate_inputs
from firestore import FirestoreClient
from slack_tools.slack import SlackMessage
from exceptions import UserNotFoundException

# WebClient instantiates a client that can call API methods
# When using Bolt, you can use either `app.client` or the `client` passed to listeners.
_SLACK_CLIENT = WebClient(token=os.environ.get("SLACK_BOT_TOKEN"))
_FS = FirestoreClient()
_ADMIN_SLACK_MAPPING = {
    "brian@usekaya.com": "U02NBHYDFKR",
    "jeeyen@usekaya.com": "U02P4RZDN5P",
}


@setup
def configure_slack_for_slack_connect(data: dict) -> dict:
    mandatory_fields = ["slack_channel_name", "admin_email", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    resp = execute(data["slack_channel_name"], data["admin_email"])
    return resp


def execute(channel_name, admin_email):
    admin_slack_id = _ADMIN_SLACK_MAPPING[admin_email]
    channel_id = _get_channel_id(channel_name)
    members = _SLACK_CLIENT.conversations_members(channel=channel_id)["members"]

    successful = []
    unsuccessful = []
    for m in members:
        if m == "U02PN0WJ2G4":
            continue

        res = _SLACK_CLIENT.users_info(user=m)
        try:
            email = res["user"]["profile"]["email"]

            if email == "dtran320@gmail.com":
                email = "david@flow.club"
            elif email == "yean.ricky@gmail.com":
                email = "ricky@flow.club"

        except KeyError as e:
            # error from email = res["user"]["profile"]["email"]
            error = f"Erorr processing user {m}. Key Error: {e}"
            print(error)
            unsuccessful.append(
                {
                    "slack_member_id": m,
                    "error": error,
                    "member": res.get("user", {}).get("real_name", ""),
                }
            )
            continue

        try:
            fs_user = User(email=email)
        except UserNotFoundException as e:
            error = str(e)
            print(error)
            unsuccessful.append({"slack_member_id": m, "email": email, "error": error})
            continue

        if fs_user.has_slack_id == False:
            _FS.update_document("users", fs_user.user_id, {"slack_id": m})
            fs_user = User(email=email)

        if fs_user.has_slack_dm_channel == False:
            _send_slack_greeting(fs_user, admin_slack_id)
        successful.append(email)
    return {"successful": successful, "unsuccessful": unsuccessful}


def _send_slack_greeting(user: User, admin_slack_id: str):
    print("Processing user ", user.first_name, user.user_id)

    if user.slack_id is None:
        raise (f"User {user.first_name}, ID {user['id']} has no slack ID\n")

    bot = SlackMessage()
    bot.create_section_block(
        text=f"👋 {user.first_name}, from now on, Kayabot will notify you of task updates, including new comments and task assignments. If you have any questions, please reach out to <@{admin_slack_id}|cal>"
    )
    out = bot.send_notification(channel=user.slack_id)

    _FS.update_document(
        "users",
        user.user_id,
        {
            "slack_onboarding_greeting_sent_at": dt.datetime.utcnow(),
            "slack_dm_channel": out["channel"],
        },
    )
    return None


def _get_channel_id(chanel_name):
    all_channels_raw = _SLACK_CLIENT.conversations_list(types="private_channel")
    for ch in all_channels_raw["channels"]:
        if ch["name"] == chanel_name:
            return ch["id"]
    raise Exception(
        f"Channel {chanel_name} not found. You need to invite the bot to the channel first."
    )


if __name__ == "__main__":
    channel_name = "kaya-flowclub"
    admin_email = "jeeyen@usekaya.com"
    print(execute(channel_name, admin_email))

    # if you only want to send slack msg
    # user = User(user_id="ghewNOY3zxKiPmrLQCmz")
    # _send_slack_greeting(user, admin_slack_id="U02P4RZDN5P")
