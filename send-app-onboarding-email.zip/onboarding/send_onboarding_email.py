from setup import setup
from common import validate_inputs
from emailer.send_email import send_templated_email


@setup
def send_app_onboarding_email(data: dict) -> dict:
    mandatory_fields = [
        "to_email",
        "business_name",
        "admin_name",
        "recipient_name",
    ]
    validate_inputs(data, mandatory_fields)

    payload = {
        "name": data["recipient_name"],
        "company": data["business_name"],
        "admin": data["admin_name"],
        "invitee": data.get("invitee_name", data["admin_name"]),
    }

    send_templated_email(
        to_emails=[data["to_email"]],
        dynamic_data=payload,
        template_id="d-fbe05f5612014d0d849951b56a2c782c",
        subject=f"You're invited to join {data['business_name']} on Kaya",
        cc_emails=["admin@usekaya.com"],
    )
    print("sent to " + to)
    return None


if __name__ == "__main__":
    data = {
        "name": "",
        "company": "Encord",
        "admin": "Jee",
        "invitee": "",
    }
    to = ""

    send_templated_email(
        to_emails=[to],
        dynamic_data=data,
        template_id="d-fbe05f5612014d0d849951b56a2c782c",
        subject=f"You're invited to join {data['company']} on Kaya",
        cc_emails=["jeeyen@usekaya.com"],
    )
    print("sent to " + to)
