import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

from http_function import http_function


@http_function
def send_email(request_json={}, request_args={}):
    mandatory_fields = ["message"]

    data = {}
    for m in mandatory_fields:
        if request_json and m in request_json:
            data[m] = request_json[m]
        elif request_args and m in request_args:
            data[m] = request_args[m]
        else:
            raise Exception(f"Expecting {m} to be provided")

    print("request_json: ", request_json)
    print("request_args: ", request_args)

    out = execute(**data)
    return out


def execute(**kwargs):
    content = ""
    for k, v in kwargs.items():
        content += f"{k}: {v}\n"

    message = Mail(
        from_email="admin@usekaya.com",
        to_emails="jeeyen@usekaya.com",
        subject="Sending with Twilio SendGrid is Fun",
        html_content=f"{content}",
    )
    try:
        sg = SendGridAPIClient(os.environ.get("SENDGRID_API_KEY"))
        response = sg.send(message)
        print(response.status_code)
        print(response.body)
        print(response.headers)
    except Exception as e:
        print(e.message)
    return None


if __name__ == "__main__":
    execute(message="hello")
