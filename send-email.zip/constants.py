import datetime

TODAY = datetime.date.today()
DEFAULT_MAPPING = {
    "start_of_last_month": TODAY.replace(month=TODAY.month - 1, day=1).strftime(
        "%Y-%m-%d"
    ),
    "today": TODAY.strftime("%Y-%m-%d"),
    "7d_ago": (TODAY - datetime.timedelta(days=7)).strftime("%Y-%m-%d"),
    "30d_ago": (TODAY - datetime.timedelta(days=30)).strftime("%Y-%m-%d"),
    "yesterday": (TODAY - datetime.timedelta(days=1)).strftime("%Y-%m-%d"),
    "this_month_start": TODAY.replace(day=1).strftime("%Y-%m-%d"),
}


MILLION = 1e6

GOOGLE_ADS_MANAGER_ID_PROD = "6752450493"
GOOGLE_ADS_MANAGER_ID_DEV = "4300754090"

MAX_GOOGLE_KEYWORDS_CHAR_COUNT = 80
MAX_GOOGLE_KEYWORDS_WORD_COUNT = 10
MAX_WORDS_IN_KEYWORD = 6

NUM_DAYS_IN_QUARTER = 91
NUM_WEEKS_IN_QUARTER = 13

DATETIME_WITH_DASH = "%Y-%m-%d %H:%M:%S"
DATE_WITH_DASH = "%Y-%m-%d"
DATE_WITHOUT_DASH = "%Y%m%d"

PREFIX_TERMS = [
    "buy",
    "get",
    "affordable",
    "cheap",
    "cheapest",
    "recommend",
    "best",
    "top",
    "how to buy",
    "where to buy",
]
POSTFIX_TERMS = [
    "review",
    "discount",
    "deal",
    "voucher",
    "plans",
    "rates",
    "price",
]
