import functools
from flask import jsonify, make_response

import sentry_sdk


def http_function(cloud_func):
    """Function to run boilerplate codes for Cloud Func invoked by HTTP

    Args:
        cloud_func (func): Inner function we would like to execute

    Returns:
        flask response with status code 200 = success, 400 error
    """

    @functools.wraps(cloud_func)
    def wrapper(request, *args, **kwargs):
        request_json = request.get_json()
        request_args = request.args

        try:
            output = cloud_func(request_json, request_args, *args, **kwargs)
        except Exception as e:
            print(e)
            sentry_sdk.capture_exception(e)
            sentry_sdk.flush()
            raise
        return make_response(jsonify({"data": output}), 200)

    return wrapper
