import jinja2


def render_template(folder, filename, **kwargs):
    templateLoader = jinja2.FileSystemLoader(searchpath=folder)
    templateEnv = jinja2.Environment(loader=templateLoader)
    template_file = filename
    template = templateEnv.get_template(template_file)
    outputText = template.render(**kwargs)
    return outputText
