import yaml
from schema import Schema


def read_yaml(filename: str):
    with open(filename, "r") as file:
        content = yaml.safe_load(file)

    if content is None:
        raise Exception("Unable to read file: ", filename)
    return content


def read_yaml_as_str(string: str):
    return yaml.safe_load(string)


def validate_yaml(schema_object: Schema, filepath: str) -> None:
    """Validate a given yaml file. Raise SchemaError if invalid.
    https://github.com/keleshev/schema
    https://www.andrewvillazon.com/validate-yaml-python-schema/

    Args:
        schema_object (Schema): _description_
        filepath (str): _description_

    Returns:
        _type_: _description_
    """
    print("Validating ", filepath)
    config = read_yaml(filepath)
    validated = schema_object.validate(config)
    print("Configuration is valid.")
    return validated
