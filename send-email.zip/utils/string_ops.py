import re


def convert_to_camel_case(name):
    pattern = re.compile(r"(?<!^)(?=[A-Z])")
    converted = pattern.sub("_", name).lower()
    return converted
