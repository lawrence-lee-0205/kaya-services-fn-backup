import os

from emailer.send_email import send_templated_email
from emailer.get_email_template import get_email_template
from pulses.constructor.data_component import TextWithData, ChartWithData, StaticText

_ENV = os.environ["ENV"]


def _process_variable(type, config, business_id):
    if type == "static":
        obj = StaticText(**config)
        value = obj.create()
    elif type == "text_with_data":
        obj = TextWithData(
            business_id=business_id,
            sql_template=config["sql"]["text"],
            text_template_config=config["template"],
        )
        value = obj.create()
    elif type == "chart_with_data":
        obj = ChartWithData(
            business_id=business_id,
            sql_template=config["sql"]["text"],
            viz=config["viz"],
        )
        value = obj.create(**config["viz_config"])
    else:
        raise ValueError(f"Variable of type `{type}` is not implemented")

    return value


class Email:
    def __init__(
        self,
        business_id: str,
        emails: list,
        subject: dict,
        template: str,
        cc_emails: list = [],
        variables: list = [],
        env: str = "dev",
    ) -> None:
        self.business_id = business_id
        self._to_emails = emails
        self._cc_emails = cc_emails
        self._subject = subject
        self._variables = variables
        self._template = template
        self.env = env

    @property
    def to_emails(self):
        # the same logic is also in send_client_ads_debrief.py
        # TODO: keep only 1!
        return self._to_emails if self.env.upper() == "PROD" else ["admin@usekaya.com"]

    @property
    def cc_emails(self):
        return self._cc_emails if self.env.upper() == "PROD" else []

    @property
    def template(self):
        return get_email_template(self._template)

    @property
    def subject(self):
        subject = StaticText(
            text=self._subject["text"], is_templated=self._subject["is_templated"]
        ).create()

        if self.env.upper() == "DEV":
            subject = "[TEST] " + subject
        return subject

    @property
    def dynamic_data(self):
        dynamic_data = {}
        for variable in self._variables:
            var_type = variable["type"]
            var_name = variable["name"]

            if var_type == "list_with_data":
                existing_lst = dynamic_data.get(var_name, [])
                val = _process_variable(
                    type="text_with_data",
                    config=variable["config"],
                    business_id=self.business_id,
                )
                if val is not None:
                    existing_lst.append(val)
                dynamic_data[var_name] = existing_lst
            else:
                val = _process_variable(
                    type=var_type,
                    config=variable["config"],
                    business_id=self.business_id,
                )
                if val is not None:
                    dynamic_data[var_name] = val
        return dynamic_data

    def send_templated_email(self):
        # check if all mandatory variables exist
        mandatory_variables = self.template["mandatory_variables"]
        for v in mandatory_variables:
            if v not in self.dynamic_data.keys():
                raise Exception(f"Missing variable {v}")

        send_templated_email(
            to_emails=self.to_emails,
            template_id=self.template["id"],
            dynamic_data=self.dynamic_data,
            subject=self.subject,
            cc_emails=self.cc_emails,
        )
