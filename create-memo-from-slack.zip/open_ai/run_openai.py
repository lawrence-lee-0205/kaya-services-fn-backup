import os

import openai

openai.api_key = os.environ["OPENAI_API_KEY"]


def run_davinci(prompt, max_token=600):
    output_obj = openai.Completion.create(
        model="text-davinci-003", prompt=prompt, max_tokens=max_token, temperature=0
    )
    output = output_obj["choices"][0]["text"]
    return output
