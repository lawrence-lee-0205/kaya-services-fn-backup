import os
from openai import OpenAI


import logging
from typing import List

from common import validate_inputs
from http_function import http_function, process_request_inputs

_CLIENT = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
_DEFAULT_MODEL = "gpt-4"


@http_function
def ai_run_chat_completions(request_json={}, request_args={}):
    mandatory_fields = ["messages"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    out = run_chat_completions(
        data["messages"], data.get("model"), data.get("output_format")
    )
    return out


def run_chat_completions(
    messages: List[dict], model=_DEFAULT_MODEL, output_format="string"
):
    params = {}
    if output_format == "json":
        model = "gpt-4-1106-preview"
        params = {
            "response_format": {"type": "json_object"},
        }

    logging.info(f"Calling OpenAI model {model}")
    response = _CLIENT.chat.completions.create(messages=messages, model=model, **params)
    out = response.choices[0].message.content
    logging.info(f"OpenAI request completed")
    return out


if __name__ == "__main__":
    company_name = "Kaya"

    # header_lst_str = "\n - ".join(headers)
    # output_condensed_str = "\n - ".join(content_list)
    # user_prompt_2 = f"These are the content on the website:\n- {output_condensed_str}"

    system_prompt = f"""
    You are a marketer who is skilled at performing competitor analysis. Your task is to create a detailed and concise summary for a company, highlighting its unique selling proposition and differentiation factors. The profile should include the following seven essential elements:
    
    1. An overview of the company's primary services
    2. A description of their specific product(s)
    3. A detailed analysis of their target customer
    4. An outline of the company's unique selling proposition (USP)
    5. A breakdown of the pricing structure

    Do not include any explanations, only provide a  RFC8259 compliant JSON response following this format without deviation.
    {{
        "overview": "The company provides a service that helps people to do X.",
        "product": "The main products are X, Y, and Z.",
        "target_customers": "The company's target customers are X, Y, and Z.",
        "usps": "The company's USP is X.",
        "pricing": "The company's pricing structure is X.",
    }}
    """
    user_prompt_1 = f"The company is called {company_name}. Browse its website www.usekaya.com and write a summary of the company."

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt_1},
        # {"role": "user", "content": user_prompt_2},
        # {"role": "user", "content": task_prompt},
    ]
    o = run_chat_completions(messages)
    print(o)
