from businesses.business import Business
from firestore import FirestoreClient
from utils.kaya_yaml import read_yaml
from utils.jinja import render_template_from_string

_FS = FirestoreClient()

if __name__ == "__main__":
    business_id = "tvjxZsy4t3nv0GRi75Oi"
    template = "ad_copies"

    biz = Business(business_id)
    biz_properties = biz.get_property_values()
    biz_properties = {"business_" + k: v for k, v in biz_properties.items()}
    print(biz_properties)
    print("")

    prompt_template = read_yaml(
        f"/Users/jeeyenpersonal/Documents/kaya-services/services/open_ai/prompt_templates/{template}.yaml"
    )["template"]["content"]

    # template = _FS.get_single_document("task_templates", template)

    # populate content with params

    populated_desc = render_template_from_string(prompt_template, **biz_properties)
    print(populated_desc)
