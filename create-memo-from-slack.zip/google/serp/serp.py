import os
import requests
import traceback
from typing import List

from setup import setup
from common import validate_inputs
from firestore import FirestoreClient
from exceptions import NoDefaultSerpLocationError
from queries import (
    get_google_audience,
    get_country_code_by_criteria_id,
    get_default_serp_location,
)

_COLLECTION_NAME = "serp_results"
_DEFAULT_CRITERIA_ID_LOCATIONS = ["2458"]  # Malaysia

FS = FirestoreClient()


@setup
def main(data: dict) -> dict:
    """Get sample ads and organic results based on a list of keywords and audience

    Args:
        data (dict)

    Returns:
        dict: List of dict where each dict contains ads and organic search results for 1 keyword.
    """
    mandatory_fields = ["keywords", "audience_id"]
    validate_inputs(data, mandatory_fields)

    ###########################
    #  GET LIST OF LOCATIONS  #
    ###########################

    audience = get_google_audience(data["audience_id"])
    print(audience)

    if "includes" in audience and "location" in audience["includes"]:
        criteria_id_locations = audience["includes"]["location"]
    else:
        criteria_id_locations = _DEFAULT_CRITERIA_ID_LOCATIONS

    location_serp_inputs = convert_criteria_ids_to_serp_locations(criteria_id_locations)

    #####################
    #  START SEARCHING  #
    #####################

    outputs = process_keywords(data["keywords"], location_serp_inputs)
    return outputs


def process_keywords(keywords, location_serp_inputs):
    outputs = []
    for keyword in keywords:
        print("Processing ", keyword)
        ads = []
        organic_results = []

        ads += _get_global_ads_by_keyword(keyword)

        for loc in location_serp_inputs:
            try:
                output = _get_local_serp_by_keyword(
                    query=keyword, location=loc["location"], gl=loc["country_code"]
                )
                ads += output["ads"]  # list of dict
                organic_results += output["organic"]  # list of dict

            except Exception as e:
                print("ACCEPTABLE ERROR")
                traceback.print_exc()
                print(e)

        output = {"ads": ads, "organic": organic_results, "keyword": keyword}
        outputs.append(output)
    return outputs


def get_related_searches_by_keywords(keywords, criteria_id_locations):
    print("Running SERP queries for related searches")
    print(keywords)

    if criteria_id_locations == []:
        criteria_id_locations = _DEFAULT_CRITERIA_ID_LOCATIONS
    location_serp_inputs = convert_criteria_ids_to_serp_locations(criteria_id_locations)

    related_searches_lst = []
    for keyword in keywords:
        for loc in location_serp_inputs:
            try:
                print(f"searching '{keyword}'")
                serp = run_query(keyword, loc["location"], loc["country_code"])
                related_searches_dict = serp.get("related_searches", [])
                related_searches_lst += [d["title"] for d in related_searches_dict]

            except Exception as e:
                print("ACCEPTABLE ERROR")
                traceback.print_exc()
                print(e)
    related_searches_lst = list(set(related_searches_lst))
    return related_searches_lst


def convert_criteria_ids_to_serp_locations(criteria_ids):
    location_serp_inputs = []
    for cid in criteria_ids:
        try:
            country_code = get_country_code_by_criteria_id(cid)
            d = {
                "country_code": country_code,
                "location": get_default_serp_location(country_code),
            }
            location_serp_inputs.append(d)
        except NoDefaultSerpLocationError as e:
            traceback.print_exc()
            print(e)
    return location_serp_inputs


def run_query(query, location, gl):
    gl = gl.upper()

    collection = FS.get_collection(_COLLECTION_NAME)
    docs = (
        collection.where("query", "==", query)
        .where("location", "==", location)
        .where("gl", "==", gl)
        .stream()
    )

    result = None
    # TODO: WHAT HAPPEN IF MULTI DOCS
    for doc in docs:
        print("Found doc in firestore")
        result = doc.to_dict()
        print("--")

    if result is None:
        headers = {"apikey": os.environ["ZENSERP_API_KEY"]}

        params = (
            ("q", query),
            ("location", location),
            ("gl", gl),
        )

        response = requests.get(
            "https://app.zenserp.com/api/v2/search", headers=headers, params=params
        )

        result = response.json()
        result["query"] = query
        result["location"] = location
        result["gl"] = gl
        FS.add_document(_COLLECTION_NAME, result)

    # print(result)
    return result


##########################
#    PRIVATE FUNCTION    #
##########################


def _process_local_ads(ads: List[dict]) -> List[dict]:
    """Process raw PAID ADS results from SERP doc to dict that contains only info to return via API

    Args:
        ad (dict): input from serp result

    Returns: list of dict
    """
    ads_results = []
    for ad in ads:
        if "description" in ad and "title" in ad:
            # process paid position
            paid_pos = ad.get("paidPosition")
            if (paid_pos.lower() == "top") or paid_pos < "5":
                is_top_ads = True
            else:
                is_top_ads = False

            ads_results.append(
                {
                    "description": ad.get("description"),
                    "title": ad.get("title"),
                    "is_top_ads": is_top_ads,
                    "url": ad.get("destinationUrl"),
                    "is_local": True,
                }
            )

    return ads_results


def _process_local_organic(organic_results: List[dict]) -> List[dict]:
    """Process raw ORGANIC result from SERP doc to dict that contains only info to return via API

    Args:
        organic_results (List[dict]): [description]

    Returns:
        List[dict]: [description]
    """
    processed = [
        {
            "description": og.get("description"),
            "title": og.get("title"),
            "position": og.get("position"),
            "url": og.get("destination"),
            "is_local": True,
        }
        for og in organic_results
        if "title" in og and "description" in og
    ]

    return processed


def _get_local_serp_by_keyword(query: str, location: str, gl: str) -> dict:
    """Given a search query, get ads and organic results for when users search in
    a particular location and country code

    Args:
        query (str): keyword to search
        location (str): search location
        gl (str): country code

    Returns: dict
    """
    serp = run_query(query, location, gl)

    ads_results_raw = serp.get("paid", [])
    ads_results = _process_local_ads(ads_results_raw)

    organic_results = serp.get("organic", [])
    organic_results = _process_local_organic(organic_results)

    output = {
        "ads": ads_results,
        "organic": organic_results,
    }
    return output


def _get_global_ads_by_keyword(query: str) -> List[dict]:
    """Given a search query, get ads data from a collection containing Spyfu data

    Args:
        query (str): keywords to search

    Returns: list of dict
    """
    col_ref = FS.get_collection("google_search_ads_samples")
    docs = col_ref.where("keywords", "array_contains", query).stream()

    ads_results = []
    for doc in docs:
        doc_dict = doc.to_dict()

        ads_results.append(
            {
                "description": doc_dict.get("body"),
                "title": doc_dict.get("title"),
                "url": doc_dict.get("url"),
                "is_top_ads": doc_dict.get("is_top_ads", False),
                "is_local": False,
            }
        )
    return ads_results


if __name__ == "__main__":
    import pandas as pd

    keywords = [
        "iphone",
        "ipad",
    ]
    # location_serp_inputs = convert_criteria_ids_to_serp_locations(["2840"])
    outputs = process_keywords(
        keywords,
        [{"country_code": "US", "location": "Silicon Valley,California,United States"}],
    )
    print(outputs)
    ads_lst = []
    org_lst = []
    for out in outputs:
        ads_lst.append(pd.DataFrame(out["ads"]))
        org_lst.append(pd.DataFrame(out["organic"]))

    ads_df = pd.concat(ads_lst)
    organic_df = pd.concat(org_lst)

    ads_df.to_csv("ads_df.csv", index=0)
    organic_df.to_csv("organic_df.csv", index=0)
