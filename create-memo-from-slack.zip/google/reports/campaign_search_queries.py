import os

from setup import setup
from common import validate_inputs
from google.gutils.bigquery import run_query
from google.campaigns.campaign import Campaign


@setup
def main(data: dict) -> dict:
    mandatory_fields = [
        "business_id",
        "auth_user_id",
        "campaign_id",
    ]
    validate_inputs(data, mandatory_fields)

    if os.environ["ENV"].lower() == "prod":
        campaign = Campaign(data["campaign_id"])
        google_campaign_id = campaign.google_campaign_id
    else:
        google_campaign_id = "15340145241"

    query = f"""
    WITH raw_ AS (
        SELECT
            AdGroupName as ad_group,
            Query as query,
            SUM(Impressions) AS impressions,
            SUM(Clicks) AS clicks,
            SUM(Cost) AS spent_micros,
            COUNT(DISTINCT Date) AS num_dates
        FROM `{os.environ['GCP_PROJECT_NAME'].lower()}.google_ads.search_query_daily_stats` s
        JOIN `{os.environ['GCP_PROJECT_NAME'].lower()}.google_ads.ad_groups` USING (AdGroupId)
        WHERE s.CampaignId = {google_campaign_id}
        GROUP BY 1, 2
    )
    SELECT
        ad_group,
        query,
        impressions,
        clicks,
        spent_micros / 1e6 as spent,
        num_dates
    FROM raw_ r
    """
    raw_outputs = run_query(query)

    output = {"queries": raw_outputs}
    print(output)
    return output


if __name__ == "__main__":
    data = {
        "business_id": "test",
        "auth_user_id": "test",
        "campaign_id": "test",
    }
    main(data)
