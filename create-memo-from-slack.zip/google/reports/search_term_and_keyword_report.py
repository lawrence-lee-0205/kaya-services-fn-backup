import os

from setup import setup
from common import validate_inputs
from google.gutils.bigquery import run_query
from google.campaigns.campaign import Campaign

from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount
from gsheets.gsheet import GSheet

import pandas as pd


if __name__ == "__main__":
    business_id = "82cutQRlx6gagQFMKjPa"
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    query = """
    SELECT 
        search_term_view.search_term, 
        segments.keyword.info.match_type, 
        segments.keyword.info.text, 
        segments.month,  
        segments.week,
        segments.date,  
        metrics.cost_micros, 
        metrics.all_conversions, 
        metrics.all_conversions_value, 
        metrics.conversions, 
        metrics.conversions_value, 
        metrics.impressions, 
        metrics.clicks 
    FROM search_term_view 
    WHERE 
        segments.date >= '2024-01-01'
        AND segments.date <= '2024-05-28'
        AND campaign.name LIKE '%CA%Payroll%Kaya%' 
    """
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )
    ads = []
    for row in rows:
        # print(row)
        ad = {
            "search_term": row.search_term_view.search_term,
            "match_type": row.segments.keyword.info.match_type.name,
            "keyword_text": row.segments.keyword.info.text,
            "month": row.segments.month,
            "week": row.segments.week,
            "date": row.segments.date,
            "cost_micros": row.metrics.cost_micros / 1e6,
            "all_conversions": row.metrics.all_conversions,
            "all_conversions_value": row.metrics.all_conversions_value,
            "conversions": row.metrics.conversions,
            "conversions_value": row.metrics.conversions_value,
            "impressions": row.metrics.impressions,
            "clicks": row.metrics.clicks,
        }
        ads.append(ad)
    df = pd.DataFrame(ads)

    gsheet = GSheet()
    gsheet.create(filename=f"Rippling Payroll")
    gsheet.share_public(role="writer")

    pivot_tabname = "Ad Copies by Campaign"
    gsheet.add_tab(pivot_tabname, rows=df.shape[0])
    tab_url = gsheet.write_dataframe_to_tab(df.fillna(""), pivot_tabname)
    print(tab_url)
