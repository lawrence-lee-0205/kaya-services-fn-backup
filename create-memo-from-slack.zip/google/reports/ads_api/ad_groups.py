from typing import List

from google.gutils.ads_query import run_ads_query
from constants import MILLION


def query_ad_groups(
    customer_id: str, campaign_resource_name: str, manager_id: str
) -> List[dict]:
    query = f"""
    SELECT
        ad_group_criterion.criterion_id,
        ad_group_criterion.keyword.text,
        ad_group_criterion.keyword.match_type,
        ad_group_criterion.income_range.type,
        ad_group_criterion.negative,
        ad_group_criterion.cpc_bid_micros,
        ad_group_criterion.resource_name,
        ad_group_criterion.final_urls,
        ad_group_criterion.final_url_suffix,
        ad_group_criterion.status,
        ad_group.cpc_bid_micros,
        ad_group.id,
        ad_group.name,
        ad_group.resource_name,
        ad_group.status,
        ad_group.type,
        ad_group.target_roas,
        ad_group.final_url_suffix
    FROM ad_group_criterion
    WHERE customer.id = {customer_id}
        AND campaign.resource_name = '{campaign_resource_name}'
        AND ad_group_criterion.type = 'KEYWORD'
    """

    rows = run_ads_query(customer_id, query, manager_id)

    ad_groups = {}
    for row in rows:
        ad_group_rn = row.ad_group.resource_name

        # each row represents data for a unique keyword
        criterion = {
            "keyword": {
                "status": row.ad_group_criterion.status.name,
                "type": row.ad_group_criterion.type_.name,
                "text": row.ad_group_criterion.keyword.text,
                "match_type": row.ad_group_criterion.keyword.match_type.name,
                "negative": row.ad_group_criterion.negative,
                "cpc_bid_micros": row.ad_group_criterion.cpc_bid_micros,
                "cpc_bid": row.ad_group_criterion.cpc_bid_micros / MILLION,
            },
            "resource_name": row.ad_group_criterion.resource_name,
        }

        if ad_group_rn not in ad_groups:
            ad_group = {
                "resource_name": ad_group_rn,
                "status": row.ad_group.status.name,
                "type": row.ad_group.type_.name,
                "id": row.ad_group.id,
                "name": row.ad_group.name,
                "cpc_bid_micros": row.ad_group.cpc_bid_micros,
                "final_url_suffix": row.ad_group.final_url_suffix,
                "keywords": [criterion],
            }
            # ad_groups.append(ad_group)

        else:
            ad_group = ad_groups[ad_group_rn]
            existing_keywords = ad_group["keywords"]
            existing_keywords.append(criterion)

            ad_group["keywords"] = existing_keywords

        ad_groups[ad_group_rn] = ad_group

    return ad_groups
