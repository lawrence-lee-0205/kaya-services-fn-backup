from typing import List

from google.gutils.ads_query import run_ads_query
from constants import MILLION


def query_campaigns_for_single_ad_account(customer_id: str, manager_id: str):
    sql = """
    SELECT
        campaign.id,
        campaign.name,
        campaign.resource_name
    FROM campaign
    """
    rows = run_ads_query(customer_id, sql, manager_id)

    google_campaign_records = []
    for row in rows:
        campaign = row.campaign
        c = {
            "campaign_resource_name": campaign.resource_name,
            "name": campaign.name,
            "campaign_id": campaign.id,
        }
        google_campaign_records.append(c)
    return google_campaign_records


def query_campaign_budget(
    customer_id: str, campaign_budget_resource_name: str, manager_id: str
):
    query = f"""
    SELECT
        campaign_budget.amount_micros,
        campaign_budget.delivery_method,
        campaign_budget.id,
        campaign_budget.name,
        campaign_budget.resource_name,
        campaign_budget.type,
        campaign_budget.status,
        campaign_budget.total_amount_micros
    FROM campaign_budget
    WHERE
        campaign_budget.resource_name = '{campaign_budget_resource_name}'
    """
    rows = run_ads_query(customer_id, query, manager_id)

    if len(rows) > 1:
        raise Exception(
            f"Expecting only 1 row to be returned from Google API for campaign budget with resource name: {campaign_budget_resource_name}. Received {len(rows)} rows."
        )
    elif len(rows) == 0:
        raise Exception(
            f"No data returned from Google API for campaign budget with resource name: {campaign_budget_resource_name}"
        )

    row = rows[0]
    output = {
        "campaign_budget_resource_name": row.campaign_budget.resource_name,
        "campaign_budget_status": row.campaign_budget.status.name,
        "campaign_budget_delivery_method": row.campaign_budget.delivery_method.name,
        "campaign_budget_type": row.campaign_budget.type_.name,
        "campaign_budget_name": row.campaign_budget.name,
        "campaign_budget_amount_micros": row.campaign_budget.amount_micros,
        "campaign_budget": row.campaign_budget.amount_micros / MILLION,
    }
    return output


def query_campaign_criteria(
    customer_id: str, campaign_resource_name: str, manager_id: str
):
    query = f"""
    SELECT
        campaign_criterion.criterion_id,
        campaign_criterion.keyword.text,
        campaign_criterion.resource_name,
        campaign_criterion.status,
        campaign_criterion.type,
        campaign_criterion.negative,
        campaign_criterion.keyword.match_type,
        campaign_criterion.display_name,
        campaign_criterion.device.type,
        campaign_criterion.custom_affinity.custom_affinity,
        campaign_criterion.custom_audience.custom_audience,
        campaign_criterion.location.geo_target_constant,
        campaign_criterion.language.language_constant
    FROM campaign_criterion
    WHERE
        campaign.resource_name = '{campaign_resource_name}'
        AND campaign_criterion.type IN ('LANGUAGE', 'LOCATION')
    """
    rows = run_ads_query(customer_id, query, manager_id)

    if len(rows) == 0:
        raise Exception(
            f"No campaign criteria data returned from Google API for campaign with resource name: {campaign_resource_name}"
        )

    # NEED TO PROCESS negative_keyword_phrase
    output = []
    for row in rows:
        criterion_raw = row.campaign_criterion
        criterion = {
            "criterion_id": criterion_raw.criterion_id,
            "resource_name": criterion_raw.resource_name,
            "type": str(criterion_raw.type_.name).lower(),
        }
        output.append(criterion)
    return output


def query_campaign(customer_id: str, resource_name: str, manager_id: str) -> List[dict]:
    """
    Get details for a single campaign
    """
    query = f"""
    SELECT 
        campaign.end_date, 
        campaign.campaign_budget, 
        campaign.bidding_strategy, 
        campaign.bidding_strategy_type, 
        campaign.name, 
        campaign.resource_name, 
        campaign.start_date, 
        campaign.status, 
        campaign.serving_status,
        campaign.advertising_channel_sub_type, 
        campaign.advertising_channel_type
    FROM campaign 
    WHERE campaign.resource_name = '{resource_name}'
    """
    rows = run_ads_query(customer_id, query, manager_id)

    campaigns = []
    for row in rows:
        ori_status = row.campaign.status.name
        ori_serving_status = row.campaign.serving_status.name

        if (ori_status.upper() == "ENABLED") and (
            ori_serving_status.upper() == "ENDED"
        ):
            status = "ENDED"
        else:
            status = ori_status.upper()

        campaign = {
            "campaign_resource_name": row.campaign.resource_name,
            "campaign_status": status,
            "campaign_serving_status": ori_serving_status,
            "bidding_strategy_type": row.campaign.bidding_strategy_type.name,
            "campaign_name": row.campaign.name,
            "campaign_budget_resource_name": row.campaign.campaign_budget,
            "campaign_start_time": row.campaign.start_date,
            "campaign_end_time": row.campaign.end_date,
            "campaign_advertising_channel_sub_type": row.campaign.advertising_channel_sub_type.name,
            "campaign_advertising_channel_type": row.campaign.advertising_channel_type.name,
        }
        campaigns.append(campaign)

    if len(campaigns) > 1:
        raise Exception(
            f"Expecting only 1 row to be returned from google. Received {len(campaigns)} rows instead!"
        )
    campaign = campaigns[0]
    return campaign
