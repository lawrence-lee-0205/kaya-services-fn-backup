import os

from setup import setup
from common import validate_inputs
from google.gutils.bigquery import run_query
from google.campaigns.campaign import Campaign

from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount
from gsheets.gsheet import GSheet

import pandas as pd


if __name__ == "__main__":
    business_id = "82cutQRlx6gagQFMKjPa"
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    query = """
    SELECT 
        segments.week, 
        campaign.name, 
        metrics.impressions, 
        metrics.clicks, 
        metrics.search_impression_share, 
        metrics.cost_micros, 
        metrics.all_conversions, 
        metrics.conversions 
    FROM campaign 
    WHERE 
        segments.date >= '2024-01-01'
        AND segments.date <= '2024-05-28'
        AND campaign.name LIKE '%CA%Kaya%' 
    """
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )
    ads = []
    for row in rows:
        # print(row)
        ad = {
            "week": row.segments.week,
            "name": row.campaign.name,
            "impressions": row.metrics.impressions,
            "clicks": row.metrics.clicks,
            "search_impression_share": row.metrics.search_impression_share,
            "cost": row.metrics.cost_micros / 1e6,
            "all_conversions": row.metrics.all_conversions,
            "conversions": row.metrics.conversions,
        }
        ads.append(ad)
    df = pd.DataFrame(ads)

    gsheet = GSheet()
    gsheet.create(filename=f"Rippling Search Impr Share")
    gsheet.share_public(role="writer")

    pivot_tabname = "by Campaign"
    gsheet.add_tab(pivot_tabname, rows=df.shape[0])
    tab_url = gsheet.write_dataframe_to_tab(df.fillna(""), pivot_tabname)
    print(tab_url)
