import datetime
from typing import List

from firestore import FirestoreClient
from http_function import http_function
from utils.list import remove_duplicates
from google.reports.ads_api.campaigns import (
    query_campaign_budget,
    query_campaign_criteria,
    query_campaign,
    query_campaigns_for_single_ad_account,
)
from google.accounts.ads_account import GoogleAdsAccount
from google.reports.ads_api.ad_groups import query_ad_groups
from databases.firebase.get_collection import get_collection

FS = FirestoreClient()

# TODO: ADD TO CRON


def get_campaign_list_in_fs(business_id: str) -> List[str]:
    campaign_collection_name = get_collection("google", "campaigns")

    campaign_col = FS.get_collection(campaign_collection_name)
    campaign_col_ref = campaign_col.where("business_id", "==", business_id).stream()

    fs_campaign_rns = []
    for doc in campaign_col_ref:
        doc_content = doc.to_dict()
        fs_campaign_rns.append(doc_content["campaign_resource_name"])
    return fs_campaign_rns


def add_campaign_to_firestore(
    client_id: str, campaign_resource_name: str, ads_manager_id: str
) -> dict:
    ###########################################
    #     PROCESS CAMPAIGN LEVEL DETAILS      #
    ###########################################

    google_campaign_config = query_campaign(
        client_id,
        campaign_resource_name,
        ads_manager_id,
    )

    # fix campaign start and end dates
    for col in ["campaign_start_time", "campaign_end_time"]:
        google_campaign_config[col] = datetime.datetime.strptime(
            google_campaign_config[col], "%Y-%m-%d"
        )

    ###########################################
    #         PROCESS CAMPAIGN BUDGET         #
    ###########################################

    campaign_budget = {}
    if "campaign_budget" not in google_campaign_config:
        campaign_budget_rn = google_campaign_config["campaign_budget_resource_name"]
        campaign_budget = query_campaign_budget(
            client_id,
            campaign_budget_rn,
            ads_manager_id,
        )

    #####################################
    #         PROCESS AD GROUPS         #
    #####################################

    ad_groups_configs = query_ad_groups(
        client_id,
        campaign_resource_name,
        ads_manager_id,
    )

    processed_ad_groups = []
    for ad_group_rn, ad_group_content in ad_groups_configs.items():
        ag = {**ad_group_content, "id": ad_group_rn.split("/")[-1]}
        processed_ad_groups.append(ag)

    #############################################
    #         PROCESS CAMPAIGN CRITERIA         #
    #############################################

    # TODO: FIX NEGATIVE KEYWORDS
    campaign_criteria_list = query_campaign_criteria(
        client_id,
        campaign_resource_name,
        ads_manager_id,
    )

    campaign_details = {
        **google_campaign_config,
        **campaign_budget,
        "ad_groups": processed_ad_groups,
        "campaign_criteria": campaign_criteria_list,
    }
    return campaign_details


def main(business_id: str) -> None:
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    # get list of campaigns found on google
    google_campaign_records = query_campaigns_for_single_ad_account(
        google_ads_account.client_id, google_ads_account.ads_manager_id
    )

    # get list of campaigns we have on firestore
    fs_campaign_rns = get_campaign_list_in_fs(business_id)

    # get campaigns resource names that exist in Google but not in Firestore
    campaign_records_not_in_fs = [
        c
        for c in google_campaign_records
        if c["campaign_resource_name"] not in fs_campaign_rns
    ]

    print(
        f"Found {len(campaign_records_not_in_fs)} campaigns that are not in Firestore for business '{business_id}'"
    )

    for rec in campaign_records_not_in_fs:
        doc_to_add = add_campaign_to_firestore(
            google_ads_account.client_id,
            rec["campaign_resource_name"],
            google_ads_account.ads_manager_id,
        )
        doc_to_add["business_id"] = business_id
        doc_to_add["client_id"] = google_ads_account.client_id
        doc_to_add["created_at"] = datetime.datetime.utcnow()
        doc_to_add["created_by"] = "sync_bot"
        doc_to_add["updated_at"] = datetime.datetime.utcnow()
        doc_to_add["is_created_by_kaya"] = False
        FS.add_document("google_campaigns", doc_to_add)

    return None


@http_function
def execute_http(request_json={}, request_args={}):
    businesses_ref = (
        FS.get_collection("google_accounts").order_by("business_id").stream()
    )
    biz_id_list = [biz.to_dict()["business_id"] for biz in businesses_ref]
    biz_id_list = remove_duplicates(biz_id_list)
    for biz in biz_id_list:
        print("Processing ", biz)
        main(business_id=biz)
    return "Success"


if __name__ == "__main__":
    # execute_http()
    main(business_id="JPnlL37LM9m1R6QXxqq7")
