import datetime
import pytz

from constants import DATE_WITH_DASH
from firestore import FirestoreClient
from slack_tools.slack import send_notification
from google.accounts.ads_account import GoogleAdsAccount
from databases.firebase.get_collection import get_collection
from google.reports.ads_api.ad_groups import query_ad_groups
from google.reports.ads_api.campaigns import query_campaign

_SKIP_SLACK = False

_COLLECTION = get_collection("google", "campaigns")
_FS = FirestoreClient()


def main():
    """This script is used to sync latest campaign status provided by
    Google's API with our own records in Firestore, for all campaigns stored in
    Firestore. When a discrepancy is found, we'll update Firestore record and
    send slack msg (if enabled).

    Returns:
    """

    # TODO: WHAT IF FIRESTORE HAS MORE FIELDS THAN GOOOGLE

    # TODO: SHOULD ADD CRITERIA TO GET SMALLER LIST OF CAMPAIGNS
    # INSTEAD OF RUNNING FOR ALL CAMPAIGNS

    # get list of campaigns from firestore
    col = _FS.get_collection(_COLLECTION)
    fs_campaigns_ref = col.where("campaign_status", "!=", "REMOVED").stream()

    for doc in fs_campaigns_ref:
        doc_id = doc.id
        fs_campaign = doc.to_dict()

        business_id = fs_campaign["business_id"]
        google_ads_account = GoogleAdsAccount(business_id=business_id)

        print("Processing campaign ", doc_id)
        campaign_payload = _process_campaign(
            fs_campaign, google_ads_account.ads_manager_id
        )
        ad_groups_payload = _process_ad_groups(
            fs_campaign, google_ads_account.ads_manager_id
        )

        fields_to_update = {
            **campaign_payload["values_to_update"],
            **ad_groups_payload["values_to_update"],
        }
        messages = campaign_payload["logs"] + ad_groups_payload["logs"]

        if len(fields_to_update) > 0:
            _update_firestore(doc_id, fields_to_update, messages)

            if not _SKIP_SLACK:
                slack_msg = (
                    f"Running reconciliation betw Google campaign data & Firestore. Found discrepancy in campaign {doc_id}..\n"
                    + "\n".join(messages)
                )
                send_notification(text=slack_msg)

        print(f"Campaign {doc_id} completed")
        print()
    return None


def _compare_firestore_and_google(
    google: str, firestore: str, field: str, postfix: str = ""
):
    if google == firestore:
        return None
    else:
        msg = f"Updated {field} to {google}. Was {firestore}. {postfix}"
        print(msg)
        return msg


def _process_campaign(fs_campaign, manager_id):
    customer_id = fs_campaign["client_id"]
    campaign_resource_name = fs_campaign["campaign_resource_name"]

    print(f"Processing campaign level data")
    google_data = query_campaign(customer_id, campaign_resource_name, manager_id)

    messages = []
    fields_to_update = {}
    for field, value in google_data.items():
        google_value = _process_raw_value_from_google(field, value)

        # move to next field if firestore record matches google's
        msg = _compare_firestore_and_google(google_value, fs_campaign.get(field), field)
        if msg is not None:
            messages.append(msg)

            # add google's value to be updated later
            fields_to_update[field] = google_value

    if len(messages) > 0:
        output = {
            "values_to_update": fields_to_update,
            "logs": messages,
        }
    else:
        output = {"values_to_update": {}, "logs": []}
    return output


def _get_firestore_keyword_dict(resource_name, fs_keywords):
    for fs_kw in fs_keywords:
        if fs_kw["resource_name"] == resource_name:
            return fs_kw
    print(f"Keyword '{resource_name}' not found in Firestore")
    return {}


def _process_single_ad_group(fs_ad_group, google_ad_group):
    # copy data from Firestore's ad_group param
    ad_group_to_update = fs_ad_group.copy()
    messages = []

    for field, google_value in google_ad_group.items():
        # by default overwrite data from Firestore with Google's value
        ad_group_to_update[field] = google_value

        # process keyword
        if field == "keywords":
            for google_kw in google_value:
                google_kw_resource_name = google_kw["resource_name"]
                fs_kw = _get_firestore_keyword_dict(
                    google_kw_resource_name, fs_ad_group["keywords"]
                )

                for field_within_kw, google_value_within_kw in google_kw[
                    "keyword"
                ].items():
                    msg = _compare_firestore_and_google(
                        google_value_within_kw,
                        fs_kw.get("keyword", {}).get(field_within_kw),
                        field_within_kw,
                        f"Affected '{field_within_kw}' of keyword '{google_kw_resource_name}' within ad group '{google_ad_group['name']}'.",
                    )
                    if msg is not None:
                        messages.append(msg)
        else:
            # move to next field if firestore record matches google's
            msg = _compare_firestore_and_google(
                google_value,
                fs_ad_group.get(field),
                field,
                f"Affected ad group: {google_ad_group['name']}.",
            )
            if msg is not None:
                messages.append(msg)
    return ad_group_to_update, messages


def _process_ad_groups(fs_campaign, manager_id):
    # TODO: Also need to check for ad group that exists in Google but not FS
    fs_ad_groups = fs_campaign["ad_groups"]
    customer_id = fs_campaign["client_id"]
    campaign_resource_name = fs_campaign["campaign_resource_name"]

    google_ad_groups = query_ad_groups(customer_id, campaign_resource_name, manager_id)

    ad_groups_to_update = []
    messages = []
    for fs_ad_group in fs_ad_groups:
        ad_group_rn = fs_ad_group["resource_name"]

        # get ad group data stored in Google
        print("Processing ad group ", ad_group_rn)
        try:
            google_ad_group = google_ad_groups[ad_group_rn]
        except KeyError:
            raise Exception(
                f"Ad group with resource name {ad_group_rn} cannot be found in Google."
            )

        ad_group_to_update, new_messages = _process_single_ad_group(
            fs_ad_group, google_ad_group
        )

        messages += new_messages
        ad_groups_to_update.append(ad_group_to_update)

    if len(messages) > 0:
        output = {
            "values_to_update": {"ad_groups": ad_groups_to_update},
            "logs": messages,
        }
    else:
        output = {"values_to_update": {}, "logs": []}

    return output


def _update_firestore(campaign_id, fields_to_update, messages):
    print("Summary to update: ", fields_to_update)
    _FS.update_document(_COLLECTION, campaign_id, fields_to_update)

    changelogs = [
        {
            "date": datetime.datetime.utcnow(),
            "value": msg,
            "user_id": "bot",
        }
        for msg in messages
    ]
    _FS.append_list_single_document(
        "google_campaigns",
        campaign_id,
        "changelogs",
        changelogs,
    )
    return None


def _process_raw_value_from_google(field, value):
    if field not in ["campaign_start_time", "campaign_end_time"]:
        google_value = value
    else:
        # convert campaign start and end date from string to datetime
        date = datetime.datetime.strptime(value, DATE_WITH_DASH)
        google_value = datetime.datetime(
            date.year,
            date.month,
            date.day,
            0,
            0,
            0,
            tzinfo=pytz.UTC
            # TODO: DANGER: NOT NECESSARILY 00:00 UTC!!
        )
    return google_value


if __name__ == "__main__":
    main()
