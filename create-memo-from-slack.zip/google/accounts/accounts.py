import os
import datetime

from setup import setup
from firestore import FirestoreClient
from google.gutils.utilities import get_api_client
from common import validate_non_empty_string, validate_inputs
from queries import get_google_account
from constants import GOOGLE_ADS_MANAGER_ID_DEV, GOOGLE_ADS_MANAGER_ID_PROD

_DEFAULT_TRACKING_URL = "{lpurl}?campaignid={campaignid}&adgroupid={adgroupid}&keyword={keyword}&device={device}"


@setup
def create_gg_account(data: dict) -> dict:
    # process inputs
    today = datetime.date.today().strftime("%Y-%m-%d")

    mandatory_fields = ["business_id", "ccy_code", "time_zone", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    business_id = data["business_id"]
    name = data.get(
        "name", f"Account created via API on {today} for {data['business_id']}"
    )

    # check if account exists
    try:
        # if get_google_account return values, that means G Ads exist and we need to raise exception here
        _ = get_google_account(business_id)
        raise Exception("Google Ads Account already exist for business ", business_id)
    except:
        pass

    # create account in Google
    google_client_id = _create_account(
        business_id,
        name,
        data["ccy_code"],
        data["time_zone"],
        data["auth_user_id"],
        tracking_url=_DEFAULT_TRACKING_URL,
        final_url_suffix="",
    )
    return {"google_client_id": google_client_id}


def _create_account(
    business_id,
    name,
    ccy,
    time_zone,
    auth_user_id,
    tracking_url=_DEFAULT_TRACKING_URL,
    final_url_suffix="",
):
    # TODO: VALIDATE TIMEZONE

    # get ads_manager_id
    if os.environ["ENV"] in ["PROD", "LOCAL_PROD"]:
        ads_manager_id = GOOGLE_ADS_MANAGER_ID_PROD
    else:
        ads_manager_id = GOOGLE_ADS_MANAGER_ID_DEV

    # validate format of the param 'name'
    validate_non_empty_string(name, "name")

    # validate format of the param 'ccy'
    if len(ccy) != 3:
        raise ValueError(f"'ccy' should have 3 characters only. Received {ccy}")

    # INITIALISE GOOGLE ADS SERVICES
    client = get_api_client(ads_manager_id)
    customer_service = client.get_service("CustomerService")

    # CREATE CUSTOMER RECORD
    customer = client.get_type("Customer")
    customer.descriptive_name = name
    customer.currency_code = ccy
    customer.time_zone = time_zone
    customer.tracking_url_template = tracking_url
    customer.final_url_suffix = final_url_suffix

    response = customer_service.create_customer_client(
        customer_id=ads_manager_id, customer_client=customer
    )
    google_client_id = str(response.resource_name).replace("customers/", "")
    print(
        f'Customer created with resource name "{google_client_id}" '
        f'under manager account with ID "{ads_manager_id}".'
    )

    # PREPARE OUTPUT DOC FOR FIRESTORE
    # TODO: Refactor to use add_ads_account_to_firestore
    output = {
        "name": name,
        "ccy_code": ccy,
        "time_zone": time_zone,
        "ads_manager_id": ads_manager_id,
        "tracking_url": tracking_url,
        "final_url_suffix": final_url_suffix,
        "created_at": datetime.datetime.utcnow(),
        "created_by": auth_user_id,
        "client_id": google_client_id,
        "status": "ACTIVE",
        "business_id": business_id,
    }

    # INITIALISE FIRESTORE
    fs = FirestoreClient()
    fs.add_document("google_accounts", output)
    return google_client_id


if __name__ == "__main__":
    data = {
        "business_id": "test_delete",
        "name": "test",
        "ccy_code": "GBP",
        "time_zone": "Asia/Seoul",
        "auth_user_id": "test",
    }
    create_gg_account(data)
