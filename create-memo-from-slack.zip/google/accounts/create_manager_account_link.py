from os import environ
from datetime import datetime

from firestore import FirestoreClient
from setup import setup
from common import validate_inputs
from google.gutils.utilities import get_api_client
from constants import GOOGLE_ADS_MANAGER_ID_DEV, GOOGLE_ADS_MANAGER_ID_PROD

if "PROD" in environ["ENV"].upper():
    _MANAGER_ID = GOOGLE_ADS_MANAGER_ID_PROD
else:
    _MANAGER_ID = GOOGLE_ADS_MANAGER_ID_DEV

_GOOGLE_ADS_CLIENT = get_api_client(_MANAGER_ID)

_FS = FirestoreClient()
_FS_COLLECTION = "google_accounts"


@setup
def gads_create_manager_account_link(data: dict) -> dict:
    mandatory_fields = ["business_id", "google_ads_account_id", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    resp = execute(
        business_id=data["business_id"],
        google_ads_account_id=data["google_ads_account_id"],
    )
    return resp


def execute(business_id, google_ads_account_id):
    # process account ID
    google_ads_account_id = _process_google_ads_account_id(google_ads_account_id)

    # write to Firestore
    doc = {
        "business_id": business_id,
        "client_id": google_ads_account_id,
        "created_at": datetime.utcnow(),
        "created_by": "API",
    }
    if _FS.check_if_document_exist(_FS_COLLECTION, business_id):
        # if business alrd has a Google Ads account registered,
        # create a new doc with a random ID
        _FS.add_document("google_accounts", doc)
    else:
        _FS.add_document("google_accounts", doc, business_id)

    # create linking request
    _send_request(google_ads_account_id)

    return "Success"


def _process_google_ads_account_id(id: str) -> str:
    id = id.strip()
    id = id.replace("-", "")
    if not id.isdigit():
        raise Exception("Google Ads account ID must contain numbers or '-' only.")
    return id


def _send_request(google_ads_account_id: str):
    customer_client_link_service = _GOOGLE_ADS_CLIENT.get_service(
        "CustomerClientLinkService"
    )

    # Extend an invitation to the client while authenticating as the manager.
    client_link_operation = _GOOGLE_ADS_CLIENT.get_type("CustomerClientLinkOperation")
    client_link = client_link_operation.create
    client_link.client_customer = customer_client_link_service.customer_path(
        google_ads_account_id
    )
    client_link.status = _GOOGLE_ADS_CLIENT.enums.ManagerLinkStatusEnum.PENDING

    response = customer_client_link_service.mutate_customer_client_link(
        customer_id=_MANAGER_ID, operation=client_link_operation
    )
    resource_name = response.result.resource_name

    print(
        f'Extended an invitation from customer "{_MANAGER_ID}" to '
        f'customer "{google_ads_account_id}" with client link resource_name '
        f'"{resource_name}"'
    )
    return None


if __name__ == "__main__":
    # id = _process_google_ads_account_id("233-318-1635")
    # _send_request(id)

    # 233-318-1635 = dev
    execute("test", " 233-318-1635")
