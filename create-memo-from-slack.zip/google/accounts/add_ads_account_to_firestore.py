import datetime

from firestore import FirestoreClient


def main(business_id: str) -> str:
    """_summary_
    timezone: https://developers.google.com/adwords/api/docs/appendix/codes-formats#expandable-22

    Args:
        business_id (str): _description_

    Returns:
        str: _description_
    """
    output = {
        "name": "",
        "ccy_code": "USD",
        "time_zone": "America/Los_Angeles",
        "ads_manager_id": "",
        "tracking_url": "",
        "final_url_suffix": "",
        "created_at": datetime.datetime.utcnow(),
        "created_by": "",
        "client_id": "",
        "status": "ACTIVE",
        "business_id": business_id,
    }

    # INITIALISE FIRESTORE
    fs = FirestoreClient()
    doc_id = fs.add_document("google_accounts", output)

    return doc_id


if __name__ == "__main__":
    business_id = ""
    main(business_id)
