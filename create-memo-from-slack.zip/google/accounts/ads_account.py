from queries import get_google_account, get_google_account_by_client_id


class GoogleAdsAccount:
    def __init__(self, business_id: str = None, client_id: str = None) -> None:
        if (business_id is None) and (client_id is None):
            raise Exception(
                "Either business_id or client_id must be provided. Received None."
            )

        if business_id is not None:
            self._account = get_google_account(business_id)
        elif (business_id is None) and (client_id is not None):
            self._account = get_google_account_by_client_id(client_id)

    @property
    def ads_manager_id(self):
        return self._account.get("ads_manager_id", "6752450493")

    @property
    def client_id(self):
        return self._account["client_id"].replace("-", "")

    @property
    def business_id(self):
        return self._account["business_id"]

    @property
    def ccy(self):
        return self._account["ccy_code"]


if __name__ == "__main__":
    acc = GoogleAdsAccount(business_id="l7qIE5HhbKidx58tKpDB")
    print(acc._account)
    print()
    acc2 = GoogleAdsAccount(client_id="9298524019")
    print(acc2._account)
