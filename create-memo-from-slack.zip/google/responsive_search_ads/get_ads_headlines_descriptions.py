from datetime import datetime
from typing import List

from businesses.business import Business
from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount
from utils.dataframe import remove_duplicated_index_from_pivot
from gsheets.gsheet import GSheet


def main(business_id: str) -> List[dict]:
    """
    Only works for customer_id in Prod account. To run locally,
    set environment variable to LOCAL_PROD
    """
    # process ads account
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    query = """
    SELECT 
        ad_group.id, 
        ad_group.campaign, 
        campaign.name, 
        ad_group.name, 
        ad_group_ad.ad.id, 
        ad_group_ad.ad.responsive_search_ad.headlines, 
        ad_group_ad.ad.responsive_search_ad.descriptions, 
        ad_group_ad.status, 
        ad_group_ad.ad.final_urls, 
        ad_group_ad.ad_strength, 
        ad_group.status, 
        campaign.status 
    FROM ad_group_ad 
    WHERE 
        ad_group_ad.ad.type = RESPONSIVE_SEARCH_AD 
        AND ad_group_ad.status = ENABLED 
        AND campaign.name LIKE '%kaya%' 
        AND ad_group.status = 'ENABLED' 
        AND campaign.status = 'ENABLED' 
    """
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )

    ads = []
    for row in rows:
        ad_group = row.ad_group
        ad_group_ad = row.ad_group_ad
        campaign = row.campaign

        headlines = [
            {
                "text": headline.text,
                "asset_performance_label": headline.asset_performance_label.name,
                "policy_summary_review_status": headline.policy_summary_info.review_status.name,
                "policy_summary_approval_status": headline.policy_summary_info.approval_status.name,
            }
            for headline in ad_group_ad.ad.responsive_search_ad.headlines
        ]

        descriptions = [
            {
                "text": desc.text,
                "asset_performance_label": desc.asset_performance_label.name,
                "policy_summary_review_status": desc.policy_summary_info.review_status.name,
                "policy_summary_approval_status": desc.policy_summary_info.approval_status.name,
            }
            for desc in ad_group_ad.ad.responsive_search_ad.descriptions
        ]

        ad = {
            "ad_group_resource_name": ad_group.resource_name,
            "ad_group_id": ad_group.id,
            "ad_id": ad_group_ad.ad.id,
            "campaign": ad_group.campaign,
            "ad_group_name": ad_group.name,
            "ad_group_ad_resource_name": ad_group_ad.resource_name,
            "ad_group_ad_status": ad_group_ad.status.name,
            "responsive_search_ad_headlines": headlines,
            "responsive_search_ad_descriptions": descriptions,
            "campaign_name": campaign.name,
            "final_urls": (
                ad_group_ad.ad.final_urls[0]
                if len(ad_group_ad.ad.final_urls) == 1
                else ", ".join(ad_group_ad.ad.final_urls)
            ),
            "ad_strength": ad_group_ad.ad_strength.name,
        }
        ads.append(ad)
    return ads


if __name__ == "__main__":
    import pandas as pd

    business_id = "82cutQRlx6gagQFMKjPa"
    biz = Business(business_id)

    output = main(business_id)
    print(output)

    dfs_list = []
    for ag in output:
        for i, prop in enumerate(["headlines", "descriptions"], start=1):
            df = pd.DataFrame(ag["responsive_search_ad_" + prop])
            for col in [
                "ad_group_resource_name",
                "ad_group_id",
                "ad_group_ad_resource_name",
                "ad_group_ad_status",
                "ad_group_name",
                "campaign",
                "campaign_name",
                "final_urls",
                "ad_strength",
                "ad_id",
            ]:
                df[col] = ag[col]
            df["property"] = f"{i}. {prop}"
            dfs_list.append(df)

    ads_df = pd.concat(dfs_list)
    print(ads_df.head().T)

    pivoted_df = pd.pivot_table(
        ads_df,
        index=["campaign_name", "ad_group_name", "ad_id", "property", "text"],
    )
    pivoted_df = remove_duplicated_index_from_pivot(pivoted_df)

    gsheet = GSheet()
    gsheet.create(
        filename=f"{biz.name}: Google SEM Ad Copies v{datetime.today().strftime('%Y%m%d')}"
    )
    gsheet.share_public(role="writer")

    pivot_tabname = "Ad Copies by Campaign"
    gsheet.add_tab(pivot_tabname)
    tab_url = gsheet.write_dataframe_to_tab(pivoted_df.fillna(""), pivot_tabname)
    print(tab_url)

    raw_tabname = "raw"
    gsheet.add_tab(raw_tabname)
    tab_url = gsheet.write_dataframe_to_tab(ads_df, raw_tabname)
