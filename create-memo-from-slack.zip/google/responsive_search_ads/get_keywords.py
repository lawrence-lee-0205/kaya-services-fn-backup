from typing import List

from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount


def get_ad_group_keywords(business_id: str) -> List[dict]:
    """
    Only works for customer_id in Prod account. To run locally,
    set environment variable to LOCAL_PROD
    """
    # process ads account
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    query = """
    SELECT 
        ad_group.id, 
        ad_group.name, 
        ad_group.status, 
        ad_group.type, 
        ad_group.url_custom_parameters, 
        ad_group.tracking_url_template, 
        ad_group.final_url_suffix, 
        campaign.name, 
        campaign.tracking_url_template, 
        ad_group_criterion.criterion_id, 
        ad_group_criterion.keyword.match_type, 
        ad_group_criterion.keyword.text, 
        ad_group_criterion.negative, 
        ad_group_criterion.status 
    FROM ad_group_criterion 
    """
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )

    keywords = []
    for row in rows:
        ad_group = row.ad_group
        ad_group_criterion = row.ad_group_criterion
        campaign = row.campaign

        data = {
            "campaign_resource_name": campaign.resource_name,
            "campaign_name": campaign.name,
            "ad_group_resource_name": ad_group.resource_name,
            "ad_group_status": ad_group.status.name,
            "ad_group_type": ad_group.type_.name,
            "ad_group_id": ad_group.id,
            "ad_group_name": ad_group.name,
            "keyword_resource_name": ad_group_criterion.resource_name,
            "keyword_status": ad_group_criterion.status.name,
            "keyword_match_type": ad_group_criterion.keyword.match_type.name,
            "keyword_text": ad_group_criterion.keyword.text,
            "keyword_criterion_id": ad_group_criterion.criterion_id,
            "is_negative_keyword": ad_group_criterion.negative,
        }
        keywords.append(data)
    print("***")
    keywords_df = pd.DataFrame(keywords)
    return keywords_df


if __name__ == "__main__":
    import pandas as pd

    # output = main("vzsuUIgfhKRenZq6I0U5")
    output = get_ad_group_keywords("vzsuUIgfhKRenZq6I0U5")
    print(output)

    output.to_csv("keywords.csv", index=0)
