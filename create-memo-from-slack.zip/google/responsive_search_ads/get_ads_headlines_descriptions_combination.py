from typing import List

from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount
from gsheets.gsheet import GSheet

from datetime import datetime


def main(business_id: str) -> List[dict]:
    """
    Only works for customer_id in Prod account. To run locally,
    set environment variable to LOCAL_PROD
    """
    # process ads account
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    query = """
    SELECT
        ad_group_ad.ad.responsive_search_ad.headlines,
        ad_group_ad.ad.responsive_search_ad.descriptions,
        ad_group.name,
        ad_group.id,
        ad_group.status,
        ad_group_ad.ad.final_urls,
        ad_group_ad.resource_name,
        ad_group_ad.status,
        campaign.id,
        campaign.name,
        campaign.status,
        campaign.primary_status,
        metrics.impressions
    FROM ad_group_ad_asset_combination_view
    WHERE 
        ad_group_ad.ad.type = RESPONSIVE_SEARCH_AD 
        AND campaign.name LIKE '%annotation%' 
        AND segments.date >= '2024-08-24'
        AND segments.date < '2024-11-21'


    """
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )

    ads = []
    for row in rows:
        print(row)
        ad_group = row.ad_group
        ad_group_ad = row.ad_group_ad
        campaign = row.campaign

        headlines = [
            {
                "text": headline.text,
                "asset_performance_label": headline.asset_performance_label.name,
                "policy_summary_review_status": headline.policy_summary_info.review_status.name,
                "policy_summary_approval_status": headline.policy_summary_info.approval_status.name,
            }
            for headline in ad_group_ad.ad.responsive_search_ad.headlines
        ]

        descriptions = [
            {
                "text": desc.text,
                "asset_performance_label": desc.asset_performance_label.name,
                "policy_summary_review_status": desc.policy_summary_info.review_status.name,
                "policy_summary_approval_status": desc.policy_summary_info.approval_status.name,
            }
            for desc in ad_group_ad.ad.responsive_search_ad.descriptions
        ]

        ad = {
            "ad_group_resource_name": ad_group.resource_name,
            "ad_group_id": ad_group.id,
            "campaign": ad_group.campaign,
            "ad_group_name": ad_group.name,
            "ad_group_ad_resource_name": ad_group_ad.resource_name,
            "ad_group_ad_status": ad_group_ad.status.name,
            "responsive_search_ad_headlines": headlines,
            "responsive_search_ad_descriptions": descriptions,
            "campaign_name": campaign.name,
            "final_urls": (
                ad_group_ad.ad.final_urls[0]
                if len(ad_group_ad.ad.final_urls) == 1
                else ", ".join(ad_group_ad.ad.final_urls)
            ),
            "ad_strength": ad_group_ad.ad_strength.name,
            "impressions": row.metrics.impressions,
        }
        ads.append(ad)
    return ads
    # return None


def ad_metrics(business_id):
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    query = """
    SELECT 
        ad_group_ad.resource_name, 
        metrics.all_conversions, 
        metrics.clicks, 
        metrics.conversions, 
        metrics.cost_micros, 
        metrics.impressions
    FROM ad_group_ad 
    WHERE 
        ad_group_ad.ad.type = RESPONSIVE_SEARCH_AD 
        AND campaign.name LIKE '%annotation%' 
        AND segments.date >= '2024-08-24'
        AND segments.date < '2024-11-21'

    """
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )

    ads = []
    for row in rows:
        ad = {
            "ad_group_ad_resource_name": row.ad_group_ad.resource_name,
            "all_conversions": row.metrics.all_conversions,
            "clicks": row.metrics.clicks,
            "conversions": row.metrics.conversions,
            "cost_micros": row.metrics.cost_micros,
            "impressions": row.metrics.impressions,
        }
        ads.append(ad)
    return ads


if __name__ == "__main__":
    import pandas as pd

    ad_metrics_output = ad_metrics("G28ayyMdb3NpFTpmnDDx")

    output = main("G28ayyMdb3NpFTpmnDDx")
    # print(output)

    dfs_list = []
    for ag in output:
        for prop in ["headlines", "descriptions"]:
            df = pd.DataFrame(ag["responsive_search_ad_" + prop])
            for col in [
                "ad_group_resource_name",
                "ad_group_id",
                "ad_group_ad_resource_name",
                "ad_group_ad_status",
                "ad_group_name",
                "campaign",
                "campaign_name",
                "final_urls",
                "ad_strength",
                "impressions",
            ]:
                df[col] = ag[col]
            df["property"] = prop
            dfs_list.append(df)

    master_df = pd.concat(dfs_list)
    print("master_df")
    print(master_df.shape)

    ad_metrics_df = pd.DataFrame(ad_metrics_output)
    print("ad_metrics_df")
    print(ad_metrics_df.shape)
    ad_metrics_df.to_csv("ads_metrics.csv", index=0, sep="\t")

    merged_df = pd.merge(
        master_df, ad_metrics_df, on="ad_group_ad_resource_name", validate="m:1"
    )

    merged_df.to_csv("ads_metrics.csv", index=0, sep="\t")
    print("merged_df")
    print(merged_df.shape)

    gsheet = GSheet()
    gsheet.create(
        filename=f"Google SEM Ad Copies v{datetime.today().strftime('%Y%m%d')}"
    )
    gsheet.share_public(role="writer")

    pivot_tabname = "Ad Copies by Campaign"
    gsheet.add_tab(pivot_tabname, rows=merged_df.shape[0], cols=merged_df.shape[1])
    tab_url = gsheet.write_dataframe_to_tab(merged_df.fillna(""), pivot_tabname)
    print(tab_url)

    # raw_tabname = "raw"
    # gsheet.add_tab(raw_tabname)
    # tab_url = gsheet.write_dataframe_to_tab(merged_df, raw_tabname)
