from typing import List

from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount


def _get_shared_criterion_df(business_id):
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    shared_criterion_query = f"""
    SELECT 
        shared_criterion.criterion_id, 
        shared_criterion.keyword.match_type, 
        shared_criterion.keyword.text, 
        shared_criterion.shared_set, 
        shared_criterion.resource_name, 
        shared_set.resource_name 
    FROM shared_criterion
    """
    shared_criterion_rows = run_ads_query(
        google_ads_account.client_id,
        shared_criterion_query,
        google_ads_account.ads_manager_id,
    )

    shared_criterion_outputs = []
    for row in shared_criterion_rows:
        out = {
            "keyword_criterion_id": row.shared_criterion.criterion_id,
            "keyword_match_type": row.shared_criterion.keyword.match_type.name,
            "keyword_text": row.shared_criterion.keyword.text,
            "shared_criterion_shared_set": row.shared_criterion.shared_set,
            "shared_criterion_resource_name": row.shared_criterion.resource_name,
            "shared_set_resource_name": row.shared_set.resource_name,
        }
        shared_criterion_outputs.append(out)
    shared_criterion_df = pd.DataFrame(shared_criterion_outputs)
    return shared_criterion_df


def _get_shared_set_df(business_id):
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    shared_set_query = f"""
    SELECT 
        campaign_shared_set.campaign,
        campaign_shared_set.shared_set,
        campaign_shared_set.status,
        campaign.name,
        campaign.resource_name,
        shared_set.resource_name,
        shared_set.status,
        shared_set.name,
        shared_set.reference_count,
        shared_set.id, 
        shared_set.member_count, 
        campaign.id 
    FROM campaign_shared_set
    """
    shared_set_rows = run_ads_query(
        google_ads_account.client_id,
        shared_set_query,
        google_ads_account.ads_manager_id,
    )

    shared_set_outputs = []
    for row in shared_set_rows:
        out = {
            "campaign_shared_set_campaign": row.campaign_shared_set.campaign,
            "campaign_shared_set_shared_set": row.campaign_shared_set.shared_set,
            "campaign_shared_set_status": row.campaign_shared_set.status.name,
            "campaign_name": row.campaign.name,
            "campaign_resource_name": row.campaign.resource_name,
            "shared_set_resource_name": row.shared_set.resource_name,
            "shared_set_status": row.shared_set.status.name,
            "shared_set_name": row.shared_set.name,
            "shared_set_reference_count": row.shared_set.reference_count,
            "shared_set_id": row.shared_set.id,
            "shared_set_member_count": row.shared_set.member_count,
            "campaign_id": row.campaign.id,
        }
        shared_set_outputs.append(out)
    shared_set_df = pd.DataFrame(shared_set_outputs)
    return shared_set_df


def get_campaign_negative_keywords(business_id: str) -> List[dict]:
    shared_set_df = _get_shared_set_df(business_id)
    shared_criterion_df = _get_shared_criterion_df(business_id)

    campaign_negative_keywords_df = pd.merge(
        shared_criterion_df, shared_set_df, how="outer", on=["shared_set_resource_name"]
    )
    return campaign_negative_keywords_df


if __name__ == "__main__":
    import pandas as pd

    # output = main("vzsuUIgfhKRenZq6I0U5")
    output = get_campaign_negative_keywords("vzsuUIgfhKRenZq6I0U5")
    print(output)

    output.to_csv("neg_keywords.csv", index=0)
