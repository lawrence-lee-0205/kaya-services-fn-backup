import datetime
import pandas as pd
import numpy as np
import traceback
from typing import List

from google.ads.googleads.client import GoogleAdsClient

from firestore import FirestoreClient
from constants import MILLION
from queries import insert_last_google_api_timestamp
from google.gutils.utilities import queue_for_api


_TODAY_DATE = datetime.date.today()

FS = FirestoreClient()
CLIENT = GoogleAdsClient.load_from_env()


def get_historical_performance(
    keyword_plan_resource_name: str, firestore_doc_id: str = None
) -> List[dict]:
    """Given a keyword plan, get the following data from Google:
    - keyword
    - avg_monthly_searches
    - competition
    - competition_index
    - low_top_of_page_bid
    - high_top_of_page_bid
    - monthly_search_volumes
    - trend
    - l3m_avg_monthly_searches

    Args:
        keyword_plan_resource_name (str): [description]
        firestore_doc_id (str, optional): [description]. Defaults to None.

    Returns: list of dict
    """
    queue_for_api(service="keyword_plan")
    insert_last_google_api_timestamp(
        service="keyword_plan", function="generate_historical_metrics", num_operations=1
    )

    keyword_plan_service = CLIENT.get_service("KeywordPlanService")
    response = keyword_plan_service.generate_historical_metrics(
        keyword_plan=keyword_plan_resource_name
    )

    results = []
    keywords_only = []
    for historical in response.metrics:
        keyword = historical.search_query

        try:
            # Process similar keywords
            close_variants = []
            if "close_variants" in historical:
                close_variants = [cv for cv in historical.close_variants]

            metrics = historical.keyword_metrics

            # unpack monthly_search_volumes
            monthly_search_volumes = []
            if "monthly_search_volumes" in metrics:
                for msv in metrics.monthly_search_volumes:
                    month_num = int(msv.month.value) - 1
                    year = (
                        msv.year
                        if "year" in msv
                        else _fix_search_volume_year(month_num)
                    )

                    monthly_search_volumes.append(
                        {
                            "month": msv.month.name,
                            "month_num": month_num,
                            "year": year,
                            "monthly_searches": msv.monthly_searches,
                        }
                    )
                volume_df = pd.DataFrame(monthly_search_volumes)
                volume_df.sort_values(by=["year", "month_num"], inplace=True)

                trend = _calculate_trend(volume_df)
                l3m_avg = _calculate_l3m_average(volume_df)

                d = {
                    "keyword": keyword,
                    "avg_monthly_searches": metrics.avg_monthly_searches,
                    "competition": metrics.competition.name,
                    "competition_index": metrics.competition_index,
                    "low_top_of_page_bid": metrics.low_top_of_page_bid_micros / 1e6,
                    "high_top_of_page_bid": metrics.high_top_of_page_bid_micros / 1e6,
                    "monthly_search_volumes": monthly_search_volumes,
                    "trend": trend,
                    "l3m_avg_monthly_searches": l3m_avg,
                    "close_variants": close_variants,
                }
                results.append(d)
                keywords_only.append(keyword)
        except KeyError as e:
            print(
                f"Acceptable errors while processing historical metrics for keyword: {keyword}"
            )
            traceback.print_exc()

    if firestore_doc_id is not None:
        print("Updating Firestore")
        try:
            doc = {
                "history": results,
                "keywords_only": keywords_only,
                "is_in_subcollection": False,
                "created_at": datetime.datetime.utcnow(),
            }
            FS.add_document("keyword_plan_histories", doc, id=firestore_doc_id)
        except Exception as e:
            print(f"Error while writing to keyword_plan_histories")
            traceback.print_exc()

            print("Writing history to subcollection instead")
            doc = {
                "is_in_subcollection": True,
                "keywords_only": keywords_only,
                "created_at": datetime.datetime.utcnow(),
            }
            kw_idea_parent_doc = FS.add_document(
                "keyword_plan_histories", doc, id=firestore_doc_id
            )

            total_num_history = len(keywords_only)
            num_history_per_collection = 300
            for start_idx in range(0, total_num_history, num_history_per_collection):
                end_idx = start_idx + num_history_per_collection
                batched_outputs = results[start_idx:end_idx]

                FS.add_subcollection_to_document(
                    "keyword_plan_histories",
                    kw_idea_parent_doc,
                    "histories",
                    {"history": batched_outputs},
                    f"raw_{start_idx}_{end_idx-1}",
                )

    return results


def get_campaign_weekly_forecast(keyword_plan_resource_name):
    print("Generating weekly forecast")
    queue_for_api(service="keyword_plan")
    insert_last_google_api_timestamp(
        service="keyword_plan",
        function="generate_forecast_time_series",
        num_operations=1,
    )

    keyword_plan_service = CLIENT.get_service("KeywordPlanService")
    forecast_time_series_response = keyword_plan_service.generate_forecast_time_series(
        keyword_plan=keyword_plan_resource_name
    )

    if len(forecast_time_series_response.weekly_time_series_forecasts) > 1:
        raise Exception(
            f"Google GenerateForecastTimeSeriesResponse returns more than 1 forecast. Keyword plan name: {keyword_plan_resource_name}"
        )
    elif len(forecast_time_series_response.weekly_time_series_forecasts) == 0:
        raise Exception("No weekly forecast available")

    weekly_forecast_results = (
        forecast_time_series_response.weekly_time_series_forecasts[0]
    )
    wk_forecasts = weekly_forecast_results.weekly_forecasts

    weekly_forecast_output = []
    for wk in wk_forecasts:
        weekly_forecast_output.append(
            {
                "impressions": wk.forecast.impressions,
                "ctr": wk.forecast.ctr,
                "average_cpc": wk.forecast.average_cpc / MILLION,
                "clicks": wk.forecast.clicks,
                "cost": wk.forecast.cost_micros / MILLION,
                "start_date": wk.start_date,
            }
        )
    return weekly_forecast_output


def get_campaign_forecast_curve(keyword_plan_resource_name):
    print("Generating Curves")

    queue_for_api(service="keyword_plan")
    insert_last_google_api_timestamp(
        service="keyword_plan", function="generate_forecast_curve", num_operations=1
    )

    keyword_plan_service = CLIENT.get_service("KeywordPlanService")

    forecast_curve_response = keyword_plan_service.generate_forecast_curve(
        keyword_plan=keyword_plan_resource_name
    )

    print(forecast_curve_response)
    for curve in forecast_curve_response.campaign_forecast_curves:
        print("curve")
        print(curve)
        print(curve.max_cpc_bid_forecast_curve.max_cpc_bid_forecasts)
    return None


def summarise_forecast_performance(df):
    # TODO: CHECK IF STILL REQUIRED
    for col in ["avg_cpc", "clicks", "impressions"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df["cost"] = df["avg_cpc"] * df["clicks"]
    df["avg_cpm"] = MILLION * df["cost"] / df["impressions"]

    agg_metrics = {}
    for col in ["clicks", "impressions", "cost"]:
        agg_metrics["total_" + col] = df[col].sum()
    agg_metrics["avg_cpc"] = agg_metrics["total_cost"] / agg_metrics["total_clicks"]
    agg_metrics["avg_cpm"] = (
        MILLION * agg_metrics["total_cost"] / agg_metrics["total_impressions"]
    )
    return agg_metrics


###########################
#    PRIVATE FUNCTIONS    #
###########################


def _calculate_trend(volume_df):
    threshold = 0.05
    num_months = 6

    volume_df.sort_values(by=["year", "month_num"], inplace=True)

    # calculate rate of change relative to prev month
    volume_df["search_diff_rate"] = volume_df["monthly_searches"].diff() / volume_df[
        "monthly_searches"
    ].shift(1)

    # keep only the last N months
    volume_df = volume_df.iloc[-num_months:]

    # find mode of change
    masks = {
        "increase": volume_df["search_diff_rate"] > threshold,
        "decrease": volume_df["search_diff_rate"] < -threshold,
        "constant": volume_df["search_diff_rate"].between(-threshold, threshold),
    }
    for key, mask in masks.items():
        volume_df.loc[mask, "change"] = key
    change_modes = volume_df["change"].mode()

    # if there is only 1 mode and it's constant, keep it
    # else run regression
    if (change_modes.nunique() == 1) and (change_modes.values[0] == "constant"):
        trend = "constant"
    else:
        # cap values at 5th and 95th percentile
        low, high = volume_df["monthly_searches"].quantile([0.05, 0.95])
        volume_df.loc[:, "monthly_searches_clipped"] = volume_df[
            "monthly_searches"
        ].clip(low, high)

        # calculate gradient
        l6m_values = volume_df["monthly_searches_clipped"].tolist()
        avg = np.mean(l6m_values)
        m = np.polyfit(range(num_months), l6m_values, 1)[0]

        # if average search volume is small,
        # return unspecified trend to avoid division by zero
        if avg < 0.1:
            return "unspecified"

        gradient_relative_avg = m / avg
        if gradient_relative_avg < -threshold:
            trend = "decrease"
        elif gradient_relative_avg > threshold:
            trend = "increase"
        else:
            trend = "constant"
    return trend


def _calculate_l3m_average(volume_df):
    this_year = datetime.datetime.today().year
    this_month = datetime.datetime.today().month

    # calculate last 3 months average
    l3m_avg_monthly_searches = volume_df.loc[
        (volume_df["year"] == this_year) & (volume_df["month_num"] >= this_month - 4),
        "monthly_searches",
    ].mean()
    return l3m_avg_monthly_searches


def _fix_search_volume_year(month_num: int) -> int:
    """Return year for historical search volume data.
    Create a new date based on the 1st of current year and provided month. If this date
    is in the future, return last year's value.

    Args:
        month_num (int):

    Returns:
        int: year
    """
    print(f"in here: {month_num}")
    this_year = _TODAY_DATE.year

    if datetime.date(this_year, month_num, 1) >= _TODAY_DATE:
        year = this_year - 1
    else:
        year = this_year
    return int(year)


if __name__ == "__main__":
    pass
