import datetime
import pandas as pd
from typing import List
from pulp import LpProblem, LpVariable, lpSum, LpMaximize

from firestore import FirestoreClient
from common import validate_inputs
from setup import setup

_DEFAULT_CAMPAIGN_GOAL = "MAXIMISE_CLICK"
_GOALS_MAPPING = {
    "MAXIMISE_CLICK": "clicks",
    "MAXIMISE_IMPRESSION": "impressions",
    "MAXIMISE_CONVERSION": "conversion",
}
_DEFAULT_LIMIT_RESULT = 50
_COLS_TO_RETURN = [
    "keyword",
    "avg_monthly_searches",
    "competition",
    "low_top_of_page_bid",
    "high_top_of_page_bid",
    "trend",
    "l3m_avg_monthly_searches",
    "clicks",
    "impressions",
    "avg_cpc",
    "ctr",
    "recommended_max_bid",
    "est_cost",
    "cpa",
    "conversion",
    "intent",
    "is_recommended",
    "portion",
    "is_budget_limited",
    "is_user_provided",
    "revenue",
    "roi",
]

FS = FirestoreClient()


@setup
def recommend_keywords(data):
    mandatory_inputs = ["business_id", "google_session_id", "campaign_budget"]
    validate_inputs(data, mandatory_inputs)

    budget = data["campaign_budget"]
    if not isinstance(budget, float):
        budget = float(budget)

    preselect_keywords = data.get("preselect_keywords", [])

    #######################
    #    PROCESS INPUT    #
    #######################

    google_session_id = data["google_session_id"]
    session_input = _get_input_from_session(google_session_id)
    keywords_in_scope_df = session_input["keywords_in_scope_df"]
    avg_annual_revenue_per_user = session_input["avg_annual_revenue_per_user"]
    seed_keywords = session_input["seed_keywords"]
    ccy = session_input["ccy"]

    ######################
    #    PROCESS GOAL    #
    ######################

    campaign_goal = data.get("campaign_goal", _DEFAULT_CAMPAIGN_GOAL)
    _validate_campaign_goal(campaign_goal)
    col_to_maximise = _GOALS_MAPPING[campaign_goal]

    if campaign_goal == "MAXIMISE_CONVERSION":
        min_clicks_for_one_conversion = 1 / session_input["conversion_rate"]
        print(
            f"Shape before removing rows where num_clicks below {min_clicks_for_one_conversion}: {keywords_in_scope_df.shape}"
        )

        keywords_in_scope_df = keywords_in_scope_df[
            (keywords_in_scope_df["clicks"] >= min_clicks_for_one_conversion)
            & (keywords_in_scope_df["recommended_max_bid"] > 0)
        ]

    keywords_in_scope_df = _drop_na_rows(keywords_in_scope_df, [col_to_maximise])

    ##################
    #    OPTIMISE    #
    ##################
    budget_multipliers = [0.5, 1, 1.5]

    optimised_dfs = {}
    goals_by_budget = {}
    for m in budget_multipliers:
        budget_mul = budget * m
        kw_optimised_df = _run_optimisation(
            keywords_in_scope_df, budget_mul, col_to_maximise, preselect_keywords
        )
        goals_by_budget[budget_mul] = _sum_goal(kw_optimised_df, col_to_maximise)
        optimised_dfs[budget_mul] = kw_optimised_df

    all_keywords_to_review = optimised_dfs[budget].copy()

    ##############################
    #    CALCULATE FINANCIALS    #
    ##############################

    all_keywords_to_review = _calculate_revenue(
        all_keywords_to_review, avg_annual_revenue_per_user
    )
    all_keywords_to_review = _calculate_roi(all_keywords_to_review)
    all_keywords_to_review = _label_budget_limited_cols(all_keywords_to_review)

    ###############################
    #    PROCESS SEED KEYWORDS    #
    ###############################

    keywords_user_provided_without_metrics = _get_seed_keywords_without_metrics(
        all_keywords_to_review, seed_keywords
    )
    all_keywords_to_review = _label_user_provided_keywords(
        all_keywords_to_review, seed_keywords
    )

    ########################
    #    RETURN RESULTS    #
    ########################

    # restructure
    goals_by_budget_list = [
        {"budget": budget, "goal": goal} for budget, goal in goals_by_budget.items()
    ]

    output_json = _get_output_json(all_keywords_to_review, col_to_maximise)
    output = {
        "ccy": ccy,
        "keywords": output_json,
        "user_provided_keywords_to_reject": keywords_user_provided_without_metrics,
        "goals_by_budget": goals_by_budget_list,
    }

    ################################
    #      WRITE TO FIRESTORE      #
    ################################

    # add new doc to recommendations subcollection
    recommendation_doc = {
        **output,
        "created_at": datetime.datetime.utcnow(),
        "keywords_in_scope_id": session_input["latest_keywords_in_scope_id"],
    }
    recommendation_id = FS.add_subcollection_to_document(
        "google_sessions",
        google_session_id,
        "recommendations",
        recommendation_doc,
    )

    # update main session doc
    FS.update_document(
        "google_sessions",
        google_session_id,
        {
            "campaign_budget": budget,
            "preselect_keywords": preselect_keywords,
            "latest_recommendation_id": recommendation_id,
            "updated_at": datetime.datetime.utcnow(),
        },
    )

    print(goals_by_budget)

    return output


# ----------- PRIVATE FUNCTIONS ----------- #


def _get_output_json(df: pd.DataFrame, col_to_maximise) -> dict:
    """Return at least 50 results.
    If num of recommended keywords exceed 50, return 1.2 x num_recommended results
    so users always have options to see more keywords

    Args:
        all_keywords_to_review (pd.DataFrame): raw data
        col_to_maximise (str): metric we want to maximise

    Returns: dict
    """

    num_recommended = df[df["is_recommended"]].shape[0]
    limit_num_results = int(max(_DEFAULT_LIMIT_RESULT, num_recommended * 1.2))

    output_json = (
        df[_COLS_TO_RETURN]
        .sort_values(by=["is_recommended", col_to_maximise], ascending=False)
        .head(limit_num_results)
        .to_dict(orient="records")
    )
    return output_json


def _run_optimisation(
    keywords_df: pd.DataFrame,
    budget_limit: float,
    col_to_maximise: str,
    preselect_keywords: list = [],
) -> pd.DataFrame:
    df = keywords_df.copy()

    optimised_df = _optimise(df, budget_limit, col_to_maximise, preselect_keywords)
    optimised_df = _process_recommended_keywords(optimised_df)
    optimised_df = _deduplicate(optimised_df)
    _print_summary(optimised_df, col_to_maximise)
    return optimised_df


def _optimise(
    keywords_df: pd.DataFrame,
    budget_limit: float,
    col_to_maximise: str,
    preselect_keywords: list = [],
) -> pd.DataFrame:
    """Given a budget, find the combination of keywords that maximises target metrics

    Resources:
    https://bit.ly/3kSmjrI
    https://bit.ly/3oIfASr

    Args:
        keywords_df (pd.DataFrame): [description]
        budget_limit (int): [description]

    Returns:
        pd.DataFrame: dataframe with new col is_recommended
    """
    prob = LpProblem("Maximise_" + col_to_maximise, LpMaximize)

    len_preselect_keywords = len(preselect_keywords)
    keywords_df["keyword_id"] = keywords_df["keyword"].str.replace(" ", "_")

    if len_preselect_keywords > 0:
        # if preselect keywords are provided, each of them needs to have non 0 portion
        df_to_optimise = keywords_df[keywords_df["keyword"].isin(preselect_keywords)]
        if df_to_optimise.shape[0] == 0:
            raise Exception(
                "Keywords provided could not be found: {preselect_keywords}"
            )
        keyword_vars = LpVariable.dicts("keyword", df_to_optimise["keyword_id"], 0.1, 1)
    else:
        df_to_optimise = keywords_df.copy()
        keyword_vars = LpVariable.dicts("keyword", df_to_optimise["keyword_id"], 0, 1)

    print("Num of keywords to optimise: ", df_to_optimise.shape[0])

    # objective function
    prob += lpSum(
        [
            goal * keyword_vars[kw]
            for kw, goal in zip(
                df_to_optimise["keyword_id"], df_to_optimise[col_to_maximise]
            )
        ]
    )

    # constraint
    prob += (
        lpSum(
            [
                est_cost * keyword_vars[kw]
                for kw, est_cost in zip(
                    df_to_optimise["keyword_id"], df_to_optimise["cost"]
                )
            ]
        )
        <= budget_limit
    )

    if len_preselect_keywords == 0:
        cut_off_goal = df_to_optimise[col_to_maximise].quantile(0.75)

        keywords_above_cut_off = df_to_optimise.loc[
            df_to_optimise[col_to_maximise] > cut_off_goal, "keyword_id"
        ].tolist()

        for keyword_id in keywords_above_cut_off:
            prob += keyword_vars[keyword_id] >= 0.001

    # get list of keywords to return
    if prob.solve() == 1:
        keyword_id_portions = {
            v.name.replace("keyword_", ""): v.varValue for v in prob.variables()
        }
    else:
        keyword_id_portions = {}

    keywords_df["portion"] = keywords_df["keyword_id"].map(keyword_id_portions)
    keywords_df["portion"].fillna(0, inplace=True)

    # calc final goal in proportion with assigned budget
    keywords_df["proportionate_goal"] = (
        keywords_df["portion"] * keywords_df[col_to_maximise]
    )

    return keywords_df


def _process_recommended_keywords(df):
    # label recommended keywords
    recommended_keywords_filter = df["proportionate_goal"] >= 1
    df.loc[recommended_keywords_filter, "is_recommended"] = True
    df["is_recommended"].fillna(False, inplace=True)

    # scale metrics
    for col in ["clicks", "impressions", "conversion"]:
        df[col + "_full"] = df[col]

        df.loc[recommended_keywords_filter, col] = (
            df.loc[recommended_keywords_filter, col]
            * df.loc[recommended_keywords_filter, "portion"]
        ).astype(int)

    # create est_cost col
    df["est_cost"] = df["cost"].copy()
    df.loc[recommended_keywords_filter, "est_cost"] = (
        df.loc[recommended_keywords_filter, "cost"]
        * df.loc[recommended_keywords_filter, "portion"]
    )
    # df.to_csv(f"df_{df[recommended_keywords_filter].shape[0]}.csv", index=0)
    return df


def _sum_goal(df, col_to_maximise):
    if "is_recommended" not in df.columns:
        raise ValueError("Expecting is_recommended col in the dataframe!")

    return df.loc[df["is_recommended"] == True, col_to_maximise].sum()


def _deduplicate(df):
    df = df.sort_values(
        by=["keyword", "is_recommended", "recommended_max_bid"],
        ascending=[True, False, True],
    ).drop_duplicates(subset=["keyword"], keep="first")
    return df


def _print_summary(df, col_to_maximise):
    recommended_df = df[df["is_recommended"]]

    print(
        f"""
    ------
    Total cost: {recommended_df['est_cost'].sum():.2f}
    Goal ({col_to_maximise}): {recommended_df[col_to_maximise].sum():.0f}
    
    Recommend {recommended_df.shape[0]} out of {df.shape[0]} keywords
    
    {recommended_df['keyword'].unique()}
    ------
    """
    )
    return None


def _get_seed_keywords_without_metrics(df, seed_keywords):
    keywords_with_metrics = df["keyword"].to_list()
    keywords_user_provided_without_metrics = [
        kw for kw in seed_keywords if kw not in keywords_with_metrics
    ]
    print(
        f"Keywords provided by users but don't have any metric: {keywords_user_provided_without_metrics}"
    )
    return keywords_user_provided_without_metrics


def _label_user_provided_keywords(
    df: pd.DataFrame, seed_keywords: List[str]
) -> pd.DataFrame:
    df.loc[df["keyword"].isin(seed_keywords), "is_user_provided"] = True
    df["is_user_provided"].fillna(False, inplace=True)
    return df


def _calculate_revenue(df, avg_annual_revenue_per_user):
    df["revenue"] = df["conversion"] * avg_annual_revenue_per_user
    return df


def _calculate_roi(df):
    df["roi"] = df["revenue"] / df["est_cost"]
    return df


def _label_budget_limited_cols(df):
    """Keywords that are recommended but have portion < 1 are budget limited"""
    filter_ = (df["portion"] < 1) & (df["is_recommended"])

    df.loc[filter_, "is_budget_limited"] = True
    df["is_budget_limited"].fillna(False, inplace=True)
    return df


def _drop_na_rows(df: pd.DataFrame, based_on_cols: list) -> pd.DataFrame:
    print(f"Shape before removing rows where {based_on_cols} are NA: {df.shape}")
    df.dropna(subset=based_on_cols, inplace=True)
    print(f"Shape after: {df.shape}")
    return df


def _get_input_from_session(google_session_id: str) -> dict:
    """Extract required inputs from session doc of the given ID

    Args:
        google_session_id (str): doc ID of google_sessions collection

    Returns:
        dict: [description]
    """
    session_doc = FS.get_single_document("google_sessions", google_session_id)

    # get latest keywords that are in scope
    latest_keywords_in_scope_id = session_doc["latest_keywords_in_scope_id"]
    keywords_in_scope = FS.get_single_document(
        ["google_sessions", "keywords_in_scope"],
        [google_session_id, latest_keywords_in_scope_id],
    )
    keywords_in_scope_df = pd.DataFrame(keywords_in_scope["keywords"])

    input = {
        "latest_keywords_in_scope_id": latest_keywords_in_scope_id,
        "keywords_in_scope_df": keywords_in_scope_df,
        "conversion_rate": session_doc["conversion_rate"],
        "avg_annual_revenue_per_user": session_doc["avg_annual_revenue_per_user"],
        "seed_keywords": session_doc.get("seed_keywords", []),
        "ccy": session_doc["ccy"],
    }
    return input


def _validate_campaign_goal(campaign_goal):
    if campaign_goal not in _GOALS_MAPPING.keys():
        raise Exception(
            f"campaign_goal provided ({campaign_goal}) is not accepted. Only accepts {list(_GOALS_MAPPING.keys())}"
        )


if __name__ == "__main__":
    data = {
        "google_session_id": "2zxBVT1Kf0Mh8d0mD2gM",
        "business_id": "HEqx0JkrNrkHHHlw9B4R",
        "campaign_goal": _DEFAULT_CAMPAIGN_GOAL,
        "campaign_budget": 5000,
        "preselect_keywords": [
            "best insurance for cats",
            "dog insurance quotes",
            "pet plan insurance",
            "pet insurance affordable",
            "pet insurance plans",
            "best dog insurance",
            "insurance online quote",
            "pet insurance reviews",
            "medical insurance policy for family",
            "pet insurance for cats",
        ],
    }
    recommend_keywords(data)
