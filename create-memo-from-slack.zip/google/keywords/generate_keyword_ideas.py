import os
import datetime
import pandas as pd
from typing import List

from setup import setup
from google.keyword_planner.utils_keywords import (
    map_locations_ids_to_resource_names,
    map_language_ids_to_resource_names,
)
from common import (
    get_unique_list_of_dict,
    validate_inputs,
    validate_non_empty_string,
)
from constants import POSTFIX_TERMS, PREFIX_TERMS
from firestore import FirestoreClient
from queries import (
    insert_last_google_api_timestamp,
    get_google_account,
    get_criteria_id_by_country_code,
)
from nlp.utils import is_substring_exists
from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.utilities import queue_for_api, get_api_client
from google.keywords.classify_intent import classify_intent
from google.serp.serp import get_related_searches_by_keywords


_MIN_NUM_MONTHLY_SEARCHES = 10
_SOFT_LIMIT_KEYWORD_SUGGESTIONS = 1000 if os.environ["ENV"] == "PROD" else 500
_HARD_LIMIT_KEYWORD_SUGGESTIONS = 300 if os.environ["ENV"] == "PROD" else 120

_KEYWORD_IDEA_COLLECTION = "keyword_ideas"
_KEYWORD_IDEA_SUBCOLLECTION = "keywords"

_HIGH_INTENT_CATEGORIES = ["transactional", "commercial"]

_DEFAULT_KEYWORD_PLAN_NETWORK = "GOOGLE_SEARCH_AND_PARTNERS"


@setup
def main(data: dict) -> dict:
    """Cloud function wrapper for generate_keyword_ideas. Get keyword ideas
    from google_search_hints collection.

    Mandatory fields within 'data':
    - business_id,
    - google_session_id
    - either keywords, page_urls or both
    - customer_url
    - negative_keywords

    Returns:
        dict: [description]
    """
    # TODO: CURRENTLY DISREGARD AUDIENCE ID, SHOULD WE DO SOMETHING?

    mandatory_fields = ["business_id"]
    validate_inputs(data, mandatory_fields)
    validate_non_empty_string(data["business_id"], "business_id")

    business_id = data["business_id"]

    fs = FirestoreClient()
    # get keyword ideas from google_search_hints collection.
    try:
        print("Getting keyword ideas from google_search_hints collection")
        hints = fs.get_single_document("google_search_hints", business_id)
        kw_ideas = hints.get("keyword_ideas", [])
    except ValueError:
        print(
            f"No document found in google_search_hints collection for business '{business_id}'"
        )
        kw_ideas = []
        pass

    # if keyword ideas not available, generate on the go
    if len(kw_ideas) == 0:
        print(
            "0 keyword ideas provided in google_search_hints collection. Regenerating new list.."
        )
        business_doc = fs.get_single_document("businesses", business_id)

        google_account = get_google_account(data["business_id"])
        client_id = google_account["client_id"]

        url = business_doc["url"]
        country_code = business_doc["country"]

        kw_ideas = add_keyword_ideas_as_hints(business_id, url, client_id, country_code)

    output = {"keywords": kw_ideas[:50]}
    return output


def add_keyword_ideas_as_hints(
    business_id: str, url: str, client_id: str, country_code: str
) -> list:
    """Every time a business account is created, generate Google keyword ideas

    Args:
        business_id (str): [description]
        url (str): [description]
        client_id (str): [description]
        country_code (str): [description]

    Returns:
        list: [description]
    """

    # TODO: GET IT FROM LANGUAGE SETTING?
    incl_languages = ["1000"]
    incl_locations = [get_criteria_id_by_country_code(country_code)]

    keyword_suggestions = _generate_keyword_ideas_from_url(
        customer_id=client_id,
        url=url,
        incl_location_ids=incl_locations,
        incl_language_ids=incl_languages,
    )

    print(f"Num of raw keyword_suggestions: ", len(keyword_suggestions))

    if len(keyword_suggestions) > 0:
        keyword_suggestions_df = pd.DataFrame(keyword_suggestions)
        keyword_suggestions_df.drop_duplicates(subset=["idea_text"], inplace=True)
        keyword_suggestions_df.sort_values(
            by=["avg_monthly_searches"], ascending=False, inplace=True
        )
        print(f"Total num of keywords in scope: {keyword_suggestions_df.shape[0]}")

        # TODO: SORT COMPETITION VALUE
        # ['MEDIUM' 'LOW' 'HIGH' 'UNSPECIFIED']
        keyword_ideas = keyword_suggestions_df["idea_text"].to_list()

        # Write to google_search_hints collection
        fs = FirestoreClient()
        is_doc_exist = fs.check_if_document_exist("google_search_hints", business_id)
        if is_doc_exist:
            fs.update_document(
                "google_search_hints", business_id, {"keyword_ideas": keyword_ideas}
            )
        else:
            fs.add_document(
                "google_search_hints",
                {
                    "keyword_ideas": keyword_ideas,
                    "created_at": datetime.datetime.utcnow(),
                },
                business_id,
            )
    else:
        keyword_ideas = []
    return keyword_ideas


def generate_keyword_ideas(
    google_session_id,
    customer_id,
    incl_location_ids=[],
    incl_language_ids=[],
    keywords=[],
    customer_url="",
    page_urls=[],
    negative_keywords=[],
    exclude_branded_keywords=False,
):
    keyword_ideas_df = _generate_keyword_ideas(
        customer_id,
        incl_location_ids,
        incl_language_ids,
        keywords,
        customer_url,
        page_urls,
        negative_keywords,
        exclude_branded_keywords,
    )
    keyword_ideas = keyword_ideas_df["idea_text"].to_list()

    fs = FirestoreClient()
    keyword_ideas_doc = {"keywords": keyword_ideas_df.to_dict("records")}

    keyword_ideas_doc_id = fs.add_subcollection_to_document(
        "google_sessions",
        google_session_id,
        "keyword_ideas",
        keyword_ideas_doc,
    )
    return {"keywords": keyword_ideas, "keyword_ideas_doc_id": keyword_ideas_doc_id}


def _generate_keyword_ideas(
    customer_id,
    incl_location_ids=[],
    incl_language_ids=[],
    keywords=[],
    customer_url="",
    page_urls=[],
    negative_keywords=[],
    exclude_branded_keywords=False,
):
    if len(keywords) == 0 and len(page_urls) == 0:
        raise Exception(
            "At least one of keywords or page URLs is required, "
            "but neither was specified."
        )

    ###################################
    #  GET KEYWORD IDEAS FROM GOOGLE  #
    ###################################

    keyword_suggestions_from_seed = []
    if len(keywords) > 0:
        # trend_keywords = get_related_queries(keywords, incl_location_ids)
        # TODO: IF WE ARE ADDING TREND KEYWORDS, NEED TO CHECK KEYWORD LENGTH

        # get keywords from SERP (limit to 5 keywords only)
        related_searches = []
        if len(keywords) < 5:
            related_searches = get_related_searches_by_keywords(
                keywords[:5], incl_location_ids
            )
            print(f"List of related searches: {len(related_searches)}")

        full_keywords = list(set(related_searches + keywords))

        keyword_suggestions_from_seed += (
            _generate_keyword_ideas_from_seed_keywords_and_url(
                customer_id=customer_id,
                customer_url=customer_url,
                keywords=full_keywords,
                incl_location_ids=incl_location_ids,
                incl_language_ids=incl_language_ids,
            )
        )
    keyword_suggestions_from_seed_df = pd.DataFrame(keyword_suggestions_from_seed)
    keyword_suggestions_from_seed_df["source"] = "seed"

    keyword_suggestions_from_url = []
    for url in page_urls:
        # generate keyword ideas based on URL
        keyword_suggestions_from_url += _generate_keyword_ideas_from_url(
            customer_id=customer_id,
            url=url,
            incl_location_ids=incl_location_ids,
            incl_language_ids=incl_language_ids,
        )
    keyword_suggestions_from_url_df = pd.DataFrame(keyword_suggestions_from_url)
    keyword_suggestions_from_url_df["source"] = "url"

    keyword_suggestions_df = pd.concat(
        [keyword_suggestions_from_seed_df, keyword_suggestions_from_url_df]
    )
    keyword_suggestions_df.drop_duplicates(subset=["idea_text"], inplace=True)
    print(f"Total num of keywords in scope: {keyword_suggestions_df.shape[0]}")

    if "intent" not in keyword_suggestions_df.columns:
        keyword_suggestions_df["intent"] = None

    #####################################
    #  KEEP KEYWORDS PROVIDED BY USERS  #
    #####################################
    filter_kw_by_users = keyword_suggestions_df["idea_text"].isin(keywords)
    keyword_suggestions_df.loc[filter_kw_by_users, "is_user_provided"] = True

    # keywords_by_user_df = keyword_suggestions_df[filter_kw_by_users]
    # keyword_suggestions_df = keyword_suggestions_df[~filter_kw_by_users]

    ################################
    #  FILTER BY MIN NUM SEARCHES  #
    ################################
    # print(
    #     f"Shape before removing keywords where avg_monthly_searches < {_MIN_NUM_MONTHLY_SEARCHES}: {keyword_suggestions_df.shape} and are not high intent keywords"
    # )
    # filter_min_search_or_intent = (
    #     keyword_suggestions_df["avg_monthly_searches"] >= _MIN_NUM_MONTHLY_SEARCHES
    # ) | (keyword_suggestions_df["intent"].isin(_HIGH_INTENT_CATEGORIES))

    # keyword_suggestions_df = keyword_suggestions_df[filter_min_search_or_intent]

    ##############################
    #  REMOVE BRANDED KEYWORDS  #
    ##############################
    # if exclude_branded_keywords:
    #     print(f"Shape before removing branded keywords: {keyword_suggestions_df.shape}")
    #     keyword_suggestions_df = keyword_suggestions_df[
    #         keyword_suggestions_df["is_branded"] == False
    #     ]

    ##############################
    #  REMOVE NEGATIVE KEYWORDS  #
    ##############################

    if len(negative_keywords) > 0:
        print(
            f"Shape before removing negative keywords: {keyword_suggestions_df.shape}"
        )
        print(f"Removing negative keywords: {negative_keywords}")
        keyword_suggestions_df["has_negative_word"] = keyword_suggestions_df[
            "idea_text"
        ].apply(
            lambda idea_text: any(
                is_substring_exists(negative_kw, idea_text)
                for negative_kw in negative_keywords
            )
        )
        keyword_suggestions_df = keyword_suggestions_df[
            ~keyword_suggestions_df["has_negative_word"]
        ]
    return keyword_suggestions_df

    ######################################
    #   KEEP KEYWORDS WITH HIGH INTENT   #
    ######################################
    filter_high_intent_kw = keyword_suggestions_df["intent"].isin(
        _HIGH_INTENT_CATEGORIES
    )

    high_intent_keywords_df = keyword_suggestions_df[filter_high_intent_kw]
    keyword_suggestions_df = keyword_suggestions_df[~filter_high_intent_kw]

    ######################################
    #  LIMIT NUM OF KEYWORD SUGGESTIONS  #
    ######################################
    keyword_suggestions_df.sort_values(
        by="avg_monthly_searches", ascending=False, inplace=True
    )
    print("Shape: ", keyword_suggestions_df.shape)
    keyword_suggestions_df = keyword_suggestions_df.head(
        _SOFT_LIMIT_KEYWORD_SUGGESTIONS
    )

    ############################################################
    #  COMBINE FILTERED KEYWORDS WITH THOSE PROVIDED BY USERS  #
    ############################################################

    keywords_df = pd.concat(
        [keywords_by_user_df, keyword_suggestions_df, high_intent_keywords_df]
    )
    keywords_df.sort_values(by=["avg_monthly_searches"], ascending=False, inplace=True)
    keywords_df.drop_duplicates(subset=["idea_text"], inplace=True)
    keywords_df = keywords_df.head(_HARD_LIMIT_KEYWORD_SUGGESTIONS)

    num_keyword_ideas = keywords_df.shape[0]
    if num_keyword_ideas == 0:
        raise Exception(
            "No keyword suggestions available. Please try again by providing more URL or keyword seeds."
        )

    print(f"Total num of keywords in scope after filtering: {num_keyword_ideas}")

    return keywords_df


def _generate_keywords_ideas_from_google(
    customer_id,
    page_url,
    keyword_texts,
    incl_location_ids=[],
    incl_language_ids=[],
    include_adult_keywords=False,
):
    """
    For the URL of a webpage or entire website related to your business, use UrlSeed.
    The URL seed targets only a specific URL. If there are no hits, the search automatically
    expands up to the pages from the same domain.

    For an entire site, use SiteSeed. Given a top-level domain name, such as www.example.com,
    the site seed generates up to 250,000 keyword ideas from publicly available information.
    """
    print("Generating keyword ideas from Google API")

    queue_for_api(service="keyword_plan_idea")
    insert_last_google_api_timestamp(
        service="keyword_plan_idea", function="generate_keyword_ideas"
    )

    # initiate google client
    ads_account = GoogleAdsAccount(client_id=customer_id)
    client = get_api_client(manager_id=ads_account.ads_manager_id)

    keyword_plan_idea_service = client.get_service("KeywordPlanIdeaService")
    # TODO: MAKE THIS AN INPUT
    keyword_plan_network = client.enums.KeywordPlanNetworkEnum[
        _DEFAULT_KEYWORD_PLAN_NETWORK
    ]
    keyword_annotation = client.enums.KeywordPlanKeywordAnnotationEnum

    # Either keywords or a page_url are required to generate keyword ideas
    # so this raises an error if neither are provided.
    if not (keyword_texts or page_url):
        raise ValueError(
            "At least one of keywords or page URL is required, "
            "but neither was specified."
        )

    if len(keyword_texts) > 20:
        raise Exception("Too many keywords: at most 20 keywords can be set")

    # Only one of the fields "url_seed", "keyword_seed", or
    # "keyword_and_url_seed" can be set on the request, depending on whether
    # keywords, a page_url or both were passed to this function.
    kw_request = client.get_type("GenerateKeywordIdeasRequest")
    kw_request.customer_id = customer_id
    kw_request.include_adult_keywords = include_adult_keywords
    kw_request.keyword_plan_network = keyword_plan_network
    kw_request.keyword_annotation = keyword_annotation

    if len(incl_location_ids) > 0:
        print("Mapping location ids to resourc name for ", incl_location_ids)
        location_rns = map_locations_ids_to_resource_names(incl_location_ids)
        kw_request.geo_target_constants = location_rns
        print("location_rns: ", location_rns)

    if len(incl_language_ids) > 0:
        print("Mapping location ids to resourc name for ", incl_language_ids)
        language_rn = map_language_ids_to_resource_names(incl_language_ids)
        kw_request.language = language_rn[0]  # TODO: ONLY ACCEPT 1 LANGUAGE
        print("language_rn: ", language_rn[0])

    # To generate keyword ideas with only a page_url and no keywords we need
    # to first check if the URL is top level domain page or subpage.
    # If top page, use site_seed. Else url_seed
    if not keyword_texts and page_url:
        url_type = _get_url_type(page_url)
        if url_type == "site":
            kw_request.site_seed.site = page_url
        else:
            kw_request.url_seed.url = page_url

    # To generate keyword ideas with only a list of keywords and no page_url
    # we need to initialize a KeywordSeed object and set the "keywords" field
    # to be a list of StringValue objects.
    if keyword_texts and not page_url:
        kw_request.keyword_seed.keywords.extend(keyword_texts)

    # To generate keyword ideas using both a list of keywords and a page_url we
    # need to initialize a KeywordAndUrlSeed object, setting both the "url" and
    # "keywords" fields.
    if keyword_texts and page_url:
        kw_request.keyword_and_url_seed.url = page_url
        kw_request.keyword_and_url_seed.keywords.extend(keyword_texts)

    keyword_ideas = keyword_plan_idea_service.generate_keyword_ideas(request=kw_request)

    outputs = []
    for idea in keyword_ideas:
        print(idea)
        print("^^^^^")
        concepts = []
        is_branded = False
        if len(idea.keyword_annotations.concepts) > 0:
            for concept in idea.keyword_annotations.concepts:
                if concept.concept_group.type_.name in ["BRAND", "OTHER_BRANDS"]:
                    is_branded = True

                concepts.append(
                    {
                        "name": concept.name,
                        "group_name": concept.concept_group.name,
                        "group_type": concept.concept_group.type_.name,
                        "group_raw": concept.concept_group,
                    }
                )
        text = idea.text
        competition_value = idea.keyword_idea_metrics.competition.name
        d = {
            "idea_text": text,
            "avg_monthly_searches": idea.keyword_idea_metrics.avg_monthly_searches,
            "competition_value": competition_value,
            "is_user_provided": text in keyword_texts,
            "keyword_annotations": str(concepts),
            "is_branded": is_branded,
            "intent": classify_intent(text),
        }
        outputs.append(d)

    # SAVE TO FIRESTORE
    num_keyword_ideas = len(outputs)
    num_ideas_per_subcollection = 800

    fs = FirestoreClient()
    doc = {
        "customer_id": customer_id,
        "url": page_url,
        "seed_keyword": keyword_texts,
        "incl_location_ids": incl_location_ids,
        "incl_language_ids": incl_language_ids,
        "include_adult_keywords": include_adult_keywords,
        "num_keywords_ideas": num_keyword_ideas,
        "num_keyword_ideas_per_subcollection": num_ideas_per_subcollection,
        "created_at": datetime.datetime.utcnow(),
    }
    kw_idea_parent_doc = fs.add_document(_KEYWORD_IDEA_COLLECTION, doc)

    for start_idx in range(0, num_keyword_ideas, num_ideas_per_subcollection):
        end_idx = start_idx + num_ideas_per_subcollection
        batched_outputs = outputs[start_idx:end_idx]

        fs.add_subcollection_to_document(
            _KEYWORD_IDEA_COLLECTION,
            kw_idea_parent_doc,
            _KEYWORD_IDEA_SUBCOLLECTION,
            {"keywords": batched_outputs},
            f"raw_{start_idx}_{end_idx-1}",
        )
    return outputs


###########################
#    PRIVATE FUNCTIONS    #
###########################


def _generate_keyword_ideas_from_seed_keywords_and_url(
    customer_id: str,
    customer_url: str,
    keywords: List[str],
    incl_location_ids: List[str],
    incl_language_ids: List[str],
) -> List[dict]:

    fs = FirestoreClient()
    collection = fs.get_collection(_KEYWORD_IDEA_COLLECTION)

    ideas = []
    used_doc_ids = []
    for start_idx in range(0, len(keywords), 10):
        ten_keywords = keywords[start_idx : start_idx + 10]

        # Filter on docs related to a specific customer and url
        # and incl_location_ids that are the same as current request
        # and incl_language_ids that are the same as current request
        doc_ref = (
            collection.where("customer_id", "==", customer_id)
            .where(
                "url", "==", customer_url
            )  # TODO: DO WE NEED TO FILTER BY CUSTOMER URL
            .where("seed_keyword", "array_contains_any", ten_keywords)
            .stream()
        )

        for doc in doc_ref:
            doc_dict = doc.to_dict()

            # select doc that have matching language ids
            if (
                (set(incl_language_ids) == set(doc_dict["incl_language_ids"]))
                and (set(incl_location_ids) == set(doc_dict["incl_location_ids"]))
                and (doc.id not in used_doc_ids)
            ):
                subcollection_docs = fs.get_all_documents_within_subcollection(
                    f"{_KEYWORD_IDEA_COLLECTION}/{doc.id}/{_KEYWORD_IDEA_SUBCOLLECTION}",
                    skip_id=True,
                )

                for subcol in subcollection_docs:
                    ideas += subcol["keywords"]

                used_doc_ids.append(doc.id)

    keywords_found = [keyword_dict["idea_text"] for keyword_dict in ideas]
    keywords_to_seed = [kw for kw in keywords if kw not in keywords_found]

    print(f"Found {len(keywords_found)} existing keyword ideas from seeded keywords")
    print(f"{len(keywords_to_seed)} keywords left to be seeded")

    # generate keyword ideas based on keyword seeds
    for start_idx in range(0, len(keywords_to_seed), 20):
        print(
            f"Getting kw suggestions for batch {start_idx}: {keywords_to_seed[start_idx : start_idx + 20]}"
        )
        ideas = _generate_keywords_ideas_from_google(
            customer_id=customer_id,
            page_url=customer_url,
            keyword_texts=keywords_to_seed[start_idx : start_idx + 20],
            incl_location_ids=incl_location_ids,
            incl_language_ids=incl_language_ids,
        )

    ideas = get_unique_list_of_dict(ideas)
    return ideas


def _generate_keyword_ideas_from_url(
    customer_id: str, url: str, incl_location_ids: list, incl_language_ids: list
) -> List[dict]:
    """Return keyword ideas that are seeded from a given URL. Starts by searching
    if any document exists in Firestore from previous run. If yes, return results from
    previous run. Otherwise query google API.

    Args:
        customer_id (str): Google account ID
        url (str): URL to seed keywords from
        incl_location_ids (list): search locations
        incl_language_ids (list): search language

    Returns:
        List[dict]: list containing dict, where each dict = 1 keyword
    """

    fs = FirestoreClient()
    collection = fs.get_collection(_KEYWORD_IDEA_COLLECTION)

    # Filter on docs related to a specific customer and url
    # and incl_location_ids that are the same as current request
    # and incl_language_ids that are the same as current request
    doc_ref = (
        collection.where("customer_id", "==", customer_id)
        .where("url", "==", url)  # TODO: WHAT IS URL IS SIMILAR BUT SLIGHTLY DIFFERENT
        .where("incl_location_ids", "in", [incl_location_ids])
        .stream()
    )

    ideas = []
    num_doc_found = 0
    for doc in doc_ref:
        doc_dict = doc.to_dict()

        # select doc that have matching language ids
        if set(incl_language_ids) == set(doc_dict["incl_language_ids"]):
            subcollection_docs = fs.get_all_documents_within_subcollection(
                f"{_KEYWORD_IDEA_COLLECTION}/{doc.id}/{_KEYWORD_IDEA_SUBCOLLECTION}",
                skip_id=True,
            )

            for subcol in subcollection_docs:
                ideas += subcol["keywords"]

            num_doc_found += 1

    print(
        f"Found {len(ideas)} existing keyword ideas from URL {url} in {_KEYWORD_IDEA_COLLECTION} collection"
    )

    if num_doc_found == 0:
        # no matching doc found in firestore, thus query google
        ideas = _generate_keywords_ideas_from_google(
            customer_id=customer_id,
            page_url=url,
            keyword_texts=[],
            incl_location_ids=incl_location_ids,
            incl_language_ids=incl_language_ids,
        )

    ideas = get_unique_list_of_dict(ideas)
    return ideas


def _get_url_type(url: str) -> str:
    """Returns if the URL is top level domain or subpage."""
    url = url.replace("https://", "").replace("http://", "")
    # TODO: ADD CHECK TO MAKE SURE STRING DOESNT START FROM '?'
    url_components = [
        comp for comp in url.split("/") if (len(comp) > 0) and (comp[0] != "?")
    ]

    if len(url_components) > 1:
        return "page"
    else:
        return "site"


if __name__ == "__main__":
    keyword_ideas_df = _generate_keyword_ideas(
        "2855240427",
        [],
        [],
        [
            "connect quickbooks to google sheets"
            "connect google sheets to quickbooks online"
            "g accon for quickbooks"
            "google sheets quickbooks integration"
            "quickbooks and google sheets"
            "integrate google sheets with quickbooks"
            "quickbooks google sheets integration"
        ],
        "www.liveflow.io",
        [
            "https://www.accon.services",
            "https://www.geniussheets.com",
            "https://www.coupler.io",
            "https://digits.com",
            "https://causal.app",
            "https://www.dancingnumbers.com",
        ],
        ["free excel"],
    )
    keyword_ideas_df.to_csv("keyword_ideas_df.csv")
    # add_keyword_ideas_as_hints(
    #     business_id="test19",
    #     url="www.oyen.my",
    #     client_id="9298524019",
    #     country_code="MY",
    # )
    # fs = FirestoreClient()

    # businesses_ref = (
    #     fs.get_collection("businesses").where("is_deleted", "==", False).stream()
    # )
    # for biz in businesses_ref:
    #     business_id = biz.id

    #     data = {
    #         "business_id": business_id  # "test17",
    #         # "google_session_id": "0yD7q6GbMiodKpBudgvI",
    #         # "negative_keywords": [],
    #         # "keywords": ["pet insurance", "dog insurance"],
    #         # "customer_url": "www.oyen.my",
    #         # "audience_id": "zZW0pVZNsPV1cCqgI2BA",
    #     }
    #     o = main(data)
    #     print(o)
