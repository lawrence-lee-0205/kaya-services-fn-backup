import pandas as pd

from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount
from google.keywords.keyword_planner import get_historical_performance


def get_list_of_keyword_plans(business_id):
    google_ads_account = GoogleAdsAccount(business_id=business_id)
    query = f"""
    SELECT 
        keyword_plan.name, 
        keyword_plan.id, 
        keyword_plan.resource_name 
    FROM keyword_plan 
    WHERE 
        customer.id = {google_ads_account.client_id} 
    """

    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )
    for row in rows:
        print(row)
    return None


if __name__ == "__main__":
    # get_list_of_keyword_plans(business_id="82cutQRlx6gagQFMKjPa")
    res_by_keyword_lst = get_historical_performance(
        "customers/5735788545/keywordPlans/993133716"
    )

    search_vol_df_lst = []
    for res in res_by_keyword_lst:
        print(res)
        monthly_search_volume_df = pd.DataFrame(res["monthly_search_volumes"])
        monthly_search_volume_df["keyword"] = res["keyword"]
        search_vol_df_lst.append(monthly_search_volume_df)
    monthly_search_volume_df = pd.concat(search_vol_df_lst)
    monthly_search_volume_df.to_csv("monthly_search_volume_df.csv", index=0)
