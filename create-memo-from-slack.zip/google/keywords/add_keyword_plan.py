from os import environ

from google.keywords.keyword_plan import KeywordPlan
from http_function import process_request_inputs, http_function
from common import validate_inputs

_DEFAULT_FORECAST_PERIOD = "NEXT_MONTH"
_DEFAULT_KEYWORD_PLAN_NETWORK = "GOOGLE_SEARCH"


@http_function
def add_gads_keyword_plan_http(request_json={}, request_args={}):
    mandatory_fields = [
        "business_id",
        "ad_groups",
        "incl_location_ids",
        "incl_language_ids",
    ]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    customer_id = "3545980072" if "PROD" in environ["ENV"] else "3385265876"

    output = execute(
        customer_id=customer_id,
        ad_groups=data["ad_groups"],
        incl_location_ids=data["incl_location_ids"],
        incl_language_ids=data["incl_language_ids"],
        campaign_bid_cpc=data.get("campaign_bid_cpc", None),
    )
    return output


def execute(
    customer_id,
    ad_groups,
    incl_location_ids,
    incl_language_ids,
    campaign_bid_cpc=None,
):
    plan = KeywordPlan(customer_id)
    output = plan.create(
        forecast_period=_DEFAULT_FORECAST_PERIOD,
        keyword_plan_network=_DEFAULT_KEYWORD_PLAN_NETWORK,
        ad_groups=ad_groups,
        incl_location_ids=incl_location_ids,
        incl_language_ids=incl_language_ids,
        campaign_bid_cpc=campaign_bid_cpc,
    )
    return output


if __name__ == "__main__":
    default_cpc_bid = 15
    ad_groups = [
        {
            "name": "Payroll",
            "keywords": [
                {
                    "text": "Cloud Based Payroll Software",
                    "cpc_bid": 10,
                    "match_type": "BROAD",
                },
                {
                    "text": "HMRC Payroll Software",
                    "cpc_bid": 10,
                    "match_type": "BROAD",
                },
            ],
            "cpc_bid": default_cpc_bid,
        },
        z,
    ]

    incl_locations = [2826]
    incl_languages = [1000]
    execute(
        "3545980072",
        ad_groups,
        incl_locations,
        incl_languages,
    )
