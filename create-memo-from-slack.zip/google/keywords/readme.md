3 main steps:

1. Generate Keyword Ideas

   Given customer URL, seed URLs and keywords, generate bunch of keyword ideas. Each keyword idea comes with basic metrics such as avg_monthly_searches, competition_value, is_user_provided, keyword_annotations, is_branded and intent.

   These keywords are produced without taking into account the business' metrics like budget, average revenue per user & conversion rate.

2. Scope keywords for recommendation

   Based on the business' average revenue per user & conversion rate, we calculate their max CPA. Then we use the keywords produced from step 1.
