# create a class called KeywordPlan
from typing import List
import datetime

from google.ads.googleads.client import GoogleAdsClient
from google.api_core import protobuf_helpers

from google.gutils.api_queue import Queue
from firestore import FirestoreClient
from google.keyword_planner.utils_keywords import (
    map_locations_ids_to_resource_names,
    map_language_ids_to_resource_names,
)

_ACCEPTABLE_FORECAST_PERIODS = ["NEXT_QUARTER", "NEXT_MONTH", "NEXT_WEEK"]
_ACCEPTABLE_KEYWORD_PLAN_NETWORKS = ["GOOGLE_SEARCH"]
_MUTATE_AD_GROUP_KEYWORD_BATCH_SIZE = 100


class KeywordPlan:
    def __init__(self, customer_id):
        self._customer_id = customer_id

        self.client = GoogleAdsClient.load_from_env()
        self.firestore = FirestoreClient()

        self.keyword_plan_rn = None

    @property
    def customer_id(self):
        if not isinstance(self._customer_id, str):
            return str(self._customer_id)

        return self._customer_id

    def create(
        self,
        forecast_period: str,
        keyword_plan_network: str,
        ad_groups: List[dict],
        campaign_bid_cpc: int = None,
        incl_location_ids: list = [],
        incl_language_ids: list = [],
        skip_firestore: bool = False,
        **kwargs,
    ):

        print("Adding keyword plan")
        # validate inputs
        if forecast_period not in _ACCEPTABLE_FORECAST_PERIODS:
            raise Exception(
                f"Value provided for param forecast_period is not acceptable. Only accepts: {_ACCEPTABLE_FORECAST_PERIODS}"
            )

        if keyword_plan_network not in _ACCEPTABLE_KEYWORD_PLAN_NETWORKS:
            raise Exception(
                f"Value provided for param keyword_plan_network is not acceptable. Only accepts: {_ACCEPTABLE_KEYWORD_PLAN_NETWORKS}"
            )

        keyword_plan_name = kwargs.get(
            "keyword_plan_name",
            f"Keyword plan for {self.customer_id} {datetime.datetime.now()}",
        )
        keyword_plan_campaign_name = kwargs.get(
            "campaign_name", f"Campaign under {keyword_plan_name}"
        )

        # PROCESS BIDS
        # convert cpc bids to micros and set ad group level cpc bid if not provided
        ad_groups = [self._process_ad_group(ag) for ag in ad_groups]
        campaign_bid_cpc = (
            max([ag["cpc_bid"] for ag in ad_groups])
            if campaign_bid_cpc is None
            else campaign_bid_cpc * 1e6
        )

        self.keyword_plan_rn = self._create_keyword_plan(
            plan_name=keyword_plan_name,
            forecast_period=forecast_period,
        )
        keyword_plan_campaign_rn = self._create_keyword_plan_campaign(
            campaign_name=keyword_plan_campaign_name,
            campaign_bid_cpc=campaign_bid_cpc,
            keyword_plan_network=keyword_plan_network,
            incl_location_ids=incl_location_ids,
            incl_language_ids=incl_language_ids,
        )

        ad_group_resources = []
        for ad_group in ad_groups:
            keyword_plan_ad_group_rn = self._create_keyword_plan_ad_group(
                ad_group_name=ad_group["name"],
                ad_group_bid_cpc=ad_group["cpc_bid"],
                keyword_plan_campaign_resource_name=keyword_plan_campaign_rn,
            )
            updated_keywords = self._create_keyword_plan_ad_group_keywords(
                keywords=ad_group["keywords"],
                keyword_plan_ad_group_resource_name=keyword_plan_ad_group_rn,
            )
            ad_group_resources.append(
                {
                    "resource_name": keyword_plan_ad_group_rn,
                    "keywords": updated_keywords,
                    "name": ad_group["name"],
                    "cpc_bid_micros": ad_group["cpc_bid"],
                }
            )

        api_output = {
            "client_id": self.customer_id,
            "plan_resource_name": self.keyword_plan_rn,
            "plan_name": keyword_plan_name,
            "campaign_resource_name": keyword_plan_campaign_rn,
            "campaign_name": keyword_plan_campaign_name,
            "ad_group_resources": ad_group_resources,
            "campaign_bid_cpc": campaign_bid_cpc,
            "incl_location_ids": incl_location_ids,
            "incl_language_ids": incl_language_ids,
            "forecast_period": forecast_period,
        }

        if not skip_firestore:
            content = {**api_output, "created_at": datetime.datetime.now()}
            doc_id = self.firestore.add_document("keyword_plans", content)
            api_output["doc_id"] = doc_id

        return api_output

    def mutate_ad_group_keywords(self, keywords, keyword_plan_ad_group_resource_name):
        # TODO: update keyword plan doc so actual keyword plan & firestore are in sync
        content_to_update = self._create_keyword_plan_ad_group_keywords(
            keywords, keyword_plan_ad_group_resource_name, operation="update"
        )
        return content_to_update

    def _create_keyword_plan(self, plan_name, forecast_period):
        """
        Adds a keyword plan to the given customer account.
        """
        operation = self.client.get_type("KeywordPlanOperation")

        keyword_plan = operation.create
        keyword_plan.name = plan_name

        # SET FORECAST INTERVAL
        # TODO: IMPLEMENT date range
        # https://developers.google.com/google-ads/api/reference/rpc/v9/KeywordPlanForecastPeriod
        forecast_interval = self.client.enums.KeywordPlanForecastIntervalEnum[
            forecast_period
        ]
        keyword_plan.forecast_period.date_interval = forecast_interval

        Queue("keyword_plan").queue(function="mutate_keyword_plans", num_operations=1)
        keyword_plan_service = self.client.get_service("KeywordPlanService")
        response = keyword_plan_service.mutate_keyword_plans(
            customer_id=self.customer_id, operations=[operation]
        )
        keyword_plan_rn = response.results[0].resource_name

        print(f"Created keyword plan with resource name: {keyword_plan_rn}")
        return keyword_plan_rn

    @staticmethod
    def _process_ad_group(ad_group: dict):
        """Process ad group by converting cpc bids to micro unit
        and setting max cpc bid to ad group if not provided

        Args:
            ad_group (dict): _description_

        Returns:
            _type_: _description_
        """
        max_cpc = 0
        for kw in ad_group["keywords"]:
            kw["cpc_bid"] = int(kw["cpc_bid"] * 1e6)
            max_cpc = max(max_cpc, kw["cpc_bid"])

        ad_group["cpc_bid"] = (
            max_cpc if "cpc_bid" not in ad_group else int(ad_group["cpc_bid"] * 1e6)
        )
        return ad_group

    def _create_keyword_plan_campaign(
        self,
        campaign_name,
        campaign_bid_cpc,
        keyword_plan_network,
        incl_location_ids=[],
        incl_language_ids=[],
    ):
        """Adds a keyword plan campaign to the given keyword plan.
        Args:
            client: An initialized instance of GoogleAdsClient
            keyword_plan: A str of the keyword plan resource_name this keyword plan
                campaign should be attributed to.create_keyword_plan.
        Returns:
            A str of the resource_name for the newly created keyword plan campaign.
        Raises:
            GoogleAdsException: If an error is returned from the API.
        """
        print("Creating campaign for keyword plan: ", self.keyword_plan_rn)
        operation = self.client.get_type("KeywordPlanCampaignOperation")
        keyword_plan_campaign = operation.create

        keyword_plan_campaign.name = campaign_name
        keyword_plan_campaign.cpc_bid_micros = campaign_bid_cpc
        keyword_plan_campaign.keyword_plan = self.keyword_plan_rn

        network = self.client.enums.KeywordPlanNetworkEnum[keyword_plan_network]
        keyword_plan_campaign.keyword_plan_network = network

        # PROCESS LOCATIONS
        if len(incl_location_ids) > 0:
            print("incl_location_ids provided: ", incl_location_ids)
            geo_constants = map_locations_ids_to_resource_names(incl_location_ids)
            for gt in geo_constants:
                geo_target = self.client.get_type("KeywordPlanGeoTarget")
                # Constant for U.S. Other geo target constants can be referenced here:
                # https://developers.google.com/google-ads/api/reference/data/geotargets
                geo_target.geo_target_constant = gt
                keyword_plan_campaign.geo_targets.append(geo_target)
                print(f"geo_target: {geo_target}")

        # PROCESS LANGUAGE
        if len(incl_language_ids) > 0:
            lang_constants = map_language_ids_to_resource_names(incl_language_ids)

            # TODO: REMOVE HARDCODED RULE OF HAVING 1 LANG ONLY
            lang_constant = lang_constants[0]
            keyword_plan_campaign.language_constants.append(lang_constant)

        # CALL GOOGLE API
        Queue("keyword_plan").queue(
            function="mutate_keyword_plan_campaigns", num_operations=1
        )
        keyword_plan_campaign_service = self.client.get_service(
            "KeywordPlanCampaignService"
        )
        response = keyword_plan_campaign_service.mutate_keyword_plan_campaigns(
            customer_id=self.customer_id, operations=[operation]
        )

        keyword_plan_campaign_rn = response.results[0].resource_name

        print(
            f"Created keyword plan campaign with resource name: {keyword_plan_campaign_rn}"
        )
        return keyword_plan_campaign_rn

    def _create_keyword_plan_ad_group(
        self,
        ad_group_name,
        ad_group_bid_cpc,
        keyword_plan_campaign_resource_name,
    ):
        if not isinstance(ad_group_bid_cpc, int):
            ad_group_bid_cpc = int(ad_group_bid_cpc)

        operation = self.client.get_type("KeywordPlanAdGroupOperation")
        keyword_plan_ad_group = operation.create

        keyword_plan_ad_group.name = ad_group_name
        keyword_plan_ad_group.cpc_bid_micros = ad_group_bid_cpc
        keyword_plan_ad_group.keyword_plan_campaign = (
            keyword_plan_campaign_resource_name
        )

        # CALL GOOGLE API
        Queue("keyword_plan").queue(
            function="mutate_keyword_plan_ad_groups", num_operations=1
        )
        keyword_plan_ad_group_service = self.client.get_service(
            "KeywordPlanAdGroupService"
        )
        response = keyword_plan_ad_group_service.mutate_keyword_plan_ad_groups(
            customer_id=self.customer_id, operations=[operation]
        )

        keyword_plan_ad_group_rn = response.results[0].resource_name

        print(
            f"Created keyword plan ad group with resource name: {keyword_plan_ad_group_rn}"
        )

        return keyword_plan_ad_group_rn

    def _create_keyword_plan_ad_group_keywords(
        self,
        keywords: List[dict],
        keyword_plan_ad_group_resource_name: str,
        operation: str = "create",
    ) -> List[dict]:
        """
        Adds keyword plan ad group keywords to the given keyword plan ad group.

        Args:
        - keywords: List of dict
        """
        num_keywords = len(keywords)

        print(f"Adding {num_keywords} keywords to ad group")
        batch_keyword_list = [
            keywords[i : i + _MUTATE_AD_GROUP_KEYWORD_BATCH_SIZE]
            for i in range(0, num_keywords, _MUTATE_AD_GROUP_KEYWORD_BATCH_SIZE)
        ]
        print(
            f"Split into {len(batch_keyword_list)} batches of {_MUTATE_AD_GROUP_KEYWORD_BATCH_SIZE} each"
        )

        # CALL GOOGLE API
        Queue("keyword_plan").queue(
            function="mutate_keyword_plan_ad_group_keywords", num_operations=1
        )
        keyword_plan_ad_group_keyword_service = self.client.get_service(
            "KeywordPlanAdGroupKeywordService"
        )

        updated_keywords = []
        for batch in batch_keyword_list:
            updated_keywords += self._batch_create_keyword_plan_ad_group_keywords(
                batch,
                keyword_plan_ad_group_resource_name,
                keyword_plan_ad_group_keyword_service,
                operation,
            )
        print(f"Added {len(updated_keywords)} keywords to ad group")

        return updated_keywords

    def _batch_create_keyword_plan_ad_group_keywords(
        self,
        batch_keywords,
        keyword_plan_ad_group_resource_name,
        keyword_plan_ad_group_keyword_service,
        op_type="create",
    ):
        operations = []
        for keyword in batch_keywords:
            operation = self.client.get_type("KeywordPlanAdGroupKeywordOperation")

            if op_type == "create":
                keyword_plan_ad_group_keyword = operation.create
            elif op_type == "update":
                keyword_plan_ad_group_keyword = operation.update
                keyword_plan_ad_group_keyword.resource_name = keyword["resource_name"]
            else:
                raise Exception(
                    "Provided 'op_type' is not recognised. Only accepts ['create', 'update']"
                )

            keyword_plan_ad_group_keyword.text = keyword["text"]
            keyword_plan_ad_group_keyword.cpc_bid_micros = int(keyword["cpc_bid"])
            keyword_plan_ad_group_keyword.match_type = (
                self.client.enums.KeywordMatchTypeEnum[keyword["match_type"]]
            )
            keyword_plan_ad_group_keyword.keyword_plan_ad_group = (
                keyword_plan_ad_group_resource_name
            )
            operations.append(operation)

            if op_type == "update":
                self.client.copy_from(
                    operation.update_mask,
                    protobuf_helpers.field_mask(
                        None, keyword_plan_ad_group_keyword._pb
                    ),
                )

        keyword_plan_keywords_responses = (
            keyword_plan_ad_group_keyword_service.mutate_keyword_plan_ad_group_keywords(
                customer_id=self.customer_id, operations=operations
            )
        )

        for idx, result in enumerate(keyword_plan_keywords_responses.results):
            batch_keywords[idx].update({"resource_name": result.resource_name})
        return batch_keywords


if __name__ == "__main__":
    default_cpc_bid = 30
    ad_groups = [
        {
            "name": "Payroll",
            "keywords": [
                {
                    "text": "Cloud Based Payroll Software",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "BROAD",
                },
                {
                    "text": "HMRC Payroll Software",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "BROAD",
                },
                {
                    "text": "HR and Payroll Software",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "BROAD",
                },
                {
                    "text": "HR Payroll",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "PHRASE",
                },
                {
                    "text": "Payroll Automation Software",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "PHRASE",
                },
                {
                    "text": "Payroll Provider UK",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "PHRASE",
                },
                {
                    "text": "Payroll Software UK",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "PHRASE",
                },
                {
                    "text": "Payroll System UK",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "PHRASE",
                },
                {
                    "text": "Payroll Solutions",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "PHRASE",
                },
                {
                    "text": "Online Payroll Software",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "PHRASE",
                },
                {
                    "text": "Payroll Software",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "BROAD",
                },
                {
                    "text": "Payroll System",
                    "cpc_bid": default_cpc_bid,
                    "match_type": "BROAD",
                },
            ],
            "cpc_bid": default_cpc_bid,
        },
    ]

    incl_locations = [2826]
    incl_languages = [1000]

    plan = KeywordPlan("3545980072")
    out = plan.create(
        forecast_period="NEXT_QUARTER",
        keyword_plan_network="GOOGLE_SEARCH",
        ad_groups=ad_groups,
        incl_location_ids=incl_locations,
        incl_language_ids=incl_languages,
    )
    print(out)
