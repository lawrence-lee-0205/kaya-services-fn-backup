import pandas as pd
import numpy as np
import datetime
from typing import List

from setup import setup
from common import validate_inputs, validate_and_fix_bid
from constants import MILLION
from firestore import FirestoreClient
from google.keywords.keyword_planner import (
    add_keyword_plan,
    get_forecasted_performance,
    get_historical_performance,
    mutate_ad_group_keywords,
)
from google.keywords.classify_intent import classify_intent
from queries import get_google_account

_DEFAULT_FORECAST_PERIOD = "NEXT_QUARTER"
_DEFAULT_KEYWORD_MATCH_TYPE = "PHRASE"
_DEFAULT_ADS_NETWORK = "GOOGLE_SEARCH"
_MAX_CPC_BID = 50
_MULTIPLIER_TOP_OF_PAGE_BID = 1.2


@setup
def scope_keywords_for_recommendations(data):
    """mandatory_fields = [
        "google_session_id",
        "avg_annual_revenue_per_user",
        "conversion_rate",
        "business_id",
    ]

    Args:
        data ([type]): [description]
    """
    mandatory_fields = [
        "google_session_id",
        "avg_annual_revenue_per_user",
        "conversion_rate",
        "business_id",
    ]
    validate_inputs(data, mandatory_fields)

    # get doc from the session
    google_session_id = data["google_session_id"]
    fs = FirestoreClient()
    session_doc = fs.get_single_document("google_sessions", google_session_id)

    keywords_to_use = list(set(session_doc["keyword_ideas"]))
    client_id = session_doc["client_id"]

    forecast_period = data.get("forecast_period", _DEFAULT_FORECAST_PERIOD)
    incl_locations = session_doc["incl_locations"]
    incl_languages = session_doc["incl_languages"]

    # calculate max bid based on business inputs
    avg_annual_revenue_per_user = data["avg_annual_revenue_per_user"]
    conversion_rate = data["conversion_rate"] / 100
    max_cpc = avg_annual_revenue_per_user * conversion_rate

    google_account = get_google_account(data["business_id"])
    ccy = google_account["ccy_code"]

    ##############################
    #    CREATE KEYWORD PLANS    #
    ##############################
    # TODO: ONLY CREATE NEW KEYWORD PLAN IF INPUT CHANGES

    init_cpc_bid = min(_MAX_CPC_BID, max_cpc)
    keywords_to_use_params = [
        {
            "text": kw,
            "cpc_bid": int(init_cpc_bid * MILLION),
            "match_type": _DEFAULT_KEYWORD_MATCH_TYPE,
        }
        for kw in keywords_to_use
    ]
    ad_groups = [
        {
            "name": "ad group #1",
            "keywords": keywords_to_use_params,
            "cpc_bid": int(init_cpc_bid * MILLION),
        }
    ]

    print(f"Num keywords passed to keyword plan: {len(keywords_to_use_params)}")
    keyword_plan_setting = add_keyword_plan(
        customer_id=client_id,
        forecast_period=forecast_period,
        keyword_plan_network=_DEFAULT_ADS_NETWORK,
        ad_groups=ad_groups,
        campaign_bid_cpc=int(init_cpc_bid * MILLION),
        incl_location_ids=incl_locations,
        incl_language_ids=incl_languages,
    )
    keyword_plan_rn = keyword_plan_setting["plan_resource_name"]
    plan_firestore_id = keyword_plan_setting["doc_id"]
    ad_group_resources = keyword_plan_setting["ad_group_resources"]

    if len(ad_group_resources) == 1:
        ad_group_resource = ad_group_resources[0]
    else:
        raise Exception(
            f"Expecting ad_group_resources to contain 1 element only. Received {len(ad_group_resources)}"
        )

    ################################
    #    HISTORICAL PERFORMANCE    #
    ################################

    print(f"Getting historical performance for keyword plan {keyword_plan_rn}")
    historical_results = get_historical_performance(keyword_plan_rn, plan_firestore_id)
    historical_results_df = pd.DataFrame(historical_results)
    print(f"Shape of historical_results_df: {historical_results_df.shape}")

    ###################################
    #    CALCULATE RECOMMENDED BID    #
    ###################################

    max_high_top_of_page_bid = _MULTIPLIER_TOP_OF_PAGE_BID * (
        historical_results_df["high_top_of_page_bid"].max()
    )
    print("max_high_top_of_page_bid: ", max_high_top_of_page_bid)

    historical_results_df["recommended_max_bid"] = historical_results_df[
        "high_top_of_page_bid"
    ].apply(lambda x: _recommend_bid(x, max_high_top_of_page_bid, max_cpc))

    ##################################################
    #      FIND KEYWORDS THAT REQUIRE BID UPDATE     #
    ###################################################

    historical_results_df["abs_bid_changes"] = (
        historical_results_df["recommended_max_bid"] - init_cpc_bid
    ).abs()

    # only updates if the bid changes by 1 unit
    keywords_to_update_bid_df = historical_results_df[
        historical_results_df["abs_bid_changes"] > 1
    ]

    ################################
    #      UPDATE WITH NEW BID     #
    ################################

    # from ad_group_resource, join with historical df and determine which
    # keywords need to be updated. then create a list of dict that contains the
    # new values and update keyword plan
    ad_group_resource_df = pd.DataFrame(ad_group_resource["keywords"])
    ad_group_resource_to_update_df = pd.merge(
        ad_group_resource_df.rename(columns={"text": "keyword"}),
        keywords_to_update_bid_df,
        on="keyword",
        how="inner",
    )
    keywords_to_update_bid_params = [
        {
            "text": kw,
            "cpc_bid": validate_and_fix_bid(int(bid * MILLION)),
            "match_type": _DEFAULT_KEYWORD_MATCH_TYPE,
            "resource_name": resource_name,
        }
        for kw, bid, resource_name in zip(
            ad_group_resource_to_update_df["keyword"],
            ad_group_resource_to_update_df["recommended_max_bid"],
            ad_group_resource_to_update_df["resource_name"],
        )
    ]
    print("Keywords to update in forecast:\n", keywords_to_update_bid_params)

    mutate_ad_group_keywords(
        customer_id=client_id,
        keywords=keywords_to_update_bid_params,
        keyword_plan_ad_group_resource_name=ad_group_resource["resource_name"],
    )

    #################################
    #      FORECAST PERFORMANCE     #
    #################################

    forecasted_results = get_forecasted_performance(keyword_plan_rn, plan_firestore_id)
    forecasted_results_df = _process_forecast_to_df(forecasted_results["keyword"])

    ##### MERGE DATAFRAMES #######
    # this step remove keywords where forecasted metrics are 0
    print(f"Shape of historical data before merging: {historical_results_df.shape}")
    print(f"Shape of forecast data before merging: {forecasted_results_df.shape}")
    keyword_summary = pd.merge(
        historical_results_df,
        forecasted_results_df,
        on="keyword",
        how="inner",
        validate="1:1",
    )
    print(f"Shape after merging: {keyword_summary.shape}")

    print("avg CPC: ", forecasted_results_df["avg_cpc"].mean())

    keyword_summary = _calculate_ctr(keyword_summary)
    keyword_summary = _calculate_intent_score(keyword_summary)
    keyword_summary = _calculate_conversion(keyword_summary, conversion_rate)
    keyword_summary = _calculate_cpa(keyword_summary)

    ##### POPULATE MISSING VALUES WITH DEFAULT #####
    fillna_dict = {
        "avg_monthly_searches": 0,
        "competition": "undefined",
        "high_top_of_page_bid": 0,
        "low_top_of_page_bid": 0,
        "l3m_avg_monthly_searches": 0,
        "recommended_max_bid": 0.01,
        "trend": "undefined",
        "cpa": 0,
        "ctr": 0,
    }
    for col, fill_value in fillna_dict.items():
        keyword_summary[col].fillna(fill_value, inplace=True)

    output_json = keyword_summary.to_dict(orient="records")

    # Save to Firestore
    keywords_in_scope_doc = {
        "keywords": output_json,
        "ccy": ccy,
        "created_at": datetime.datetime.utcnow(),
        "keyword_plan_firestore_id": plan_firestore_id,
        "keyword_plan_resource_name": keyword_plan_rn,
    }
    keywords_in_scope_id = fs.add_subcollection_to_document(
        "google_sessions",
        google_session_id,
        "keywords_in_scope",
        keywords_in_scope_doc,
    )

    cols_to_copy = [
        "avg_annual_revenue_per_user",
        "conversion_rate",
    ]
    session_doc_to_update = {c: data[c] for c in cols_to_copy}
    fs.update_document(
        "google_sessions",
        google_session_id,
        {
            "latest_keywords_in_scope_id": keywords_in_scope_id,
            "ccy": ccy,
            **session_doc_to_update,
        },
    )
    return {"status": "success"}


def _process_forecast_to_df(keyword_forecasts: List[dict]) -> pd.DataFrame:
    metrics = ["avg_cpc", "clicks", "impressions"]

    forecasted_results_df = pd.DataFrame(keyword_forecasts)
    forecasted_results_df.rename(
        columns={"text": "keyword"}, inplace=True
    )  # TODO: MOVE TO get_forecasted_performance

    for col in metrics:
        forecasted_results_df.loc[:, col] = pd.to_numeric(
            forecasted_results_df.loc[:, col], errors="coerce"
        )

    print("Raw shape of forecasted_results_df", forecasted_results_df.shape)
    print(
        "Num of empty row per column in forecasted_results_df:\n",
        forecasted_results_df.isnull().sum(axis=0),
    )
    forecasted_results_df.dropna(axis=0, subset=metrics, inplace=True)
    return forecasted_results_df


def _calculate_ctr(keyword_df: pd.DataFrame) -> pd.DataFrame:
    keyword_df.loc[:, "ctr"] = (
        keyword_df.loc[:, "clicks"] / keyword_df.loc[:, "impressions"]
    )
    return keyword_df


def _calculate_conversion(
    keyword_df: pd.DataFrame, conversion_rate: float
) -> pd.DataFrame:
    if conversion_rate > 1:
        raise Exception(
            f"Expecting conversion rate to have value < 1. Received {conversion_rate}"
        )

    keyword_df.loc[:, "conversion"] = (
        keyword_df.loc[:, "clicks"]
        * conversion_rate
        * keyword_df.loc[:, "intent_score"]
    )
    return keyword_df


def _calculate_intent_score(keyword_df: pd.DataFrame) -> pd.DataFrame:
    intent_score = {"transactional": 2, "commercial": 1.5}

    keyword_df.loc[:, "intent"] = keyword_df.loc[:, "keyword"].apply(
        lambda x: classify_intent(x)
    )
    keyword_df.loc[:, "intent_score"] = (
        keyword_df.loc[:, "intent"].map(intent_score).fillna(0.5)
    )
    return keyword_df


def _calculate_cpa(keyword_df: pd.DataFrame) -> pd.DataFrame:
    keyword_df.loc[:, "cpa"] = (
        keyword_df.loc[:, "cost"] / keyword_df.loc[:, "conversion"]
    )
    return keyword_df


def _recommend_bid(
    high_top_of_page_bid: float, max_high_top_of_page_bid: float, max_cpc: float
) -> float:
    """Recommend bid based on the minimum of:
    - multiple of top of page bid if top of page bid for the keyword is not null and have value > 0.1
    - highest top of page bid across all keywords
    - max cpc the user can afford
    - max cpc universally (defined by us)

    Args:
        high_top_of_page_bid (float): [description]
        max_high_top_of_page_bid (float): [description]
        max_cpc (float): [description]

    Returns:
        float: [description]
    """

    candidates = [
        max_high_top_of_page_bid,
        max_cpc,
        _MAX_CPC_BID,
    ]

    if (not np.isnan(high_top_of_page_bid)) and high_top_of_page_bid > 0.1:
        candidates.append(_MULTIPLIER_TOP_OF_PAGE_BID * (high_top_of_page_bid + 0.01))

    bid = np.nanmin(candidates)
    return bid


if __name__ == "__main__":
    data = {
        "google_session_id": "HEqx0JkrNrkHHHlw9B4R",  # "0yD7q6GbMiodKpBudgvI",
        "avg_annual_revenue_per_user": 35,
        "conversion_rate": 20,
        "business_id": "SWlTMQLhNmhit98gFu5j",
    }
    scope_keywords_for_recommendations(data)
