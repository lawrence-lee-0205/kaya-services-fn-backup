from google.ads.googleads.client import GoogleAdsClient

from constants import MILLION
from common import validate_inputs
from firestore import FirestoreClient
from google.gutils.api_queue import Queue
from http_function import http_function, process_request_inputs

# import pandas as pd

FS = FirestoreClient()
CLIENT = GoogleAdsClient.load_from_env()


@http_function
def get_gads_forecast_http(request_json={}, request_args={}):
    mandatory_fields = ["keyword_plan_resource_name", "firestore_doc_id"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    out = execute(
        keyword_plan_resource_name=data["keyword_plan_resource_name"],
        firestore_doc_id=data["firestore_doc_id"],
    )
    return out


def execute(keyword_plan_resource_name: str, firestore_doc_id: str):
    print(f"Getting performance forecast for {keyword_plan_resource_name}")
    Queue("keyword_plan").queue(function="generate_forecast_metrics", num_operations=1)

    keyword_plan_service = CLIENT.get_service("KeywordPlanService")
    response = keyword_plan_service.generate_forecast_metrics(
        keyword_plan=keyword_plan_resource_name
    )

    kw_maps = _get_keyword_mapping(firestore_doc_id)

    keyword_results = []
    for _, forecast in enumerate(response.keyword_forecasts):
        # https://developers.google.com/google-ads/api/reference/rpc/v8/ForecastMetrics
        metrics = forecast.keyword_forecast

        click_val = metrics.clicks
        clicks = f"{click_val:.2f}" if click_val else "unspecified"

        imp_val = metrics.impressions
        impressions = f"{imp_val:.2f}" if imp_val else "unspecified"

        cpc_val = metrics.average_cpc / MILLION
        cpc = f"{cpc_val:.2f}" if cpc_val else "unspecified"

        keyword_info_tuple = kw_maps[forecast.keyword_plan_ad_group_keyword]

        d = {
            "keyword_resource_name": forecast.keyword_plan_ad_group_keyword,
            "clicks": clicks,
            "impressions": impressions,
            "text": keyword_info_tuple[0],
            "ad_group": keyword_info_tuple[1],
            "cost": metrics.cost_micros / MILLION,
        }
        keyword_results.append(d)

    # PROCESS CAMPAIGN METRICS
    # check if campaign_forecasts only has 1 element
    if len(response.campaign_forecasts) > 1:
        raise Exception(
            f"WARNING: campaign_forecasts has more than 1 element: {len(response.campaign_forecasts)}"
        )

    campaign_metrics = response.campaign_forecasts[0].campaign_forecast
    campaign_result = {
        "impressions": campaign_metrics.impressions,
        "ctr": campaign_metrics.ctr,
        "average_cpc": campaign_metrics.average_cpc / MILLION,
        "clicks": campaign_metrics.clicks,
        "cost": campaign_metrics.cost_micros / MILLION,
    }

    output = {
        "keywords": keyword_results,
        "campaign": campaign_result,
    }
    # export forecast to gsheet
    # pd.DataFrame(output["keywords"]).to_csv("keyword_forecast.csv")
    return output


def _process_ad_group_resources(ad_group_resources):
    """Map keyword resource names to keyword text and ad group name.

    Args:
        ad_group_resources (_type_): _description_

    Returns:
        _type_: _description_
    """
    keyword_mapping = {}
    for ad_group in ad_group_resources:
        for keyword in ad_group["keywords"]:
            resource_name = keyword["resource_name"].replace(
                "keywordPlanAdGroupKeywords", "keywordPlanKeywords"
            )
            keyword_mapping[resource_name] = (
                keyword["text"],
                ad_group["name"],
            )
    return keyword_mapping


def _get_keyword_mapping(firestore_doc_id):
    ad_group_resources = FS.get_single_document("keyword_plans", firestore_doc_id)[
        "ad_group_resources"
    ]

    keyword_mapping = _process_ad_group_resources(ad_group_resources)
    return keyword_mapping


if __name__ == "__main__":
    out = execute(
        keyword_plan_resource_name="customers/5735788545/keywordPlans/665227660",
        firestore_doc_id="odx80QiyAwXBTsWhVRty",
    )
    print(out)

    #     {
    #     "keyword_plan_resource_name": "customers/3545980072/keywordPlans/650666074",
    #     "firestore_doc_id": "cOekQ7K9wGmOJ7OmaZSK"
    # }
