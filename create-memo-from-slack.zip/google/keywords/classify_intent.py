def classify_intent(keyword: str) -> str:
    intent_dict = {}
    intent_dict["informative"] = ["what", "who", "when", "where", "which", "why", "how"]
    intent_dict["transactional"] = [
        "buy",
        "order",
        "purchase",
        "cheap",
        "price",
        "discount",
        "shop",
        "sale",
        "offer",
    ]
    intent_dict["commercial"] = [
        "best",
        "top",
        "review",
        "comparison",
        "compare",
        "vs",
        "versus",
        "guide",
        "ultimate",
    ]

    word_list = keyword.split(" ")
    label = None

    for intent, terms in intent_dict.items():
        for term in terms:
            if term in word_list:
                label = intent
                break
    return label
