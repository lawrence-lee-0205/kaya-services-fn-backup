import datetime
import pandas as pd
from textpack import tp

from setup import setup
from common import validate_inputs
from firestore import FirestoreClient

_THRESHOLDS = {"optimal": 0.55, "compact": 0.50}

# TODO: SAFE TO REMOVE THIS FILE?


@setup
def main(data: dict) -> dict:
    """Given a list of keywords, cluster them into groups based on similarity.

    Args:
        data (dict): Payload processed by setup decorator. Contains input from front end client.

    Raises:
        Exception: [description]

    Returns:
        dict
    """

    mandatory_fields = ["business_id", "auth_user_id", "keywords"]
    validate_inputs(data, mandatory_fields)

    if not isinstance(data["keywords"], list):
        raise TypeError(
            f"Expecting 'keywords' to be a list of string. Received {data['keywords']} instead."
        )

    # RUN CLUSTERING ALGO
    groups = group_keywords(data["keywords"])

    # STORE RECORD IN FIRESTORE
    fs = FirestoreClient()
    doc = {
        **groups,
        "business_id": data["business_id"],
        "created_by": data["auth_user_id"],
        "created_at": datetime.datetime.now(),
    }
    doc_id = fs.add_document("keyword_groups", doc)

    output = {**groups, "doc_id": doc_id}

    return output


##########################
#    PRIVATE FUNCTION    #
##########################


def group_keywords(keywords: list) -> dict:
    """Explanation: https://github.com/lukewhyte/textpack

    Args:
        keywords (list): list of strings

    Returns:
        dict: [description]
    """
    # convert list to dataframe
    kw_df = pd.DataFrame(keywords, columns=["keywords"])

    # run
    outputs = {}
    for name, threshold in _THRESHOLDS.items():
        textpack = tp.TextPack(
            kw_df,
            "keywords",
            match_threshold=threshold,
            ngram_remove=r"[,-./]",
            ngram_length=3,
        )
        textpack.run()

        result_df = textpack.df
        output = result_df.groupby("Group")["keywords"].apply(list).to_dict()

        outputs[name] = output
    return outputs
