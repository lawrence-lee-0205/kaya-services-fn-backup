import pandas as pd
import numpy as np
import datetime
from typing import List

from setup import setup
from common import (
    validate_inputs,
    validate_and_fix_bid,
    validate_positive_number,
    validate_datetime,
)
from constants import (
    MAX_GOOGLE_KEYWORDS_CHAR_COUNT,
    MAX_GOOGLE_KEYWORDS_WORD_COUNT,
    MAX_WORDS_IN_KEYWORD,
    MILLION,
    NUM_WEEKS_IN_QUARTER,
)
from firestore import FirestoreClient
from queries import get_google_account, get_location_lang_from_audience
from google.keywords.generate_keyword_ideas import generate_keyword_ideas
from google.keywords.keyword_planner import (
    add_keyword_plan,
    get_forecasted_performance,
    get_historical_performance,
    mutate_ad_group_keywords,
    get_campaign_weekly_forecast,
)
from pulp import LpProblem, LpVariable, lpSum, LpMaximize

_DEFAULT_FORECAST_PERIOD = "NEXT_QUARTER"
_DEFAULT_CAMPAIGN_GOAL = "MAXIMISE_CLICK"
_DEFAULT_KEYWORD_MATCH_TYPE = "PHRASE"
_DEFAULT_ADS_NETWORK = "GOOGLE_SEARCH"
_MAX_CPC_BID = 50
_MULTIPLIER_TOP_OF_PAGE_BID = 5

_GOALS_MAPPING = {
    "MAXIMISE_CLICK": "clicks",
    "MAXIMISE_IMPRESSION": "impressions",
    "MAXIMISE_CONVERSION": "conversion",
}
_DEFAULT_LIMIT_RESULT = 50

_COL_TO_COMPARE = [
    "seed_keywords",
    "audience_id",
    "customer_url",
    "page_urls",
    "negative_keywords",
    "exclude_branded_keywords",
]


@setup
def main(data: dict) -> dict:
    mandatory_fields = [
        "business_id",
        # "google_session_id", TODO: MAKE THIS MANDATORY
        "auth_user_id",
        "conversion_rate",
        "avg_annual_revenue_per_user",
        "campaign_budget",
        "start_time",
        "end_time",
    ]

    collection_to_write = "keyword_strategies"
    cols_to_return = [
        "keyword",
        "avg_monthly_searches",
        "competition",
        "low_top_of_page_bid",
        "high_top_of_page_bid",
        "trend",
        "l3m_avg_monthly_searches",
        "clicks",
        "impressions",
        "avg_cpc",
        "ctr",
        "recommended_max_bid",
        "est_cost",
        "cpa",
        "conversion",
        "intent",
        "is_recommended",
        "portion",
        "is_budget_limited",
        "is_user_provided",
        "revenue",
        "roi",
    ]
    limit_num_results = 50

    validate_inputs(data, mandatory_fields)

    ########################
    #    PROCESS INPUTS    #
    ########################
    fs = FirestoreClient()

    input = {}
    content_for_session_doc = {}

    if data["business_id"] == "":
        raise ValueError("business_id must not be null or empty")

    # Create google session if didn't exist
    # TODO: Remove as google_session_id should always exist
    if ("google_session_id" not in data) or (data["google_session_id"] is None):
        init_session_doc = {
            "created_at": datetime.datetime.now(),
            "business_id": data["business_id"],
        }
        google_session_id = fs.add_document("google_sessions", init_session_doc)
    else:
        google_session_id = data["google_session_id"]
        init_session_doc = fs.get_single_document("google_sessions", google_session_id)

    google_account = get_google_account(data["business_id"])
    customer_id = google_account["client_id"]
    ccy = google_account["ccy_code"]

    input["seed_keywords"] = data.get("keywords", [])
    input["customer_url"] = data.get("customer_url", "")
    input["page_urls"] = data.get("page_urls", [])
    input["negative_keywords"] = data.get("negative_keywords", [])
    input["exclude_branded_keywords"] = data.get("exclude_branded_keywords", False)

    for dc in ["start_time", "end_time"]:
        input[dc] = validate_datetime(data[dc], dc)
    input["forecast_period"] = _DEFAULT_FORECAST_PERIOD
    input["num_campaign_days"] = (input["end_time"] - input["start_time"]).days
    input["num_campaign_weeks"] = int(input["num_campaign_days"] / 7)

    if input["num_campaign_weeks"] > NUM_WEEKS_IN_QUARTER:
        raise ValueError(
            f"Campaign duration must be shorter than 1 quarter. Campaign duration: {input['num_campaign_weeks']} weeks"
        )

    # validate input type for audience_id
    input["audience_id"] = data.get("audience_id", "")
    if not isinstance(input["audience_id"], str):
        raise TypeError(
            f"Expecting 'audience_id' to be of type 'str'. Received type '{type(input['audience_id'])}' instead"
        )

    for col in ["avg_annual_revenue_per_user", "conversion_rate", "campaign_budget"]:
        validate_positive_number(data[col], col)

    avg_annual_revenue_per_user = data["avg_annual_revenue_per_user"]
    conversion_rate = data["conversion_rate"] / 100
    max_cpc = avg_annual_revenue_per_user * conversion_rate

    budget = data["campaign_budget"]

    # process campaign goal
    campaign_goal = data.get("campaign_goal", _DEFAULT_CAMPAIGN_GOAL)
    if campaign_goal not in _GOALS_MAPPING.keys():
        raise Exception(
            f"campaign_goal provided ({campaign_goal}) is not accepted. Only accepts {list(_GOALS_MAPPING.keys())}"
        )
    col_to_maximise = _GOALS_MAPPING[campaign_goal]

    # process keywords
    for kw in input["seed_keywords"]:
        if (len(kw.split()) > MAX_GOOGLE_KEYWORDS_WORD_COUNT) or (
            len(kw) > MAX_GOOGLE_KEYWORDS_CHAR_COUNT
        ):
            raise Exception(
                f"Keywords can only be at most 80 characters and 10 words. Keyword: {kw}"
            )

    # process audience
    if input["audience_id"] != "":
        audience_processed = get_location_lang_from_audience(input["audience_id"])
        incl_locations = audience_processed["locations"]
        incl_languages = audience_processed["languages"]
    else:
        incl_locations = []
        incl_languages = []

    print(input)

    ###########################
    #    GET KEYWORD IDEAS    #
    ###########################

    # only rerun keyword ideas if any of these changes:
    # - audience_id
    # - keywords
    # - customer_url
    # - page_urls
    # - negative_keywords
    # - exclude_branded_keywords

    if _should_rerun_keyword_ideas(input, init_session_doc):
        kw_ideas_output = generate_keyword_ideas(
            google_session_id,
            customer_id,
            incl_locations,
            incl_languages,
            input["seed_keywords"],
            input["customer_url"],
            input["page_urls"],
            input["negative_keywords"],
            input["exclude_branded_keywords"],
        )
        keyword_ideas = kw_ideas_output["keywords"]

        content_for_session_doc["keyword_ideas"] = keyword_ideas
        content_for_session_doc["latest_keyword_ideas_doc_id"] = kw_ideas_output[
            "keyword_ideas_doc_id"
        ]
        # to overwrite google session doc with these values
        for c in _COL_TO_COMPARE:
            content_for_session_doc[c] = input[c]

    else:
        print(f"Getting keyword ideas from session_id {google_session_id}")
        keyword_ideas = init_session_doc["keyword_ideas"]

    # remove kw with too many words.
    # TODO: CONFIRM LIMIT
    keyword_ideas = [
        kw for kw in keyword_ideas if len(kw.split()) < MAX_WORDS_IN_KEYWORD
    ]

    ##############################
    #    CREATE KEYWORD PLANS    #
    ##############################
    init_cpc_bid = min(_MAX_CPC_BID, max_cpc)
    keywords_to_use_params = [
        {
            "text": kw,
            "cpc_bid": int(init_cpc_bid * MILLION),
            "match_type": _DEFAULT_KEYWORD_MATCH_TYPE,
        }
        for kw in keyword_ideas
    ]
    ad_groups = [
        {
            "name": "ad group #1",
            "keywords": keywords_to_use_params,
            "cpc_bid": int(init_cpc_bid * MILLION),
        }
    ]

    print(f"Num keywords passed to keyword plan: {len(keywords_to_use_params)}")
    keyword_plan_setting = add_keyword_plan(
        customer_id=customer_id,
        forecast_period=input["forecast_period"],
        keyword_plan_network=_DEFAULT_ADS_NETWORK,
        ad_groups=ad_groups,
        campaign_bid_cpc=int(init_cpc_bid * MILLION),
        incl_location_ids=incl_locations,
        incl_language_ids=incl_languages,
    )

    keyword_plan_rn = keyword_plan_setting["plan_resource_name"]
    plan_firestore_id = keyword_plan_setting["doc_id"]
    ad_group_resources = keyword_plan_setting["ad_group_resources"]

    if len(ad_group_resources) == 1:
        ad_group_resource = ad_group_resources[0]
    else:
        raise Exception(
            f"Expecting ad_group_resources to contain 1 element only. Received {len(ad_group_resources)}"
        )

    ################################
    #    HISTORICAL PERFORMANCE    #
    ################################

    print(f"Getting historical performance for keyword plan {keyword_plan_rn}")
    historical_results = get_historical_performance(keyword_plan_rn, plan_firestore_id)
    historical_results_df = pd.DataFrame(historical_results)
    print(f"Shape of historical_results_df: {historical_results_df.shape}")

    ###################################
    #    CALCULATE RECOMMENDED BID    #
    ###################################

    max_high_top_of_page_bid = _MULTIPLIER_TOP_OF_PAGE_BID * (
        historical_results_df["high_top_of_page_bid"].max()
    )
    print("max_high_top_of_page_bid: ", max_high_top_of_page_bid)

    historical_results_df["recommended_max_bid"] = historical_results_df[
        "high_top_of_page_bid"
    ].apply(lambda x: _recommend_bid(x, max_high_top_of_page_bid, max_cpc))

    ##################################################
    #      FIND KEYWORDS THAT REQUIRE BID UPDATE     #
    ###################################################

    # TODO: REMOVE KEYWORDS THAT DONT HAVE HISTORY

    historical_results_df["abs_bid_changes"] = (
        historical_results_df["recommended_max_bid"] - init_cpc_bid
    ).abs()

    # only updates if the bid changes by 1 unit
    keywords_to_update_bid_df = historical_results_df[
        historical_results_df["abs_bid_changes"] > 1
    ]

    ################################
    #      UPDATE WITH NEW BID     #
    ################################

    # from ad_group_resource, join with historical df and determine which
    # keywords need to be updated. then create a list of dict that contains the
    # new values and update keyword plan
    ad_group_resource_df = pd.DataFrame(ad_group_resource["keywords"])
    ad_group_resource_to_update_df = pd.merge(
        ad_group_resource_df.rename(columns={"text": "keyword"}),
        keywords_to_update_bid_df,
        on="keyword",
        how="inner",
    )
    keywords_to_update_bid_params = [
        {
            "text": kw,
            "cpc_bid": validate_and_fix_bid(int(bid * MILLION)),
            "match_type": _DEFAULT_KEYWORD_MATCH_TYPE,
            "resource_name": resource_name,
        }
        for kw, bid, resource_name in zip(
            ad_group_resource_to_update_df["keyword"],
            ad_group_resource_to_update_df["recommended_max_bid"],
            ad_group_resource_to_update_df["resource_name"],
        )
    ]
    print("Keywords to update in forecast:\n", keywords_to_update_bid_params)

    mutate_ad_group_keywords(
        customer_id=customer_id,
        keywords=keywords_to_update_bid_params,
        keyword_plan_ad_group_resource_name=ad_group_resource["resource_name"],
    )

    #################################
    #      FORECAST PERFORMANCE     #
    #################################

    # Based on the newly created keyword plan,
    # first get keyword level forecast for the NEXT QUARTER
    # then, get campaign level forecast on a weekly basis for the NEXT 52 WEEKS.
    # To get keyword level forecast for user-defined campaign duration,
    # calculate metric_sum_during_campaign_duration / metric_sum_within_next_quarter * keyword_level_metric_within_next_quarter

    forecasted_results = get_forecasted_performance(keyword_plan_rn, plan_firestore_id)
    forecasted_results_df = _process_forecast_to_df(forecasted_results["keyword"])

    weekly_forecast_results = get_campaign_weekly_forecast(keyword_plan_rn)
    weekly_forecast_results_df = _process_weekly_forecast(
        weekly_forecast_results, input["num_campaign_weeks"]
    )

    # calculate metrics ratio during campaign period relative to next quarter's
    # and scale keyword level forecase based on the new ratio
    ratios = _calculate_metric_ratios(weekly_forecast_results_df)
    forecasted_results_df = _scale_metrics(forecasted_results_df, ratios)

    ##### MERGE DATAFRAMES #######
    # this step remove keywords where forecasted metrics are 0
    print(f"Shape of historical data before merging: {historical_results_df.shape}")
    print(f"Shape of forecast data before merging: {forecasted_results_df.shape}")
    keyword_summary = pd.merge(
        historical_results_df,
        forecasted_results_df,
        on="keyword",
        how="inner",
        validate="1:1",
    )
    print(f"Shape after merging: {keyword_summary.shape}")

    print("avg CPC: ", forecasted_results_df["avg_cpc"].mean())

    keyword_summary = _calculate_ctr(keyword_summary)
    keyword_summary = _calculate_intent_score(keyword_summary)
    keyword_summary = _calculate_conversion(keyword_summary, conversion_rate)
    keyword_summary = _calculate_cpa(keyword_summary)

    if campaign_goal == "MAXIMISE_CONVERSION":
        min_clicks_for_one_conversion = 1 / conversion_rate
        print(
            f"Shape before removing rows where num_clicks below {min_clicks_for_one_conversion}: {keyword_summary.shape}"
        )

        keyword_summary = keyword_summary[
            (keyword_summary["clicks"] >= min_clicks_for_one_conversion)
            & (keyword_summary["recommended_max_bid"] > 0)
        ]

    print(
        f"Shape before removing rows where {col_to_maximise} is NA: {keyword_summary.shape}"
    )
    keyword_summary.dropna(subset=[col_to_maximise], inplace=True)
    print(f"Shape after: {keyword_summary.shape}")

    ##### POPULATE MISSING VALUES WITH DEFAULT #####
    fillna_dict = {
        "avg_monthly_searches": 0,
        "competition": "undefined",
        "high_top_of_page_bid": 0,
        "low_top_of_page_bid": 0,
        "l3m_avg_monthly_searches": 0,
        "recommended_max_bid": 0.01,
        "trend": "undefined",
        "cpa": 0,
        "ctr": 0,
    }
    for col, fill_value in fillna_dict.items():
        keyword_summary[col].fillna(fill_value, inplace=True)

    ##### CREATE NEW COL TO FLAG KEYWORDS THAT FORM THE BEST COMBO ######
    all_keywords_to_review = _label_optimal_keywords(
        keyword_summary, budget, col_to_maximise
    )

    all_keywords_to_review["proportionate_goal"] = (
        all_keywords_to_review["portion"] * all_keywords_to_review[col_to_maximise]
    )

    recommended_keywords_filter = all_keywords_to_review["proportionate_goal"] >= 1
    all_keywords_to_review.loc[recommended_keywords_filter, "is_recommended"] = True
    all_keywords_to_review["is_recommended"].fillna(False, inplace=True)

    all_keywords_to_review.loc[
        (all_keywords_to_review["portion"] < 1)
        & (all_keywords_to_review["is_recommended"]),
        "is_budget_limited",
    ] = True
    all_keywords_to_review["is_budget_limited"].fillna(False, inplace=True)

    print(
        "Recommend ",
        all_keywords_to_review.loc[
            all_keywords_to_review["is_recommended"], "keyword"
        ].tolist(),
    )
    print(all_keywords_to_review["is_recommended"].value_counts())

    # calculate revenue
    all_keywords_to_review["revenue"] = (
        all_keywords_to_review["conversion"] * avg_annual_revenue_per_user
    )

    # calculate roi
    all_keywords_to_review["roi_value"] = (
        all_keywords_to_review["revenue"] / all_keywords_to_review["cost"]
    )
    all_keywords_to_review["roi"] = pd.qcut(
        all_keywords_to_review["roi_value"], 3, labels=["LOW", "MED", "HIGH"]
    )

    # TODO: FIX PROPERLY
    all_keywords_to_review.loc[recommended_keywords_filter, "roi"] = "HIGH"
    all_keywords_to_review.loc[
        ~recommended_keywords_filter & (all_keywords_to_review["roi"] == "HIGH"), "roi"
    ] = "MED"

    for col in ["clicks", "impressions", "conversion", "revenue"]:
        all_keywords_to_review.loc[recommended_keywords_filter, col] = (
            all_keywords_to_review.loc[recommended_keywords_filter, col]
            * all_keywords_to_review.loc[recommended_keywords_filter, "portion"]
        ).astype(int)

    # create est_cost col
    all_keywords_to_review["est_cost"] = all_keywords_to_review["cost"]
    all_keywords_to_review.loc[recommended_keywords_filter, "est_cost"] = (
        all_keywords_to_review.loc[recommended_keywords_filter, "cost"]
        * all_keywords_to_review.loc[recommended_keywords_filter, "portion"]
    )

    ##### KEEP ONLY 1 ROW PER KEYWORD
    all_keywords_to_review = all_keywords_to_review.sort_values(
        by=["keyword", "is_recommended", "recommended_max_bid"],
        ascending=[True, False, True],
    ).drop_duplicates(subset=["keyword"], keep="first")

    ##### CHECK KEYWORDS THAT ARE PROVIDED BY USERS BUT NOT IN LIST #######
    keywords_with_metrics = all_keywords_to_review["keyword"].to_list()
    keywords_user_provided_without_metrics = [
        kw for kw in input["seed_keywords"] if kw not in keywords_with_metrics
    ]
    print(
        f"Keywords provided by users but don't have any metric: {keywords_user_provided_without_metrics}"
    )

    # RETURN RESULT
    # return at least 50 results. If num of recommended keywords exceed 50, return 1.2 x num_recommended results
    # so users always have options to see more keywords
    num_recommended = all_keywords_to_review[
        all_keywords_to_review["is_recommended"]
    ].shape[0]
    limit_num_results = int(max(_DEFAULT_LIMIT_RESULT, num_recommended * 1.2))

    # FLAG USER PROVIDED KEYWORDS
    all_keywords_to_review.loc[
        all_keywords_to_review["keyword"].isin(input["seed_keywords"]),
        "is_user_provided",
    ] = True
    all_keywords_to_review["is_user_provided"].fillna(False, inplace=True)

    output_json = (
        all_keywords_to_review[cols_to_return]
        .sort_values(by=["is_recommended", col_to_maximise], ascending=False)
        .head(limit_num_results)
        .to_dict(orient="records")
    )

    api_output = {
        "ccy": ccy,
        "keywords": output_json,
        "keyword_plan_resource_name": keyword_plan_rn,
        "user_provided_keywords_to_reject": keywords_user_provided_without_metrics,
        # "doc_id": doc_id,
    }

    #############################
    #      UPDATE FIRESTORE     #
    #############################

    recommendation_doc = {
        **api_output,
        "created_at": datetime.datetime.utcnow(),
        "keyword_plan_firestore_id": plan_firestore_id
        # "keywords_in_scope_id": session_input["latest_keywords_in_scope_id"],
    }
    recommendation_id = fs.add_subcollection_to_document(
        "google_sessions",
        google_session_id,
        "recommendations",
        recommendation_doc,
    )

    # update main session doc
    fs.update_document(
        "google_sessions",
        google_session_id,
        {
            "campaign_budget": budget,
            "preselect_keywords": [],
            "latest_recommendation_id": recommendation_id,
            "updated_at": datetime.datetime.utcnow(),
            "forecast_period": input["forecast_period"],
            "audience_id": input["audience_id"],
            "customer_id": customer_id,
            "ccy": ccy,
            "avg_annual_revenue_per_user": avg_annual_revenue_per_user,
            "conversion_rate": conversion_rate,
            "budget": budget,
            "campaign_goal": campaign_goal,
            **content_for_session_doc,
        },
    )
    return api_output


@setup
def mock(data: dict) -> dict:
    mandatory_fields = [
        "business_id",
        "auth_user_id",
        "conversion_rate",
        "avg_annual_revenue_per_user",
        "campaign_budget",
    ]
    validate_inputs(data, mandatory_fields)

    temp = {
        "ccy": "MYR",
        "keyword_plan_resource_name": "customers/1455945100/keywordPlans/368297025",
        "keywords": [
            {
                "avg_cpc": 2.834857066479938,
                "avg_monthly_searches": 170,
                "clicks": 48.0,
                "competition": "MEDIUM",
                "conversion": 7.0,
                "cpa": 18.899047109866252,
                "ctr": 0.08188187933228343,
                "est_cost": 138.43148866915266,
                "high_top_of_page_bid": 2.641336,
                "impressions": 596.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "medikal kad",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.086017,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 256.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 2.814198041360892,
                "avg_monthly_searches": 170,
                "clicks": 31.0,
                "competition": "MEDIUM",
                "conversion": 7.0,
                "cpa": 12.50754685049285,
                "ctr": 0.024412213946593347,
                "est_cost": 87.57702790884001,
                "high_top_of_page_bid": 5.980388,
                "impressions": 1274.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "great eastern medical insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.097122,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 245.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 2.6295287842346267,
                "avg_monthly_searches": 170,
                "clicks": 18.0,
                "competition": "LOW",
                "conversion": 4.0,
                "cpa": 11.686794596598343,
                "ctr": 0.07777707931699945,
                "est_cost": 47.6095594740474,
                "high_top_of_page_bid": 5.962677,
                "impressions": 232.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "aia a plus health",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.747074,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 142.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 1.8380124160678775,
                "avg_monthly_searches": 30,
                "clicks": 15.0,
                "competition": "HIGH",
                "conversion": 3.0,
                "cpa": 8.168944071412788,
                "ctr": 0.16988306851692175,
                "est_cost": 29.010946558017526,
                "high_top_of_page_bid": 4.762481,
                "impressions": 92.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "online medical malaysia",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.239408,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 124.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.0057855398799176,
                "avg_monthly_searches": 90,
                "clicks": 9.0,
                "competition": "MEDIUM",
                "conversion": 1.0,
                "cpa": 20.038570265866117,
                "ctr": 0.011808030635517183,
                "est_cost": 29.141128111318725,
                "high_top_of_page_bid": 5.376567,
                "impressions": 821.0,
                "intent": "undefined",
                "is_budget_limited": True,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "hospitalisation insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.06621,
                "portion": 0.61683819,
                "recommended_max_bid": 5.25,
                "revenue": 50.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 2.285885382227536,
                "avg_monthly_searches": 210,
                "clicks": 9.0,
                "competition": "LOW",
                "conversion": 1.0,
                "cpa": 15.239235881516908,
                "ctr": 0.08234694735183577,
                "est_cost": 21.216269937287723,
                "high_top_of_page_bid": 2.563425,
                "impressions": 112.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "medisafe infinite",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 0.944646,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 48.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 2.802209892840373,
                "avg_monthly_searches": 30,
                "clicks": 9.0,
                "competition": "MEDIUM",
                "conversion": 2.0,
                "cpa": 12.45426619040166,
                "ctr": 0.0818967119415672,
                "est_cost": 25.79642441303415,
                "high_top_of_page_bid": 4.561386,
                "impressions": 112.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "prudential medical plan",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 0.846214,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 72.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 2.30362053477218,
                "avg_monthly_searches": 170,
                "clicks": 8.0,
                "competition": "MEDIUM",
                "conversion": 1.0,
                "cpa": 10.238313487876354,
                "ctr": 0.10051896606352605,
                "est_cost": 18.842508390116937,
                "high_top_of_page_bid": 2.597239,
                "impressions": 81.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "prudential medical card brochure",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 0.713407,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 64.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 2.753988955440499,
                "avg_monthly_searches": 260,
                "clicks": 6.0,
                "competition": "MEDIUM",
                "conversion": 1.0,
                "cpa": 12.239950913068887,
                "ctr": 0.04246951716391577,
                "est_cost": 16.773844090710575,
                "high_top_of_page_bid": 5.4687,
                "impressions": 143.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "36 critical illness",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.413453,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 47.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 2.4128560021424996,
                "avg_monthly_searches": 30,
                "clicks": 6.0,
                "competition": "MEDIUM",
                "conversion": 1.0,
                "cpa": 10.723804453966665,
                "ctr": 0.09391506479221194,
                "est_cost": 15.893982359715224,
                "high_top_of_page_bid": 4.282506,
                "impressions": 70.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "allianz medical plan",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.484331,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 51.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 2.9696728774050736,
                "avg_monthly_searches": 20,
                "clicks": 6.0,
                "competition": "MEDIUM",
                "conversion": 1.0,
                "cpa": 13.198546121800325,
                "ctr": 0.0730246062102644,
                "est_cost": 20.254066689533207,
                "high_top_of_page_bid": 5.950339,
                "impressions": 93.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "great eastern medical plan",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.893788,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 53.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 0.5313306485465764,
                "avg_monthly_searches": 40,
                "clicks": 2.0,
                "competition": "LOW",
                "conversion": 0.0,
                "cpa": 2.361469549095895,
                "ctr": 0.2412853810375903,
                "est_cost": 1.5103336257739899,
                "high_top_of_page_bid": 0.0,
                "impressions": 11.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "medical claim form",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 0.0,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 22.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 2.84391815238665,
                "avg_monthly_searches": 210,
                "clicks": 2.0,
                "competition": "MEDIUM",
                "conversion": 0.0,
                "cpa": 12.639636232829556,
                "ctr": 0.06920445284038876,
                "est_cost": 6.895917240615876,
                "high_top_of_page_bid": 4.091703,
                "impressions": 35.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "standalone medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.527342,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 19.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 2.675499505111187,
                "avg_monthly_searches": 110,
                "clicks": 1.0,
                "competition": "MEDIUM",
                "conversion": 0.0,
                "cpa": 11.89110891160528,
                "ctr": 0.22195875646905897,
                "est_cost": 4.592301204580138,
                "high_top_of_page_bid": 2.975344,
                "impressions": 7.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "aia medical card monthly payment",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.095101,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 13.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 0.7936042805700088,
                "avg_monthly_searches": 30,
                "clicks": 1.0,
                "competition": "MEDIUM",
                "conversion": 0.0,
                "cpa": 3.527130135866706,
                "ctr": 0.10088998632961674,
                "est_cost": 1.4558581339862855,
                "high_top_of_page_bid": 3.162544,
                "impressions": 18.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "allianz medical card brochure",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.297084,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 14.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 2.5867087368080974,
                "avg_monthly_searches": 210,
                "clicks": 1.0,
                "competition": "MEDIUM",
                "conversion": 0.0,
                "cpa": 11.496483274702655,
                "ctr": 0.10098487294158301,
                "est_cost": 4.0718643827657175,
                "high_top_of_page_bid": 5.944363,
                "impressions": 15.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "critical illness list",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.265816,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 12.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 2.9801960347089715,
                "avg_monthly_searches": 50,
                "clicks": 1.0,
                "competition": "LOW",
                "conversion": 0.0,
                "cpa": 13.245315709817651,
                "ctr": 0.009537792513373472,
                "est_cost": 5.855068235382235,
                "high_top_of_page_bid": 7.074629,
                "impressions": 205.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "early critical illness",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.308529,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 15.0,
                "roi": "HIGH",
                "trend": "decrease",
            },
            {
                "avg_cpc": 3.482701260453262,
                "avg_monthly_searches": 880,
                "clicks": 1.0,
                "competition": "MEDIUM",
                "conversion": 0.0,
                "cpa": 23.21800840302175,
                "ctr": 0.05315545768833523,
                "est_cost": 3.8877342639158514,
                "high_top_of_page_bid": 6.056919,
                "impressions": 21.0,
                "intent": "undefined",
                "is_budget_limited": True,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "health insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.265895,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 5.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.5235541913629835,
                "avg_monthly_searches": 2400,
                "clicks": 1.0,
                "competition": "MEDIUM",
                "conversion": 0.0,
                "cpa": 23.490361275753223,
                "ctr": 0.05886255217211667,
                "est_cost": 3.837638172959802,
                "high_top_of_page_bid": 3.982192,
                "impressions": 18.0,
                "intent": "undefined",
                "is_budget_limited": True,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "insurance malaysia",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.73932,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 5.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 2.5121839190241637,
                "avg_monthly_searches": 50,
                "clicks": 1.0,
                "competition": "HIGH",
                "conversion": 0.0,
                "cpa": 11.165261862329617,
                "ctr": 0.06316621862940752,
                "est_cost": 4.304376918270271,
                "high_top_of_page_bid": 5.31996,
                "impressions": 27.0,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": True,
                "is_user_provided": False,
                "keyword": "outpatient medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.85172,
                "portion": 1.0,
                "recommended_max_bid": 5.25,
                "revenue": 13.0,
                "roi": "HIGH",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.899137947718143,
                "avg_monthly_searches": 4400,
                "clicks": 216.50902760639303,
                "competition": "MEDIUM",
                "conversion": 48.71453121143843,
                "cpa": 17.329501989858414,
                "ctr": 0.07345384088150628,
                "est_cost": 844.1985655636421,
                "high_top_of_page_bid": 5.198165,
                "impressions": 2947.552163482635,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "aia medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.495361,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 1705.008592400345,
                "roi": "MED",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.5415778588553537,
                "avg_monthly_searches": 1000,
                "clicks": 129.63720583068155,
                "competition": "MEDIUM",
                "conversion": 19.445580874602232,
                "cpa": 23.610519059035692,
                "ctr": 0.024723913747822207,
                "est_cost": 459.12025785381593,
                "high_top_of_page_bid": 18.775469,
                "impressions": 5243.393386376806,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": True,
                "keyword": "critical illness",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 3.082494,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 680.5953306110781,
                "roi": "LOW",
                "trend": "decrease",
            },
            {
                "avg_cpc": 3.6585275193040596,
                "avg_monthly_searches": 2400,
                "clicks": 99.9221205412651,
                "competition": "MEDIUM",
                "conversion": 22.482477121784648,
                "cpa": 16.260122308018044,
                "ctr": 0.06965618624676566,
                "est_cost": 365.5678277874358,
                "high_top_of_page_bid": 3.768323,
                "impressions": 1434.5046136645872,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "prudential medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.089796,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 786.8866992624627,
                "roi": "MED",
                "trend": "decrease",
            },
            {
                "avg_cpc": 3.5570027580292596,
                "avg_monthly_searches": 1900,
                "clicks": 71.21812311723832,
                "competition": "MEDIUM",
                "conversion": 16.024077701378623,
                "cpa": 15.808901146796709,
                "ctr": 0.07423962283958274,
                "est_cost": 253.32306034968408,
                "high_top_of_page_bid": 4.310726,
                "impressions": 959.3007129242387,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "great eastern medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.258124,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 560.8427195482518,
                "roi": "MED",
                "trend": "decrease",
            },
            {
                "avg_cpc": 3.759051213048644,
                "avg_monthly_searches": 90,
                "clicks": 67.27972397690309,
                "competition": "MEDIUM",
                "conversion": 10.091958596535463,
                "cpa": 25.060341420324292,
                "ctr": 0.04161186923270412,
                "est_cost": 252.90792802895547,
                "high_top_of_page_bid": 5.026968,
                "impressions": 1616.8397435034176,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "medical plan",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.91323,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 353.2185508787412,
                "roi": "LOW",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.4715694628900016,
                "avg_monthly_searches": 480,
                "clicks": 60.2868707761541,
                "competition": "MEDIUM",
                "conversion": 13.564545924634672,
                "cpa": 15.429197612844453,
                "ctr": 0.05107037489676391,
                "est_cost": 209.29005959969223,
                "high_top_of_page_bid": 6.185059,
                "impressions": 1180.4665796564223,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "aia medical insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.242779,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 474.7591073622135,
                "roi": "MED",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.9828284303423658,
                "avg_monthly_searches": 720,
                "clicks": 56.25160094212882,
                "competition": "HIGH",
                "conversion": 12.656610211978983,
                "cpa": 17.701459690410516,
                "ctr": 0.06704288460266904,
                "est_cost": 224.04047548458405,
                "high_top_of_page_bid": 5.777242,
                "impressions": 839.0390908073994,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "medical card malaysia",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.684113,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 442.9813574192644,
                "roi": "LOW",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.3677113458385035,
                "avg_monthly_searches": 170,
                "clicks": 55.228404240027885,
                "competition": "MEDIUM",
                "conversion": 12.426390954006273,
                "cpa": 14.967605981504462,
                "ctr": 0.05717234000565102,
                "est_cost": 185.99332357169723,
                "high_top_of_page_bid": 7.362035,
                "impressions": 965.9986670926711,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "allianz medical insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.427845,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 434.92368339021954,
                "roi": "MED",
                "trend": "decrease",
            },
            {
                "avg_cpc": 4.0592879366475225,
                "avg_monthly_searches": 260,
                "clicks": 53.39391547827296,
                "competition": "MEDIUM",
                "conversion": 12.013630982611417,
                "cpa": 18.04127971843343,
                "ctr": 0.09243333917432808,
                "est_cost": 216.74127699133084,
                "high_top_of_page_bid": 3.40181,
                "impressions": 577.6478049502542,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "aia family medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 0.962083,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 420.4770843913996,
                "roi": "LOW",
                "trend": "decrease",
            },
            {
                "avg_cpc": 4.161604479683887,
                "avg_monthly_searches": 1000,
                "clicks": 50.179019331435114,
                "competition": "HIGH",
                "conversion": 11.2902793495729,
                "cpa": 18.496019909706163,
                "ctr": 0.04342956197423844,
                "est_cost": 208.82523163584472,
                "high_top_of_page_bid": 9.752905,
                "impressions": 1155.411591790871,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "medical insurance malaysia",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 3.451888,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 395.15977723505154,
                "roi": "LOW",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.431687414645472,
                "avg_monthly_searches": 40,
                "clicks": 27.223692136076014,
                "competition": "HIGH",
                "conversion": 9.187996095925655,
                "cpa": 10.167962710060657,
                "ctr": 0.056700641509546096,
                "est_cost": 93.42320168355496,
                "high_top_of_page_bid": 6.41606,
                "impressions": 480.1302315334941,
                "intent": "commercial",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "best medical insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.755272,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 321.5798633573979,
                "roi": "MED",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.0349612984301815,
                "avg_monthly_searches": 170,
                "clicks": 25.107672920784438,
                "competition": "MEDIUM",
                "conversion": 5.649226407176498,
                "cpa": 13.488716881911918,
                "ctr": 0.04406522939064316,
                "est_cost": 76.20081560822425,
                "high_top_of_page_bid": 5.046976,
                "impressions": 569.784232783679,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "prudential medical insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.348185,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 197.72292425117743,
                "roi": "MED",
                "trend": "decrease",
            },
            {
                "avg_cpc": 4.184596641534037,
                "avg_monthly_searches": 590,
                "clicks": 24.980530135316275,
                "competition": "HIGH",
                "conversion": 5.620619280446162,
                "cpa": 18.598207295706832,
                "ctr": 0.038211175572600044,
                "est_cost": 104.53344250798429,
                "high_top_of_page_bid": 12.678016,
                "impressions": 653.7493223115852,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "health insurance malaysia",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 3.340636,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 196.72167481561567,
                "roi": "LOW",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.058825897815149,
                "avg_monthly_searches": 170,
                "clicks": 21.441722606452394,
                "competition": "MEDIUM",
                "conversion": 4.824387586451789,
                "cpa": 13.594781768067328,
                "ctr": 0.0621363912005321,
                "est_cost": 65.58649640238512,
                "high_top_of_page_bid": 5.997137,
                "impressions": 345.0751193009223,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "great eastern critical illness",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.381349,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 168.85356552581263,
                "roi": "MED",
                "trend": "constant",
            },
            {
                "avg_cpc": 4.024858962185286,
                "avg_monthly_searches": 70,
                "clicks": 19.498254314296187,
                "competition": "MEDIUM",
                "conversion": 4.387107220716642,
                "cpa": 17.88826205415683,
                "ctr": 0.07180397424942203,
                "est_cost": 78.47772362386293,
                "high_top_of_page_bid": 5.973292,
                "impressions": 271.548399905638,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "aia insurance medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.072823,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 153.54875272508247,
                "roi": "LOW",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.8019315184737383,
                "avg_monthly_searches": 880,
                "clicks": 18.865567596133182,
                "competition": "MEDIUM",
                "conversion": 4.244752709129966,
                "cpa": 16.897473415438835,
                "ctr": 0.04414070391251361,
                "est_cost": 71.72559605763558,
                "high_top_of_page_bid": 9.794171,
                "impressions": 427.39616553294053,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "axa medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.024427,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 148.56634481954882,
                "roi": "MED",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.488765587345013,
                "avg_monthly_searches": 720,
                "clicks": 18.723288764775955,
                "competition": "MEDIUM",
                "conversion": 4.21273997207459,
                "cpa": 15.505624832644504,
                "ctr": 0.046724756118636086,
                "est_cost": 65.32116552447387,
                "high_top_of_page_bid": 5.520308,
                "impressions": 400.7145316550556,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "allianz medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.467141,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 147.44589902261063,
                "roi": "MED",
                "trend": "decrease",
            },
            {
                "avg_cpc": 4.119309930635801,
                "avg_monthly_searches": 320,
                "clicks": 16.791929309330996,
                "competition": "HIGH",
                "conversion": 3.7781840945994745,
                "cpa": 18.30804413615911,
                "ctr": 0.07448520338740099,
                "est_cost": 69.17116115846153,
                "high_top_of_page_bid": 6.996189,
                "impressions": 225.43979939204027,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "family medical card",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 1.916631,
                "portion": 0.001,
                "recommended_max_bid": 5.25,
                "revenue": 132.2364433109816,
                "roi": "LOW",
                "trend": "constant",
            },
            {
                "avg_cpc": 3.7997835902181127,
                "avg_monthly_searches": 110,
                "clicks": 10.492307010301285,
                "competition": "HIGH",
                "conversion": 2.3607690773177894,
                "cpa": 16.887927067636056,
                "ctr": 0.060019934108637464,
                "est_cost": 39.86849600127329,
                "high_top_of_page_bid": 5.167651,
                "impressions": 174.81370424882454,
                "intent": "undefined",
                "is_budget_limited": False,
                "is_recommended": False,
                "is_user_provided": False,
                "keyword": "medical cover insurance",
                "l3m_avg_monthly_searches": 0.0,
                "low_top_of_page_bid": 2.335381,
                "portion": 0.0,
                "recommended_max_bid": 5.25,
                "revenue": 82.62691770612263,
                "roi": "MED",
                "trend": "decrease",
            },
        ],
        "user_provided_keywords_to_reject": [
            "investment linked insurance",
            "life insurance",
            "life insurance quote",
            "medical cards",
            "savings plans",
            "term life insurance",
        ],
    }

    return temp


###########################
#    PRIVATE FUNCTIONS    #
###########################


def _should_rerun_keyword_ideas(input: dict, init_session_doc: dict):
    for cc in _COL_TO_COMPARE:
        if cc not in init_session_doc:
            return True

        if not _are_values_equal(input[cc], init_session_doc[cc]):
            return True

    return False


def _are_values_equal(v0, v1):
    if isinstance(v0, list):
        v0.sort()
        v1.sort()

    return v0 == v1


def _label_optimal_keywords(
    keywords_df: pd.DataFrame, budget_limit: int, col_to_maximise: str
) -> pd.DataFrame:
    """Given a budget, find the combination of keywords that maximises target metrics

    Resources:
    https://bit.ly/3kSmjrI
    https://bit.ly/3oIfASr

    Args:
        keywords_df (pd.DataFrame): [description]
        budget_limit (int): [description]

    Returns:
        pd.DataFrame: dataframe with new col is_recommended
    """
    print("Num of keywords to optimise: ", keywords_df.shape[0])
    cut_off_goal = keywords_df[col_to_maximise].quantile(0.75)

    keywords_df["keyword_id"] = keywords_df["keyword"].str.replace(" ", "_")

    prob = LpProblem("Maximise_" + col_to_maximise, LpMaximize)

    # define variables which represent each keyword and
    # whether or not they should be included
    keyword_vars = LpVariable.dicts("keyword", keywords_df["keyword_id"], 0, 1)

    # objective function
    prob += lpSum(
        [
            goal * keyword_vars[kw]
            for kw, goal in zip(keywords_df["keyword_id"], keywords_df[col_to_maximise])
        ]
    )

    # constraint
    prob += (
        lpSum(
            [
                est_cost * keyword_vars[kw]
                for kw, est_cost in zip(keywords_df["keyword_id"], keywords_df["cost"])
            ]
        )
        <= budget_limit
    )
    # prob += lpSum(
    #     [
    #         est_cost * keyword_vars[kw]
    #         for kw, est_cost in zip(keywords_df["keyword_id"], keywords_df["est_cost"])
    #     ]
    # ) >= (budget_limit * 0.6)

    keywords_above_median = keywords_df.loc[
        keywords_df[col_to_maximise] > cut_off_goal, "keyword_id"
    ].tolist()
    for keyword_id in keywords_above_median:
        print(keyword_id)
        prob += keyword_vars[keyword_id] >= 0.001

    # get list of keywords to return
    if prob.solve() == 1:
        keyword_id_portions = {
            v.name.replace("keyword_", ""): v.varValue for v in prob.variables()
        }
    else:
        keyword_id_portions = {}

    keywords_df["portion"] = keywords_df["keyword_id"].map(keyword_id_portions)
    keywords_df["portion"].fillna(0, inplace=True)

    return keywords_df


def _calculate_ctr(keyword_df: pd.DataFrame) -> pd.DataFrame:
    keyword_df["ctr"] = keyword_df["clicks"] / keyword_df["impressions"]
    return keyword_df


def _calculate_conversion(
    keyword_df: pd.DataFrame, conversion_rate: float
) -> pd.DataFrame:
    if conversion_rate > 1:
        raise Exception(
            f"Expecting conversion rate to have value < 1. Received {conversion_rate}"
        )

    keyword_df["conversion"] = (
        keyword_df["clicks"] * conversion_rate * keyword_df["intent_score"]
    )
    return keyword_df


def _calculate_intent_score(keyword_df: pd.DataFrame) -> pd.DataFrame:
    intent_score = {
        "transactional": 2,
        "commercial": 1.5,
        "informative": 0.5,
        "undefined": 1,
    }

    keyword_df["intent"] = keyword_df["keyword"].apply(lambda x: _classify_intent(x))
    keyword_df["intent_only_score"] = keyword_df["intent"].map(intent_score).fillna(1)

    # assign score based on keyword length
    keyword_df["word_len"] = keyword_df["keyword"].str.split().str.len()

    filter_three_or_more_words = keyword_df["word_len"] >= 3
    filter_one_word = keyword_df["word_len"] == 1
    keyword_df["word_len_score"] = 1
    keyword_df.loc[filter_three_or_more_words, "word_len_score"] = 1.5
    keyword_df.loc[filter_one_word, "word_len_score"] = 0.2

    keyword_df["intent_score"] = (
        keyword_df["intent_only_score"] * keyword_df["word_len_score"]
    )

    return keyword_df


def _calculate_cpa(keyword_df: pd.DataFrame) -> pd.DataFrame:
    keyword_df["cpa"] = keyword_df["cost"] / keyword_df["conversion"]
    return keyword_df


def _classify_intent(keyword: str) -> str:
    intent_dict = {}
    intent_dict["transactional"] = [
        "buy",
        "order",
        "purchase",
        "cheap",
        "price",
        "discount",
        "shop",
        "sale",
        "offer",
        "cost",
        "near me",
        "nearest",
        "delivery",
        "online store",
    ]
    intent_dict["commercial"] = [
        "best",
        "top",
        "review",
        "comparison",
        "compare",
        "vs",
        "versus",
        "guide",
        "ultimate",
    ]
    intent_dict["informative"] = ["what", "who", "when", "which", "why", "how"]

    word_list = keyword.split(" ")

    for intent in ("transactional", "commercial", "informative"):
        for term in intent_dict[intent]:
            if term in word_list:
                return intent

    return "undefined"


def _process_forecast_to_df(keyword_forecasts: List[dict]) -> pd.DataFrame:
    metrics = ["avg_cpc", "clicks", "impressions"]

    forecasted_results_df = pd.DataFrame(keyword_forecasts)
    forecasted_results_df.rename(
        columns={"text": "keyword"}, inplace=True
    )  # TODO: MOVE TO get_forecasted_performance

    for col in metrics:
        forecasted_results_df[col] = pd.to_numeric(
            forecasted_results_df[col], errors="coerce"
        )

    forecasted_results_df.dropna(axis=0, subset=metrics, inplace=True)
    return forecasted_results_df


def _process_weekly_forecast(
    weekly_forecasts: List[dict], num_campaign_weeks: int
) -> pd.DataFrame:
    weekly_forecast_results_df = pd.DataFrame(weekly_forecasts)

    # process forecast start date col and format as datetime
    weekly_forecast_results_df["start_date_formatted"] = pd.to_datetime(
        weekly_forecast_results_df["start_date"]
    )
    weekly_forecast_results_df.sort_values(
        by="start_date_formatted", ascending=True, inplace=True
    )

    # label weeks that are within NEXT QUARTER
    weekly_forecast_results_df.loc[
        weekly_forecast_results_df.index < NUM_WEEKS_IN_QUARTER, "is_quarter"
    ] = True
    weekly_forecast_results_df["is_quarter"].fillna(False, inplace=True)

    # label weeks that are within campaign duration
    weekly_forecast_results_df.loc[
        weekly_forecast_results_df.index < num_campaign_weeks,
        "within_campaign_duration",
    ] = True
    weekly_forecast_results_df["within_campaign_duration"].fillna(False, inplace=True)

    return weekly_forecast_results_df


def _calculate_metric_ratios(weekly_forecast_results_df):
    ratios = {}
    for col in ["impressions", "clicks", "cost"]:
        quarter_sum = weekly_forecast_results_df.loc[
            weekly_forecast_results_df["is_quarter"] == True, col
        ].sum()

        campaign_duration_sum = weekly_forecast_results_df.loc[
            weekly_forecast_results_df["within_campaign_duration"] == True, col
        ].sum()

        ratios[col] = campaign_duration_sum / quarter_sum

    print("Ratios:\n", ratios)
    return ratios


def _scale_metrics(forecasted_results_df, ratios):
    for col in ["impressions", "clicks", "cost"]:
        col_name = f"{col}_full"
        forecasted_results_df[col_name] = forecasted_results_df[col]
        forecasted_results_df[col] = ratios[col] * forecasted_results_df[col_name]
    forecasted_results_df["avg_cpc"] = (
        forecasted_results_df["cost"] / forecasted_results_df["clicks"]
    )
    return forecasted_results_df


def _recommend_bid(
    high_top_of_page_bid: float, max_high_top_of_page_bid: float, max_cpc: float
) -> float:
    """Recommend bid based on the minimum of:
    - multiple of top of page bid if top of page bid for the keyword is not null and have value > 0.1
    - highest top of page bid across all keywords
    - max cpc the user can afford
    - max cpc universally (defined by us)

    Args:
        high_top_of_page_bid (float): [description]
        max_high_top_of_page_bid (float): [description]
        max_cpc (float): [description]

    Returns:
        float: [description]
    """

    candidates = [
        max_high_top_of_page_bid,
        max_cpc,
        _MAX_CPC_BID,
    ]

    if (not np.isnan(high_top_of_page_bid)) and high_top_of_page_bid > 0.1:
        candidates.append(_MULTIPLIER_TOP_OF_PAGE_BID * (high_top_of_page_bid + 0.01))

    bid = np.nanmin(candidates)
    return bid


if __name__ == "__main__":
    import os

    os.environ["ENV"] = "LOCAL"

    # input = {
    #     "business_id": "SWlTMQLhNmhit98gFu5j",
    #     "keywords": [
    #         "cat insurance",
    #         "pet insurance",
    #         "dog insurance",
    #         "insurance for pets",
    #     ],
    #     "customer_url": "www.oyen.my",
    #     "page_urls": [
    #         "https://www.msig.com.my/personal-insurance/products/Pet/",
    #     ],
    #     "negative_keywords": ["jason"],
    #     "exclude_branded_keywords": True,
    #     "campaign_goal": "MAXIMISE_IMPRESSION",
    #     "audience_id": "zZW0pVZNsPV1cCqgI2BA",
    #     "campaign_budget": 4000,
    #     "forecast_period": "NEXT_QUARTER",
    #     "avg_annual_revenue_per_user": 50,
    #     "conversion_rate": 20,
    #     "auth_user_id": "test_local",
    #     "google_session_id": "pM85jjABuL9dlrCROUrR",
    # }

    input = {
        "business_id": "SWlTMQLhNmhit98gFu5j",
        "audience_id": "KDIlePkyWfkSw30wVkI9",
        "google_session_id": "Et0OmgcjoRKvqOr6VOuW",
        "keywords": [
            "cat insurance",
            "pet insurance",
            "dog insurance",
            "insurance for pets",
        ],
        "customer_url": "www.oyen.my",
        "page_urls": ["https://www.msig.com.my/personal-insurance/products/Pet/"],
        "negative_keywords": [],
        "exclude_branded_keywords": True,
        "campaign_goal": "MAXIMISE_CLICK",
        "campaign_budget": 788,
        "start_time": "2022-01-06 00:00:00",
        "end_time": "2022-04-01 00:00:00",
        "avg_annual_revenue_per_user": 35,
        "conversion_rate": 15,
        "auth_user_id": "test_local",
    }
    output = main(input)
    keywords_df = pd.DataFrame(output["keywords"])
    keywords_df.to_csv("keywords_df.csv", index=0)
