import pandas as pd
from pytrends.request import TrendReq
from queries import get_country_code_by_criteria_id


def get_related_queries(keywords, incl_location_ids=[], timeframe="today 12-m"):
    if len(keywords) > 5:
        # raise Exception("Google Trends API only accept max 5 keywords")
        # TODO: MAKE INTO A LOOP
        keywords = keywords[:5]

    if len(keywords) == 0:
        raise Exception("No keyword provided to run Google Trend")

    output = []
    if len(incl_location_ids) > 0:
        country_codes = [
            get_country_code_by_criteria_id(id) for id in incl_location_ids
        ]

        for cc in country_codes:
            print("Processing ", cc)
            output += _run_single_trend_query(keywords, timeframe=timeframe, geo=cc)
    else:
        output = _run_single_trend_query(keywords, timeframe=timeframe)
    return output


def _run_single_trend_query(keywords, **kwargs):
    pytrends = TrendReq()
    pytrends.build_payload(kw_list=keywords, **kwargs)

    related_queries_raw = pytrends.related_queries()
    related_queries_df = _parse_results_to_df(results=related_queries_raw)

    if related_queries_df.shape[0] > 0:
        return related_queries_df["query"].unique().tolist()
    return []


def _parse_results_to_df(results):
    related_queries_list = []
    for term, type_v_df in results.items():
        for type_, df in type_v_df.items():
            if df is not None:
                df["search_term"] = term
                df["type"] = type_

                threshold = df["value"].quantile(0.5)
                df = df[df["value"] > threshold]
                related_queries_list.append(df)
    related_queries_df = pd.concat(related_queries_list)
    return related_queries_df


if __name__ == "__main__":
    keywords = ["life insurance", "health insurance", "buy insurance"]
    print(
        get_related_queries(
            keywords, incl_location_ids=["2458"], timeframe="today 12-m"
        )
    )
