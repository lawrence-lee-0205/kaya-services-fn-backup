from setup import setup

from databases.airtable.airtable import Airtable
from common import validate_inputs

_RECOMMENDATION_TABLE = "recommendations"


@setup
def main(data: dict) -> dict:
    mandatory_fields = ["business_id"]
    validate_inputs(data, mandatory_fields)

    business_id = data["business_id"]
    campaign_id = data.get("campaign_id")

    table = Airtable(_RECOMMENDATION_TABLE)
    all_data = table.get_all_rows()

    filtered = [
        d
        for d in all_data
        if (d.get("business_id", "") == business_id) and (d.get("show", False))
    ]

    # filter by campaign_id if it's provided
    if campaign_id is not None:
        filtered = [d for d in filtered if campaign_id == d.get("campaign_id", "")]

    output = {
        "recommendations": filtered,
        "business_id": business_id,
        "campaign_id": campaign_id,
    }
    return output


if __name__ == "__main__":
    data = {"business_id": "lyu6tWbXJlYQmfzi6uGg"}
    print(main(data))
    print()
    data2 = {
        "business_id": "lyu6tWbXJlYQmfzi6uGg",
        "campaign_id": "146yyLIra7N0P7nY4hbj",
    }
    print(main(data2))
