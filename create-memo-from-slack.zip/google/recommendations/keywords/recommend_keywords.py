# from pandas_gbq import schema
from datetime import datetime
import pandas as pd
import numpy as np
import enum

from nlp.clustering import group_keywords
from google.gutils.bigquery import load_local_file
from google.gutils.bigquery import run_query
from databases.bigquery.get_table_definition import get_table_definition

_PROJECT_ID = "kaya-apps-00"
_SCHEMA = "src_google_ads"
_TABLE = "search_keyword_with_score_daily"


class DerivedMetric(enum.Enum):
    def __new__(cls, *args, **kwds):
        value = len(cls.__members__) + 1
        obj = object.__new__(cls)
        obj._value_ = value
        return obj

    def __init__(self, score_trend, threshold, weight):
        self.score_trend = (
            score_trend  # asc means score increases as value increases. eg ROAS = asc
        )
        self.threshold = threshold  # if asc, anything below threshold will have score 0. if desc, anything above will have score 0
        self.weight = weight

    ROAS = "asc", 0.1, 6
    COST_PER_CONVERSION = "desc", 200, 6
    CLICK_THROUGH_RATE = "asc", 0.05, 2
    CONVERSION_RATE = "asc", 0.01, 4
    QUALITY_SCORE = "asc", 0.1, 1
    IMPRESSIONS = "asc", 10, 4
    DAILY_IMPRESSIONS = "asc", 2, 4


_KPI_BIZ_MAPPING = {
    "NtV6Ynivm40Ip4h2LmaO": DerivedMetric.COST_PER_CONVERSION,
    "q7RQxPR7p0U8P6uKm8Do": DerivedMetric.ROAS,
    "UshtKQ4c3TVDh0C6UJFa": DerivedMetric.COST_PER_CONVERSION,
    "H7LfqWsJcmC4sBXtXws0": DerivedMetric.COST_PER_CONVERSION,
    "vRLbGhzzXiADEqh9MmCu": DerivedMetric.ROAS,
}


def _calc_num_days(min_date, max_date):
    if isinstance(min_date, int) and isinstance(max_date, int):
        return 0

    # plus 1 as max_date is inclusive
    return (max_date - min_date).days + 1


def _calculate_keyword_score(df, kpi):
    score_params = [
        DerivedMetric.CLICK_THROUGH_RATE,
        DerivedMetric.QUALITY_SCORE,
        # DerivedMetric.CONVERSION_RATE,
        kpi,
    ]

    # TODO: USE DAILY IMPRESSIONS AND CONVERSION RATE
    # if "daily_impressions" in df.columns:
    #     score_params.append(DerivedMetric.DAILY_IMPRESSIONS)
    # else:
    score_params.append(DerivedMetric.IMPRESSIONS)

    # get rows that are eligible for scoring
    is_eligible_filter = True
    for param in score_params:
        col_name = param.name.lower()
        direction = param.score_trend

        if direction == "asc":
            is_eligible_filter = is_eligible_filter & (df[col_name] > param.threshold)
        else:
            is_eligible_filter = is_eligible_filter & (df[col_name] < param.threshold)

    # calculate score
    num_bins = 10

    score_cols = []
    for m in score_params:
        col_name = m.name.lower()
        direction = m.score_trend
        score_col_name = col_name + "_score"

        # if col contains inf, replace with large values
        has_infinite = np.isinf(df[col_name]).values.sum() > 0
        if has_infinite:
            # copy ori values
            df[col_name + "_ori"] = df[col_name]

            infinite_col_filter = np.isinf(df[col_name])
            df.loc[infinite_col_filter, col_name] = (
                df.loc[~infinite_col_filter, col_name].max() * 10
            )

        df[col_name + "_bin"] = pd.cut(df[col_name], num_bins, labels=range(num_bins))

        if direction == "asc":
            df[score_col_name] = df[col_name + "_bin"].cat.codes + 1
        else:
            df[score_col_name] = (
                df[col_name + "_bin"].cat.codes.max()
                - df[col_name + "_bin"].cat.codes
                + 1
            )

        df[score_col_name] *= m.weight
        score_cols.append(score_col_name)

        # for col that has infinite values, restore ori values
        if has_infinite:
            df[col_name] = df[col_name + "_ori"]

    df["score"] = df[score_cols].mean(axis=1)
    df.loc[is_eligible_filter, "score"] += 1000
    return df


def _get_active_keywords(business_id):
    sql = f"""
    SELECT 
        c.ad_group_id, 
        c.id as criterion_id,
        c.keyword_text,
        c.keyword_match_type,
        cc.id as google_campaign_id,
        cc.name as campaign_name,
        a.name as ad_group_name,
        c.quality_info_creative_score as creative_quality_score,
        c.quality_info_post_click_score as post_click_quality_score,
        c.quality_info_score as quality_score,
        c.system_serving_status
    FROM `kaya-apps-00.m_google_ads.ad_group_criterion` c
    join `kaya-apps-00.m_google_ads.ad_group` a 
        on c.ad_group_id = a.id
    join `kaya-apps-00.m_google_ads.campaign` cc
        on a.campaign_id = cc.id
    where a.business_id = '{business_id}'
        and c.status = 'ENABLED'
        and a.status = 'ENABLED'
        and cc.status = 'ENABLED'
        and c.type = 'KEYWORD'
        and negative is FALSE 
        -- and c.updated_at = (select max(updated_at) from `kaya-apps-00.m_google_ads.ad_group_criterion`)
    """
    df = run_query(sql, "dataframe")

    return df


def _get_keyword_performance_data(business_id: str, last_n_days: int):
    sql = f"""
    with base as (
        select 
            campaign_id as google_campaign_id,
            ad_group_id,
            ad_group_criterion_criterion_id as criterion_id,
            ccy,
            sum(impressions) as impressions, 
            sum(cost) as cost, 
            sum(clicks) as clicks,
            sum(conversions) as conversions,
            sum(conversions_value) as conversion_value,
            min(date) as min_date,
            max(date) as max_date,
        from `kaya-apps-00.m_google_ads.keyword_stats_daily`  c 
        where business_id = '{business_id}'
            and date >= CURRENT_DATE() - {last_n_days}
            and date < CURRENT_DATE()
        group by 1, 2, 3, 4
    )
    select 
        b.*,
        case when cost > 0 then conversion_value/cost end as roas,
        case when conversions > 0 then cost/conversions end as cost_per_conversion,
        case when impressions > 0 then 1000*cost/impressions end as cost_per_mille_impressions,
        case when impressions > 0 then 100*clicks/impressions end as click_through_rate,
        case when clicks > 0 then 100*conversions/clicks end as conversion_rate,
        case when clicks > 0 then cost/clicks end as cost_per_click,
    from base b
    """
    df = run_query(sql, "dataframe")
    df["num_days"] = df[["max_date", "min_date"]].apply(
        lambda x: _calc_num_days(x["min_date"], x["max_date"]), axis=1
    )
    return df


def _generate_histogram(df):
    keywords_with_perf_master_df = df.copy()

    hist_records = []
    for x in [
        "click_through_rate",
        "conversion_rate",
        "cost_per_conversion",
        "cost_per_click",
        "daily_impressions",
        "cost_per_mille_impressions",
        "roas",
    ]:
        print("Processing ", x)

        filter_non_null = ~keywords_with_perf_master_df[x].isnull()
        count, bin_edges = np.histogram(
            keywords_with_perf_master_df.loc[filter_non_null, x], bins=10
        )
        for idx in range(bin_edges.shape[0] - 1):
            hist_records.append(
                {
                    "start": bin_edges[idx],
                    "end": bin_edges[idx + 1],
                    "count": count[idx],
                    "metric": x,
                    "bin_index": idx,
                }
            )
    df = pd.DataFrame(hist_records)
    return df


def _upload_histogram(df):
    filename = "/tmp/histogram_df.csv"
    bq_table = f"{_PROJECT_ID}.{_SCHEMA}.search_keyword_histogram"

    columns = [
        "bin_index",
        "start",
        "end",
        "count",
        "metric",
        "as_of_date",
        "business_id",
        "last_n_days",
        "created_timestamp",
    ]
    df[columns].to_csv(filename, index=0)

    load_local_file(
        filename,
        bq_table,
        write_disposition="WRITE_APPEND",
        # write_disposition="WRITE_TRUNCATE",
        # schema=table_definition,
    )
    return None


def _upload_keywords_stats(df):
    filename = "/tmp/keywords_with_perf_master_df.csv"
    bq_table = f"{_PROJECT_ID}.{_SCHEMA}.{_TABLE}"

    table_definition = get_table_definition(_SCHEMA, _TABLE)["columns"]
    columns = [col["name"] for col in table_definition]

    for col in columns:
        if col not in df:
            df[col] = ""

    df[columns].to_csv(filename, index=0)

    load_local_file(
        filename,
        bq_table,
        write_disposition="WRITE_APPEND",
        # write_disposition="WRITE_TRUNCATE",
        schema=table_definition,
    )
    return None


def _add_metadata_cols(df, business_id, last_n_days):
    df["as_of_date"] = datetime.utcnow().date()
    df["business_id"] = business_id
    df["last_n_days"] = int(last_n_days)
    df["created_timestamp"] = datetime.utcnow()
    return df


def recommend_bid_keywords(business_id: str, last_n_days: int):
    # TODO: get all keywords from the account
    keywords_df = _get_active_keywords(business_id)

    # get keyword level performance
    keyword_stats_df = _get_keyword_performance_data(business_id, last_n_days)

    non_null_days_filter = keyword_stats_df["num_days"] > 0
    keyword_stats_df.loc[non_null_days_filter, "daily_impressions"] = (
        keyword_stats_df.loc[non_null_days_filter, "impressions"]
        / keyword_stats_df.loc[non_null_days_filter, "num_days"]
    )

    print(keywords_df.shape)
    print(keyword_stats_df.shape)

    # combine stats data with metadata
    keywords_with_perf_master_df = pd.merge(
        keywords_df,
        keyword_stats_df,
        how="left",
        on=["ad_group_id", "criterion_id", "google_campaign_id"],
        validate="1:1",
    )

    cols_fill_zero = [
        "quality_score",
        "impressions",
        "cost",
        "clicks",
        "conversions",
        "conversion_value",
        "roas",
        # "cost_per_conversion",
        "click_through_rate",
        "conversion_rate",
        "daily_impressions",
    ]
    fill_zero = {col: 0 for col in cols_fill_zero}
    keywords_with_perf_master_df.fillna(fill_zero, inplace=True)

    histogram_df = _generate_histogram(keywords_with_perf_master_df)
    histogram_df = _add_metadata_cols(histogram_df, business_id, last_n_days)
    _upload_histogram(histogram_df)

    # calculate score for each keyword
    keywords_with_perf_scored_df = _calculate_keyword_score(
        keywords_with_perf_master_df.copy(), _KPI_BIZ_MAPPING[business_id]
    )
    keywords_with_perf_scored_df["score_ranked_by_best"] = keywords_with_perf_scored_df[
        "score"
    ].rank(method="dense", ascending=False, na_option="bottom")

    for c in ["min_date", "max_date"]:
        keywords_with_perf_scored_df[c] = pd.to_datetime(
            keywords_with_perf_scored_df[c]
        ).dt.strftime("%Y-%m-%d")

    keywords_with_perf_scored_df = _add_metadata_cols(
        keywords_with_perf_scored_df, business_id, last_n_days
    )
    _upload_keywords_stats(keywords_with_perf_scored_df.copy())
    # calculate distribution for CPC, CTR
    return None


def _upload_negative_keywords(df):
    filename = "/tmp/negative_keywords.csv"
    table_name = "search_terms_for_negative_keywords"
    bq_table = f"{_PROJECT_ID}.{_SCHEMA}.{table_name}"

    table_definition = get_table_definition(_SCHEMA, table_name)["columns"]
    columns = [col["name"] for col in table_definition]

    df[columns].to_csv(filename, index=0)

    load_local_file(
        filename,
        bq_table,
        write_disposition="WRITE_APPEND",
        # write_disposition="WRITE_TRUNCATE",
        # schema=table_definition,
    )
    return None


def get_negative_keyword_candidates(negative_df):
    """Filter keywords that have impressions over a certain threshold and score below another threshold"""
    negative_kw_options = [
        # (0.99, 0.05),
        # (0.9, 0.05),
        # (0.8, 0.05),
        # (0.6, 0.05),
        # (0.4, 0.05),
        (0.8, 0.3),
        (0.6, 0.3),
        (0.4, 0.3),
        (0.4, 0.5),
    ]

    for option in negative_kw_options:
        impression_quantile_9 = negative_df["impressions"].quantile(option[0])
        score_quantile_1 = negative_df["score"].quantile(option[1])

        ng_kw_filter = (negative_df["impressions"] > impression_quantile_9) & (
            negative_df["score"] < score_quantile_1
        )

        neg_keywords_candidate = negative_df[ng_kw_filter].sort_values(by="score")

        print(
            f"Impressions above {impression_quantile_9}, Score below {score_quantile_1}"
        )
        print(neg_keywords_candidate.shape)

        if neg_keywords_candidate.shape[0] > 0:
            return neg_keywords_candidate
    return None


def _get_search_terms_stats(business_id, last_n_days):
    sql = f"""
    with keywords as (
        SELECT 
            c.ad_group_id, 
            cast(c.id as string) as criterion_id,
            c.keyword_text,
            c.keyword_match_type,
            cc.id as campaign_id,
            cc.name as campaign_name,
            a.name as ad_group_name,
            c.quality_info_creative_score as creative_quality_score,
            c.quality_info_post_click_score as post_click_quality_score,
            c.quality_info_score as quality_score,
            c.system_serving_status,
            c.status as keyword_status,
            a.status as ad_group_status,
            cc.status as campaign_status
        FROM `kaya-apps-00.m_google_ads.ad_group_criterion` c
        join `kaya-apps-00.m_google_ads.ad_group` a 
            on c.ad_group_id = a.id
        join `kaya-apps-00.m_google_ads.campaign` cc
            on a.campaign_id = cc.id
        where a.business_id = '{business_id}'
    ), stats as (
        SELECT
            date,
            search_term,
            search_term_match_type,
            status,
            cast(keyword_ad_group_criterion_id as string) as criterion_id,
            ad_group_id,
            campaign_id,
            sum(clicks) as clicks,
            sum(impressions) as impressions,
            sum(cost) as cost,
            sum(all_conversions_value) as conversion_value, 
            sum(all_conversions) as conversions
        FROM `kaya-apps-00.m_google_ads.search_term_stats_daily`
        where business_id = '{business_id}'
            and date >= CURRENT_DATE() - {last_n_days}
            and date < CURRENT_DATE()
        group by 1,2,3,4,5,6,7
    )
    select 
        s.*,
        keyword_text,
        keyword_match_type,
        campaign_name,
        ad_group_name,
        creative_quality_score,
        post_click_quality_score,
        quality_score,
        system_serving_status,
        case when cost > 0 then conversion_value/cost end as roas,
        case when impressions > 0 then clicks/impressions end as click_through_rate,
        case when conversions > 0 then cost/conversions end as cost_per_conversion
    from stats s
    left join keywords k 
        using (criterion_id, ad_group_id, campaign_id)
    where keyword_status = 'ENABLED'
        and ad_group_status	= 'ENABLED'
        and campaign_status = 'ENABLED'
    """
    df = run_query(sql, "dataframe")
    return df


def recommend_negative_keywords(business_id, last_n_days):
    search_term_df = _get_search_terms_stats(business_id, last_n_days)
    search_term_scored_df = _calculate_keyword_score(
        search_term_df.copy(), _KPI_BIZ_MAPPING[business_id]
    )

    neg_keywords_candidate = get_negative_keyword_candidates(search_term_scored_df)
    ng_suggestions_lst = []
    for names, grp in neg_keywords_candidate.groupby(
        ["campaign_name", "ad_group_name", "campaign_id", "ad_group_id"]
    ):
        print(names)
        temp_neg_kw_df = grp.sort_values(
            by=["score", "impressions"], ascending=[True, False]
        )
        search_term_lst = neg_keywords_candidate["search_term"].tolist()

        if len(search_term_lst) > 1:
            grouped = group_keywords(search_term_lst, 0.9)
            for group_name, elements in grouped.items():
                temp_neg_kw_df.loc[
                    temp_neg_kw_df["search_term"].isin(elements), "group_name"
                ] = group_name
        else:
            temp_neg_kw_df["group_name"] = temp_neg_kw_df["search_term"]

        # agg by group
        temp_neg_kw_df["search_term_within_group"] = temp_neg_kw_df["search_term"]
        temp_neg_kw_pivot_df = (
            pd.pivot_table(
                temp_neg_kw_df,
                index="group_name",
                values=[
                    "impressions",
                    "cost",
                    "clicks",
                    "conversion_value",
                    "conversions",
                    "quality_score",
                    "search_term",
                    "search_term_within_group",
                ],
                aggfunc={
                    "clicks": "sum",
                    "impressions": "sum",
                    "cost": "sum",
                    "conversion_value": "sum",
                    "conversions": "sum",
                    "quality_score": "mean",
                    "search_term": pd.Series.nunique,
                    "search_term_within_group": lambda x: ", ".join(list(set(x))),
                },
            )
            .reset_index()
            .sort_values(by="impressions", ascending=False)
        )

        temp_neg_kw_pivot_df["campaign_name"] = names[0]
        temp_neg_kw_pivot_df["ad_group_name"] = names[1]
        temp_neg_kw_pivot_df["campaign_id"] = names[2]
        temp_neg_kw_pivot_df["ad_group_id"] = names[3]
        ng_suggestions_lst.append(temp_neg_kw_pivot_df)

    ng_keywords_df = pd.concat(ng_suggestions_lst)
    ng_keywords_df = _add_metadata_cols(ng_keywords_df, business_id, last_n_days)

    _upload_negative_keywords(ng_keywords_df)

    return None


def main():
    for business_id in [
        "q7RQxPR7p0U8P6uKm8Do",
        "vRLbGhzzXiADEqh9MmCu",
        "H7LfqWsJcmC4sBXtXws0",
    ]:
        for d in [90, 7, 30, 60]:  #
            print(f"Processing {d}D...")
            recommend_bid_keywords(business_id=business_id, last_n_days=d)
            recommend_negative_keywords(business_id, last_n_days=d)
    return "Success"


if __name__ == "__main__":
    main()
