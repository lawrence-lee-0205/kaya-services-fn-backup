from firestore import FirestoreClient
from setup import setup
from common import validate_inputs

FS = FirestoreClient()


@setup
def get_gg_search_input_hints(data):
    mandatory_inputs = ["business_id", "auth_user_id"]
    validate_inputs(data, mandatory_inputs)

    doc = FS.get_single_document("google_search_hints", data["business_id"])
    return doc


if __name__ == "__main__":
    data = {"business_id": "SWlTMQLhNmhit98gFu5j", "auth_user_id": "test"}
    o = get_gg_search_input_hints(data)
    print(o)
