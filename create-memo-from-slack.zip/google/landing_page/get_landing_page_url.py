import pandas as pd
from typing import List

from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount
from utils.url import get_url_without_params


def main(business_id: str) -> List[dict]:
    """
    Only works for customer_id in Prod account. To run locally,
    set environment variable to LOCAL_PROD
    """
    # process ads account
    google_ads_account = GoogleAdsAccount(business_id=business_id)

    query = """
    SELECT 
        segments.date, 
        landing_page_view.resource_name, 
        landing_page_view.unexpanded_final_url, 
        campaign.name 
    FROM landing_page_view
    WHERE segments.date >= '2024-04-01'
        AND segments.date < '2024-04-17'
    """
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )

    links = []
    for row in rows:
        full_url = row.landing_page_view.unexpanded_final_url.replace("{ignore}", "")
        links.append(
            {
                "date": row.segments.date,
                "resource_name": row.landing_page_view.resource_name,
                "unexpanded_final_url": full_url,
                "campaign_name": row.campaign.name,
                "url": get_url_without_params(full_url),
            }
        )
    return links


if __name__ == "__main__":
    links = main("WMMViNa0CiauqVUwsB60")
    links_df = pd.DataFrame(links)
    print(links_df)

    print()
    print("\n".join(links_df["url"].unique()))
