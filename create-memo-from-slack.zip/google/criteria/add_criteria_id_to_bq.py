import pandas as pd

from firestore import FirestoreClient
from google.gutils.bigquery import run_query
from google.gutils.ads_query import run_ads_query
from google.accounts.ads_account import GoogleAdsAccount


def main(business_id):
    # get data about the google ads account
    acc = GoogleAdsAccount(business_id=business_id)

    fs = FirestoreClient()
    campaigns_ref = fs.get_collection("google_campaigns")

    # Get a list of criteria IDs that exist in google_campaigns docs
    all_criteria_ids = []
    for doc in campaigns_ref.stream():
        doc_id = doc.id
        content = doc.to_dict()

        print("Processing ", doc_id)
        campaign_criteria = content["campaign_criteria"]  # list of dict
        campaign_criteria_ids = [
            str(d["criterion_id"]) for d in campaign_criteria if d["type"] == "location"
        ]
        all_criteria_ids += campaign_criteria_ids

    unique_criteria_ids = list(set(all_criteria_ids))

    # Get list of criteria ids available in BQ
    sql = f"""
    SELECT distinct criteria_id
    FROM `kaya-apps-00.google_ads.geotargets`
    WHERE criteria_id in ({', '.join(unique_criteria_ids)})
    """
    bq_criteria_ids_raw = run_query(sql)
    bq_criteria_ids = [str(c["criteria_id"]) for c in bq_criteria_ids_raw]

    # Query Google Ads to get info on criteria ids
    # that exist in google campaigns but NOT in BQ
    not_in_bq_criteria_ids = [
        c for c in unique_criteria_ids if c not in bq_criteria_ids
    ]
    if len(not_in_bq_criteria_ids) == 0:
        print("All criteria IDs exist in BQ. Terminating script..")
        return None

    sql = f"""
    SELECT 
        geo_target_constant.id, 
        geo_target_constant.name, 
        geo_target_constant.canonical_name, 
        geo_target_constant.parent_geo_target, 
        geo_target_constant.country_code, 
        geo_target_constant.target_type, 
        geo_target_constant.status 
    FROM geo_target_constant 
    where geo_target_constant.id IN {tuple(not_in_bq_criteria_ids)}
    """
    rows = run_ads_query(acc.client_id, sql, acc.ads_manager_id)

    outputs = []
    for row in rows:
        geo_target_constant = row.geo_target_constant
        parent_id = float(geo_target_constant.parent_geo_target.split("/")[1])

        output = {
            "status": geo_target_constant.status.name,
            "parent_id": parent_id,
            "criteria_id": geo_target_constant.id,
            "name": geo_target_constant.name,
            "country_code": geo_target_constant.country_code,
            "target_type": geo_target_constant.target_type,
            "canonical_name": geo_target_constant.canonical_name,
        }
        outputs.append(output)

    df = pd.DataFrame(outputs)

    # check if all criteria IDs we are supposed to add to BQ is found on the dataset to be uploaded
    criteria_id_to_add = df["criteria_id"].unique()
    criteria_ids_still_missing = [
        x for x in not_in_bq_criteria_ids if x not in criteria_id_to_add
    ]

    if len(criteria_ids_still_missing) > 0:
        raise Exception(
            f"The following criteria IDs are still missing: {criteria_ids_still_missing}\nSkipping upload.."
        )

    print("Uploading data")
    df.to_gbq("kaya-apps-00.google_ads.geotargets", "kaya-apps-00", if_exists="append")
    print("Data uploaded")
    return None


if __name__ == "__main__":
    main(business_id="s1ssHGiuT2S1vHBgdAe2")
