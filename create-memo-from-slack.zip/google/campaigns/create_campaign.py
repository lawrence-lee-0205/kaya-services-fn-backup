import datetime
from typing import List
from google.ads.googleads.errors import GoogleAdsException

from common import (
    handle_googleads_exception,
    validate_non_empty_list,
    validate_non_empty_string,
    validate_datetime,
)
from setup import setup
from constants import (
    DATE_WITHOUT_DASH,
    MAX_GOOGLE_KEYWORDS_CHAR_COUNT,
    MAX_GOOGLE_KEYWORDS_WORD_COUNT,
)
from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.utilities import get_api_client
from google.gutils.conversion import convert_to_micro_unit
from google.campaigns.campaign_utils import add_campaign_criteria
from google.campaigns.extensions import (
    CalloutExtension,
    PromotionExtension,
    SitelinkExtension,
)
from google.gutils.api_queue import Queue
from queries import get_google_audience

_ACCEPTABLE_CAMPAIGN_CRITERIA = ["location", "language"]
_DEFAULT_BUDGET_DELIVERY_METHOD = "standard"
_DEFAULT_CAMPAIGN_STATUS = "paused"


@setup
def create_gg_campaign(data: dict) -> dict:
    """
    Create 3 or more ads per ad group, and optimize how they show.
    With at least 3 ads available in each ad group, the one most relevant to the
    query gets selected. So Google shows the ad predicted to have the highest chance
    of getting you the clicks or conversions you want.

    For successful account organization, be sure to create very specific ad groups.
    For example, if you sell gourmet food, create different ad groups for different foods you offer.
    A cookie-loving customer is more likely to click an ad about cookies than a generic ad about food.
    Specificity and detail helps your ads be more relevant. Relevance tends to lead to higher quality ads
    that perform better in the ad auction (and generate more conversions).

    End date is inclusive, ie that's the last day ads will run
    """
    from firestore import FirestoreClient
    from queries import get_google_account
    from common import validate_inputs

    # TODO: DELETE CAMPAIGN ON ERROR
    mandatory_fields = [
        "business_id",
        "campaign_name",
        "campaign_budget_amount",
        "ad_groups",
        "google_session_id",
        "auth_user_id",
    ]
    collection_to_write = "google_campaigns"

    ##################################
    #    VALIDATE & PROCESS INPUTS   #
    ##################################
    validate_inputs(data, mandatory_fields)

    validate_non_empty_string(data["google_session_id"], "google_session_id")

    business_id = data["business_id"]
    google_acc = GoogleAdsAccount(business_id=business_id)
    client_id = google_acc.client_id
    manager_id = google_acc.ads_manager_id
    ccy = google_acc.ccy

    client = get_api_client(manager_id)

    # process dates
    campaign_start_time = (
        validate_datetime(data["start_time"], "start_time")
        if "start_time" in data
        else datetime.datetime.today() + datetime.timedelta(days=1)
    )
    campaign_end_time = (
        validate_datetime(data["end_time"], "end_time")
        if "end_time" in data
        else campaign_start_time + datetime.timedelta(weeks=4)
    )
    dates_payload = _process_dates(campaign_start_time, campaign_end_time)

    # process budget
    budget_payload = _process_budget(
        data["campaign_budget_amount"], dates_payload["num_campaign_days"]
    )

    # process ad groups
    ad_group_payload = _process_ad_groups(data["ad_groups"])

    # process extensions
    # CALL extension is only available for v9
    extension_payload = data.get("extensions", {})

    #################################
    #        CREATE CAMPAIGN        #
    #################################

    campaign_status = data.get("campaign_status", _DEFAULT_CAMPAIGN_STATUS)

    # create new campaign entry
    campaign_rn = create_campaign(
        client,
        client_id,
        data["campaign_name"],
        budget_payload["daily_budget_micros"],
        dates_payload["campaign_start_time"],
        dates_payload["campaign_end_time"],
        campaign_status,
    )

    # add targeting
    campaign_audiences = data.get("campaign_audiences", [])
    negative_keywords = data.get("negative_keywords", [])

    campaign_criteria_output = []
    if (len(campaign_audiences) > 0) or (len(negative_keywords) > 0):
        campaign_criteria_output = add_campaign_targeting(
            client, client_id, campaign_rn, campaign_audiences, negative_keywords
        )

    # add ad groups
    ad_groups_output = add_ad_groups_with_keywords(
        client, client_id, campaign_rn, ad_group_payload["ad_groups"]
    )

    # add extensions
    extensions_output = []
    if len(extension_payload) > 0:
        extensions_output = add_extensions(
            client, client_id, campaign_rn, extension_payload
        )

    #################################
    #           CHANGELOG           #
    #################################

    changelogs = [
        {
            "date": datetime.datetime.utcnow(),
            "value": f"Draft campaign created, with status as {campaign_status}.",
            "user_id": data["auth_user_id"],
        },
    ]

    ################################
    #      WRITE TO FIRESTORE      #
    ################################

    fs = FirestoreClient()
    doc = {
        **ad_group_payload,
        **dates_payload,
        **budget_payload,
        "extensions_setting": extension_payload,
        "business_id": business_id,
        "client_id": client_id,
        "ccy": ccy,
        "campaign_resource_name": campaign_rn,
        "campaign_criteria": campaign_criteria_output,
        "campaign_name": data["campaign_name"],
        "created_by": data["auth_user_id"],
        "created_at": datetime.datetime.now(),
        "ad_groups": ad_groups_output,
        "campaign_status": campaign_status,
        "extensions": extensions_output,
        "changelogs": changelogs,
    }
    campaign_id = fs.add_document(collection_to_write, doc)

    # update main session doc
    fs.update_document(
        "google_sessions",
        data["google_session_id"],
        {"google_campaign_id": campaign_id, "updated_at": datetime.datetime.utcnow()},
    )

    output = {
        "campaign_id": campaign_id,
    }
    return {"data": output}


def create_campaign(
    client,
    customer_id,
    campaign_name,
    daily_budget_micros,
    start_time,
    end_time,
    campaign_status=_DEFAULT_CAMPAIGN_STATUS,
):
    ####################
    #      Mapping     #
    ####################

    # process campaign status
    acceptable_campaign_statuses = [e.name for e in client.enums.CampaignStatusEnum]
    if campaign_status.upper() not in acceptable_campaign_statuses:
        raise Exception(
            "Provided value for param 'campaign_status' is not acceptable. Only accepts: "
            + acceptable_campaign_statuses
        )

    # Add budget
    budget_resource_name = create_budget(
        client, customer_id, campaign_name, daily_budget_micros
    )

    # Create campaign.
    campaign_operation = client.get_type("CampaignOperation")
    campaign = campaign_operation.create
    campaign.name = campaign_name
    campaign.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.SEARCH

    # Recommendation: Set the campaign to PAUSED when creating it to prevent
    # the ads from immediately serving. Set to ENABLED once you've added
    # targeting and the ads are ready to serve.
    campaign.status = client.enums.CampaignStatusEnum[campaign_status.upper()]

    # Set the bidding strategy and budget.
    # https://developers.google.com/google-ads/api/reference/rpc/v8/Campaign#campaign_bidding_strategy
    campaign.manual_cpc.enhanced_cpc_enabled = (
        False  # can only set to True if conversion tracking is in place
    )
    campaign.campaign_budget = budget_resource_name

    # Set the campaign network options.
    campaign.network_settings.target_google_search = True
    campaign.network_settings.target_search_network = False
    campaign.network_settings.target_content_network = False
    campaign.network_settings.target_partner_search_network = False

    # Optional: Set the start date and end date.
    # Google adds 1 day to end date on their end, so we need to minus 1 day here
    campaign.start_date = datetime.date.strftime(start_time, DATE_WITHOUT_DASH)
    campaign.end_date = datetime.date.strftime(
        end_time - datetime.timedelta(days=1), DATE_WITHOUT_DASH
    )

    # add tracking
    campaign.tracking_url_template = "{lpurl}?utm_source={_utmsource}&utm_medium={_utmmedium}&utm_campaign={campaignid}&campaignid={campaignid}&adgroupid={adgroupid}&keyword={keyword}&device={device}"

    # CustomParameter can be provided at campaign, ad group, ad, criterion, or feed
    # item levels.
    utm_source = client.get_type("CustomParameter")
    utm_source.key = "utmsource"
    utm_source.value = "kaya"

    utm_medium = client.get_type("CustomParameter")
    utm_medium.key = "utmmedium"
    utm_medium.value = "search"

    campaign.url_custom_parameters.extend([utm_source, utm_medium])

    # Add the campaign.
    Queue("campaign").queue(function="mutate_campaigns", num_operations=1)
    campaign_service = client.get_service("CampaignService")
    campaign_response = campaign_service.mutate_campaigns(
        customer_id=customer_id, operations=[campaign_operation]
    )
    campaign_rn = campaign_response.results[0].resource_name
    print(f"Created campaign {campaign_rn}.")

    return campaign_rn


def add_campaign_targeting(
    client,
    client_id,
    campaign_resource_name,
    campaign_audiences=[],
    negative_keywords=[],
):
    """campaign_audiences = [
        {"criteria_ids": ["1", "2"], "type": "location", "is_include": True},
    ]

    Args:
        client (_type_): _description_
        client_id (_type_): _description_
        campaign_resource_name (_type_): _description_
        campaign_audiences (list, optional): _description_. Defaults to [].
        negative_keywords (list, optional): _description_. Defaults to [].

    Raises:
        Exception: _description_
        Exception: _description_

    Returns:
        _type_: _description_
    """
    print("Adding targeting criteria to campaign")

    try:
        criteria = []
        # process audience
        for ca in campaign_audiences:
            audience = get_google_audience(ca)

            # TODO: DEAL WITH EXCLUDES
            for criterion_type, criteria_ids in audience["includes"].items():
                # values = list of criteria IDs
                if criterion_type not in _ACCEPTABLE_CAMPAIGN_CRITERIA:
                    raise Exception(
                        f"Audience type is not valid. Only accept {_ACCEPTABLE_CAMPAIGN_CRITERIA}. Provided value: {criterion_type}"
                    )

                criteria += [
                    {"criterion_id": criterion_id, "type": criterion_type}
                    for criterion_id in criteria_ids
                ]

        # process negative keywords
        criteria += [
            {"criterion_id": neg, "type": "negative_keyword_phrase"}
            for neg in negative_keywords
        ]

        outputs = add_campaign_criteria(
            client, client_id, campaign_resource_name, criteria
        )
    except Exception as e:
        print(e)
        raise Exception(f"Encounter error while creating campaign audience: {str(e)}")

    return outputs


def add_ad_groups_with_keywords(client, customer_id, campaign_resource_name, ad_groups):
    outputs = []
    for idx, ad_group in enumerate(ad_groups):
        try:
            # VALIDATE AD GROUP INPUT
            num_headlines = len(ad_group["headlines"])
            num_descriptions = len(ad_group["descriptions"])
            if (num_headlines < 3) or (num_headlines > 15):
                raise Exception(
                    f"Num of headlines must be at least 3 and no more than 15. Ad group details: {ad_group}"
                )

            for headline in ad_group["headlines"]:
                headline_lowercase = headline.lower()
                if "{keyword:" not in headline_lowercase and len(headline) > 30:
                    # ignore keyword insertion
                    raise Exception(
                        f"Headline can only contain up to 30 characters. Headline: {headline}."
                    )

            if (num_descriptions < 2) or (num_descriptions > 4):
                raise Exception(
                    f"Num of description must be at least 2 and no more than 4. Ad group details: {ad_group}"
                )

            for desc in ad_group["descriptions"]:
                if len(desc) > 90:
                    raise Exception(
                        f"Description can only contain up to 90 characters. Description: {desc}."
                    )
        except Exception as e:
            print(f"🔴 Ignoring { ad_group['name']}. Skipping to next ad group")
            print("Please recreate later")

        # CREATE AD GROUP
        try:
            output = ad_group

            print(f"Processing ad group #{idx}")
            ad_group_rn = _create_ad_group(
                client,
                customer_id,
                campaign_resource_name,
                ad_group["name"],
            )
            keywords_rns = _create_ad_group_keywords(
                client, customer_id, ad_group_rn, ad_group["keywords"]
            )

            _create_responsive_search_ads(
                client,
                customer_id,
                ad_group_rn,
                ad_group["url"],
                ad_group["headlines"],
                ad_group["descriptions"],
                ad_group.get("pinned_headline", ""),
                ad_group.get("ad_display_path_1", ""),
                ad_group.get("ad_display_path_2", ""),
            )

            output["resource_name"] = ad_group_rn
            output["keywords"] = keywords_rns
            outputs.append(output)
        except GoogleAdsException as ex:
            handle_googleads_exception(ex)
        except Exception as e:
            print(e)
            print(f"🔴 Encounter error while creating ad groups: {str(e)}")
    return outputs


def create_budget(
    client,
    customer_id,
    campaign_name,
    daily_budget_amount,
    budget_delivery_method=_DEFAULT_BUDGET_DELIVERY_METHOD,
):
    # BUDGET DELIVERY METHOD
    # standard: throttle serving evenly across the entire time period
    # accelerated: will not throttle serving, and ads will serve as fast as possible.
    # https://developers.google.cn/google-ads/api/reference/rpc/v8/BudgetDeliveryMethodEnum.BudgetDeliveryMethod?hl=ar-LY
    acceptable_budget_delivery_methods = [
        e.name for e in client.enums.BudgetDeliveryMethodEnum
    ]
    if budget_delivery_method.upper() not in acceptable_budget_delivery_methods:
        raise Exception(
            "Provided value for param 'budget_delivery_method' is not acceptable. Only accepts: "
            + acceptable_budget_delivery_methods
        )

    campaign_budget_name = f"Budget for {campaign_name} {datetime.datetime.utcnow()}"

    # Create a budget, which can be shared by multiple campaigns.
    campaign_budget_operation = client.get_type("CampaignBudgetOperation")
    campaign_budget = campaign_budget_operation.create
    campaign_budget.name = campaign_budget_name
    campaign_budget.delivery_method = client.enums.BudgetDeliveryMethodEnum[
        budget_delivery_method.upper()
    ]
    campaign_budget.amount_micros = daily_budget_amount
    campaign_budget.period = client.enums.BudgetPeriodEnum["DAILY"]

    # Add budget to campaign
    Queue("campaign_budget").queue(function="mutate_campaign_budgets", num_operations=1)
    campaign_budget_service = client.get_service("CampaignBudgetService")
    campaign_budget_response = campaign_budget_service.mutate_campaign_budgets(
        customer_id=customer_id, operations=[campaign_budget_operation]
    )
    budget_resource_name = campaign_budget_response.results[0].resource_name
    return budget_resource_name


###########################
#    PRIVATE FUNCTIONS    #
###########################


def _create_ad_group(client, customer_id, campaign_resource_name, name):
    name_replaced = name.replace(" ", "-")
    # Create ad group.
    ad_group_operation = client.get_type("AdGroupOperation")
    ad_group = ad_group_operation.create
    ad_group.name = name_replaced
    ad_group.status = client.enums.AdGroupStatusEnum.ENABLED
    ad_group.campaign = campaign_resource_name
    ad_group.type_ = client.enums.AdGroupTypeEnum.SEARCH_STANDARD

    # TODO: ONLY FOR RIPPLING
    # param_adgroup = client.get_type("CustomParameter")
    # param_adgroup.key = "adgroup"
    # param_adgroup.value = name_replaced

    # ad_group.url_custom_parameters.extend([param_adgroup])

    # Add the ad group.
    Queue("ad_group").queue(function="mutate_ad_groups", num_operations=1)
    ad_group_service = client.get_service("AdGroupService")
    ad_group_response = ad_group_service.mutate_ad_groups(
        customer_id=customer_id, operations=[ad_group_operation]
    )
    ad_group_rn = ad_group_response.results[0].resource_name
    print(f"Created ad group {ad_group_rn}.")
    return ad_group_rn


def _create_ad_group_keywords(client, customer_id, ad_group_resource_name, keywords):
    """
    More criterion: https://developers.google.com/google-ads/api/reference/rpc/v8/AdGroupCriterion
    """
    # Create keyword.
    operations = []
    for keyword in keywords:
        ad_group_criterion_operation = client.get_type("AdGroupCriterionOperation")
        ad_group_criterion = ad_group_criterion_operation.create
        ad_group_criterion.ad_group = ad_group_resource_name
        ad_group_criterion.status = client.enums.AdGroupCriterionStatusEnum.ENABLED
        ad_group_criterion.keyword.text = keyword["text"]
        ad_group_criterion.keyword.match_type = client.enums.KeywordMatchTypeEnum[
            keyword["match_type"].upper()
        ]
        operations.append(ad_group_criterion_operation)

    # Optional field
    # All fields can be referenced from the protos directly.
    # The protos are located in subdirectories under:
    # https://github.com/googleapis/googleapis/tree/master/google/ads/googleads
    # ad_group_criterion.negative = True

    # Optional repeated field
    # ad_group_criterion.final_urls.append('https://www.example.com')

    # Add keyword
    # TODO: BATCH BY 50 AT A TIME
    Queue("ad_group_criterion").queue(
        function="mutate_ad_group_criteria", num_operations=len(operations)
    )
    ad_group_criterion_service = client.get_service("AdGroupCriterionService")
    ad_group_criterion_response = ad_group_criterion_service.mutate_ad_group_criteria(
        customer_id=customer_id,
        operations=operations,
    )

    keyword_resource_names = []
    for idx, result in enumerate(ad_group_criterion_response.results):
        # print("Created keyword " f"{result.resource_name}.")
        keyword_resource_names.append(
            {"keyword": keywords[idx], "resource_name": result.resource_name}
        )
    return keyword_resource_names


def _create_responsive_search_ads(
    client,
    customer_id,
    ad_group_resource_name,
    url,
    headlines,
    descriptions,
    pinned_headline=None,
    ad_display_path_1="",
    ad_display_path_2="",
):
    """
    Enter 3 to 15 headlines. Headlines appear at the top of your ad and can be up to 30 characters.

    Enter 2 to 4 descriptions. Your ad's description appears below the display URL and can be up to 90 characters.

    Enter at least one final URL
    """
    ad_group_ad_service = client.get_service("AdGroupAdService")

    # Create the ad group ad.
    ad_group_ad_operation = client.get_type("AdGroupAdOperation")
    ad_group_ad = ad_group_ad_operation.create
    ad_group_ad.status = client.enums.AdGroupAdStatusEnum.PAUSED
    ad_group_ad.ad_group = ad_group_resource_name

    # Set responsive search ad info.
    ad_group_ad.ad.final_urls.append(url)

    headline_text_assets = []
    for headline in headlines:
        # print("Adding headline: ", headline)
        headline_text_assets.append(_create_ad_text_asset(client, headline))

    # Set a pinning to always choose this asset for HEADLINE_1. Pinning is
    # optional; if no pinning is set, then headlines and descriptions will be
    # rotated and the ones that perform best will be used more often.
    if (pinned_headline is not None) and (pinned_headline != ""):
        served_asset_enum = client.enums.ServedAssetFieldTypeEnum.HEADLINE_1
        pinned_headline = _create_ad_text_asset(
            client, pinned_headline, served_asset_enum
        )
        headline_text_assets.insert(0, pinned_headline)

    ad_group_ad.ad.responsive_search_ad.headlines.extend(headline_text_assets)

    desc_text_assets = []
    for desc in descriptions:
        # print("Adding description: ", desc)
        desc_text_assets.append(_create_ad_text_asset(client, desc))

    ad_group_ad.ad.responsive_search_ad.descriptions.extend(desc_text_assets)

    # display path
    ad_group_ad.ad.responsive_search_ad.path1 = ad_display_path_1
    ad_group_ad.ad.responsive_search_ad.path2 = ad_display_path_2

    # Send a request to the server to add a responsive search ad.
    ad_group_ad_response = ad_group_ad_service.mutate_ad_group_ads(
        customer_id=customer_id, operations=[ad_group_ad_operation]
    )

    for result in ad_group_ad_response.results:
        print(
            f"Created responsive search ad with resource name "
            f'"{result.resource_name}".'
        )


def _create_ad_text_asset(client, text, pinned_field=None):
    """Create an AdTextAsset."""
    ad_text_asset = client.get_type("AdTextAsset")
    ad_text_asset.text = text
    if pinned_field:
        ad_text_asset.pinned_field = pinned_field
    return ad_text_asset


def add_extensions(client, customer_id, campaign_resource_name, extension_payload):
    extension_objects = []
    for extension_type, values in extension_payload.items():
        if extension_type == "CALLOUT":
            extension_objects += [
                CalloutExtension(v, campaign_resource_name, client) for v in values
            ]
        elif extension_type == "PROMOTION":
            extension_objects += [
                PromotionExtension(
                    **promo,
                    campaign_resource_name=campaign_resource_name,
                    client=client,
                )
                for promo in values
            ]
        elif extension_type == "SITELINK":
            extension_objects += [
                SitelinkExtension(
                    **sitelink,
                    campaign_resource_name=campaign_resource_name,
                    client=client,
                )
                for sitelink in values
            ]
        else:
            raise ValueError(f"'extension_type' provided is not recognised.")

    asset_operations = []
    for obj in extension_objects:
        obj.create_asset_operation()
        asset_operations.append(obj.asset_operation)

    Queue("asset_service").queue(
        function="mutate_assets", num_operations=len(asset_operations)
    )
    asset_service = client.get_service("AssetService")
    response = asset_service.mutate_assets(
        customer_id=customer_id, operations=asset_operations
    )

    campaign_asset_operations = []
    for idx, obj in enumerate(extension_objects):
        obj.set_asset_resource_name(response.results[idx].resource_name)
        obj.create_campaign_asset_operation()
        campaign_asset_operations.append(obj.campaign_asset_operation)

    Queue("campaign_asset_service").queue(
        function="mutate_campaign_assets", num_operations=len(campaign_asset_operations)
    )
    campaign_asset_service = client.get_service("CampaignAssetService")
    response = campaign_asset_service.mutate_campaign_assets(
        customer_id=customer_id, operations=campaign_asset_operations
    )

    extensions = []
    for idx, obj in enumerate(extension_objects):
        obj.set_campaign_asset_resource_name(response.results[idx].resource_name)
        print(
            "Created campaign asset with resource name "
            f'"{response.results[idx].resource_name}" for campaign {campaign_resource_name}'
        )
        extensions.append(obj.convert_to_dict())
    return extensions


def _process_dates(
    campaign_start_time: datetime.datetime, campaign_end_time: datetime.datetime
) -> dict:
    now = datetime.datetime.now()

    if campaign_start_time < now or campaign_end_time < now:
        raise ValueError("Campaign start time and end time must be in the future")

    if campaign_start_time >= campaign_end_time:
        raise ValueError("Campaign start time must be before end time")

    num_campaign_days = (campaign_end_time - campaign_start_time).days

    output = {
        "campaign_start_time": campaign_start_time,
        "campaign_end_time": campaign_end_time,
        "num_campaign_days": num_campaign_days,
    }
    return output


def _process_ad_groups(ad_groups: List[dict]) -> dict:
    """Iterate through each ad group and validate content within it

    Example ad_groups input:
    [
        {
            "url": "https://evabuy.my",
            "name": "best snack delivery",
            "keywords": [
                {"text": "best snack delivery", "cpc_bid": 50, "match_type": "PHRASE"},
                {"text": "get snacks delivered", "cpc_bid": 50, "match_type": "PHRASE"},
                {"text": "online snacks delivery", "cpc_bid": 50, "match_type": "PHRASE"}
            ],
            "headlines": [
                "EVA ",
                "Everything Valued Assured",
                "Online Food Marketplace",
            ],
            "descriptions": [
                "You Helped Reduce Wastage",
                "Pay Less For More",
                "Save As You Shop",
                "Brands You Know and Love",
            ],
        }
    ],

    Raises:
        Exception: [description]
        Exception: [description]
        ValueError: [description]
        ValueError: [description]

    Returns:
        [type]: [description]
    """

    validate_non_empty_list(ad_groups, "ad_groups")

    keywords = set()
    for i, ad_group in enumerate(ad_groups):
        # create default ad group name if not provided
        ad_group.setdefault("name", f"Ad Group #{i+1}")

        for key in ["keywords", "headlines", "descriptions"]:
            validate_non_empty_list(ad_group[key], f"{key} (within ad_groups)")

        # keywords
        for kw in ad_group["keywords"]:
            if "text" not in kw:
                raise Exception(
                    f"Excepting 'text' to be provided as key-value pairs in 'keywords' param. Received '{kw}' instead."
                )

            # validate keyword length
            text = kw["text"]
            if (len(text.split()) > MAX_GOOGLE_KEYWORDS_WORD_COUNT) or (
                len(text) > MAX_GOOGLE_KEYWORDS_CHAR_COUNT
            ):
                raise ValueError(
                    f"Keywords can only be at most 80 characters and 10 words. Keyword: {text}"
                )
            keywords.add(text)

            # add match type for each keyword
            acceptable_match_types = ["EXACT", "PHRASE", "BROAD"]
            if "match_type" in kw:
                if kw["match_type"] not in acceptable_match_types:
                    raise ValueError(
                        f"Match type for keyword '{text}' is not recognised. Provided {kw['match_type']}. Only accepts {acceptable_match_types}"
                    )
            else:
                kw["match_type"] = "PHRASE"

        # ad group bidding price
        # if "cpc_bid" in ad_group:
        #     ad_group["cpc_bid_micros"] = convert_to_micro_unit(ad_group["cpc_bid"])
        # else:
        #     ad_group["cpc_bid_micros"] = max(kw_bids_within_ad_group)

        # validate url
        validate_non_empty_string(ad_group["url"], "url (within ad_groups)")
        if (not ad_group["url"].startswith("http://")) and (
            not ad_group["url"].startswith("https://")
        ):
            raise ValueError(
                "URL provided in ad group must start with http:// or https://"
            )

    output = {
        "keywords": keywords,
        "num_unique_keywords": len(keywords),
        "ad_groups": ad_groups,
    }
    return output


def _process_budget(campaign_budget: float, num_campaign_days: int) -> dict:
    campaign_budget = float(campaign_budget)

    daily_budget = campaign_budget / num_campaign_days
    daily_budget_micros = convert_to_micro_unit(daily_budget, param="budget_micros")

    output = {
        "campaign_budget": campaign_budget,
        "daily_budget": daily_budget,
        "daily_budget_micros": daily_budget_micros,
    }
    return output


if __name__ == "__main__":
    data_ = {
        "auth_user_id": "test_local",
        "business_id": "CNfH9edXFUuf88rMWPyD",
        "campaign_name": f"Campaign test extension on {datetime.datetime.now()}",
        "campaign_budget_amount": 500,
        "start_time": "2024-02-08 00:00:00",
        "end_time": "2024-05-31 00:00:00",
        "negative_keywords": [],
        "extensions": {},
        # "extensions": {
        #     "CALLOUT": ["free shipping", "30 days warranty"],
        #     "PROMOTION": [
        #         {
        #             "target": "best promotion",
        #             "percent_off": 50,
        #             "target_url": "https://evabuy.my",
        #         },
        #         {
        #             "target": "promotion test #2",
        #             "money_amount_off": {"ccy": "GBP", "amount": 90},
        #             "promotion_code": "promotion_code",
        #             "target_url": "https://evabuy.my",
        #         },
        #         {
        #             "target": "promotion test #3",
        #             "percent_off": 90,
        #             "orders_over_amount": {"ccy": "GBP", "amount": 1000},
        #             "target_url": "https://evabuy.my",
        #         },
        #     ],
        #     "SITELINK": [
        #         {
        #             "link_text": "test sitelink 1",
        #             "target_url": "https://evabuy.my",
        #             "description1": "description1",
        #             "description2": "description2",
        #         }
        #     ],
        # },
        "ad_groups": [
            {
                "url": "https://www.rippling.com/en-GB/rippling-vs-deel",
                "name": "deel",
                "keywords": [
                    {
                        "text": "deel",
                        "match_type": "PHRASE",
                    },
                ],
                "headlines": [
                    "Better than {KeyWord:Deel}",
                    "Premium EOR For Int'l Teams",
                    "7 Day Pay Run Lead Time",
                    "Compare Rippling vs Deel",
                    "#1 Int'l Employee Experience",
                    "140+ Country Converage",
                    "All-in-One HRIS & Payroll",
                    "Pay Employees In 90 Seconds",
                    "All-in-One HRIS System",
                    "#1 Global HR & EOR",
                    "#1 Compliance Visibility",
                    "Gaurantee: Easy Administration",
                    "Automate Tax Filing in 1 Click",
                    "Compare our prices & value",
                    "Hire Contractors Or FTEs",
                ],
                "descriptions": [
                    "#1 All-In-One Global HR & Payroll Platform. Automate tax filing, compliance in 90 seconds.",
                    "Hire, Pay and Manage FTEs & Contractors All Around The World With Rippling. Get A Demo.",
                    "Unlike Deel, we offer a more flexible pay schedule, less back & forth, and 0 errors.",
                    "Unified Visibility & Reporting. No more manual spreadsheets and long support calls.",
                ],
            }
        ],
        # "campaign_audiences": ["zZW0pVZNsPV1cCqgI2BA"],
        "google_session_id": "FJrwLyj05vJYrRBcTpR5",
    }

    create_gg_campaign(data_)

    # UPDATE CAMPAIGN
    # operations = [
    #     {"type": "end_date", "new_value": datetime.datetime(2021, 12, 5)},
    #     {"type": "campaign_status", "new_value": "ENABLED"},
    # ]
    # update_campaign(
    #     "9711909572", "customers/9711909572/campaigns/15061945429", operations
    # )
