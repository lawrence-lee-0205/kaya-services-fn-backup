from typing import List

from google.gutils.utilities import queue_for_api
from queries import insert_last_google_api_timestamp


def add_campaign_criteria(
    client, client_id: str, campaign_resource_name: str, criteria: List[dict]
) -> List[dict]:
    """Add a list of campaign criteria. Doc on campaign criterion:
    https://developers.google.com/google-ads/api/reference/rpc/v8/CampaignCriterion?hl=en

    Args:
        client (GoogleAdsClient object)
        client_id (str): Google Ads Account ID of the client. Eg. "9711909572"
        campaign_resource_name (str): campaign resource name. Eg. "customers/9711909572/campaigns/15061945429"
        criteria (List[dict]): List of dict where each dict contains 'type' and 'criterion_id'

    Returns:
        List[dict]: Updated criteria dict with resouce name for the campaign criterion added
    """
    # create operation object for each criterion
    operations = [
        _create_campaign_criterion_op(
            client,
            campaign_resource_name,
            criterion_dict["criterion_id"],
            criterion_dict["type"],
        )
        for criterion_dict in criteria
    ]

    # call Google API service
    queue_for_api(service="campaign_criterion")
    insert_last_google_api_timestamp(
        service="campaign_criterion",
        function="mutate_campaign_criteria",
        num_operations=len(operations),
    )
    campaign_criterion_service = client.get_service("CampaignCriterionService")
    campaign_criterion_response = campaign_criterion_service.mutate_campaign_criteria(
        customer_id=client_id, operations=operations
    )

    for idx, result in enumerate(campaign_criterion_response.results):
        criteria[idx].update({"resource_name": result.resource_name})
        print(
            f'Added campaign criterion "{result.resource_name}" ({criteria[idx]["type"]}).'
        )
    return criteria


def _create_campaign_criterion_op(client, campaign_rn, criterion_id, criterion_type):
    campaign_criterion_operation = client.get_type("CampaignCriterionOperation")
    campaign_criterion = campaign_criterion_operation.create
    campaign_criterion.campaign = campaign_rn

    if criterion_type == "location":
        # Besides using location_id, you can also search by location names from
        # GeoTargetConstantService.suggest_geo_target_constants() and directly
        # apply GeoTargetConstant.resource_name here. An example can be found
        # in get_geo_target_constant_by_names.py.
        campaign_criterion.location.geo_target_constant = client.get_service(
            "GeoTargetConstantService"
        ).geo_target_constant_path(criterion_id)
    elif criterion_type == "language":
        campaign_criterion.language.language_constant = client.get_service(
            "LanguageConstantService"
        ).language_constant_path(criterion_id)
    elif criterion_type == "negative_keyword_phrase":
        campaign_criterion.keyword.text = criterion_id
        campaign_criterion.keyword.match_type = client.enums.KeywordMatchTypeEnum.PHRASE
        campaign_criterion.negative = True
    else:
        raise Exception(f"criterion_type '{criterion_type}' not recognised")

    return campaign_criterion_operation
