import datetime
from typing import List
from google.api_core import protobuf_helpers

from setup import setup
from firestore import FirestoreClient
from constants import DATE_WITHOUT_DASH
from queries import insert_last_google_api_timestamp
from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.conversion import convert_to_micro_unit
from google.campaigns.create_campaign import create_budget
from google.gutils.utilities import queue_for_api, get_api_client
from common import validate_inputs, validate_non_empty_list, validate_datetime


_ACCEPTABLE_GOOGLE_CAMPAIGN_STATUS = ["ENABLED", "PAUSED"]


@setup
def add_negative_keywords_to_existing_campaign(data: dict) -> dict:
    from google.campaigns.campaign_utils import add_campaign_criteria

    # validate inputs
    mandatory_fields = [
        "business_id",
        "auth_user_id",
        "campaign_id",
        "negative_keywords",
    ]
    validate_inputs(data, mandatory_fields)

    # initialise variables
    campaign_doc_id = data["campaign_id"]

    negative_keywords = data["negative_keywords"]
    validate_non_empty_list(negative_keywords, "negative_keywords")

    google_account = GoogleAdsAccount(business_id=data["business_id"])
    client_id = google_account.client_id

    client = get_api_client(google_account.ads_manager_id)

    # get campaign resource name from firebase
    fs = FirestoreClient()
    campaign = fs.get_single_document("google_campaigns", campaign_doc_id)
    campaign_resource_name = campaign["campaign_resource_name"]

    # add campaign criterion for negative keyword
    criteria = [
        {"type": "negative_keyword_phrase", "criterion_id": negative}
        for negative in negative_keywords
    ]
    criteria_outputs = add_campaign_criteria(
        client, client_id, campaign_resource_name, criteria
    )

    # update firebase
    changelogs = [
        {
            "date": datetime.datetime.utcnow(),
            "value": f"Added negative keywords: {negative_keywords}",
            "user_id": data["auth_user_id"],
        },
    ]
    fs.append_list_single_document(
        "google_campaigns", campaign_doc_id, "campaign_criteria", criteria_outputs
    )
    fs.append_list_single_document(
        "google_campaigns",
        campaign_doc_id,
        "changelogs",
        changelogs,
    )
    return {"status": "success"}


@setup
def update_campaign(data: dict) -> dict:
    """Update campaign details. Only works for fields specified in operation_types variable

    Args: data must contain
        - business_id
        - auth_user_id
        - campaign_id
        - changes (List[dict]): For eg, [{'type': 'campaign_start_time', 'new_value': xx}].
          campaign_start_time and campaign_end_time must be in the format of "%Y-%m-%d %H:%M:%S"

    Raises:
        Exception: [description]

    Returns:
        [type]: [description]
    """
    # validate inputs
    mandatory_fields = [
        "business_id",
        "auth_user_id",
        "campaign_id",
        "changes",
    ]
    validate_inputs(data, mandatory_fields)

    changes = data["changes"]
    validate_non_empty_list(changes, "changes")

    campaign_id = data["campaign_id"]

    google_account = GoogleAdsAccount(business_id=data["business_id"])
    client_id = google_account.client_id

    client = get_api_client(google_account.ads_manager_id)

    # get input from firestore
    fs = FirestoreClient()
    campaign = fs.get_single_document("google_campaigns", campaign_id)
    campaign_resource_name = campaign["campaign_resource_name"]
    client_id = campaign["client_id"]

    # Process each change and make sure all inputs are valid
    processed_changes = {}
    extra_changes_to_log = {}
    operation_types = [
        "campaign_start_time",
        "campaign_end_time",
        "campaign_status",
        "campaign_budget",
    ]
    for change in changes:
        type_ = change["type"]

        if type_ not in operation_types:
            raise Exception(
                f"Change type {type_} is not recognised. Only accept {operation_types}"
            )

        if type_ in ["campaign_start_time", "campaign_end_time"]:
            processed_changes[type_] = validate_datetime(change["new_value"], type_)

        elif (type_ == "campaign_status") and (
            change["new_value"] not in _ACCEPTABLE_GOOGLE_CAMPAIGN_STATUS
        ):
            raise Exception(
                f"Campaign status provided ({processed_changes[type_]}) is not recognised. Only accept {_ACCEPTABLE_GOOGLE_CAMPAIGN_STATUS}"
            )

        elif (type_ == "campaign_status") and (
            change["new_value"] in _ACCEPTABLE_GOOGLE_CAMPAIGN_STATUS
        ):
            processed_changes[type_] = change["new_value"]

        elif type_ == "campaign_budget":
            # new campaign budget is for the entire campaign duration
            # we need to convert it to daily budget before passing to Google
            daily_budget = _calculate_daily_budget(
                change["new_value"], changes, campaign
            )
            daily_budget_micros = convert_to_micro_unit(
                daily_budget, param="budget_micros"
            )
            extra_changes_to_log["campaign_budget"] = change["new_value"]
            extra_changes_to_log["daily_budget"] = daily_budget
            extra_changes_to_log["daily_budget_micros"] = daily_budget_micros

            # create new budget based on existing or new start, end dates
            budget_resource_name = create_budget(
                client, client_id, campaign["campaign_name"], daily_budget_micros
            )
            processed_changes["campaign_budget_resource_name"] = budget_resource_name

        # TODO: check if old and new value is different

    # call Google API to execute changes to Campaign details
    _update_campaign_operation(
        client, client_id, campaign_resource_name, processed_changes
    )

    # update firestore

    # merge key-value pairs from extra_changes_to_log and processed_changes
    # if a key exists in both dict, value from processed_changes will be used
    changes_to_update_firestore = {**extra_changes_to_log, **processed_changes}

    changelogs = []
    for fs_field_name, fs_new_value in changes_to_update_firestore.items():
        fs_old_value = campaign.get(fs_field_name, None)

        fs.update_document(
            "google_campaigns", campaign_id, {fs_field_name: fs_new_value}
        )

        changelogs.append(
            {
                "date": datetime.datetime.utcnow(),
                "value": f"Updated {fs_field_name} to {fs_new_value}. Was {fs_old_value}.",
                "user_id": data["auth_user_id"],
            },
        )

    if len(changelogs) > 0:
        # TODO: FIX THIS
        fs.append_list_single_document(
            "google_campaigns",
            campaign_id,
            "changelogs",
            changelogs,
        )

    return {"status": "success"}


def _update_campaign_operation(
    client, client_id: str, campaign_resource_name: str, operations: dict
) -> None:
    """
    operations: {'start_date': %Y-%m-%d %H:%M:%S, 'campaign_budget_resource_name': ... }
    """
    campaign_operation = client.get_type("CampaignOperation")
    campaign = campaign_operation.update
    campaign.resource_name = campaign_resource_name

    for type_, new_value in operations.items():
        if type_ == "campaign_start_time":
            campaign.start_date = datetime.date.strftime(new_value, DATE_WITHOUT_DASH)
        elif type_ == "campaign_end_time":
            campaign.end_date = datetime.date.strftime(
                new_value - datetime.timedelta(days=1), DATE_WITHOUT_DASH
            )
        elif type_ == "campaign_status":
            campaign.status = client.enums.CampaignStatusEnum[new_value.upper()]
        elif type_ == "campaign_budget_resource_name":
            campaign.campaign_budget = new_value
        else:
            raise Exception(f"Operation type {type_} is not implemented yet")

    # Retrieve a FieldMask for the fields configured in the campaign.
    client.copy_from(
        campaign_operation.update_mask,
        protobuf_helpers.field_mask(None, campaign._pb),
    )

    # what happen if operation fails partially? will any of the fields get updated?
    queue_for_api(service="campaign")
    insert_last_google_api_timestamp(
        service="campaign", function="mutate_campaigns", num_operations=1
    )
    campaign_service = client.get_service("CampaignService")
    campaign_response = campaign_service.mutate_campaigns(
        customer_id=client_id, operations=[campaign_operation]
    )

    print(f"Updated campaign {campaign_response.results[0].resource_name}.")
    return None


def _calculate_daily_budget(
    new_campaign_budget: float, changes: List[dict], ori_campaign: dict
) -> float:
    """Given new campaign budget, calc daily budget.
    Use new campaign start & end dates if available. Else, get it from
    existing campaign doc.

    Args:
        new_campaign_budget (float):
        changes (List[dict]): Each dict contains field to update and its new value
        ori_campaign (dict): Existing campaign details

    Returns:
        float: [description]
    """
    # start and end dates from Firestore have type as tz-aware datetime.
    campaign_start_time = ori_campaign["campaign_start_time"].replace(tzinfo=None)
    campaign_end_time = ori_campaign["campaign_end_time"].replace(tzinfo=None)

    # if changes requested involve setting new start and end date, calculate
    # daily budget using the new dates
    for change in changes:
        type_ = change["type"]

        if type_ == "campaign_start_time":
            campaign_start_time = change["new_value"]
        elif type_ == "campaign_end_time":
            campaign_end_time = change["new_value"]

    # convert to datetime if ori values are str
    if isinstance(campaign_start_time, str):
        campaign_start_time = validate_datetime(
            campaign_start_time, "campaign_start_time"
        )
    if isinstance(campaign_end_time, str):
        campaign_end_time = validate_datetime(campaign_end_time, "campaign_start_time")

    num_campaign_days = (campaign_end_time - campaign_start_time).days
    daily_budget = float(new_campaign_budget) / num_campaign_days

    return daily_budget


if __name__ == "__main__":
    data = {
        "campaign_id": "146yyLIra7N0P7nY4hbj",
        "negative_keywords": ["second", "hire"],
        "business_id": "lyu6tWbXJlYQmfzi6uGg",
        "auth_user_id": "test_local",
    }
    add_negative_keywords_to_existing_campaign(data)
    print("-----")
    data = {
        "campaign_id": "146yyLIra7N0P7nY4hbj",
        "changes": [
            # {"type": "campaign_start_time", "new_value": "2021-12-30 00:00:00"},
            # {"type": "campaign_end_time", "new_value": "2022-03-31 00:00:00"},
            {"type": "campaign_status", "new_value": "PAUSED"},
            {"type": "campaign_budget", "new_value": "2000"},
        ],
        "auth_user_id": "test_local",
        "business_id": "lyu6tWbXJlYQmfzi6uGg",
    }
    update_campaign(data)
