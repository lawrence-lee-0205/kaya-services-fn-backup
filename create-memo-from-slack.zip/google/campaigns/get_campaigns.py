import pytz
import datetime
from typing import List

from firestore import FirestoreClient
from utils.list import remove_duplicates
from google.reports.campaign_performance import get_campaign_level_metrics

_CAMPAIGN_COLLECTION = "google_campaigns"
_COLS_TO_COPY = [
    "created_at",
    "created_by",
    "campaign_status",
    "campaign_name",
    "campaign_start_time",
    "campaign_end_time",
    "campaign_budget",
]
_AD_GROUP_COLS_TO_COPY = [
    "headlines",
    "descriptions",
    "name",
    "url",
]

_UTC = pytz.UTC

# TODO: REPLACE BY BQ
def get_gg_campaigns(business_id: str) -> dict:
    fs = FirestoreClient()
    campaign_col = fs.get_collection(_CAMPAIGN_COLLECTION)
    campaign_col_ref = campaign_col.where("business_id", "==", business_id).where(
        "campaign_status", "==", "ENABLED"
    )

    # Limit to 5 campaigns on test account
    if business_id == "lyu6tWbXJlYQmfzi6uGg":
        campaign_col_ref = campaign_col_ref.limit(3)

    output = []
    for doc in campaign_col_ref.stream():
        campaign_id = doc.id
        content = doc.to_dict()

        print("Processing ", campaign_id)

        # copy cols from campaign doc without any modification
        # TODO: data quality check to make sure all mandatory fields are filled
        processed_campaign = {col: content.get(col) for col in _COLS_TO_COPY}

        campaign_criteria = _process_campaign_criteria(
            content["campaign_criteria"], campaign_id
        )
        audiences = campaign_criteria["audiences"]

        # process campaign metrics
        metrics = _get_metrics(content)

        if "campaign_status" in _COLS_TO_COPY:
            processed_campaign["campaign_status"] = processed_campaign[
                "campaign_status"
            ].upper()

        # TODO: MAKE SURE ALL DATETIME HAVE THE SAME FORMAT
        processed_campaign["campaign_id"] = campaign_id
        processed_campaign["campaign_criteria"] = audiences
        processed_campaign["metrics"] = metrics
        processed_campaign["platform"] = "Google"
        processed_campaign["campaign_type"] = content.get(
            "campaign_advertising_channel_type", "UNKNOWN"
        )

        output.append(processed_campaign)

    return output


def _get_metrics(campaign_content):
    metrics = {}
    midnight = _UTC.localize(
        datetime.datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    )

    # process campaign start date
    campaign_start_str = str(campaign_content["campaign_start_time"])
    campaign_start = campaign_content["campaign_start_time"]

    if isinstance(campaign_start, str):
        if len(campaign_start) == 10:
            fmt = "%Y-%m-%d"
        else:
            fmt = "%Y-%m-%d %H:%M:%S"

        campaign_start = datetime.datetime.strptime(
            campaign_content["campaign_start_time"], fmt
        )
    if ("UTC" not in campaign_start_str) and ("+00:00" not in campaign_start_str):
        campaign_start = _UTC.localize(campaign_start)

    # get campaign metrics if the start date is in the past
    if campaign_start < midnight:
        google_campaign_id = campaign_content["campaign_resource_name"].split("/")[-1]
        metrics = get_campaign_level_metrics(google_campaign_id)

    # if metric is an empty dict, return 0 for all fields
    if not metrics:
        metrics = {
            "ccy": 0,
            "clicks": 0,
            "spent": 0,
            "impressions": 0,
            "click_through_rate": 0,
            "average_cpc": 0,
        }
    return metrics


def _process_campaign_criteria(
    campaign_criteria_raw: List[dict], campaign_id: str
) -> List[dict]:
    # create a dict where key -> criterion type, value -> list of criterion_id
    campaign_criteria_dict = {}
    for criterion in campaign_criteria_raw:
        type_ = criterion["type"]
        criteria_id = campaign_criteria_dict.get(type_, [])

        if "criterion_id" in criterion:
            criteria_id.append(criterion["criterion_id"])
        else:
            raise Exception(
                f"Expecting key 'criterion_id' to exist in campaign_criteria. Found none in campaign {campaign_id}."
            )

        campaign_criteria_dict[type_] = criteria_id

    # restructure campaign_criteria_dict into a list of dict
    negative_keywords = []
    audiences = []
    for key, value in campaign_criteria_dict.items():
        if key in ["location", "language"]:
            d = {"type": key, "criteria_id": value}
            audiences.append(d)
        elif key in ["negative_keyword_phrase"]:
            negative_keywords += value
        else:
            raise Exception(f"Received unexpected criteria type: {key}")

    output = {
        "audiences": audiences,
        "negative_keywords": remove_duplicates(negative_keywords),
    }
    return output


def _process_ad_groups(ad_groups_raw: List[dict]) -> List[dict]:
    """Given raw data from campaign doc, keep only certain fields and
    return new list of dict.

    Args:
        ad_groups_raw (List[dict]): [description]

    Returns: List[dict]
    """
    ad_groups = []
    for ad_group in ad_groups_raw:
        # TODO: data quality check to make sure all mandatory fields are filled
        ag = {c: ad_group.get(c) for c in _AD_GROUP_COLS_TO_COPY}

        ag_keywords = []
        for kw_full in ad_group["keywords"]:
            kw_only = kw_full["keyword"]
            ag_keywords.append(
                {"cpc_bid": kw_only.get("cpc_bid"), "text": kw_only.get("text")}
            )
        ag["keywords"] = ag_keywords

        ad_groups.append(ag)
    return ad_groups


if __name__ == "__main__":
    # campaign with negative kw: l3mmybFln2BYH7wTpEUE
    o = get_gg_campaigns("q7RQxPR7p0U8P6uKm8Do")
    # o = get_gg_campaigns("lyu6tWbXJlYQmfzi6uGg")
    print(o)
