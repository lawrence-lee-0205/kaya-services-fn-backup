# TODO: DEPRECATE THIS FILE

import pandas as pd
import datetime

from setup import setup
from common import (
    validate_datetime,
    validate_inputs,
    validate_and_fix_bid,
    validate_non_empty_list,
    prettify_float_to_str,
)
from queries import get_google_account, get_google_audience
from constants import NUM_DAYS_IN_QUARTER, DATE_WITH_DASH, MILLION
from google.keywords.keyword_planner import (
    add_keyword_plan,
    get_campaign_weekly_forecast,
    get_forecasted_performance,
)
from firestore import FirestoreClient


@setup
def main(data):

    ##################################
    #    VALIDATE & PROCESS INPUTS   #
    ##################################

    mandatory_fields = [
        "business_id",
        "auth_user_id",
        "ad_groups",
        "start_time",
        "end_time",
    ]
    validate_inputs(data, mandatory_fields)


def execute(
    business_id,
    ad_groups,
    start_time,
    end_time,
    campaign_budget,
    forecast_period="NEXT_QUARTER",
):
    default_keyword_match_type = "PHRASE"

    google_account = get_google_account(business_id)
    customer_id = google_account["client_id"]
    ccy = google_account["ccy_code"]

    # start and end dates
    campaign_start_time = validate_datetime(start_time, "start_time")
    campaign_end_time = validate_datetime(end_time, "end_time")
    num_days = (campaign_end_time - campaign_start_time).days

    # AUDIENCE
    incl_locations = [2840]
    incl_languages = [1000]

    # AD GROUPS
    ad_group_bids = []
    validate_non_empty_list(ad_groups, "ad_groups")
    for ad_group in ad_groups:
        validate_inputs(payload=ad_group, mandatory_fields=["name", "keywords"])

        kw_bids = []
        for kw in ad_group["keywords"]:
            validate_inputs(payload=kw, mandatory_fields=["text", "cpc_bid"])

            bid = validate_and_fix_bid(kw["cpc_bid"] * MILLION)
            kw["cpc_bid"] = bid
            # TODO: update match type
            kw.setdefault("match_type", default_keyword_match_type)
            kw_bids.append(bid)

        if "cpc_bid" in ad_group:
            ad_group["cpc_bid"] = validate_and_fix_bid(ad_group["cpc_bid"] * MILLION)
        else:
            ad_group["cpc_bid"] = max(kw_bids)
        ad_group_bids.append(ad_group["cpc_bid"])

    campaign_bid_cpc = validate_and_fix_bid(max(ad_group_bids))
    print("ad_groups: ", ad_groups)
    print("ad_group_bids: ", ad_group_bids)

    ##############################
    #    CREATE KEYWORD PLANS    #
    ##############################
    keyword_plan_setting = add_keyword_plan(
        customer_id=customer_id,
        forecast_period=forecast_period,
        keyword_plan_network="GOOGLE_SEARCH",
        ad_groups=ad_groups,
        campaign_bid_cpc=campaign_bid_cpc,
        incl_location_ids=incl_locations,
        incl_language_ids=incl_languages,
        skip_firestore=True,
    )
    print(keyword_plan_setting)
    keyword_plan_rn = keyword_plan_setting["plan_resource_name"]

    out = forecast(keyword_plan_rn)
    return out


def forecast(keyword_plan_rn, ccy):
    metrics = ["cost", "clicks", "impressions"]
    campaign_budget = 1e6  # to remove

    # weekly performance
    weekly_campaign_forecast = get_campaign_weekly_forecast(keyword_plan_rn)
    weekly_forecast_df = pd.DataFrame(weekly_campaign_forecast)
    weekly_forecast_df["date"] = weekly_forecast_df["start_date"]

    print("Weekly forecast:")
    print(weekly_forecast_df.shape)
    print(weekly_forecast_df.head())

    # weekly_forecast_df = weekly_forecast_df[
    #     (
    #         weekly_forecast_df["start_date"]
    #         >= campaign_start_time.strftime(DATE_WITH_DASH)
    #     )
    #     & (
    #         weekly_forecast_df["start_date"]
    #         < campaign_end_time.strftime(DATE_ WITH_DASH)
    #     )
    # ]
    # print(weekly_forecast_df.shape)

    base_uncertainty = 0.10
    periodic_increment_uncertainty = 0.02
    scale = 1

    # if num_days < NUM_DAYS_IN_QUARTER:
    # frequency = "week"
    # weekly_forecast_df["date"] = weekly_forecast_df["start_date"]

    # else:
    #     frequency = "month"
    #     # so we can aggregate by month later
    #     weekly_forecast_df["date"] = weekly_forecast_df["start_date"].apply(
    #         lambda x: x[:7] + "-01"
    #     )

    cost_raw_total = weekly_forecast_df["cost"].sum()
    print("Total cost ", cost_raw_total)
    # if campaign_budget is None:
    #     scale = 1  # TODO: REMOVE WHEN BUDGET IS MADE MANDATORY
    # else:
    #     scale = min([campaign_budget / cost_raw_total, 1])
    # print("Applying scale: ", scale)
    # # TODO: APPLY SCALE BY KEYWORD

    metrics_dict = {}
    campaign_dict = {}
    for metric in metrics:
        # sum metric by week or month
        # new df will have 2 cols: date and value
        data_df = (
            pd.DataFrame(weekly_forecast_df.groupby("date")[metric].sum())
            .reset_index()
            .rename(columns={metric: "raw"})
        )
        # apply scaling factor
        data_df["value"] = data_df["raw"] * scale

        # get upper and lower bound
        data_df["upper"] = data_df["value"] * (
            data_df.index * periodic_increment_uncertainty + base_uncertainty + 1
        )
        data_df["lower"] = data_df["value"] * (
            1 - (data_df.index * periodic_increment_uncertainty + base_uncertainty)
        )

        # weekly records for a given metric
        metrics_dict[metric] = {
            "frequency": "placeholder",
            "data": data_df.to_dict(orient="records"),
        }

        # campaign level metric
        m_lower_bound = prettify_float_to_str(data_df["lower"].sum())

        ## cost must not be higher than budget
        upper_bound_sum = (
            min(data_df["upper"].sum(), campaign_budget)
            if metric == "cost"
            else data_df["upper"].sum()
        )
        m_upper_bound = prettify_float_to_str(upper_bound_sum)

        if m_lower_bound == m_upper_bound:
            metric_str_rep = "~" + m_lower_bound
        else:
            metric_str_rep = f"{m_lower_bound} - {m_upper_bound}"

        campaign_dict[metric] = metric_str_rep

    kw_level = get_forecasted_performance(keyword_plan_rn)

    output = {
        "ccy": ccy,
        "campaign": campaign_dict,
        "keywords": kw_level,
        **metrics_dict,
    }

    # ####################################
    # #        WRITE TO FIRESTORE        #
    # ####################################

    # fs = FirestoreClient()
    # forecast_doc = {
    #     "impressions": output["impressions"]["data"],
    #     "cost": output["cost"]["data"],
    #     "clicks": output["clicks"]["data"],
    #     "frequency": frequency,
    #     "created_at": datetime.datetime.utcnow(),
    #     "keyword_plan_resource_name": keyword_plan_rn,
    #     "ad_groups": ad_groups,
    #     "ccy": ccy,
    #     "campaign": campaign_dict,
    # }
    # forecast_doc_id = fs.add_subcollection_to_document(
    #     "google_sessions",
    #     google_session_id,
    #     "forecast",
    #     forecast_doc,
    # )
    # fs.update_document(
    #     "google_sessions",
    #     google_session_id,
    #     {
    #         "latest_forecast_id": forecast_doc_id,
    #         "updated_at": datetime.datetime.utcnow(),
    #     },
    # )
    return output


@setup
def mock(data):
    import random

    metrics = ["cost", "clicks", "impressions"]

    mandatory_fields = [
        "business_id",
        "auth_user_id",
        "ad_groups",
        "start_time",
        "end_time",
    ]
    validate_inputs(data, mandatory_fields)

    google_account = get_google_account(data["business_id"])
    ccy = google_account["ccy_code"]

    # start and end dates
    campaign_start_time = (
        validate_datetime(data["start_time"], "start_time")
        if "start_time" in data
        else datetime.datetime.today() + datetime.timedelta(days=1)
    )
    campaign_end_time = (
        validate_datetime(data["end_time"], "end_time")
        if "end_time" in data
        else campaign_start_time + datetime.timedelta(weeks=4)
    )
    num_days = (campaign_end_time - campaign_start_time).days
    num_weeks = int(num_days / 7)

    weekly_campaign_forecast = [
        {
            "impressions": 3000 * random.uniform(1, 1.2),
            "clicks": 130 * random.uniform(1, 1.2),
            "cost": 100 * random.uniform(1, 1.2),
            "start_date": (
                campaign_start_time + datetime.timedelta(days=7 * i)
            ).strftime(DATE_WITH_DASH),
        }
        for i in range(num_weeks + 1)
    ]

    weekly_forecast_df = pd.DataFrame(weekly_campaign_forecast)
    weekly_forecast_df = weekly_forecast_df[
        (
            weekly_forecast_df["start_date"]
            >= campaign_start_time.strftime(DATE_WITH_DASH)
        )
        & (
            weekly_forecast_df["start_date"]
            < campaign_end_time.strftime(DATE_WITH_DASH)
        )
    ]
    print(weekly_forecast_df.shape)

    base_uncertainty = 0.10
    periodic_increment_uncertainty = 0.02

    # if num_days < NUM_DAYS_IN_QUARTER:
    frequency = "week"
    weekly_forecast_df["date"] = weekly_forecast_df["start_date"]

    # else:
    #     frequency = "month"
    #     # so we can aggregate by month later
    #     weekly_forecast_df["date"] = weekly_forecast_df["start_date"].apply(
    #         lambda x: x[:7] + "-01"
    #     )

    metrics_dict = {}
    campaign_dict = {}
    for metric in metrics:
        # sum metric by week or month
        # new df will have 2 cols: date and value
        data_df = (
            pd.DataFrame(weekly_forecast_df.groupby("date")[metric].sum())
            .reset_index()
            .rename(columns={metric: "value"})
        )

        data_df["upper"] = data_df["value"] * (
            data_df.index * periodic_increment_uncertainty + base_uncertainty + 1
        )
        data_df["lower"] = data_df["value"] * (
            1 - (data_df.index * periodic_increment_uncertainty + base_uncertainty)
        )

        # weekly records for a given metric
        metrics_dict[metric] = {
            "frequency": frequency,
            "data": data_df.to_dict(orient="records"),
        }

        # campaign level metric
        m_lower_bound = prettify_float_to_str(data_df["lower"].sum())
        m_upper_bound = prettify_float_to_str(data_df["upper"].sum())
        if m_lower_bound == m_upper_bound:
            metric_str_rep = "~" + m_lower_bound
        else:
            metric_str_rep = f"{m_lower_bound} - {m_upper_bound}"

        campaign_dict[metric] = metric_str_rep

    output = {
        "ccy": ccy,
        "campaign": campaign_dict,
        **metrics_dict,
    }
    return output


if __name__ == "__main__":
    # data = {
    #     "business_id": "lyu6tWbXJlYQmfzi6uGg",
    #     "ad_groups": [
    #         {
    #             "name": "placeholder",
    #             "keywords": [
    #                 {"text": "animal insurance", "cpc_bid": 3.76},
    #                 {"text": "best insurance in malaysia", "cpc_bid": 5.25},
    #                 {"text": "cat insurance", "cpc_bid": 5.25},
    #                 {"text": "cat insurance malaysia", "cpc_bid": 4.58},
    #                 {"text": "dog insurance", "cpc_bid": 3.84},
    #                 {"text": "dog insurance malaysia", "cpc_bid": 4.24},
    #                 {"text": "health care", "cpc_bid": 4.64},
    #                 {"text": "health insurance", "cpc_bid": 5.25},
    #                 {"text": "insurance medical", "cpc_bid": 5.25},
    #                 {"text": "malaysia pet insurance", "cpc_bid": 2.75},
    #                 {"text": "pet health", "cpc_bid": 2.66},
    #             ],
    #             "cpc_bid": 5.25,
    #         }
    #     ],
    #     "campaign_budget": 4954,
    #     "start_time": "2021-12-07 00:00:00",
    #     "end_time": "2022-03-01 00:00:00",
    #     "auth_user_id": "test",
    # }
    # main(data)

    # ad_groups = [
    #     {
    #         "name": "placeholder",
    #         "keywords": [
    #             {"text": "animal insurance", "cpc_bid": 3.76},
    #             {"text": "best insurance in malaysia", "cpc_bid": 5.25},
    #         ],
    #         "cpc_bid": 5.25,
    #     }
    # ]
    # out = execute(
    #     business_id="2grjw03Yn7ei9EAIvxiy",
    #     ad_groups=ad_groups,
    #     start_time="2023-04-01 00:00:00",
    #     end_time="2023-04-10 00:00:00",
    #     campaign_budget=1000,
    #     forecast_period="NEXT_QUARTER",
    # )
    # print(out)

    forecast("customers/3545980072/keywordPlans/650391355", "USD")
