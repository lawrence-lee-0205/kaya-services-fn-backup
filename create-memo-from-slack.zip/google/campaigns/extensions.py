""" Available asset types: 
https://developers.google.com/google-ads/api/reference/rpc/v8/AssetFieldTypeEnum.AssetFieldType
"""
from abc import (
    ABC,
    abstractmethod,
)
import uuid

from google.gutils.money import Money
from utils.validations import validate_is_either


class Extension(ABC):
    def __init__(self, campaign_resource_name, asset_type, client):
        self.asset_type = asset_type
        self.asset_operation = None
        self.campaign_asset_operation = None
        self.asset_resource_name = None
        self.campaign_resource_name = campaign_resource_name
        self.client = client

    @abstractmethod
    def create_asset_operation(self):
        pass

    @abstractmethod
    def convert_to_dict(self):
        pass

    def set_asset_resource_name(self, resource_name):
        self.asset_resource_name = resource_name

    def set_campaign_asset_resource_name(self, resource_name):
        self.campaign_asset_resource_name = resource_name

    def create_campaign_asset_operation(self):
        print("self.type: ", self.asset_type)
        campaign_asset_operation = self.client.get_type("CampaignAssetOperation")
        campaign_asset = campaign_asset_operation.create
        campaign_asset.asset = self.asset_resource_name
        campaign_asset.field_type = self.client.enums.AssetFieldTypeEnum[
            self.asset_type
        ]
        campaign_asset.campaign = self.campaign_resource_name
        self.campaign_asset_operation = campaign_asset_operation


class CalloutExtension(Extension):
    def __init__(self, text, campaign_resource_name, client):
        self.text = text
        super().__init__(campaign_resource_name, "CALLOUT", client)

    def create_asset_operation(self):
        asset_operation = self.client.get_type("AssetOperation")
        asset = asset_operation.create
        asset.name = self.text

        callout_asset = asset.callout_asset
        callout_asset.callout_text = self.text
        self.asset_operation = asset_operation

    def convert_to_dict(self):
        return {
            "asset_type": self.asset_type,
            "text": self.text,
            "asset_resource_name": self.asset_resource_name,
            "campaign_resource_name": self.campaign_resource_name,
        }


class PromotionExtension(Extension):
    """Create Promotion Extension.
    One of percent_off and money_amount_off must be provided.
    Either provide only one of "orders_over_amount", "promotion_code" OR none at all. Not both.

    More: https://developers.google.com/google-ads/api/reference/rpc/v8/PromotionAsset"""

    def __init__(
        self,
        target,
        target_url,
        client,
        campaign_resource_name,
        promotion_code=None,
        orders_over_amount=None,
        percent_off=None,
        money_amount_off=None,
    ):
        validate_is_either(
            [percent_off, money_amount_off],
            ["percent_off", "money_amount_off"],
            mandatory=True,
        )
        validate_is_either(
            [orders_over_amount, promotion_code],
            ["orders_over_amount", "promotion_code"],
        )

        if (promotion_code is not None) and (len(promotion_code) >= 15):
            raise Exception(
                f"Promotion code provided '{promotion_code}' is too long. Should be <15 characters."
            )

        self._percent_off = percent_off
        self._money_amount_off = money_amount_off
        self._orders_over_amount = orders_over_amount

        self.promotion_target = target
        self.target_url = target_url
        self.promotion_code = promotion_code

        super().__init__(campaign_resource_name, "PROMOTION", client)

    @property
    def percent_off(self):
        if self._percent_off is not None:
            return int(self._percent_off / 100 * 1e6)
        else:
            return self._percent_off

    @property
    def money_amount_off(self):
        return Money(self._money_amount_off["ccy"], self._money_amount_off["amount"])

    @property
    def orders_over_amount(self):
        if self._orders_over_amount is not None:
            return Money(
                self._orders_over_amount["ccy"], self._orders_over_amount["amount"]
            )
        else:
            return self._orders_over_amount

    def create_asset_operation(self):
        asset_operation = self.client.get_type("AssetOperation")
        asset = asset_operation.create
        asset.name = self.promotion_target.lower().replace(" ", "-")
        asset.final_urls.append(self.target_url)

        promotion_asset = asset.promotion_asset
        promotion_asset.promotion_target = self.promotion_target

        if self.percent_off is not None:
            promotion_asset.percent_off = self.percent_off
        elif self.money_amount_off is not None:
            promotion_asset.money_amount_off.currency_code = self.money_amount_off.ccy
            promotion_asset.money_amount_off.amount_micros = (
                self.money_amount_off.amount_micros
            )

        if self.promotion_code is not None:
            promotion_asset.promotion_code = self.promotion_code
        elif self.orders_over_amount is not None:
            promotion_asset.orders_over_amount.currency_code = (
                self.orders_over_amount.ccy
            )
            promotion_asset.orders_over_amount.amount_micros = (
                self.orders_over_amount.amount_micros
            )

        self.asset_operation = asset_operation

    def convert_to_dict(self):
        return {
            "asset_type": self.asset_type,
            "percent_off": self.percent_off,
            "target_url": self.target_url,
            "promotion_target": self.promotion_target,
            "asset_resource_name": self.asset_resource_name,
            "campaign_resource_name": self.campaign_resource_name,
        }


class SitelinkExtension(Extension):
    """https://developers.google.com/google-ads/api/reference/rpc/v9/SitelinkAsset"""

    def __init__(
        self,
        link_text: str,
        target_url: str,
        campaign_resource_name: str,
        client,
        description1: str = "",
        description2: str = "",
    ):
        """Args:
            link_text (str): Required. URL display text for the sitelink. The length of this string should be between 1 and 25, inclusive.
            target_url (str): [description]
            campaign_resource_name (str): [description]
            description1 (str, optional): [description]. First line of the description for the sitelink. If set, the length should be between 1 and 35, inclusive, and description2 must also be set. Defaults to "".
            description2 (str, optional): [description]. Second line of the description for the sitelink. If set, the length should be between 1 and 35, inclusive, and description1 must also be set. Defaults to "".

        Raises:
            ValueError: [description]
        """
        if (len(link_text) < 1) or (len(link_text) > 25):
            raise ValueError(
                f"Length of link_text should be between 1 and 25, inclusive. Current length: {len(link_text)}"
            )

        # validate description1 and description2
        if (description1 == "") and (description2 != ""):
            raise ValueError(
                f"description2 is provided but description1 is not set. Please set value for description1."
            )

        if (description2 == "") and (description1 != ""):
            raise ValueError(
                f"description1 is provided but description2 is not set. Please set value for description2."
            )

        if (description1 != "") and (description2 != ""):
            for desc in [description1, description2]:
                if len(desc) > 35:
                    raise ValueError(
                        "Length of description1 and description2 should be between 1 and 35, inclusive"
                    )

        # set attributes
        self.link_text = link_text
        self.target_url = target_url
        self.description1 = description1
        self.description2 = description2
        super().__init__(campaign_resource_name, "SITELINK", client)

    @property
    def should_add_description(self):
        return (self.description1 != "") and (self.description2 != "")

    def create_asset_operation(self):
        asset_operation = self.client.get_type("AssetOperation")
        asset = asset_operation.create
        asset.name = f"site_link_{uuid.uuid4()}"
        asset.final_urls.append(self.target_url)

        sitelink_asset = asset.sitelink_asset
        sitelink_asset.link_text = self.link_text

        if self.should_add_description:
            sitelink_asset.description1 = self.description1
            sitelink_asset.description2 = self.description2

        self.asset_operation = asset_operation

    def convert_to_dict(self):
        return {
            "asset_type": self.asset_type,
            "link_text": self.link_text,
            "target_url": self.target_url,
            "campaign_resource_name": self.campaign_resource_name,
            "description1": self.description1,
            "description2": self.description2,
        }


# only available with v9
class CallExtension(Extension):
    def __init__(self, country_code, phone_number, campaign_resource_name, client):
        self.type = "CALL"
        self.country_code = country_code
        self.phone_number = phone_number
        super().__init__(campaign_resource_name, client)

    def create_asset_operation(self):
        asset_operation = self.client.get_type("AssetOperation")
        asset = asset_operation.create
        asset.name = "call"

        call_asset = asset.call_asset
        call_asset.country_code = self.country_code
        call_asset.phone_number = self.phone_number
        self.asset_operation = asset_operation

    def create_campaign_asset_operation(self):
        campaign_asset_operation = self.client.get_type("CampaignAssetOperation")
        campaign_asset = campaign_asset_operation.create
        campaign_asset.asset = self.asset_resource_name
        campaign_asset.field_type = self.client.enums.AssetFieldTypeEnum.CALL
        campaign_asset.campaign = self.campaign_resource_name
        self.campaign_asset_operation = campaign_asset_operation

    def convert_to_dict(self):
        raise NotImplementedError()
