"""Campaign object for existing campaign"""
from firestore import FirestoreClient


class Campaign:
    def __init__(self, campaign_id) -> None:
        self.campaign_id = campaign_id

        fs = FirestoreClient()
        campaign_raw = fs.get_single_document("google_campaigns", campaign_id)
        self.campaign_resource_name = campaign_raw["campaign_resource_name"]

    @property
    def google_campaign_id(self):
        return self.campaign_resource_name.split("/")[-1]
