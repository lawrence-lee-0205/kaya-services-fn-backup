import os
import math
import time
import pytz
import datetime

# from utils.env_variables import set_env_var_from_yaml
from queries import get_last_google_api_timestamp
from google.oauth2.service_account import Credentials as ServiceAccountCredentials

_DEFAULT_WAIT_TIME_IN_SECONDS = 2
_WAIT_TIMES_IN_SECONDS = {
    "keyword_plan": 3,
    "keyword_plan_idea": 2,
    "google_analytics": 2,
    "google_analytics_4": 4,
}


def queue_for_api(service: str):
    utc = pytz.UTC
    seconds_betw_requests = _WAIT_TIMES_IN_SECONDS.get(
        service, _DEFAULT_WAIT_TIME_IN_SECONDS
    )

    last_api_timestamp = get_last_google_api_timestamp(service)
    if last_api_timestamp is None:
        # first time calling the service during this period
        return None

    elapsed = (
        utc.localize(datetime.datetime.utcnow()) - last_api_timestamp
    ).total_seconds()

    if elapsed < seconds_betw_requests:
        remaining = math.ceil(seconds_betw_requests - elapsed)
        # print(f"wait for {remaining}s..")
        time.sleep(remaining)
    return None


def get_api_client(manager_id: str):
    """Get API client for Google Ads. To upgrade to a newer version, change the version in this function.
    You might need to run `pip install google-ads --upgrade` to install the latest version.
    """
    from google.ads.googleads.client import GoogleAdsClient
    from constants import GOOGLE_ADS_MANAGER_ID_DEV, GOOGLE_ADS_MANAGER_ID_PROD

    # only set GOOGLE_ADS_LOGIN_CUSTOMER_ID if we are accessing
    # client accounts that belong under our manager account
    if manager_id in [GOOGLE_ADS_MANAGER_ID_PROD, GOOGLE_ADS_MANAGER_ID_DEV]:
        os.environ["GOOGLE_ADS_LOGIN_CUSTOMER_ID"] = manager_id
    else:
        if "GOOGLE_ADS_LOGIN_CUSTOMER_ID" in os.environ:
            os.environ.pop("GOOGLE_ADS_LOGIN_CUSTOMER_ID")

    client = GoogleAdsClient.load_from_env(version="v16")
    return client


def get_bq_client():
    import os
    from google.cloud import bigquery

    if os.environ["ENV"] in ["LOCAL", "LOCAL_PROD"]:
        client = bigquery.Client().from_service_account_json(
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"]
        )
    else:
        client = bigquery.Client()
    return client


def get_service_account_credentials():
    creds = ServiceAccountCredentials.from_service_account_file(
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"],
    )
    return creds
