from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.ads_query import run_ads_query

import pandas as pd
from urllib.parse import urlparse, urlunparse


def get_all_conversions(
    client_id, ads_manager_id, start_date, end_date, filter_kaya=True
):
    filter_kaya_str = "AND campaign.name LIKE '%Kaya%'" if filter_kaya else ""
    query = f"""
    SELECT 
        ad_group.id, 
        ad_group.name, 
        campaign.id, 
        campaign.name, 
        landing_page_view.resource_name,
        landing_page_view.unexpanded_final_url, 
        customer.id,
        segments.week,
        metrics.cost_micros, 
        metrics.clicks, 
        metrics.conversions, 
        metrics.conversions_value, 
        metrics.all_conversions, 
        metrics.all_conversions_value, 
        metrics.impressions 
    FROM landing_page_view
    WHERE segments.date >= '{start_date}' 
        AND segments.date <= '{end_date}' 
        {filter_kaya_str}
    """
    rows = run_ads_query(client_id, query, ads_manager_id)

    outputs = []
    for row in rows:
        out = {
            "week": row.segments.week,
            "customer_id": row.customer.id,
            "campaign_id": row.campaign.id,
            "name": row.campaign.name,
            "landing_page_rn": row.landing_page_view.resource_name,
            "landing_page_unexpanded_final_url": row.landing_page_view.unexpanded_final_url,
            "impressions": row.metrics.impressions,
            "clicks": row.metrics.clicks,
            "conversions": row.metrics.conversions,
            "conversions_value": row.metrics.conversions_value,
            "cost": row.metrics.cost_micros / 1e6,
        }
        outputs.append(out)
    output_df = pd.DataFrame(outputs)
    return output_df


def get_conversion_by_action(
    client_id,
    ads_manager_id,
    start_date,
    end_date,
    primary_conversion_actions,
    filter_kaya=True,
):
    primary_conversion_actions_str = ", ".join(
        [f"'{c}'" for c in primary_conversion_actions]
    )

    filter_kaya_str = "AND campaign.name LIKE '%Kaya%'" if filter_kaya else ""
    filter_conversion_names = (
        f"AND segments.conversion_action_name IN ({primary_conversion_actions_str})"
    )
    query = f"""
    SELECT 
        segments.week,
        ad_group.id, 
        ad_group.name, 
        campaign.id, 
        campaign.name, 
        landing_page_view.resource_name, 
        landing_page_view.unexpanded_final_url,   
        segments.conversion_action, 
        segments.conversion_action_name,
        metrics.all_conversions, 
        metrics.all_conversions_value
    FROM landing_page_view
    WHERE segments.date >= '{start_date}' 
        AND segments.date <= '{end_date}' 
        {filter_kaya_str}
        {filter_conversion_names}
    """
    rows = run_ads_query(client_id, query, ads_manager_id)

    outputs = []
    for row in rows:
        out = {
            "week": row.segments.week,
            "customer_id": row.customer.id,
            "campaign_id": row.campaign.id,
            "name": row.campaign.name,
            "landing_page_rn": row.landing_page_view.resource_name,
            "landing_page_unexpanded_final_url": row.landing_page_view.unexpanded_final_url,
            "conversion_action": row.segments.conversion_action,
            "conversion_action_name": row.segments.conversion_action_name,
            "all_conversions": row.metrics.all_conversions,
            "all_conversions_value": row.metrics.all_conversions_value,
        }
        outputs.append(out)
    output_df = pd.DataFrame(outputs)
    return output_df


def remove_query_params(url):
    # Parse the URL
    parsed_url = urlparse(url)

    # Reconstruct the URL without the query parameters
    clean_url = urlunparse(parsed_url._replace(query=""))

    return clean_url


if __name__ == "__main__":
    business_id = "WEjnxhwjRclMr05ZwcNw"
    start_date = "2023-08-01"
    end_date = "2023-11-30"

    required_conv_lst = ["Purchase"]

    google_ads_account = GoogleAdsAccount(business_id=business_id)

    all_stats_df = get_all_conversions(
        google_ads_account.client_id,
        google_ads_account.ads_manager_id,
        start_date,
        end_date,
        filter_kaya=True,
    )
    print(all_stats_df.head())
    selected_conv_df = get_conversion_by_action(
        google_ads_account.client_id,
        google_ads_account.ads_manager_id,
        start_date,
        end_date,
        required_conv_lst,
    )
    print(selected_conv_df.head())

    selected_conv_df["conversion_action_name"] = selected_conv_df[
        "conversion_action_name"
    ].apply(lambda x: x.replace(" ", "_"))
    conversion_action_names = selected_conv_df["conversion_action_name"].unique()
    pivot_selected_conv_df = pd.pivot_table(
        selected_conv_df,
        index=[
            "customer_id",
            "campaign_id",
            "name",
            "landing_page_rn",
            "landing_page_unexpanded_final_url",
            "week",
        ],
        columns="conversion_action_name",
        values="all_conversions",
        aggfunc="sum",
    ).reset_index()

    master_df = pd.merge(
        all_stats_df,
        pivot_selected_conv_df,
        on=[
            "customer_id",
            "campaign_id",
            "landing_page_rn",
            "landing_page_unexpanded_final_url",
            "name",
            "week",
        ],
        how="left",
    )

    master_df.to_csv("master_df.csv", index=0)

    # master_df = pd.read_csv("master_df.csv")
    master_df["landing_page_url"] = master_df[
        "landing_page_unexpanded_final_url"
    ].apply(lambda x: remove_query_params(x))
    print(master_df.head())

    conversion_action_names = ["Purchase"]
    values = [
        "impressions",
        "clicks",
        "conversions",
        "conversions_value",
        "cost",
    ] + conversion_action_names
    master_df = pd.pivot_table(
        master_df,
        index=[
            "customer_id",
            "campaign_id",
            "name",
            "landing_page_url",
            "week",
        ],
        values=values,
        aggfunc="sum",
    ).reset_index()
    master_df.to_csv("master_df_2.csv", index=0)
