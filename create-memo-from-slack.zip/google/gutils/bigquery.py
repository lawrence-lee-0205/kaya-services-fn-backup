import pandas as pd

from google.gutils.utilities import get_bq_client


def run_query(query, format="dict"):
    print("Executing query:\n", query)
    client = get_bq_client()
    query_job = client.query(query)

    rows = query_job.result()  # Waits for job to complete.

    output_list_of_dict = [dict(row) for row in rows]

    if format == "dict":
        output = output_list_of_dict
    elif format == "dataframe":
        output = pd.DataFrame(output_list_of_dict)

    return output


def load_local_file(csv_filepath, table_id, **kwargs):
    from google.cloud import bigquery

    client = get_bq_client()

    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,
        autodetect=True,
        **kwargs
    )

    with open(csv_filepath, "rb") as source_file:
        job = client.load_table_from_file(source_file, table_id, job_config=job_config)

    job.result()  # Waits for the job to complete.

    table = client.get_table(table_id)  # Make an API request.
    print(
        "Loaded {} rows and {} columns to {}".format(
            table.num_rows, len(table.schema), table_id
        )
    )

    return None


# TODO(developer): Set table_id to the ID of the table to create.
# table_id = "your-project.your_dataset.your_table_name"


if __name__ == "__main__":
    load_local_file()
    # print(
    #     run_query(
    #         """
    #         SELECT
    #         AccountCurrencyCode as ccy,
    #         SUM(clicks) as clicks,
    #         SUM(cost) /1e6 as cost,
    #         SUM(impressions) as impressions,
    #         SUM(clicks)/SUM(impressions) as ctr,
    #         SUM(cost) / (SUM(clicks) * 1e6) as avg_cpc
    #         FROM
    #         `kaya-apps-staging.google_ads.keyword_performance`
    #         WHERE
    #         CampaignId = 15340145241
    #         group by 1
    #         ;
    #         """
    #     )
    # )
