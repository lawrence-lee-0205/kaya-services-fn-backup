from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.ads_query import run_ads_query
import pandas as pd

if __name__ == "__main__":
    business_id = "HxqMRHHuaEa3TMasBaus"
    query = f"""
        SELECT 
            keyword_view.resource_name, 
            ad_group_criterion.criterion_id, 
            ad_group_criterion.display_name, 
            ad_group_criterion.keyword.text, 
            ad_group_criterion.keyword.match_type, 
            ad_group_criterion.negative, 
            ad_group_criterion.status, 
            campaign.base_campaign, 
            campaign.name, 
            customer.id, 
            segments.month, 
            segments.date, 
            metrics.cost_micros, 
            metrics.clicks, 
            metrics.impressions,
            metrics.all_conversions, 
            metrics.conversions, 
            metrics.all_conversions_value, 
            metrics.conversions_value
        FROM keyword_view 
        WHERE 
            segments.date >= '2022-08-01' 
            AND segments.date < '2022-10-31' 
    """
    google_ads_account = GoogleAdsAccount(business_id=business_id)
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )
    outputs = []
    for row in rows:
        out = {
            "customer_id": row.customer.id,
            "customer_rn": row.customer.resource_name,
            "campaign_rn": row.campaign.resource_name,
            "campaign_base_campaign": row.campaign.base_campaign,
            "campaign_name": row.campaign.name,
            "conversions_value": row.metrics.conversions_value,
            "conversions": row.metrics.conversions,
            "all_conversions_value": row.metrics.all_conversions_value,
            "all_conversions": row.metrics.all_conversions,
            "match_type": row.ad_group_criterion.keyword.match_type,
            "keyword": row.ad_group_criterion.keyword.text,
            "date": row.segments.date,
            "cost_micros": row.metrics.cost_micros / 1e6,
            "clicks": row.metrics.clicks,
            "impressions": row.metrics.impressions,
        }
        outputs.append(out)
    output_df = pd.DataFrame(outputs)
    output_df.to_csv("output2_df.csv", index=0)

    # if row.campaign.name == "Security Deposit Alternatives":
    #     print(row)
