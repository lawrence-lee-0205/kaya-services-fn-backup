from google.gutils.utilities import get_api_client, queue_for_api
from queries import insert_last_google_api_timestamp


def run_ads_query(customer_id: str, query: str, manager_id: str) -> list:
    """Execute search queries

    Args:
        customer_id (str):
        query (str):

    Returns: list
    """
    print("Executing ", query)
    client = get_api_client(manager_id)

    queue_for_api(service="google_ads_service")
    insert_last_google_api_timestamp(
        service="google_ads_service", function="search_stream", num_operations=1
    )

    ga_service = client.get_service("GoogleAdsService")
    search_request = client.get_type("SearchGoogleAdsStreamRequest")
    search_request.customer_id = customer_id
    search_request.query = query

    stream = ga_service.search_stream(search_request)

    rows = []
    for batch in stream:
        for row in batch.results:
            rows.append(row)
    return rows
