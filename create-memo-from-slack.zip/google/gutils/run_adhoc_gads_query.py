from google.protobuf import json_format

from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.ads_query import run_ads_query
from http_function import http_function


@http_function
def run_adhoc_gads_query(request_json={}, request_args={}):
    print(request_json)
    print(request_args)
    mandatory_fields = ["business_id", "query"]

    for m in mandatory_fields:
        if m not in request_json:
            raise Exception(f"Expecting {m} to be provided")

    results_raw = execute(request_json["business_id"], request_json["query"])
    results = [json_format.MessageToDict(res._pb) for res in results_raw]
    return results


def execute(business_id, query):
    google_ads_account = GoogleAdsAccount(business_id=business_id)
    rows = run_ads_query(
        google_ads_account.client_id, query, google_ads_account.ads_manager_id
    )
    return rows


if __name__ == "__main__":
    import pandas as pd

    business_id = "WMMViNa0CiauqVUwsB60"
    start_date = "2024-01-01"
    end_date = "2024-08-01"

    query = f"""
        SELECT 
        segments.conversion_action_name, 
        segments.date,
        campaign.name, 
        campaign.id,
        campaign_criterion.location.geo_target_constant,
        metrics.all_conversions_value, 
        metrics.all_conversions 
        FROM location_view 
        WHERE segments.date >= '{ start_date }' 
        AND segments.date <= '{ end_date }'
        AND segments.conversion_action_name IN ('User 1st interaction', 'Payment')
    """
    rows = execute(business_id, query)

    output = [json_format.MessageToDict(res._pb) for res in rows]
    print(output)

    outputs = []
    for row in rows:
        print(row)
        out = {
            "conversion_action_name": row.segments.conversion_action_name,
            "date": row.segments.date,
            "week": row.segments.week,
            "month": row.segments.month,
            "campaign_name": row.campaign.name,
            "campaign_id": row.campaign.id,
            "all_conversions_value": row.metrics.all_conversions_value,
            "all_conversions": row.metrics.all_conversions,
            "geo_target_constant": row.campaign_criterion.location.geo_target_constant,
        }
        outputs.append(out)
    output_df = pd.DataFrame(outputs)

    by_action_df = pd.pivot_table(
        output_df,
        index=["campaign_id", "date", "geo_target_constant"],
        columns="conversion_action_name",
        values="all_conversions",
        aggfunc="sum",
    ).reset_index()
    by_action_df.to_csv("dailybot_location_by_action_df.csv", index=0)

    query = f"""
    SELECT 
        campaign.id, 
        campaign.name,
        segments.date,
        segments.week,
        segments.month,
        campaign_criterion.location.geo_target_constant,
        metrics.impressions, 
        metrics.clicks, 
        metrics.conversions, 
        metrics.conversions_value, 
        metrics.cost_micros
    FROM location_view 
    WHERE segments.date >= '{start_date}' 
        AND segments.date <= '{end_date}' 
    """
    rows = execute(business_id, query)

    output = [json_format.MessageToDict(res._pb) for res in rows]
    print(output)

    outputs = []
    for row in rows:
        # print(row)
        out = {
            "campaign_id": row.campaign.id,
            "campaign_name": row.campaign.name,
            "date": row.segments.date,
            "week": row.segments.week,
            "month": row.segments.month,
            "impressions": row.metrics.impressions,
            "clicks": row.metrics.clicks,
            "conversions": row.metrics.conversions,
            "conversions_value": row.metrics.conversions_value,
            "cost": row.metrics.cost_micros / 1e6,
            "geo_target_constant": row.campaign_criterion.location.geo_target_constant,
        }
        outputs.append(out)
    o_output_df = pd.DataFrame(outputs)
    o_output_df.to_csv("dailybot_location_df.csv", index=0)

    dailybot = pd.merge(
        o_output_df,
        by_action_df,
        on=["campaign_id", "date", "geo_target_constant"],
        how="left",
    )
    dailybot.to_csv("dailybot_location_merged.csv", index=0)

    # outputs = []
    # for row in rows:
    #     print(row)
    #     out = {
    #         "search_term": row.search_term_view.search_term,
    #         "status": row.search_term_view.status.name,
    #         "all_conversions": row.metrics.all_conversions,
    #         "all_conversions_value": row.metrics.all_conversions_value,
    #         "clicks": row.metrics.clicks,
    #         "conversions": row.metrics.conversions,
    #         "conversions_value": row.metrics.conversions_value,
    #         "cost_micros": row.metrics.cost_micros,
    #         "impressions": row.metrics.impressions,
    #         "name": row.ad_group.name,
    #         "name": row.campaign.name,
    #         "keyword_resource_name": row.segments.keyword.ad_group_criterion,
    #         "keyword_text": row.segments.keyword.info.text,
    #         "keyword_match_type": row.segments.keyword.info.match_type.name,
    #     }
    #     outputs.append(out)
    # output_df = pd.DataFrame(outputs)

    # q = f"""
    # SELECT
    #     search_term_view.search_term,
    #     segments.conversion_action_name,
    #     metrics.all_conversions_value,
    #     metrics.all_conversions,
    #     metrics.conversions,
    #     metrics.conversions_value
    # FROM search_term_view
    # WHERE segments.keyword.info.text LIKE '%text classification%'
    #     AND segments.date <= '{ start_date }'
    #     AND segments.date >= '{ end_date }'
    # """
    # rows_q = execute(business_id, q)
    # output_q = []
    # for row in rows_q:
    #     print(row)
    #     out = {
    #         "search_term": row.search_term_view.search_term,
    #         "conversion_action_name": row.segments.conversion_action_name,
    #         "all_conversions_value": row.metrics.all_conversions_value,
    #         "all_conversions": row.metrics.all_conversions,
    #         "conversions": row.metrics.conversions,
    #         "conversions_value": row.metrics.conversions_value,
    #     }
    #     output_q.append(out)
    # outputq_df = pd.DataFrame(output_q)

    # outputq_df.to_csv("outputq_df.csv", index=0)

    # # if row.campaign.name == "Security Deposit Alternatives":
    # #     print(row)
