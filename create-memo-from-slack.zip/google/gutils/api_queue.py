from queries import insert_last_google_api_timestamp
from google.gutils.utilities import queue_for_api


class Queue:
    def __init__(self, service) -> None:
        self.service = service

    def queue(self, function, num_operations):
        queue_for_api(self.service)
        insert_last_google_api_timestamp(self.service, function, num_operations)
