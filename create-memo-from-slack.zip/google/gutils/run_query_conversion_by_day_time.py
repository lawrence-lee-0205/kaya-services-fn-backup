from google.accounts.ads_account import GoogleAdsAccount
from google.gutils.ads_query import run_ads_query
import pandas as pd


def get_all_conversions(
    client_id, ads_manager_id, start_date, end_date, filter_kaya=True
):
    filter_kaya_str = "AND campaign.name LIKE '%Kaya%'" if filter_kaya else ""
    query = f"""
    SELECT 
        customer.id, 
        campaign.id, 
        campaign.name,
        segments.hour, 
        segments.date, 
        segments.day_of_week,
        metrics.impressions, 
        metrics.clicks, 
        metrics.conversions, 
        metrics.conversions_value, 
        metrics.cost_micros
    FROM campaign 
    WHERE segments.date >= '{start_date}' 
        AND segments.date <= '{end_date}' 
        {filter_kaya_str}
    """
    rows = run_ads_query(client_id, query, ads_manager_id)

    outputs = []
    for row in rows:
        out = {
            "customer_id": row.customer.id,
            "campaign_id": row.campaign.id,
            "name": row.campaign.name,
            "hour": row.segments.hour,
            "date": row.segments.date,
            "day_of_week": row.segments.day_of_week,
            "impressions": row.metrics.impressions,
            "clicks": row.metrics.clicks,
            "conversions": row.metrics.conversions,
            "conversions_value": row.metrics.conversions_value,
            "cost": row.metrics.cost_micros / 1e6,
        }
        outputs.append(out)
    output_df = pd.DataFrame(outputs)
    return output_df


def get_conversion_by_action(
    client_id,
    ads_manager_id,
    start_date,
    end_date,
    primary_conversion_actions,
    filter_kaya=True,
):
    primary_conversion_actions_str = ", ".join(
        [f"'{c}'" for c in primary_conversion_actions]
    )

    filter_kaya_str = "AND campaign.name LIKE '%Kaya%'" if filter_kaya else ""
    filter_conversion_names = (
        f"AND segments.conversion_action_name IN ({primary_conversion_actions_str})"
    )
    query = f"""
    SELECT 
        customer.id, 
        campaign.id, 
        segments.hour, 
        segments.date, 
        segments.day_of_week, 
        campaign.name, 
        segments.conversion_action, 
        segments.conversion_action_name,
        metrics.all_conversions, 
        metrics.all_conversions_value 
    FROM campaign 
    WHERE segments.date >= '{start_date}' 
        AND segments.date <= '{end_date}' 
        {filter_kaya_str}
        {filter_conversion_names}
    """
    rows = run_ads_query(client_id, query, ads_manager_id)

    outputs = []
    for row in rows:
        out = {
            "customer_id": row.customer.id,
            "campaign_id": row.campaign.id,
            "name": row.campaign.name,
            "hour": row.segments.hour,
            "date": row.segments.date,
            "day_of_week": row.segments.day_of_week,
            "conversion_action": row.segments.conversion_action,
            "conversion_action_name": row.segments.conversion_action_name,
            "all_conversions": row.metrics.all_conversions,
            "all_conversions_value": row.metrics.all_conversions_value,
        }
        outputs.append(out)
    output_df = pd.DataFrame(outputs)
    return output_df


if __name__ == "__main__":
    business_id = "82cutQRlx6gagQFMKjPa"
    start_date = "2023-08-27"
    end_date = "2023-11-24"

    required_conv_lst = ["Demo, Quote, or Tour", "S1 Meeting Booked", "S2 Opportunity"]

    google_ads_account = GoogleAdsAccount(business_id=business_id)

    all_stats_df = get_all_conversions(
        google_ads_account.client_id,
        google_ads_account.ads_manager_id,
        start_date,
        end_date,
        filter_kaya=True,
    )
    selected_conv_df = get_conversion_by_action(
        google_ads_account.client_id,
        google_ads_account.ads_manager_id,
        start_date,
        end_date,
        required_conv_lst,
    )

    selected_conv_df["conversion_action_name"] = selected_conv_df[
        "conversion_action_name"
    ].apply(lambda x: x.replace(" ", "_"))
    pivot_selected_conv_df = pd.pivot_table(
        selected_conv_df,
        index=["customer_id", "campaign_id", "hour", "date", "day_of_week", "name"],
        columns="conversion_action_name",
        values="all_conversions",
        aggfunc="sum",
    ).reset_index()

    master_df = pd.merge(
        all_stats_df,
        pivot_selected_conv_df,
        on=["customer_id", "campaign_id", "hour", "date", "day_of_week", "name"],
        how="left",
    )
    master_df["dow"] = pd.to_datetime(master_df["date"]).dt.strftime("%a")

    master_df.to_csv("master_df.csv", index=0)

    pivoted_report_by_dow_hour_df = (
        pd.pivot_table(
            master_df,
            index=["name", "dow", "hour"],
            values=[
                "Demo,_Quote,_or_Tour",
                "S1_Meeting_Booked",
                "S2_Opportunity",
                "impressions",
                "clicks",
                "cost",
            ],
            aggfunc="sum",
        )
        .reset_index()
        .to_csv("pivoted_report_by_dow_hour_df.csv", index=0)
    )

    # if row.campaign.name == "Security Deposit Alternatives":
    #     print(row)
