import os
import pandas as pd
from datetime import datetime

from setup import setup
from gsheets.gsheet import GSheet
from common import validate_inputs
from http_function import http_function, process_request_inputs
from google.cloud_functions.call_cloud_function import call_cloud_function

from firestore import FirestoreClient
_FS = FirestoreClient()

os.environ["GOOGLE_ADS_USE_PROTO_PLUS"] = "True"


@setup
def generate_gad_copy_gsheet(data: dict) -> dict:
    mandatory_fields = ["auth_user_id", "ads_copy_gen_id", "email"]
    validate_inputs(data, mandatory_fields)

    out = execute(
        ads_copy_gen_id=data["ads_copy_gen_id"],
        email=data["email"],
        export_to_gsheet=True,
    )
    return out

@http_function
def generate_gad_copy_gsheet_http(request_json={}, request_args={}):
    mandatory_fields = ["ads_copy_gen_id", "email"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    out = execute(
        ads_copy_gen_id=data["ads_copy_gen_id"],
        email=data["email"],
        export_to_gsheet=True,
    )
    return out

def get_firestore_ads_copy_data(ads_copy_gen_id):
    # get data from firestore sources, output in dict format
    # (1) google_ads_generation_sessions
    # (2) google_ads_keyword_generations
    # (3) google_ads_copy_generations
    
    ad_copy_doc = _FS.get_single_document("google_ads_copy_generations", ads_copy_gen_id)

    fs_gads_session_id = ad_copy_doc["gads_session_doc_id"]
    ad_gen_doc = _FS.get_single_document("google_ads_generation_sessions", fs_gads_session_id)

    fs_keyword_gen_id = ad_copy_doc["gads_keyword_doc_id"]
    ad_keyword_doc = _FS.get_single_document("google_ads_keyword_generations", fs_keyword_gen_id)

    return ad_copy_doc, ad_gen_doc, ad_keyword_doc

def get_selected_keywords_from_gsheet(ad_keyword_doc):
    endpoint = f"/get-proposal-from-gsheet"

    selected_keywords_dict = {}
    if ad_keyword_doc["keyword_gsheet_id"]:
        params = {"key": ad_keyword_doc["keyword_gsheet_id"]}
        selected_keywords_dict_list = call_cloud_function(endpoint, params)

        selected_keywords_dict = {}
        for item in selected_keywords_dict_list:
            ad_group = item['ad_group'].replace(' ', '_')
            keyword = item['text']
            if ad_group not in selected_keywords_dict:
                selected_keywords_dict[ad_group] = []
            selected_keywords_dict[ad_group].append(keyword)
    else:
        print("keyword_gsheet_id is False")
    
    return selected_keywords_dict

def ad_copy_dict_to_df(ad_copy_doc, selected_keywords_dict):
    rows = []
    for ad_group, group_data in ad_copy_doc['ad_groups'].items():
        # Sort headlines order
        keyorder = ["headline_1", "headline_2", "headline_3", "headline_4", "descriptions"]
        group_data['headlines'] = {
            k: group_data['headlines'][k] 
            for k in keyorder 
            if k in group_data['headlines']
        }

        # Iterate over headlines
        for headline, selected_headlines in group_data['headlines'].items():
            # Append each selected headline to the rows list as a separate row
            for selected_headline in selected_headlines:
                rows.append({'ad_group_name': ad_group, 'ad_component': headline, 'text': selected_headline})

        # Iterate over descriptions
        for description in group_data['descriptions']:
            rows.append({'ad_group_name': ad_group, 'ad_component': 'descriptions', 'text': description})

        # Iterate over keywords
        ad_group_keywords = selected_keywords_dict[ad_group]
        for keyword in ad_group_keywords:
            rows.append({'ad_group_name': ad_group, 'ad_component': 'keyword', 'text': keyword})

    df = pd.DataFrame(rows)
    return df

def ad_gen_info_dict_to_df(ad_gen_doc):
    # add business info
    data_list = ["business_name", "business_domain", "business_id"]

    rows = []
    for d in data_list:
         if ad_gen_doc[d]:
            rows.append([f"{d}", ad_gen_doc[d]])

    df = pd.DataFrame(rows)
    return df

def ad_keyword_info_dict_to_df(ad_keyword_doc):
    # add keyword_gsheet_id
    if ad_keyword_doc["keyword_gsheet_id"]:
        row = [[f"keyword_gsheet_id", ad_keyword_doc["keyword_gsheet_id"]]]
        df = pd.DataFrame(row)
        return df
    else:
        print("keyword_gsheet_id is False")

def ad_copy_info_dict_to_df(ad_copy_doc):
    # add ad copy info
    data_list = ["business_desc", "business_usp", "tone_of_voice", "campaign_goal", "sample_ad_copies"]

    rows = []
    for d in data_list:
        if ad_copy_doc[d]:
            rows.append([f"{d}", ad_copy_doc[d]])

    ad_copy_info_df = pd.DataFrame(rows)

    # add ad_group
    ad_group_rows = []
    ad_group_index = 1
    ad_group_rows.append(["ad_groups", ""])
    for ad_group in list(ad_copy_doc["ad_groups"].keys()):
        ad_group_rows.append([f"ad group {ad_group_index}", ad_group])
        ad_group_index += 1
    ad_group_df = pd.DataFrame(ad_group_rows)

    return ad_copy_info_df, ad_group_df

def export_ad_copies_to_gsheet(
    ad_copy_doc,
    ad_gen_doc,
    ad_keyword_doc,
    email,
    export_to_gsheet,
):
    customer_url = ad_gen_doc["business_domain"]
    filename = f"GAds Copies for {customer_url} {datetime.now()} {os.environ['ENV']}"
    print("filename: ", filename)

    if export_to_gsheet and ad_copy_doc:
        gsheet = GSheet()
        gsheet.create(filename)

        # Add summary
        ad_gen_info_df = ad_gen_info_dict_to_df(ad_gen_doc)
        ad_copy_info_df, ad_group_df = ad_copy_info_dict_to_df(ad_copy_doc)
        ad_keyword_info_df = ad_keyword_info_dict_to_df(ad_keyword_doc)

        ad_copy_summary_df = pd.concat(
            [ad_gen_info_df, ad_copy_info_df, ad_keyword_info_df, ad_group_df], 
            ignore_index=True, 
            sort=False
        )

        uniq_tab_name = "summary"
        gsheet.add_tab(
            uniq_tab_name,
            rows=ad_copy_summary_df.shape[0],
            # cols=ad_copy_df.shape[1],
        )
        gsheet.write_dataframe_to_tab(ad_copy_summary_df, uniq_tab_name)

        # Add ad copies
        selected_keywords_dict = get_selected_keywords_from_gsheet(ad_keyword_doc)
        ad_copy_df = ad_copy_dict_to_df(ad_copy_doc, selected_keywords_dict)

        uniq_tab_name = "ad_copy"
        gsheet.add_tab(
            uniq_tab_name,
            rows=ad_copy_df.shape[0],
        )
        gsheet.write_dataframe_to_tab(ad_copy_df, uniq_tab_name)

        # share
        emails = [{"email": "usekaya.com", "role": "reader", "type": "domain"}]
        if email is not None:
            emails.append({"email": email, "role": "writer"})
        gsheet.share(emails)
        print("GSheet shared successfully.")

        return {"url": gsheet.url}
    
    else:
        print("export_to_gsheet is False and/or input df is empty.")


def execute(
    ads_copy_gen_id,
    email=None,
    export_to_gsheet=False,
):
    ############################
    #    GET FIRESTORE DATA    #
    ############################
    (
        ad_copy_doc, 
        ad_gen_doc, 
        ad_keyword_doc,
    ) = get_firestore_ads_copy_data(ads_copy_gen_id)

    #########################
    #   EXPORT TO GSHEET    #
    #########################
    gsheet_info = export_ad_copies_to_gsheet(
        ad_copy_doc,
        ad_gen_doc,
        ad_keyword_doc,
        email,
        export_to_gsheet,
    )

    return gsheet_info


if __name__ == "__main__":
    from utils.kaya_yaml import read_yaml

    # company = "dailybot"
    # yaml_dir = "/Users/jeeyenpersonal/Documents/kaya-services/notebooks/yaml/"
    # config = read_yaml(yaml_dir + company.lower() + ".yml")
    doc = {
        "ads_copy_gen_id": "mJseFlWddUci6wAonVZV",
        "email": "hailey@usekaya.com", # TEMP
    }

    execute(export_to_gsheet=True, **doc)
