"""https://github.com/sendgrid/sendgrid-python/blob/main/use_cases/kitchen_sink.md"""

import os
from sendgrid.helpers.mail import Mail, Cc, ReplyTo, TrackingSettings, OpenTracking
from sendgrid import SendGridAPIClient

from http_function import http_function

# from address passed to our Mail object
_FROM_EMAIL = "admin@usekaya.com"

_TEMPLATE_ID_MAPPING = {
    "postcall": "d-7388f0b79c8f464cbd3369c9f9f16c24",
    "precall": "d-a9764bd00f3f4eb2924db479dbbea4dd",
}

_TEMPLATE_PARAMS_MAPPING = {
    "postcall": [
        "contact_name",
        "ad_groups",
        "landing_page",
        "daily_budget",
        "num_ad_groups",
        "launch_date",
        "first_mth_subtotal",
        "first_mth_setup_fee",
        "first_mth_maintenance_fee",
        "first_mth_ad_spend",
        "first_mth_total",
        "sub_mth_maintenance_fee",
        "sub_mth_ad_spend",
        "sub_mth_total",
        "next_steps",
    ],
    "precall": [
        "contact_name",
        "intro",
        "ad_groups",
        "landing_page",
    ],
}


def execute(data):
    """Send a dynamic email to a list of email addresses

    :returns API response code
    :raises Exception e: raises an exception"""

    # Validate recipient emails
    if not isinstance(data["to_emails"], list):
        raise Exception("Param `to_emails` must be a list.")

    to_emails = data["to_emails"]

    # Process dynamic data
    non_dynamic_data_fields = ["to_emails", "template"]
    dynamic_data = {
        key: value for key, value in data.items() if key not in non_dynamic_data_fields
    }

    # Validate fields required for dynamic template
    template = data["template"]
    mandatory_inputs = _TEMPLATE_PARAMS_MAPPING[template]
    for m in mandatory_inputs:
        if m not in dynamic_data.keys():
            raise Exception(f"Expecting `{m}` to be provided for template `{template}`")

    # Send email
    message = Mail(from_email=_FROM_EMAIL, to_emails=to_emails)

    # process cc emails
    processed_cc_emails = [
        Cc(email=em) for em in data["cc_emails"]
    ]  # IMPORTANT! TO EMAIL & CC CANNOT BE THE SAME
    message.cc = processed_cc_emails

    # process reply emails
    message.reply_to = ReplyTo("admin@usekaya.com", "Team Kaya")

    # pass custom values for our HTML placeholders
    message.dynamic_template_data = {
        "subject": "Google Ads Proposal by Kaya",
        **dynamic_data,
    }
    message.template_id = _TEMPLATE_ID_MAPPING[template]

    # add tracking
    tracking_settings = TrackingSettings()
    tracking_settings.open_tracking = OpenTracking(True)
    message.tracking_settings = tracking_settings

    # create our sendgrid client object, pass it our key, then send and return our response objects
    sg = SendGridAPIClient(os.environ["SENDGRID_API_KEY"])
    response = sg.send(message)
    if str(response.status_code)[:1] != "2":
        raise Exception(
            f"Email failure (code {response.status_code}):\n{response.body}"
        )

    return "Success"


@http_function
def send_proposal_via_email(request_json={}, request_args={}):
    mandatory_fields = [
        "template",
        "contact_name",
        "ad_groups",
        "landing_page",
        "to_emails",
        "cc_emails",
    ]
    print("request_json: ", request_json)
    print("request_args: ", request_args)

    for m in mandatory_fields:
        if m not in request_json.keys():
            raise Exception(f"Expecting {m} to be provided")

    out = execute(data=request_json)
    return out


if __name__ == "__main__":
    # from utils.jinja import render_template

    # payload = {
    #     "subject": "test proposal",
    #     "first_name": "there",
    #     "ad_groups": [{"name": "test"}],
    # }
    # html_content = render_template(
    #     folder=".", filename="proposal_email_template.html", **payload
    # )
    # send(
    #     from_email="admin@usekaya.com",
    #     to_emails=["jeeyen@usekaya.com"],
    #     subject="test proposal",
    #     html_content=html_content,
    # )
    data = {
        "first_mth_maintenance_fee": "$89",
        "landing_page": "",
        "sub_mth_total": "$4,955",
        "first_mth_ad_spend": "$1,050",
        "to_emails": ["jeeyen@usekaya.com"],
        "cc_emails": ["jeeyen+12@usekaya.com"],
        "daily_budget": "150",
        "template": "postcall",
        "first_mth_subtotal": "$834",
        "launch_date": "2022-10-25",
        "next_steps": "If you'd like to proceed, we'll send over a service agreement & Stripe link for card authorization. Once they're sorted, we'll have the campaign ready for review and delivered within 7 days. All you need to do on your side is to prepare the landing pages.",
        "sub_mth_ad_spend": "$4,560",
        "sub_mth_maintenance_fee": "$395",
        "contact_name": "there",
        "num_ad_groups": "5",
        "ad_groups": [
            {
                "ad_group": "Annotation Tool",
                "bid": "$12.91",
                "search_vol_monthly": "3,180",
                "num_keywords_in_ag": "20",
                "all_keywords": "",
                "keywords": "· annotationtool\n· image annotation tools\n· image labeling tools\n· online image annotation\n· computer vision annotation tool\n· software to annotate images\n· image annotation software\n· annotation platform\n· bounding box annotations\n· best image annotation tools\n· online image annotation tool\n· bounding box annotation tool\n· automatic image annotation tool\n· ai assisted annotation\n· ai data annotation platform\n· 3d bounding box annotation\n· 3d bounding box annotation tool\n· image annotation tools for computer vision\n· automatic image annotation\n· image classification annotation tool",
            },
            {
                "ad_group": "Data Labelling",
                "bid": "$18.51",
                "search_vol_monthly": "2,100",
                "num_keywords_in_ag": "4",
                "all_keywords": "",
                "keywords": "· automated data labeling\n· data labelling platform\n· data labeling tools\n· ai data labeling",
            },
            {
                "ad_group": "Competitor (Scale, v7, LabelB, SuperA)",
                "bid": "$6.09",
                "search_vol_monthly": "1,330",
                "num_keywords_in_ag": "29",
                "all_keywords": "",
                "keywords": "· scale pricing\n· super annotate\n· v7labs\n· v7 darwin\n· scale ai pricing\n· scale ai nucleus\n· scale ai data labeling\n· labelbox competitors\n· scale ai labeling\n· scale ai api\n· v7 annotation\n· labelbox reviews\n· labelbox python sdk\n· labelbox model assisted labeling\n· v7 ai\n· labelbox annotation tool\n· labelbox alternatives\n· labelbox segmentation\n· labelbox image segmentation\n· labelbox video annotation\n· scale data labeling\n· scale data annotation\n· scale ai annotation\n· v7 model\n· v7 image\n· v7lab\n· v7 tool\n· v7 software\n· v7 app",
            },
            {
                "ad_group": "Annotation Services",
                "bid": "$23.77",
                "search_vol_monthly": "1,080",
                "num_keywords_in_ag": "13",
                "all_keywords": "",
                "keywords": "· annotation services\n· data annotation service\n· image annotation services\n· ai image annotation\n· image annotation service\n· image labeling service\n· image annotation companies\n· data labeling and annotation services\n· ai annotation companies\n· machine learning image tagging\n· computer vision labeling\n· automatic image labelling\n· semantic labeling of images",
            },
            {
                "ad_group": "Medical Image Annotation",
                "bid": "$15.28",
                "search_vol_monthly": "470",
                "num_keywords_in_ag": "4",
                "all_keywords": "",
                "keywords": "· medical image annotation\n· medical annotation\n· medical data labeling\n· medical data annotation",
            },
        ],
        "first_mth_setup_fee": "$745",
        "first_mth_total": "$1,884",
    }

    execute(data)
