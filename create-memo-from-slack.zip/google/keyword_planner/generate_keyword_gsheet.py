import os
import pandas as pd
import copy
from datetime import datetime

from setup import setup
from gsheets.gsheet import GSheet
from common import validate_inputs
from http_function import http_function, process_request_inputs

from nlp.clustering import group_keywords

# from nlp.bert_clustering import cluster_with_bert
from nlp.utils import is_substring_exists

from google.keyword_planner.get_keyword_ideas import get_keyword_ideas
from google.keyword_planner.utils_keywords import consolidate_similar_keywords
from google.keyword_planner.recommend_keywords import (
    generate_keyword_recommendations,
    get_top_n_keyword_score_by_category,
)


os.environ["GOOGLE_ADS_USE_PROTO_PLUS"] = "True"

_DEFAULT_LANGUAGE_ID = "1000"
_MILLION = 1e6
_COLUMNS = [
    "ad_group",
    "category",
    "sub_category",
    "text",
    "to_keep",
    "is_negative",
    "similar_keywords",
    "avg_monthly_searches",
    "competition_value",
    "competition_index",
    "low_top_of_page_bid",
    "high_top_of_page_bid",
    "avg_top_of_page_bid",
    "exp_cost",
    "num_urls",
    "is_user_provided",
    "is_branded",
    "keyword_annotations",
    # keyword recommendation
    "avg_monthly_searches_category",
    "competition_index_category",
    "low_top_of_page_bid_category",
    "high_top_of_page_bid_category",
    "num_urls_category",
    "keyword_score",
    "keyword_score_rank",
    "keyword_score_category_rank",
]
_THRESHOLDS = {"category": 0.95, "sub_category": 0.8}


@setup
def generate_keyword_gsheet(data: dict) -> dict:
    mandatory_fields = ["auth_user_id", "seed_keywords", "email"]
    validate_inputs(data, mandatory_fields)

    out = execute(
        customer_url=data.get("customer_url", ""),
        locations=data.get("locations", []),
        seed_keywords=data["seed_keywords"],
        competitors=data.get("competitors", []),
        negative_keywords=data.get("negative_keywords", []),
        email=data["email"],
        skip_categorisation=data.get("skip_categorisation", False),
        export_to_gsheet=True,
    )
    return out


@http_function
def generate_keyword_gsheet_http(request_json={}, request_args={}):
    mandatory_fields = ["seed_keywords", "email"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    out = execute(
        customer_url=data.get("customer_url", ""),
        locations=data.get("locations", []),
        seed_keywords=data["seed_keywords"],
        competitors=data.get("competitors", []),
        negative_keywords=data.get("negative_keywords", []),
        email=data["email"],
        skip_categorisation=data.get("skip_categorisation", True),
        export_to_gsheet=True,
    )
    return out


@http_function
def google_generate_keyword_gsheet_http(request_json={}, request_args={}):
    mandatory_fields = ["seed_keywords", "email"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    out = execute(
        customer_url=data.get("customer_url", ""),
        locations=data.get("locations", []),
        seed_keywords=data["seed_keywords"],
        competitors=data.get("competitors", []),
        negative_keywords=data.get("negative_keywords", []),
        email=data["email"],
        skip_categorisation=data.get("skip_categorisation", True),
        export_to_gsheet=True,
    )
    return out


def generate_keyword_ideas(
    customer_url,
    seed_keywords,
    locations,
    languages,
    competitors,
    negative_keywords,
    skip_categorisation,
):
    # customer_id = "7610684994"
    customer_id = "6006145025" if "PROD" in os.environ["ENV"] else "3385265876"

    # get metadata
    # google_acc = get_google_account_by_client_id(customer_id)
    ccy = "USD"

    if len(languages) > 1:
        raise Exception("Only except 1 language now")
    lang = languages[0]

    # remove empty string
    seed_keywords = [kw for kw in seed_keywords if kw != ""]

    ################################
    #    GENERATE KEYWORD IDEAS    #
    ################################
    keyword_ideas_raw_df = get_keyword_ideas(
        customer_id,
        customer_url,
        keywords=seed_keywords,
        page_urls=competitors,
        incl_location_ids=locations,
        incl_language_id=lang,
    )

    in_competitors_series = pd.pivot_table(
        keyword_ideas_raw_df, index="text", aggfunc=pd.Series.nunique, values="page_url"
    )
    in_competitors_dct = in_competitors_series.to_dict()["page_url"]

    keyword_ideas_raw_df["num_urls"] = keyword_ideas_raw_df["text"].map(
        in_competitors_dct
    )
    # keyword_ideas_df.to_csv("keyword_ideas_df.csv", index=0)

    # keyword_ideas_df = pd.read_csv("keyword_ideas_df.csv")

    #############################
    #    POSTPROCESS RESULTS    #
    #############################
    keyword_ideas_df = keyword_ideas_raw_df.copy()

    # remove dups
    keyword_ideas_df = keyword_ideas_df.sort_values(
        by=["avg_monthly_searches"], ascending=False
    ).drop_duplicates(subset=["text"])

    # remove negative keywords
    if len(negative_keywords) > 0:
        print(f"Shape before removing negative keywords: {keyword_ideas_df.shape}")
        print(f"Removing negative keywords: {negative_keywords}")
        keyword_ideas_df["has_negative_word"] = keyword_ideas_df["text"].apply(
            lambda text: any(
                is_substring_exists(negative_kw, text)
                for negative_kw in negative_keywords
            )
        )
        keyword_ideas_df = keyword_ideas_df[~keyword_ideas_df["has_negative_word"]]

    # grouping
    if not skip_categorisation:
        # if use bert clustering
        # text_divided = int(keyword_ideas_df["text"].nunique() / 20)
        # max_cluster = min(text_divided, 10)
        # cluster_map = cluster_with_bert(keyword_ideas_df["text"].tolist(), max_cluster)
        # keyword_ideas_df["category"] = keyword_ideas_df["text"].map(cluster_map)

        # for name, kw_list in cluster_map.items():
        #     keyword_ideas_df.loc[
        #         keyword_ideas_df["text"].isin(kw_list), "category"
        #     ] = name

        # use normal clustering - better, faster
        for cat, thres in _THRESHOLDS.items():
            print("Processing", cat)
            grp = group_keywords(keyword_ideas_df["text"].tolist(), thres)
            for name, kw_list in grp.items():
                keyword_ideas_df.loc[keyword_ideas_df["text"].isin(kw_list), cat] = name

    else:
        keyword_ideas_df["category"] = "All"
        keyword_ideas_df["sub_category"] = "All"

    # convert to normal value
    for c in ["low_top_of_page_bid", "high_top_of_page_bid"]:
        keyword_ideas_df[c] = keyword_ideas_df[c + "_micros"] / _MILLION

    # get unique keywords for raw data output
    filtered_keywords = keyword_ideas_df["text"].unique()

    filtered_keyword_ideas_raw_df = copy.deepcopy(keyword_ideas_raw_df)
    filtered_keyword_ideas_raw_df = filtered_keyword_ideas_raw_df.loc[
        filtered_keyword_ideas_raw_df["text"].isin(filtered_keywords)
    ]

    # remove dups for similar keywords
    keyword_ideas_df = consolidate_similar_keywords(keyword_ideas_df)

    # calculate avg_top_of_page_bid
    keyword_ideas_df["avg_top_of_page_bid"] = (
        keyword_ideas_df["low_top_of_page_bid"]
        + keyword_ideas_df["high_top_of_page_bid"]
    ) / 2

    # calculate exp_cost
    keyword_ideas_df["exp_cost"] = (
        keyword_ideas_df["avg_top_of_page_bid"]
        * keyword_ideas_df["avg_monthly_searches"]
    )

    # add columns for input
    keyword_ideas_df["to_keep"] = False
    keyword_ideas_df["is_negative"] = False
    keyword_ideas_df["ad_group"] = ""

    ###########################
    #    RECOMMEND KEYWORDS   #
    ###########################
    feature_cols = [
        "avg_monthly_searches",
        "competition_index",
        "low_top_of_page_bid",
        "high_top_of_page_bid",
        "num_urls",
    ]
    keyword_ideas_df = generate_keyword_recommendations(keyword_ideas_df, feature_cols)
    keyword_ideas_df = keyword_ideas_df[_COLUMNS]

    return keyword_ideas_df, filtered_keyword_ideas_raw_df


def export_keywords_to_gsheet(
    customer_url,
    email,
    export_to_gsheet,
    keyword_ideas_df,
    filtered_keyword_ideas_raw_df,
    top_keywords_df,
):
    filename = f"Keywords for {customer_url} {datetime.now()} {os.environ['ENV']}"

    if export_to_gsheet and keyword_ideas_df.shape[0] > 0:
        gsheet = GSheet()
        gsheet.create(filename)

        # add filtered keywords
        uniq_tab_name = "unique"
        gsheet.add_tab(
            uniq_tab_name,
            rows=keyword_ideas_df.shape[0],
            cols=keyword_ideas_df.shape[1],
        )
        gsheet.write_dataframe_to_tab(keyword_ideas_df, uniq_tab_name)

        # add top keywords by category
        uniq_tab_name = "top_keywords"
        gsheet.add_tab(
            uniq_tab_name,
            rows=top_keywords_df.shape[0],
            cols=top_keywords_df.shape[1],
        )
        gsheet.write_dataframe_to_tab(top_keywords_df, uniq_tab_name)

        # add raw data
        raw_tab_name = "raw"
        if len(filtered_keyword_ideas_raw_df) < 5e3:
            gsheet.add_tab(
                raw_tab_name,
                rows=filtered_keyword_ideas_raw_df.shape[0],
                cols=filtered_keyword_ideas_raw_df.shape[1],
            )
            gsheet.write_dataframe_to_tab(filtered_keyword_ideas_raw_df, raw_tab_name)

        # share
        emails = [{"email": "usekaya.com", "role": "reader", "type": "domain"}]
        if email is not None:
            emails.append({"email": email, "role": "writer"})
        gsheet.share(emails)
        print("GSheet shared successfully.")

        return {"url": gsheet.url}

    else:
        print("export_to_gsheet is False and/or keyword_ideas_df is empty.")


def execute(
    customer_url,
    seed_keywords,
    locations=[],
    languages=[_DEFAULT_LANGUAGE_ID],
    competitors=[],
    negative_keywords=[],
    email=None,
    skip_categorisation=False,
    export_to_gsheet=False,
):
    ################################
    #    GENERATE KEYWORD IDEAS    #
    ################################
    keyword_ideas_df, keyword_ideas_raw_df = generate_keyword_ideas(
        customer_url,
        seed_keywords,
        locations,
        languages,
        competitors,
        negative_keywords,
        skip_categorisation,
    )

    ##########################
    #    GET TOP KEYWORDS    #
    ##########################
    top_n_keyword_score = 5
    top_keywords_df = get_top_n_keyword_score_by_category(
        keyword_ideas_df, top_n_keyword_score
    )

    #########################
    #   EXPORT TO GSHEET    #
    #########################
    gsheet_info = export_keywords_to_gsheet(
        customer_url,
        email,
        export_to_gsheet,
        keyword_ideas_df,
        keyword_ideas_raw_df,
        top_keywords_df,
    )

    return gsheet_info


if __name__ == "__main__":
    from utils.kaya_yaml import read_yaml

    # company = "dailybot"
    # yaml_dir = "/Users/jeeyenpersonal/Documents/kaya-services/notebooks/yaml/"
    # config = read_yaml(yaml_dir + company.lower() + ".yml")
    doc = {
        "customer_url": "honacare.com",
        "locations": [21180, 21137, 21136, 21170],
        "seed_keywords": [
            "speech therapy",
            "language delay therapy",
            "lisp therapy",
            "stuttering",
            "Speech Sound Disorders therapy",
            "Language Development therapy",
            "Reading & Dyslexia therapy",
            "Language Disorder therapy",
            "Aphrasia therapy",
            "aac therapy",
        ],
        "negative_keywords": [],
        "competitors": ["beaminghealth.com", "expressable.com", "joincoralcare.com"],
        "email": "jeeyen@usekaya.com",
        "skip_categorisation": True,
    }

    execute(export_to_gsheet=True, **doc)
