from http_function import process_request_inputs, http_function
from common import validate_inputs
from gsheets.gsheet import GSheet
from google.keyword_planner.utils_keywords import TEST_GSHEET_ID

_MANDATORY_COLS = [
    "text",
    "category",
    "ad_group",
    "to_keep",
    "is_negative",
    "avg_monthly_searches",
    "competition_index",
    "avg_top_of_page_bid",
    "low_top_of_page_bid",
    "high_top_of_page_bid",
    "num_urls",
    "category_avg_monthly_searches_sum",
    "category_avg_monthly_searches_median",
    "category_low_top_of_page_bid_median",
    "category_high_top_of_page_bid_median",
    "category_competition_index_median",
    "keyword_score_category_rank",
    "category_rank",
]


@http_function
def get_keyword_recommendations(request_json={}, request_args={}):
    mandatory_fields = ["key"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    print("request_json: ", request_json)
    print("request_args: ", request_args)

    out = execute(key=data["key"])
    return out


def execute(key):
    gsheet = GSheet()
    gsheet.open_existing_file_by_key(key)

    df_unq = gsheet.get_dataframe_from_tab("unique")

    df = gsheet.get_dataframe_from_tab("top_keywords")
    cols_available = df.columns

    for col in _MANDATORY_COLS:
        if col not in cols_available:
            raise Exception("Missing col", col)

    # filter out negative keywords based on both dfs
    condition = lambda df: df["is_negative"] == "TRUE"
    negative_keywords_df_list = df.loc[condition(df), "text"].unique()
    negative_keywords_df_unq_list = df_unq.loc[condition(df_unq), "text"].unique()
    negative_keywords_list = set(
        [*negative_keywords_df_list, *negative_keywords_df_unq_list]
    )

    df_filtered = df[~df["text"].isin(negative_keywords_list)]
    data = df_filtered[_MANDATORY_COLS].to_dict(orient="records")

    return data


if __name__ == "__main__":
    print(execute(TEST_GSHEET_ID))
