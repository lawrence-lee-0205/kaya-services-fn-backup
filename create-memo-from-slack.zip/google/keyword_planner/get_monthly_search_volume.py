#!/usr/bin/env python
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""This example generates historical metrics for keyword planning.

For more details see this guide:
https://developers.google.com/google-ads/api/docs/keyword-planning/generate-historical-metrics
"""

import time
import pandas as pd

from google.ads.googleads.client import GoogleAdsClient
from google.ads.googleads.errors import GoogleAdsException

CLIENT = GoogleAdsClient.load_from_env()


def generate_historical_metrics(customer_id, keywords, geo_id):
    """Generates historical metrics and prints the results.

    Args:
        client: an initialized GoogleAdsClient instance.
        customer_id: a client customer ID.
    """
    googleads_service = CLIENT.get_service("GoogleAdsService")
    keyword_plan_idea_service = CLIENT.get_service("KeywordPlanIdeaService")
    request = CLIENT.get_type("GenerateKeywordHistoricalMetricsRequest")
    request.customer_id = customer_id
    request.keywords = keywords
    # Geo target constant 2840 is for USA.
    request.geo_target_constants.append(
        googleads_service.geo_target_constant_path(str(geo_id))
    )
    request.keyword_plan_network = CLIENT.enums.KeywordPlanNetworkEnum.GOOGLE_SEARCH
    # Language criteria 1000 is for English. For the list of language criteria
    # IDs, see:
    # https://developers.google.com/google-ads/api/reference/data/codes-formats#languages
    request.language = googleads_service.language_constant_path("1000")

    response = keyword_plan_idea_service.generate_keyword_historical_metrics(
        request=request
    )

    data = []
    for result in response.results:
        metrics = result.keyword_metrics
        # These metrics include those for both the search query and any variants
        # included in the response.
        # print(
        #     f"The search query '{result.text}' (and the following variants: "
        #     f"'{result.close_variants if result.close_variants else 'None'}'), "
        #     "generated the following historical metrics:\n"
        # )

        # Approximate number of monthly searches on this query averaged for the
        # past 12 months.
        # print(f"\tApproximate monthly searches: {metrics.avg_monthly_searches}")

        # The competition level for this search query.
        # print(f"\tCompetition level: {metrics.competition}")

        # The competition index for the query in the range [0, 100]. This shows
        # how competitive ad placement is for a keyword. The level of
        # competition from 0-100 is determined by the number of ad slots filled
        # divided by the total number of ad slots available. If not enough data
        # is available, undef will be returned.
        # print(f"\tCompetition index: {metrics.competition_index}")

        # Top of page bid low range (20th percentile) in micros for the keyword.
        # print(f"\tTop of page bid low range: {metrics.low_top_of_page_bid_micros}")

        # Top of page bid high range (80th percentile) in micros for the
        # keyword.
        # print("\tTop of page bid high range: " f"{metrics.high_top_of_page_bid_micros}")

        # Approximate number of searches on this query for the past twelve
        # months.
        # for month in metrics.monthly_search_volumes:
        #     print(
        #         f"\tApproximately {month.monthly_searches} searches in "
        #         f"{month.month.name}, {month.year}"
        #     )

        data.append(
            {
                "keyword": result.text,
                "avg_monthly_searches": metrics.avg_monthly_searches,
                "competition": metrics.competition,
                "competition_index": metrics.competition_index,
                "low_top_of_page_bid": metrics.low_top_of_page_bid_micros / 1e6,
                "high_top_of_page_bid": metrics.high_top_of_page_bid_micros / 1e6,
            }
        )
    return data


if __name__ == "__main__":
    # parser = argparse.ArgumentParser(
    #     description="Generates forecast metrics for keyword planning."
    # )
    # # The following argument(s) should be provided to run the example.
    # parser.add_argument(
    #     "-c",
    #     "--customer_id",
    #     type=str,
    #     required=True,
    #     help="The Google Ads customer ID.",
    # )

    # args = parser.parse_args()

    # # GoogleAdsClient will read the google-ads.yaml configuration file in the
    # # home directory if none is specified.
    # googleads_client = GoogleAdsClient.load_from_storage(version="v17")

    customer_id = "6006145025"

    keywords = [
        "tankless water heater",
        "best tankless water heater",
        "tankless water geyser",
        "tankless water heater tax credits",
        "cost of a tankless hot water heater",
        "instant water heater cost",
        "tankless water heater rebates",
        "cost of on demand water heater",
        "tankless heater installation",
        "waterless heater cost",
        "tankless water heater installation near me",
        "navien",
        "rinnai",
        "noritz",
        "rheem on demand water heater",
        "aquastar tankless water heaters",
        "in wall tankless water heater",
        "heat pump water heater",
        "heat pump water heater price",
        "heat pump hot water heater",
        "heat pump water heater installation",
        "best heat pump water heater",
        "water pump water heater",
    ]

    geos = {
        "Alameda County": 9057119,
        "Amador County": 9057121,
        "Butte County": 9057122,
        "Calaveras County": 9057123,
        "Colusa County": 9057124,
        "Contra Costa County": 9057125,
        "El Dorado County": 9057127,
        "Fresno County": 9057128,
        "Glenn County": 9057129,
        "Humboldt County": 9057130,
        "Imperial County": 9057131,
        "Inyo County": 9057132,
        "Kern County": 9057133,
        "Kings County": 9057134,
        "Lake County": 9057135,
        "Los Angeles County": 9057137,
        "Madera County": 9057138,
        "Marin County": 9057139,
        "Mariposa County": 9057140,
        "Mendocino County": 9057141,
        "Merced County": 9057142,
        "Mono County": 9057144,
        "Monterey County": 9057145,
        "Napa County": 9057146,
        "Nevada County": 9057147,
        "Orange County": 1014091,
        "Placer County": 9057148,
        "Plumas County": 9057149,
        "Riverside County": 9057150,
        "Sacramento County": 9057151,
        "San Benito County": 9057152,
        "San Bernardino County": 9057153,
        "San Diego County": 9057154,
        "San Francisco County": 9057155,
        "San Joaquin County": 9057156,
        "San Luis Obispo County": 9057157,
        "San Mateo County": 9057158,
        "Santa Barbara County": 9057159,
        "Santa Clara County": 9057160,
        "Santa Cruz County": 9057161,
        "Shasta County": 9057162,
        "Sierra County": 9057163,
        "Solano County": 9057165,
        "Sonoma County": 9057166,
        "Stanislaus County": 9057167,
        "Sutter County": 9057168,
        "Tehama County": 9057169,
        "Tulare County": 9057171,
        "Tuolumne County": 9057172,
        "Ventura County": 9057173,
        "Yolo County": 9057174,
        "Yuba County": 9057175,
    }

    all_data = []
    for geo, geo_id in geos.items():
        try:
            data = generate_historical_metrics(customer_id, keywords, geo_id)
            df = pd.DataFrame(data)
            df["geo"] = geo
            df["group"] = (
                df["keyword"]
                .str.contains("pump")
                .map({True: "Pump", False: "Tankless"})
            )
            all_data.append(df)
        except GoogleAdsException as ex:
            print(
                f'Request with ID "{ex.request_id}" failed with status '
                f'"{ex.error.code().name}" and includes the following errors:'
            )
            for error in ex.failure.errors:
                print(f'Error with message "{error.message}".')
                if error.location:
                    for field_path_element in error.location.field_path_elements:
                        print(f"\t\tOn field: {field_path_element.field_name}")
        time.sleep(5)

    all_data_df = pd.concat(all_data)
    all_data_df.to_csv("historical_metrics.csv", index=False)
