import pandas as pd
from uuid import uuid4
from os import environ
from typing import List
from datetime import date

from google.gutils.utilities import queue_for_api, get_api_client
from queries import insert_last_google_api_timestamp
from google.accounts.ads_account import GoogleAdsAccount
from google.keyword_planner.utils_keywords import (
    map_locations_ids_to_resource_names,
    map_language_ids_to_resource_names,
)
from storage.upload_blob import upload_blob


_DEFAULT_KEYWORD_PLAN_NETWORK = "GOOGLE_SEARCH_AND_PARTNERS"
_BUCKET_NAME = (
    "kaya-apps-00-keyword-planner"
    if "PROD" in environ["ENV"]
    else "kaya-apps-staging-keyword-planner"
)
_TODAY = date.today()


def get_keyword_ideas(
    customer_id,
    customer_url,
    keywords=[],
    page_urls=[],
    incl_location_ids=[],
    incl_language_id="1000",
):
    if len(keywords) == 0 and len(page_urls) == 0:
        raise Exception(
            "At least one of keywords or page URLs is required, "
            "but neither was specified."
        )

    if len(incl_location_ids) > 0:
        print("Mapping location ids to resource name for ", incl_location_ids)
        location_rns = map_locations_ids_to_resource_names(incl_location_ids)
    else:
        location_rns = []
    print("location_rns: ", location_rns)

    print("Mapping language ids to resource name for ", incl_language_id)
    language_rn = map_language_ids_to_resource_names([incl_language_id])[0]
    print("language_rn: ", language_rn)

    ###################################
    #  GET KEYWORD IDEAS FROM GOOGLE  #
    ###################################

    keyword_suggestions_from_seed = []
    if len(keywords) > 0:
        keyword_suggestions_from_seed += (
            _generate_keyword_ideas_from_seed_keywords_and_url(
                customer_id=customer_id,
                customer_url=customer_url,
                keywords=keywords,
                location_resource_names=location_rns,
                language_resource_name=language_rn,
            )
        )
    keyword_suggestions_from_seed_df = pd.DataFrame(keyword_suggestions_from_seed)
    keyword_suggestions_from_seed_df["source"] = "seed"

    keyword_suggestions_from_url = []
    for url in page_urls:
        # generate keyword ideas based on URL
        keyword_suggestions_from_url += _generate_keyword_ideas_from_url(
            customer_id=customer_id,
            url=url,
            location_resource_names=location_rns,
            language_resource_name=language_rn,
        )
    keyword_suggestions_from_url_df = pd.DataFrame(keyword_suggestions_from_url)
    keyword_suggestions_from_url_df["source"] = "url"

    keyword_suggestions_df = pd.concat(
        [keyword_suggestions_from_seed_df, keyword_suggestions_from_url_df]
    )
    # keyword_suggestions_df.drop_duplicates(subset=["idea_text"], inplace=True)
    print(f"Total num of keywords in scope: {keyword_suggestions_df.shape[0]}")

    # UPLOAD TO BUCKET
    source_folder = "/tmp/"
    filename = f"keyword_suggestions_df_{uuid4()}.csv"
    keyword_suggestions_df.to_csv(source_folder + filename, index=0)
    print(_BUCKET_NAME)
    upload_blob(
        _BUCKET_NAME,
        source_folder + filename,
        f"{_TODAY.year}/{_TODAY.month}/{_TODAY.day}/{filename}",
        is_public=False,
    )
    return keyword_suggestions_df


def _generate_keyword_ideas_from_seed_keywords_and_url(
    customer_id: str,
    customer_url: str,
    keywords: List[str],
    location_resource_names: List[str],
    language_resource_name: str,
) -> List[dict]:

    # fs = FirestoreClient()
    # collection = fs.get_collection(_KEYWORD_IDEA_COLLECTION)

    ideas = []

    ###############################################
    #    CHECK IF KEYWORDS BEEN QUERIED & REUSE   #
    ###############################################

    # Filter on docs related to a specific customer and url
    # and incl_location_ids that are the same as current request
    # and incl_language_ids that are the same as current request

    # keywords_found = [keyword_dict["idea_text"] for keyword_dict in ideas]
    # keywords_to_seed = [kw for kw in keywords if kw not in keywords_found]
    keywords_to_seed = keywords

    # print(f"Found {len(keywords_found)} existing keyword ideas from seeded keywords")
    print(f"{len(keywords_to_seed)} keywords left to be seeded")

    # generate keyword ideas based on keyword seeds, in a batch of 20
    for start_idx in range(0, len(keywords_to_seed), 20):
        print(
            f"Getting kw suggestions for batch {start_idx}: {keywords_to_seed[start_idx : start_idx + 20]}"
        )
        ideas += _generate_keywords_ideas_from_google(
            customer_id=customer_id,
            page_url=customer_url,
            keyword_texts=keywords_to_seed[start_idx : start_idx + 20],
            location_resource_names=location_resource_names,
            language_resource_name=language_resource_name,
        )

    # ideas = get_unique_list_of_dict(ideas)
    return ideas


def _generate_keyword_ideas_from_url(
    customer_id: str,
    url: str,
    location_resource_names: list,
    language_resource_name: str,
) -> List[dict]:
    """Return keyword ideas that are seeded from a given URL. Starts by searching
    if any document exists in Firestore from previous run. If yes, return results from
    previous run. Otherwise query google API.

    Args:
        customer_id (str): Google account ID
        url (str): URL to seed keywords from
        incl_location_ids (list): search locations
        incl_language_ids (list): search language

    Returns:
        List[dict]: list containing dict, where each dict = 1 keyword
    """

    # Filter on docs related to a specific customer and url
    # and incl_location_ids that are the same as current request
    # and incl_language_ids that are the same as current request
    # print(
    #     f"Found {len(ideas)} existing keyword ideas from URL {url} in {_KEYWORD_IDEA_COLLECTION} collection"
    # )

    # no matching doc found in firestore, thus query google
    ideas = _generate_keywords_ideas_from_google(
        customer_id=customer_id,
        page_url=url,
        keyword_texts=[],
        location_resource_names=location_resource_names,
        language_resource_name=language_resource_name,
    )

    # ideas = get_unique_list_of_dict(ideas)

    return ideas


def _generate_keywords_ideas_from_google(
    customer_id,
    page_url,
    keyword_texts,
    location_resource_names=[],
    language_resource_name=None,
    include_adult_keywords=False,
):
    """
    For the URL of a webpage or entire website related to your business, use UrlSeed.
    The URL seed targets only a specific URL. If there are no hits, the search automatically
    expands up to the pages from the same domain.

    For an entire site, use SiteSeed. Given a top-level domain name, such as www.example.com,
    the site seed generates up to 250,000 keyword ideas from publicly available information.
    """
    print("Generating keyword ideas from Google API")

    queue_for_api(service="keyword_plan_idea")
    insert_last_google_api_timestamp(
        service="keyword_plan_idea", function="generate_keyword_ideas"
    )

    # initiate google client
    ads_account = GoogleAdsAccount(client_id=customer_id)
    client = get_api_client(manager_id=ads_account.ads_manager_id)

    keyword_plan_idea_service = client.get_service("KeywordPlanIdeaService")
    keyword_plan_network = client.enums.KeywordPlanNetworkEnum[
        _DEFAULT_KEYWORD_PLAN_NETWORK
    ]  # TODO: MAKE THIS AN INPUT
    keyword_annotation = client.enums.KeywordPlanKeywordAnnotationEnum

    # Either keywords or a page_url are required to generate keyword ideas
    # so this raises an error if neither are provided.
    if not (keyword_texts or page_url):
        raise ValueError(
            "At least one of keywords or page URL is required, "
            "but neither was specified."
        )

    if len(keyword_texts) > 20:
        raise Exception("Too many keywords: at most 20 keywords can be set")

    # Only one of the fields "url_seed", "keyword_seed", or
    # "keyword_and_url_seed" can be set on the request, depending on whether
    # keywords, a page_url or both were passed to this function.
    kw_request = client.get_type("GenerateKeywordIdeasRequest")
    kw_request.customer_id = customer_id
    kw_request.include_adult_keywords = include_adult_keywords
    kw_request.keyword_plan_network = keyword_plan_network
    kw_request.keyword_annotation = keyword_annotation

    if len(location_resource_names) > 0:
        kw_request.geo_target_constants = location_resource_names

    if language_resource_name:
        kw_request.language = language_resource_name

    # To generate keyword ideas with only a page_url and no keywords we need
    # to first check if the URL is top level domain page or subpage.
    # If top page, use site_seed. Else url_seed
    if not keyword_texts and page_url:
        url_type = _get_url_type(page_url)
        if url_type == "site":
            kw_request.site_seed.site = page_url
        else:
            kw_request.url_seed.url = page_url

    # To generate keyword ideas with only a list of keywords and no page_url
    # we need to initialize a KeywordSeed object and set the "keywords" field
    # to be a list of StringValue objects.
    if keyword_texts and not page_url:
        kw_request.keyword_seed.keywords.extend(keyword_texts)

    # To generate keyword ideas using both a list of keywords and a page_url we
    # need to initialize a KeywordAndUrlSeed object, setting both the "url" and
    # "keywords" fields.
    if keyword_texts and page_url:
        kw_request.keyword_and_url_seed.url = page_url
        kw_request.keyword_and_url_seed.keywords.extend(keyword_texts)

    keyword_ideas = keyword_plan_idea_service.generate_keyword_ideas(request=kw_request)
    outputs = []
    for idea in keyword_ideas:
        concepts = []
        is_branded = False
        if len(idea.keyword_annotations.concepts) > 0:
            for concept in idea.keyword_annotations.concepts:
                if concept.concept_group.type_.name in ["BRAND", "OTHER_BRANDS"]:
                    is_branded = True

                concepts.append(
                    {
                        "name": concept.name,
                        "group_name": concept.concept_group.name,
                        "group_type": concept.concept_group.type_.name,
                        "group_raw": concept.concept_group,
                    }
                )
        text = idea.text

        # TODO: PARSE MONTHLY SEARCH VOLUME
        d = {
            "text": text,
            "avg_monthly_searches": idea.keyword_idea_metrics.avg_monthly_searches,
            "competition_value": idea.keyword_idea_metrics.competition.name,
            "competition_index": idea.keyword_idea_metrics.competition_index,
            "is_user_provided": text in keyword_texts,
            "keyword_annotations": str(concepts),
            "low_top_of_page_bid_micros": idea.keyword_idea_metrics.low_top_of_page_bid_micros,
            "high_top_of_page_bid_micros": idea.keyword_idea_metrics.high_top_of_page_bid_micros,
            "is_branded": is_branded,
            "page_url": page_url,
        }
        outputs.append(d)
    return outputs


def _get_url_type(url: str) -> str:
    """Returns if the URL is top level domain or subpage."""
    url = url.replace("https://", "").replace("http://", "")
    # TODO: ADD CHECK TO MAKE SURE STRING DOESNT START FROM '?'
    url_components = [
        comp for comp in url.split("/") if (len(comp) > 0) and (comp[0] != "?")
    ]

    if len(url_components) > 1:
        return "page"
    else:
        return "site"


if __name__ == "__main__":
    import os

    customer_id = "3545980072" if "PROD" in os.environ["ENV"] else "3385265876"
    get_keyword_ideas(
        customer_id,
        customer_url="https://usekaya.com/",
        keywords=["marketing analytics", "marketing reporting"],
        page_urls=["https://funnel.io/"],
        incl_location_ids=["2840"],
    )
