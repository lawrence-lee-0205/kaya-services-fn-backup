import pandas as pd
import numpy as np


def generate_keyword_feature_score(df, col_name, n_bins):
    """
    Bin a numerical column of a pandas DataFrame into n_bins.
    Label as high (3), mid (2), low (1) based on bin.

    Args:
    df (pandas.DataFrame): The DataFrame containing the column to bin.
    col_name (str): The name of the column to bin.
    n_bins (int): Number of bins to divide the column into.

    Returns:
    pandas.DataFrame: DataFrame with the new binned and category columns.
    """

    if col_name not in df.columns:
        raise ValueError(f"Column {col_name} not found in DataFrame")

    # create bins based on numerical values
    feature_score_col = f"{col_name}_score"
    df[feature_score_col] = pd.cut(
        df[col_name], bins=n_bins, labels=range(1, n_bins + 1)
    )
    df[feature_score_col] = df[feature_score_col].astype(int)

    # create categories based on bin scores
    conditions = [
        df[feature_score_col] == 1,
        df[feature_score_col] == 2,
        df[feature_score_col] == 3,
    ]
    choices = ["1_LOW", "2_MID", "3_HIGH"]

    feature_category_col = f"{col_name}_category"
    df[feature_category_col] = np.select(conditions, choices, default=None)

    return df


def generate_keyword_recommendations(df, feature_cols):
    # bin columns into feature scores: high (3) /mid (2) /low (1)
    for col in feature_cols:
        df = generate_keyword_feature_score(df, col, 3)

    # calculate product of features as composite recommendation score
    feature_score_cols = [col + "_score" for col in feature_cols]
    df["keyword_score"] = df[feature_score_cols].prod(axis=1)

    # rank recommendation score
    df["keyword_score_rank"] = df["keyword_score"].rank(ascending=False)

    # rank within each keyword category in descending order
    df["keyword_score_category_rank"] = df.groupby("category")["keyword_score"].rank(
        ascending=False, method="dense"
    )

    return df


def get_keyword_category_features(df):
    # add sum feature
    col = "avg_monthly_searches"
    col_name = f"category_{col}_sum"
    df[col_name] = df.groupby("category")[col].transform("sum")

    # add category median features
    median_cols = [
        "avg_monthly_searches",
        "low_top_of_page_bid",
        "high_top_of_page_bid",
        "competition_index",
    ]

    for col in median_cols:
        col_name = f"category_{col}_median"
        df[col_name] = df.groupby("category")[col].transform("median")

    # rank category by avg_monthly_searches median, in descending order
    df["category_rank"] = df["category_avg_monthly_searches_median"].rank(
        ascending=False, method="dense"
    )

    # sort df
    df = df.sort_values(
        by=["category_rank", "category", "avg_monthly_searches"],
        ascending=[True, True, False],
    )
    return df


def get_top_n_keyword_score_by_category(keyword_ideas_df, top_n_keyword_score):
    top_keywords_df = keyword_ideas_df.copy()

    ## filter for desired output ##

    # filter by top n keyword score
    filter_top_n_keyword_score = (
        top_keywords_df["keyword_score_category_rank"] <= top_n_keyword_score
    )

    # filter for desired columns
    cols_to_keep = [
        "ad_group",
        "category",
        "text",
        "to_keep",
        "is_negative",
        "avg_monthly_searches",
        "avg_top_of_page_bid",
        "low_top_of_page_bid",
        "high_top_of_page_bid",
        "competition_index",
        "num_urls",
        "keyword_score_category_rank",
    ]

    # filter based on all conditions
    top_keywords_df = top_keywords_df.loc[filter_top_n_keyword_score, cols_to_keep]

    ## recommend by category ##
    top_keywords_df = get_keyword_category_features(top_keywords_df)
    return top_keywords_df
