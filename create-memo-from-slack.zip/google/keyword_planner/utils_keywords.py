import numpy as np
import pandas as pd

TEST_GSHEET_ID = "1u8NC8sO-zCjoE7Z07WPJ5sva7vGN72A91ovkjkIyOyc"


# TODO: GENERALISE AND MOVE TO OTHER FILES
def map_locations_ids_to_resource_names(location_ids):
    """Converts a list of location IDs to resource names.
    Args:
        client: an initialized GoogleAdsClient instance.
        location_ids: a list of location ID strings.
    Returns:
        a list of resource name strings using the given location IDs.
    """
    output = []
    for location_id in location_ids:
        if not isinstance(location_id, str):
            location_id = str(location_id)

        if not location_id.isdigit():
            raise ValueError(
                "Invalid criteria ID for location, it should contain numbers only. Faulty value: {location_id}"
            )

        output.append(f"geoTargetConstants/{location_id}")
    return output


def map_language_ids_to_resource_names(language_ids):
    """Converts a list of location IDs to resource names.
    Args:
        client: an initialized GoogleAdsClient instance.
        location_ids: a list of location ID strings.
    Returns:
        a list of resource name strings using the given location IDs.
    """
    output = []
    for lang_id in language_ids:
        if not isinstance(lang_id, str):
            lang_id = str(lang_id)

        if not lang_id.isdigit():
            raise ValueError(
                "Invalid criteria ID for language, it should contain numbers only. Faulty value: {lang_id}"
            )

        output.append(f"languageConstants/{lang_id}")
    return output


def consolidate_similar_keywords(df):
    """
    Removes highly similar keywords by grouping and dropping duplicates based on features.
    Dedup for keywords with features that are not all-zero but with the same competition index.
    This indicates that keywords are weighted similarly by Google.

    Args:
        df (pd.DataFrame): The DataFrame to modify.

    Returns:
        pd.DataFrame: The modified DataFrame.
    """

    # Split df into filter features being zero or not
    cols_to_check = [
        "avg_monthly_searches",
        "low_top_of_page_bid",
        "high_top_of_page_bid",
    ]

    # Create a boolean mask where all specified columns are zero
    mask_all_zeros = df[cols_to_check].eq(0).all(axis=1)

    # Separate the DataFrame into two
    df_all_zeros = df[mask_all_zeros]
    df_non_zeros = df[~mask_all_zeros]

    # Group similar texts with same features and are not zero
    cols_to_group = [*cols_to_check, *["category", "competition_index"]]
    df_non_zeros_grp = df_non_zeros.groupby(cols_to_group).agg(
        **{"similar_keywords_list": ("text", list)}
    )
    df_non_zeros_grp["text"] = df_non_zeros_grp["similar_keywords_list"].apply(
        lambda x: x[0] if x and isinstance(x, list) else []
    )
    df_non_zeros_grp["similar_keywords"] = df_non_zeros_grp[
        "similar_keywords_list"
    ].apply(lambda x: x[1:] if isinstance(x, list) and len(x) > 0 else [])
    df_non_zeros_grp.reset_index(drop=False, inplace=True)
    df_non_zeros_grp = df_non_zeros_grp[["text", "similar_keywords"]]

    df_non_zeros_grp = pd.merge(df, df_non_zeros_grp, on="text", how="inner")

    # Combine rows for zero- and non-zero deduplicated dfs
    modified_df = pd.concat([df_all_zeros, df_non_zeros_grp])
    modified_df["similar_keywords"] = modified_df["similar_keywords"].apply(
        lambda x: [] if x is np.nan or (isinstance(x, list) and not x) else x
    )
    return modified_df
