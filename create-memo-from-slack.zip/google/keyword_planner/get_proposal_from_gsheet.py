from http_function import http_function
from gsheets.gsheet import GSheet
from google.keyword_planner.recommend_keywords import get_keyword_category_features
from google.keyword_planner.utils_keywords import TEST_GSHEET_ID

_MANDATORY_COLS = [
    "text",

    "category",
    "ad_group",
    "avg_monthly_searches",
    "avg_top_of_page_bid",
    "competition_index",
    "low_top_of_page_bid",
    "high_top_of_page_bid",
    "num_urls",

    "avg_monthly_searches_category", 
    "competition_index_category", 
    "low_top_of_page_bid_category", 
    "high_top_of_page_bid_category", 
    "num_urls_category",

    "keyword_score",
    "keyword_score_rank",
    "keyword_score_category_rank",

    "to_keep",
]


@http_function
def get_proposal_from_gsheet(request_json={}, request_args={}):
    mandatory_fields = ["key"]

    data = {}
    for m in mandatory_fields:
        if request_json and m in request_json:
            data[m] = request_json[m]
        elif request_args and m in request_args:
            data[m] = request_args[m]
        else:
            raise Exception(f"Expecting {m} to be provided")

    print("request_json: ", request_json)
    print("request_args: ", request_args)

    out = execute(key=data["key"])
    return out


def execute(key):
    gsheet = GSheet()
    gsheet.open_existing_file_by_key(key)

    df_top_kw = gsheet.get_dataframe_from_tab("top_keywords")

    df = gsheet.get_dataframe_from_tab("unique")
    cols_available = df.columns

    for col in _MANDATORY_COLS:
        if col not in cols_available:
            raise Exception("Missing col", col)
    
    # filter out selected keywords based on both dfs
    condition = lambda df: df["to_keep"] == "TRUE"
    to_keep_df_list = df.loc[condition(df), 'text'].unique()
    to_keep_df_top_kw_list = df_top_kw.loc[condition(df_top_kw), 'text'].unique()
    to_keep_keywords_list = set([*to_keep_df_list, *to_keep_df_top_kw_list])
    
    df_filtered = df[df['text'].isin(to_keep_keywords_list)]

    # fill up ad_group if have been inputted in top_keyword tab
    replacement_dict = df_top_kw[df_top_kw['ad_group'] != ''].set_index('text')['ad_group'].to_dict()

    # replace values in column_a of df_b based on the dictionary
    df_filtered.loc[:, 'ad_group'] = df_filtered['text'].map(replacement_dict).fillna(df_filtered['ad_group'])

    # get final output
    df_filtered = df_filtered[_MANDATORY_COLS]

    df_filtered = get_keyword_category_features(df_filtered)

    data = df_filtered.to_dict(orient="records")
    return data


if __name__ == "__main__":
    print(execute(TEST_GSHEET_ID))
