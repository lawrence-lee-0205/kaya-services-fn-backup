"""https://developers.google.com/google-ads/api/docs/change-status"""

from datetime import datetime, timedelta

from proto.enums import ProtoEnumMeta

from google.ads.googleads.util import get_nested_attr


_DEFAULT_PAGE_SIZE = 1000

from google.gutils.utilities import get_api_client
from google.accounts.ads_account import GoogleAdsAccount


def get_overall_change(client, customer_id):
    ads_service = client.get_service("GoogleAdsService")

    # Construct a query to find information about changed resources in your
    # account.
    query = """
        SELECT
          change_status.resource_name,
          change_status.last_change_date_time,
          change_status.resource_type,
          change_status.campaign,
          change_status.ad_group,
          change_status.resource_status,
          change_status.ad_group_ad,
          change_status.ad_group_criterion,
          change_status.campaign_criterion
        FROM change_status
        WHERE change_status.last_change_date_time DURING LAST_14_DAYS
        ORDER BY change_status.last_change_date_time
        LIMIT 10000"""

    search_request = client.get_type("SearchGoogleAdsRequest")
    search_request.customer_id = customer_id
    search_request.query = query
    search_request.page_size = _DEFAULT_PAGE_SIZE

    response = ads_service.search(request=search_request)

    for row in response:
        print(row)
        cs = row.change_status
        resource_type = cs.resource_type.name
        if resource_type == "AD_GROUP":
            resource_name = cs.ad_group
        if resource_type == "AD_GROUP_AD":
            resource_name = cs.ad_group_ad
        if resource_type == "AD_GROUP_CRITERION":
            resource_name = cs.ad_group_criterion
        if resource_type == "CAMPAIGN":
            resource_name = cs.campaign
        if resource_type == "CAMPAIGN_CRITERION":
            resource_name = cs.campaign_criterion
        else:
            resource_name = "UNKNOWN"

        resource_status = cs.resource_status.name
        print(
            f"On '{cs.last_change_date_time}', change status "
            f"'{cs.resource_name}' shows that a resource type of "
            f"'{resource_type}' with resource name '{resource_name}' was "
            f"{resource_status}"
        )


def get_exact_change(client, customer_id):
    """Gets specific details about the most recent changes in the given account.

    Args:
      client: The Google Ads client.
      customer_id: The Google Ads customer ID.
    """
    googleads_service = client.get_service("GoogleAdsService")

    # Construct a query to find details for recent changes in your account.
    # The LIMIT clause is required for the change_event resource.
    # The maximum size is 10000, but a low limit was set here for demonstrative
    # purposes. For more information see:
    # https://developers.google.com/google-ads/api/docs/change-event#getting_changes
    # The WHERE clause on change_date_time is also required. It must specify a
    # window within the past 30 days.
    tomorrow = (datetime.now() + timedelta(1)).strftime("%Y-%m-%d")
    one_weeks_ago = (datetime.now() + timedelta(-7)).strftime("%Y-%m-%d")
    query = f"""
        SELECT
          change_event.resource_name,
          change_event.change_date_time,
          change_event.change_resource_name,
          change_event.user_email,
          change_event.client_type,
          change_event.change_resource_type,
          change_event.old_resource,
          change_event.new_resource,
          change_event.resource_change_operation,
          change_event.changed_fields
        FROM change_event
        WHERE change_event.change_date_time <= '{tomorrow}'
        AND change_event.change_date_time >= '{one_weeks_ago}'
        ORDER BY change_event.change_date_time DESC
        LIMIT 1000
        """

    search_request = client.get_type("SearchGoogleAdsRequest")
    search_request.customer_id = customer_id
    search_request.query = query
    search_request.page_size = _DEFAULT_PAGE_SIZE

    results = googleads_service.search(request=search_request)

    for row in results:
        event = row.change_event
        resource_type = event.change_resource_type.name
        if resource_type == "AD":
            old_resource = event.old_resource.ad
            new_resource = event.new_resource.ad
        elif resource_type == "AD_GROUP":
            old_resource = event.old_resource.ad_group
            new_resource = event.new_resource.ad_group
        elif resource_type == "AD_GROUP_AD":
            old_resource = event.old_resource.ad_group_ad
            new_resource = event.new_resource.ad_group_ad
        elif resource_type == "AD_GROUP_ASSET":
            old_resource = event.old_resource.ad_group_asset
            new_resource = event.new_resource.ad_group_asset
        elif resource_type == "AD_GROUP_CRITERION":
            old_resource = event.old_resource.ad_group_criterion
            new_resource = event.new_resource.ad_group_criterion
        elif resource_type == "AD_GROUP_BID_MODIFIER":
            old_resource = event.old_resource.ad_group_bid_modifier
            new_resource = event.new_resource.ad_group_bid_modifier
        elif resource_type == "AD_GROUP_FEED":
            old_resource = event.old_resource.ad_group_feed
            new_resource = event.new_resource.ad_group_feed
        elif resource_type == "ASSET":
            old_resource = event.old_resource.asset
            new_resource = event.new_resource.asset
        elif resource_type == "ASSET_SET":
            old_resource = event.old_resource.asset_set
            new_resource = event.new_resource.asset_set
        elif resource_type == "ASSET_SET_ASSET":
            old_resource = event.old_resource.asset_set_asset
            new_resource = event.new_resource.asset_set_asset
        elif resource_type == "CAMPAIGN":
            old_resource = event.old_resource.campaign
            new_resource = event.new_resource.campaign
        elif resource_type == "CAMPAIGN_ASSET":
            old_resource = event.old_resource.campaign_asset
            new_resource = event.new_resource.campaign_asset
        elif resource_type == "CAMPAIGN_ASSET_SET":
            old_resource = event.old_resource.campaign_asset_set
            new_resource = event.new_resource.campaign_asset_set
        elif resource_type == "CAMPAIGN_BUDGET":
            old_resource = event.old_resource.campaign_budget
            new_resource = event.new_resource.campaign_budget
        elif resource_type == "CAMPAIGN_CRITERION":
            old_resource = event.old_resource.campaign_criterion
            new_resource = event.new_resource.campaign_criterion
        elif resource_type == "CAMPAIGN_FEED":
            old_resource = event.old_resource.campaign_feed
            new_resource = event.new_resource.campaign_feed
        elif resource_type == "CUSTOMER_ASSET":
            old_resource = event.old_resource.customer_asset
            new_resource = event.new_resource.customer_asset
        elif resource_type == "FEED":
            old_resource = event.old_resource.feed
            new_resource = event.new_resource.feed
        elif resource_type == "FEED_ITEM":
            old_resource = event.old_resource.feed_item
            new_resource = event.new_resource.feed_item
        else:
            print("Unknown change_resource_type: '{event.change_resource_type}'")
            # If the resource type is unrecognized then we continue to
            # the next row.
            continue

        print(
            f"On {event.change_date_time}, user {event.user_email} "
            f"used interface {event.client_type.name} to perform a(n) "
            f"{event.resource_change_operation.name} operation on a "
            f"{event.change_resource_type.name} with resource name "
            f"'{event.change_resource_name}'"
        )

        operation_type = event.resource_change_operation.name

        if operation_type in ("UPDATE", "CREATE"):
            for changed_field in event.changed_fields.paths:
                # Change field name from "type" to "type_" so that it doesn't
                # raise an exception when accessed on the protobuf object, see:
                # https://developers.google.com/google-ads/api/docs/client-libs/python/library-version-10#field_names_that_are_reserved_words
                if changed_field == "type":
                    changed_field = "type_"

                new_value = get_nested_attr(new_resource, changed_field)
                # If the field value is an Enum get the human readable name
                # so that it is printed instead of the field ID integer.
                if isinstance(type(new_value), ProtoEnumMeta):
                    new_value = new_value.name

                if operation_type == "CREATE":
                    print(f"\t{changed_field} set to {new_value}")
                else:
                    old_value = get_nested_attr(old_resource, changed_field)
                    # If the field value is an Enum get the human readable name
                    # so that it is printed instead of the field ID integer.
                    if isinstance(type(old_value), ProtoEnumMeta):
                        old_value = old_value.name

                    print(f"\t{changed_field} changed from {old_value} to {new_value}")


if __name__ == "__main__":
    business_id = "2ububBhO0RIq0tURuqnY"
    google_acc = GoogleAdsAccount(business_id=business_id)
    client_id = google_acc.client_id
    manager_id = google_acc.ads_manager_id
    ccy = google_acc.ccy

    client = get_api_client(manager_id)
    get_exact_change(client, client_id)
    print("\n---\n")
    get_overall_change(client, client_id)
