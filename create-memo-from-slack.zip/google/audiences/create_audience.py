import datetime
from typing import List

from setup import setup
from common import validate_inputs
from firestore import FirestoreClient, DESCENDING

_COLLECTION = "google_audiences"
_SUBCOLLECTION = "criteria"

FS = FirestoreClient()


@setup
def main(data: dict) -> dict:
    """
    Given an audience definition, check if a document already exists in google_audiences collection.
    If it exists, return its document id. Otherwise, create new document and return its id.
    """
    mandatory_fields = ["business_id", "name", "audiences", "auth_user_id"]
    acceptable_criteria_types = ["location", "language"]

    validate_inputs(data, mandatory_fields)

    business_id = data["business_id"]

    ########################
    #    VALIDATE INPUTS   #
    ########################

    if not isinstance(data["name"], str):
        raise TypeError(
            f"Expecting 'name' to be string, received '{data['name']}' instead"
        )

    # TODO: VALIDATE IF AUDIENCE NAME ALRD EXISTS
    for audience in data["audiences"]:
        for f in ["criteria_ids", "values"]:
            if not isinstance(audience[f], list):
                raise TypeError(
                    f"Expecting param '{f}' in 'audiences' to be a list of string, received '{audience[f]}' instead"
                )

        if len(audience["criteria_ids"]) != len(audience["values"]):
            raise ValueError(
                f"""
                Expecting num of elements in 'criteria_ids' to match num of elements in 'values'. 
                Received {audience['criteria_ids']} (len: {len(audience['criteria_ids'])}) and {audience['values']} (len: {len(audience['values'])})
                """
            )

        if audience["type"] not in acceptable_criteria_types:
            raise ValueError(
                f"Invalid value for criteria type. Received {audience['type']}. Only accepts {acceptable_criteria_types}"
            )

    #######################################
    #    TRANSFORM AUDIENCE DEFINITION    #
    #######################################

    audience_to_add = _convert_list_of_criteria_to_dict(data["audiences"])

    #######################################
    #     PROCESS AUDIENCE COLLECTION     #
    #######################################

    google_audience_id = _get_matching_audience_doc(business_id, audience_to_add)

    if google_audience_id is None:
        # current audience doesn't exist in Firestore, thus create new audience
        parent_doc = {
            "business_id": business_id,
            "name": data["name"],
            "created_at": datetime.datetime.now(),
            "created_by": data["auth_user_id"],
        }

        google_audience_id = FS.add_document(_COLLECTION, parent_doc)

        children_doc_id = []
        for audience in data["audiences"]:
            # TODO: validate content within audience
            children_doc_id.append(
                FS.add_subcollection_to_document(
                    _COLLECTION, google_audience_id, _SUBCOLLECTION, audience
                )
            )

    output = {"google_audience_id": google_audience_id}
    return output


###########################
#    PRIVATE FUNCTIONS    #
###########################


def _convert_list_of_criteria_to_dict(audience: List[dict]) -> dict:
    """Convert a list of criteria to a single dict

    For eg:
    [
        {
            "criteria_ids": ["3000"],
            "is_include": True,
            "type": "location",
            "values": ["2458"],
        },
        {
            "criteria_ids": ["1000"],
            "is_include": True,
            "type": "language",
            "values": ["1000"],
        },
    ] --> {"location": ["3000"], "language": ["1000"]}

    Args:
        audience (List[dict]): [description]

    Returns:
        dict: [description]
    """
    # TODO: WHAT IF AUDIENCE IS SET TO IS_INCLUDE = FALSE
    return {criterion["type"]: criterion["criteria_ids"] for criterion in audience}


def _get_matching_audience_doc(business_id: str, audience_to_add: dict):
    """Find document from Firestore that matches the audience definition given in API.
    If audience is found, return its id. Otherwise, return None.

    Args:
        business_id (str): [description]
        audience_to_add (dict): [description]

    Returns: str
    """
    collection = FS.get_collection(_COLLECTION)
    all_audiences_ref = (
        collection.where("business_id", "==", business_id)
        .order_by("created_at", direction=DESCENDING)
        .stream()
    )

    # loop through all audiences created under given business_id
    for doc in all_audiences_ref:
        audience_id = doc.id
        criteria_list = FS.get_all_documents_within_subcollection(
            f"google_audiences/{audience_id}/criteria", skip_id=True
        )

        fs_criteria = _convert_list_of_criteria_to_dict(criteria_list)

        if fs_criteria == audience_to_add:
            return audience_id

    return None


if __name__ == "__main__":
    data = {
        "business_id": "SWlTMQLhNmhit98gFu5j",
        "auth_user_id": "test",
        "name": "",
        "audiences": [
            {
                "criteria_ids": ["3000"],
                "is_include": True,
                "type": "location",
                "values": ["2458"],
            },
            {
                "criteria_ids": ["1000"],
                "is_include": True,
                "type": "language",
                "values": ["1000"],
            },
        ],
    }
    print(main(data))
