import pandas as pd


def get_category(category, idx):
    split = category.split("/")

    if len(split) <= idx:
        return ""
    return split[idx]


if __name__ == "__main__":
    files = [
        "products-services.csv",
        "in-market-categories.csv",
        "affinity-categories.csv",
    ]

    outputs = []
    for f in files:
        df = pd.read_csv(f)
        df["Type"] = f.replace("-", " ").capitalize().replace(".csv", "")
        for idx in range(1, 7):
            df[f"Category {idx}"] = df["Category"].apply(lambda x: get_category(x, idx))

        outputs.append(df)
    output_df = pd.concat(outputs)
    output_df.to_csv("audiences.csv", index=0)
