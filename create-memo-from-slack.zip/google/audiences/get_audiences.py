from setup import setup
from common import validate_inputs
from firestore import FirestoreClient
from queries import get_audience_include_exclude_values


_AUDIENCE_COLLECTION = "google_audiences"


@setup
def main(data: dict) -> dict:
    """Given a business id, list all the audiences within it.

    Args:
        data (dict): key 'business_id' must exists. User must be authorised.

    Returns:
        dict: Example output :=
        {
            "data": {
                "audiences": [{
                    "audience_id":"JbsNMmRsNe1r3s7cL0NA",
                    "business_id":"IqodTGWgK2yARP2daoTo",
                    "created_at":"Wed, 03 Nov 2021 14:23:46 GMT",
                    "excludes":{},
                    "includes":{
                        "language":["1000"],
                        "location":["20339","2380"]
                    },
                    "name":"Malaysian Teenagers"
                }],
                "invalid_audiences":[]
            }
        }
    """
    # validate input
    mandatory_fields = ["business_id", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    # get doc from collection
    fs = FirestoreClient()
    audience_col = fs.get_collection(_AUDIENCE_COLLECTION)
    audience_docs_ref = audience_col.where(
        "business_id", "==", data["business_id"]
    ).stream()

    # process docs in the collection
    audiences = []
    invalid_audiences = []
    for doc in audience_docs_ref:
        audience_id = doc.id
        content = doc.to_dict()

        if isinstance(content["name"], dict):
            print("Invalid doc structure, skipping doc ", audience_id)
            invalid_audiences.append(audience_id)
            continue

        content["audience_id"] = audience_id

        # get all the criteria under a given audience_id
        print(f"Processing {audience_id}")
        audience_criteria_docs = fs.get_all_documents_within_subcollection(
            f"google_audiences/{audience_id}/criteria"
        )  # list of dict

        try:
            # process criteria docs into includes and excludes list
            includes, excludes = get_audience_include_exclude_values(
                audience_criteria_docs
            )
        except TypeError:
            print(
                "Invalid structure found in criteria definition, skipping doc ",
                audience_id,
            )
            invalid_audiences.append(audience_id)
            continue

        content["includes"] = includes
        content["excludes"] = excludes
        audiences.append(content)

    output = {"audiences": audiences, "invalid_audiences": invalid_audiences}

    return output


if __name__ == "__main__":
    res = main()
    print(res)
