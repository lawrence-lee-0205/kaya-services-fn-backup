import time
from os import environ
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
from utils.datetimes import get_date_betw_dates

import pandas as pd
from typing import List

# from pandas_gbq import schema
from enums.google_analytics import GAVersion
from firestore import FirestoreClient
from google.k_analytics.analytics_client import (
    Analytics4Client,
    UniversalAnalyticsClient,
)
from common import validate_datetime
from slack_tools.slack import SlackMessage
from google.k_analytics.analytics_utils import get_config
from databases.bigquery.upload_to_bq import upload_dataframe

# replace data from X days ago as there is a chance
# where most recent data is not stabilised
_DEFAULT_REFRESH_DAYS = 3
_TODAY_DATE = date.today()
_TOMORROW_DATE = _TODAY_DATE + relativedelta(days=1)
_SCHEMA = {
    GAVersion.UA: "google_analytics_staging",
    GAVersion.GA4: "google_analytics_4_staging",
}
_BUCKET_NAME = (
    "kaya-apps-00-etl-ga" if "PROD" in environ["ENV"] else "kaya-apps-staging-etl-ga"
)


def run_etl(
    business_id: str,
    config_name: str,
    start_date=None,
    end_date=None,
    skip_upload=False,
    **kwargs,
):
    """
    start_date and end_date determines the as_of_date for backfilling.
    end_date is exclusive.
    With each backfill date, we get data spanning L1D, L7D, L30D.

    Args:
        data (dict): 'start_date' and 'end_date' are optional. If provided,
        must be in the format of "%Y-%m-%d"

    Returns:
        [type]: [description]
    """
    print("Warning! These params are ignored: ", kwargs)
    print("Processing ", business_id)

    ###################################
    #          PROCESS DATES          #
    ###################################

    if start_date is None:
        start_date = _TOMORROW_DATE - relativedelta(days=_DEFAULT_REFRESH_DAYS)
    else:
        start_date = validate_datetime(start_date, "start_date", "%Y-%m-%d", "date")

    if end_date is None:
        end_date = _TOMORROW_DATE
    else:
        end_date = validate_datetime(end_date, "end_date", "%Y-%m-%d", "date")

    as_of_dates = get_date_betw_dates(
        start_date, end_date, include_end=True, include_start=False
    )

    ###############################
    #        EXECUTE ETL          #
    ###############################

    fs = FirestoreClient()
    business_doc = fs.get_single_document("businesses", business_id)
    ga_list = business_doc["google_analytics"]

    for ga_dict in ga_list:
        # skip data from not primary ga
        if not ga_dict["is_primary"]:
            continue

        ga_id = ga_dict["id"]
        ga_version = GAVersion[ga_dict["version"].upper()]

        try:
            df = get_ga_data(config_name, as_of_dates, ga_id, ga_version)
        except Exception as e:
            print(e)
            time.sleep(5)
            df = get_ga_data(config_name, as_of_dates, ga_id, ga_version)

        # terminate if no data
        if len(df) == 0:
            print("No data returned from API. Skip uploading..")
            continue

        ######################
        #    UPLOAD TO BQ    #
        ######################

        if not skip_upload:
            schema = _SCHEMA[ga_version]
            gcs = {
                "bucket": _BUCKET_NAME,
                "destination_blob_folder": f"{schema}/{config_name}/{business_id}/{_TODAY_DATE.year}/{_TODAY_DATE.month}/{_TODAY_DATE.day}",
                "filename": f"from_{start_date}_to_{end_date}_excl_etl{datetime.utcnow()}.csv",
            }

            upload_dataframe(df, config_name, schema, if_exists="append", gcs=gcs)

    return df


def generate_date_ranges(days_span: str, as_of_dates: List[date]):
    # print(f"Processing days_span: {days_span}..")

    date_ranges = []
    for date_ in as_of_dates:
        if date_ > _TOMORROW_DATE:
            print(f"Skipping date range for days_span {days_span} from {date_}")
            continue

        end_date_excl = date_  # was date_ - relativedelta(days=1)

        if str(days_span).isnumeric():
            start_date = date_ - relativedelta(days=int(days_span))
        elif days_span == "mtd":
            # if given date is the 1st day of the month, start_date should be 1st day of previous month
            if date_.day == 1:
                start_date = (date_ - relativedelta(days=1)).replace(day=1)
            else:
                start_date = date_.replace(day=1)
        elif days_span == "ytd":
            if (date_.day == 1) and (date_.month == 1):
                start_date = (date_ - relativedelta(days=1)).replace(day=1, month=1)
            else:
                start_date = date_.replace(day=1, month=1)

        # print()
        # print("start: ", start_date)
        # print("end_date (exclusive): ", end_date_excl)

        date_ranges.append({"start_date": start_date, "end_date": end_date_excl})
    return date_ranges


def get_ga_data(config_name, as_of_dates, ga_id, version: GAVersion) -> pd.DataFrame:
    try:
        config = get_config(config_name, version)
    except ValueError as e:
        slack = SlackMessage()
        slack.create_plain_text(f":rotating_light: Warning: GA ETL\n{e}")
        slack.send_notification()
        return pd.DataFrame()

    rename = config["rename"]
    dimensions = config["ga_dimensions"]
    metrics = config["ga_metrics"]

    # Determine start and end date for the reports
    date_ranges = []
    for days in config["days_span"]:
        date_ranges += generate_date_ranges(days, as_of_dates)

    if version == GAVersion.GA4:
        client = Analytics4Client(property_id=ga_id)
    elif version == GAVersion.UA:
        client = UniversalAnalyticsClient(view_id=ga_id)
    else:
        raise ValueError("GA version provided is not acceptable: ", version)

    data_df = client.run_report(
        metrics,
        dimensions,
        date_ranges,
        rename,
        "dataframe",
        config["dimension_filter"],
    )
    return data_df


if __name__ == "__main__":
    # pass
    start_date = _TODAY_DATE - relativedelta(days=_DEFAULT_REFRESH_DAYS)
    end_date = _TODAY_DATE

    as_of_dates = get_date_betw_dates(
        start_date, end_date, include_end=True, include_start=False
    )
    print(as_of_dates)

    # days = 1
    # dt_ranges = generate_date_ranges(days, as_of_dates)
    # print(dt_ranges)

    # res = run_etl(
    #     business_id="hwzz5EEgrkx8Sh9ulXee",
    #     config_name="ga_metrics_by_dates",
    #     start_date="2022-12-01",
    #     end_date="2022-12-05",
    #     skip_upload=True,
    # )
    # res.to_csv("res.csv", index=0)

    # res = run_etl(
    #     business_id="eJFBvUCjrEYSVFB5Lppz",
    #     config_name="ga_metrics_by_dates_pages_channels",
    #     start_date="2022-05-01",
    #     end_date="2022-05-05",
    #     # skip_upload=True,
    # )
