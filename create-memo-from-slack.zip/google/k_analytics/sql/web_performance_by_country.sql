{% if days_span == 'all_time' %}
WITH all_rows AS (
  SELECT
    country,
    SUM(num_unique_visitors) AS num_unique_visitors,
    AVG(avg_session_duration_sec) AS avg_session_duration_sec,
    SUM(num_sessions) AS num_sessions,
    SUM(num_all_goals_completed) AS num_all_goals_completed
  FROM `{{ project_id }}.m_google_analytics.view_stats_by_date_geo`
  WHERE
      days_span = 1
      AND view_id = {{ view_id }}  
  GROUP BY 1
),
{% else %}
WITH all_rows AS (
  SELECT
    country,
    num_unique_visitors,
    avg_session_duration_sec,
    num_sessions,
    num_all_goals_completed
  FROM `{{ project_id }}.m_google_analytics.view_stats_by_date_geo`
  WHERE
      days_span = {{ days_span }}
      AND end_date = CURRENT_DATE()
      AND view_id = {{ view_id }}
),
{% endif %}
top_10 AS (
  SELECT *
  FROM all_rows
  ORDER BY num_unique_visitors DESC
  LIMIT 10
)
SELECT
  *
FROM top_10
UNION ALL
SELECT
  'OTHERS' AS country,
  SUM(num_unique_visitors) AS num_unique_visitors,
  AVG(avg_session_duration_sec) AS avg_session_duration_sec,
  SUM(num_sessions) AS num_sessions,
  SUM(num_all_goals_completed) AS num_all_goals_completed
FROM all_rows
WHERE country NOT IN (
    SELECT country FROM top_10
)
GROUP BY 1