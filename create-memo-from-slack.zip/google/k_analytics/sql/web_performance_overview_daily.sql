WITH data_with_channel as (
    select *
    FROM `{{ project_id }}.m_google_analytics.view_stats_by_date_channel`
    WHERE TRUE
        AND view_id = {{ view_id }}
        AND days_span = 1
), num_visitors_by_channel as (
    SELECT 
        channel as top_channels, 
        sum(num_visitors) as top_num_visitors
    from data_with_channel
    group by 1
    order by 2 desc
    limit 5
), web as (
    SELECT
        start_date,
        CASE WHEN top_channels is not null then channel else 'Others' end as channel,
        sum(num_visitors) as num_visitors,
        sum(num_unique_visitors) as num_new_visitors,
        sum(avg_session_duration_sec) as avg_session_duration_sec,
        sum(num_sessions) as num_sessions,
        sum(transaction_revenue_excl_shipping_tax) as revenue
    FROM data_with_channel d
    LEFT JOIN num_visitors_by_channel c
        on d.channel = c.top_channels
    GROUP BY 1, 2
)
select
        start_date,
        channel,
        coalesce(num_visitors, 0) as num_visitors,
        coalesce(num_new_visitors, 0) as num_new_visitors,
        coalesce(avg_session_duration_sec, 0) as avg_session_duration_sec,
        coalesce(num_sessions, 0) as num_sessions,
        coalesce(revenue, 0) as revenue
from web
