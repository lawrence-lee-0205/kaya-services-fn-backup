WITH all_rows AS (
  SELECT
    channel,
    sum(num_unique_visitors) as num_unique_visitors,
    avg(avg_session_duration_sec) as avg_session_duration_sec,
    avg(num_page_views_per_session) as num_page_views_per_session,
    sum(num_all_goals_completed) as num_all_goals_completed
  from `{{ project_id }}.m_google_analytics.view_stats_by_date_channel` c
  {% if days_span == 'all_time' %}
  WHERE
    days_span = 1
    AND view_id = {{ view_id }}
  {% else %}
  WHERE
      days_span = {{ days_span }}
      AND end_date = CURRENT_DATE()
      AND view_id = {{ view_id }}
  {% endif %}
  GROUP BY 1
),
top_10 AS (
  SELECT *
  FROM all_rows
  ORDER BY num_unique_visitors DESC
  LIMIT 10
)
SELECT
  *
FROM top_10
UNION ALL
SELECT
  'Others' AS source_medium,
  SUM(num_unique_visitors) AS num_unique_visitors,
  AVG(avg_session_duration_sec) AS avg_session_duration_sec,
  AVG(num_page_views_per_session) AS num_page_views_per_session,
  SUM(num_all_goals_completed) AS num_all_goals_completed
FROM all_rows
WHERE channel NOT IN (
    SELECT channel FROM top_10
)
GROUP BY 1