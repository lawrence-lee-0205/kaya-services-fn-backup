{% if days_span == 'all_time' %}
with org as (
    SELECT
        coalesce(SUM(num_visitors), 0) AS num_organic_searches
    FROM `{{ project_id }}.m_google_analytics.view_stats_by_date_channel`
    WHERE channel = 'Organic Search'
        AND view_id = {{ view_id }}
        AND days_span = 1
), web as (
    SELECT
        coalesce(sum(num_visitors), 0) as num_visitors,
        coalesce(sum(num_unique_visitors), 0) as num_new_visitors,
        coalesce(sum(avg_session_duration_sec), 0) as avg_session_duration_sec,
        coalesce(sum(num_sessions), 0) as num_sessions
    FROM `{{ project_id }}.m_google_analytics.view_stats_by_date`
    WHERE TRUE
        AND view_id = {{ view_id }}
        AND days_span = 1
)
{% else %}
with org as (
    SELECT
        coalesce(SUM(num_visitors), 0) AS num_organic_searches
    FROM `{{ project_id }}.m_google_analytics.view_stats_by_date_channel`
    WHERE channel = 'Organic Search'
        AND view_id = {{ view_id }}
        AND days_span = {{ days_span }}
        AND end_date = (select max(end_date) from `{{ project_id }}.m_google_analytics.view_stats_by_date`) -- was CURRENT_DATE(), but didnt work at 12am as data for CURRENT DATE doesnt come in until 3am
), web as (
    SELECT
        coalesce(num_visitors, 0) as num_visitors,
        coalesce(num_unique_visitors, 0) as num_new_visitors,
        coalesce(avg_session_duration_sec, 0) as avg_session_duration_sec,
        coalesce(num_sessions, 0) as num_sessions
    FROM `{{ project_id }}.m_google_analytics.view_stats_by_date`
    WHERE TRUE
        AND view_id = {{ view_id }}
        AND days_span = {{ days_span }}
        AND end_date = (select max(end_date) from `{{ project_id }}.m_google_analytics.view_stats_by_date`) -- was CURRENT_DATE()
)
{% endif %}
SELECT
*
FROM web
CROSS JOIN org
