# Etl

## Google Analytics

1. Every day, a cron job will run to extract data from Google Analytics API and append data to Big Query staging dataset (`kaya-apps-00.google_analytics_staging`).

Cron job:
https://console.cloud.google.com/cloudscheduler?referrer=search&authuser=0&project=kaya-apps-00

Script:
services/jobs/etl_ga.py

2. Data in staging schema contains duplicated data (as it's append-only). _Scheduled queries_ are used to deduplicate data from staging and cleaned data are stored in `kaya-apps-00.google_analytics` schema. This is the schema where external users will query.

Scheduled query:
https://console.cloud.google.com/bigquery/scheduled-queries?authuser=0&project=kaya-apps-00

3. Cron job runs every month to run data quality check and send output to slack.

Script: services/jobs/check_ga_tables.py
