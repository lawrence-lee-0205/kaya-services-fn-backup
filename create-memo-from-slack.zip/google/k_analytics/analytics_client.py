import os
import pandas as pd
from typing import List
from abc import ABC, abstractmethod
from datetime import date, datetime, timedelta

from apiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials

from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    BatchRunReportsRequest,
    RunReportRequest,
    DateRange,
    Metric,
    Dimension,
    FilterExpression,
    Filter,
)

from utils.list import chunk_list
from google.gutils.api_queue import Queue

SCOPES = ["https://www.googleapis.com/auth/analytics.readonly"]

if os.environ["ENV"] in ["PROD", "DEV"]:
    KEY_FILE_LOCATION = "/secrets/service_account.json"
elif os.environ["ENV"] == "LOCAL_PROD":
    KEY_FILE_LOCATION = (
        os.path.abspath(os.path.dirname(__file__))
        + "/../../../.local/kaya-apps-prod-ga.json"
    )
else:
    KEY_FILE_LOCATION = (
        os.path.abspath(os.path.dirname(__file__))
        + "/../../../.local/kaya-apps-staging-ga.json"
    )


class AnalyticsClient(ABC):
    @abstractmethod
    def run_report(self, **kwargs):
        raise NotImplementedError("subclass should implement this method")


class UniversalAnalyticsClient(AnalyticsClient):
    def __init__(self, view_id) -> None:
        self.client = self._init_client()
        self.view_id = view_id

    def _init_client(self):
        """Initializes an Analytics Reporting API V4 service object.

        Returns:
        An authorized Analytics Reporting API V4 service object.
        """
        credentials = ServiceAccountCredentials.from_json_keyfile_name(
            KEY_FILE_LOCATION, SCOPES
        )

        # Build the service object.
        analytics = build("analyticsreporting", "v4", credentials=credentials)

        return analytics

    def _parse_single_report(self, report, date_ranges, rename: dict = {}):
        """Parses and prints the Analytics Reporting API V4 response.

        Args:
        response: An Analytics Reporting API V4 response.
        """
        column_header = report.get("columnHeader", {})
        dim_headers = column_header.get("dimensions", [])
        metric_headers = column_header.get("metricHeader", {}).get(
            "metricHeaderEntries", []
        )

        row_count = report.get("data", {}).get("rowCount")
        rows = report.get("data", {}).get("rows", [])

        output = []
        for row in rows:
            dimensions = row.get("dimensions", [])
            metrics_by_date_ranges = row.get("metrics", [])

            dim_records = {}
            for header, dimension in zip(dim_headers, dimensions):
                field = rename.get(header, header)
                dim_records[field] = dimension

            for idx, metric_result_dict in enumerate(metrics_by_date_ranges):
                row_output = {
                    **dim_records,
                    "created_at": datetime.utcnow(),
                    "created_date": datetime.utcnow().date(),
                    "view_id": int(self.view_id),
                }
                row_output["start_date"] = date_ranges[idx]["start_date"]
                row_output["end_date"] = date_ranges[idx]["end_date"]
                row_output["days_span"] = (
                    row_output["end_date"] - row_output["start_date"]
                ).days

                for metric_header, value in zip(
                    metric_headers, metric_result_dict.get("values", [])
                ):
                    field = rename.get(metric_header["name"], metric_header["name"])
                    row_output[field] = float(value)

                output.append(row_output)

        if row_count is not None:
            output_len = len(output)
            supposed_len = row_count * len(date_ranges)

            if output_len != supposed_len:
                print("TODO: FIX THIS!!!!")
                print(
                    f"Num of row in output doesnt match that in rowCount. rowCount = {supposed_len} vs parse output = {output_len}"
                )
                # raise Exception(
                #     f"Num of row in output doesnt match that in rowCount. rowCount = {supposed_len} vs parse output = {output_len}"
                # )
        return output

    def _execute_batch_request(self, date_ranges, metrics, dimensions):
        if len(date_ranges) > 5:
            raise Exception("Only excepts 5 or less requests per batch")

        date_ranges_param = [
            {
                "startDate": dr["start_date"].strftime("%Y-%m-%d"),
                "endDate": (dr["end_date"] - timedelta(days=1)).strftime("%Y-%m-%d"),
            }
            for dr in date_ranges
        ]
        requests = {
            "viewId": self.view_id,
            "dateRanges": date_ranges_param,
            "dimensions": [{"name": d} for d in dimensions],
            "metrics": [{"expression": m} for m in metrics],
            "pageSize": 50000,
        }

        Queue("google_analytics").queue(function="batchGet", num_operations=1)
        response = (
            self.client.reports().batchGet(body={"reportRequests": requests}).execute()
        )
        return response

    def run_report(
        self,
        metrics: list,
        dimensions: list,
        date_ranges: List[dict],
        rename: dict,
        format: str = "dataframe",
        dimension_filter: dict = {},
    ):
        # TODO: FIGURE OUT WHAT TO DO WITH dimension_filter
        output = []

        chunked_date_ranges = chunk_list(date_ranges, 2)
        for date_ranges in chunked_date_ranges:
            # chunk params is a list that contains elements of all_request_params
            response = self._execute_batch_request(date_ranges, metrics, dimensions)
            for _, report in enumerate(response.get("reports", [])):
                report_output = self._parse_single_report(report, date_ranges, rename)
                output += report_output

        if format == "dataframe":
            df = pd.DataFrame(output)
            print("Query completed. Size of results:")
            print(df.shape)
            return df

        return None


class Analytics4Client(AnalyticsClient):
    def __init__(self, property_id) -> None:
        self.client = BetaAnalyticsDataClient().from_service_account_json(
            KEY_FILE_LOCATION
        )
        self.property_id = property_id

    def _parse_single_report(
        self, report, start_date: date, end_date: date, rename: dict = {}
    ) -> List[dict]:
        """Parse the output from GA API for a single report into the format ready for upload

        Args:
            report (_type_): _description_
            start_date (date): report start date
            end_date (date): report end date (exclusive)
            rename (dict): mapping to rename from GA's field name to our database column name

        Returns:
            List[dict]: _description_
        """
        ccy = report.metadata.currency_code
        time_zone = report.metadata.time_zone

        # get metric col names
        metric_headers_raw = report.metric_headers
        metric_headers = [rename.get(h.name, h.name) for h in metric_headers_raw]

        dim_headers_raw = report.dimension_headers
        dim_headers = [rename.get(h.name, h.name) for h in dim_headers_raw]

        all_row_results = []
        for row in report.rows:
            metric_values = [float(mv.value) for mv in row.metric_values]
            dim_values = [mv.value for mv in row.dimension_values]

            metric_zipped = {k: v for k, v in zip(metric_headers, metric_values)}
            dim_zipped = {k: v for k, v in zip(dim_headers, dim_values)}

            row_output = {
                **metric_zipped,
                **dim_zipped,
                "ccy": ccy,
                "time_zone": time_zone,
                "start_date": start_date,
                "end_date": end_date,
                "days_span": (end_date - start_date).days,
                "property_id": int(self.property_id),
                "created_at": datetime.utcnow(),
                "created_date": datetime.utcnow().date(),
            }
            all_row_results.append(row_output)
        # print("Single report completed")
        # print("Property Quota:")
        # print(
        #     f"""
        #     Tokens per day: consumed {report.property_quota.tokens_per_day.consumed}, {report.property_quota.tokens_per_day.remaining} remaining
        #     Tokens per hour: consumed {report.property_quota.tokens_per_hour.consumed}, {report.property_quota.tokens_per_hour.remaining} remaining
        #     Concurrent request: {report.property_quota.concurrent_requests.remaining} remaining
        #     Concurrent request: {report.property_quota.concurrent_requests.remaining} remaining
        #     server_errors_per_project_per_hour: {report.property_quota.server_errors_per_project_per_hour.remaining} remaining
        #     potentially_thresholded_requests_per_hour: {report.property_quota.potentially_thresholded_requests_per_hour.remaining} remaining
        #     """
        # )
        return all_row_results

    @staticmethod
    def _build_dimensions(dimensions):
        return [Dimension(name=dim) for dim in dimensions]

    @staticmethod
    def _build_metrics(metrics):
        return [Metric(name=m) for m in metrics]

    @staticmethod
    def _build_dimension_filter(expression: str, payload: dict) -> FilterExpression:
        """for eg.
        expression = "not_expression"
        payload = {
            'filter': {
                'field_name': "xx",
                'in_list_filter': ["xx", "yy"],
            }
        }

        Args:
            expression (str): _description_
            payload (dict): _description_
        """
        # TODO: THIS HAS TO BE RECURSIVE?
        processed_payload = None
        for exp, value in payload.items():
            if exp == "filter":
                processed_payload = FilterExpression(
                    filter=Filter(
                        field_name=value["field_name"],
                        in_list_filter=Filter.InListFilter(
                            values=value["in_list_filter"]
                        ),
                    )
                )
            else:
                raise Exception(f"exp of type '{exp}' has not been implemented")

        if expression == "not_expression":
            return FilterExpression(not_expression=processed_payload)

    def _execute_single_request(self, request_params: dict):
        report_start = request_params["job_start_date"].strftime("%Y-%m-%d")
        report_end = (request_params["job_end_date"] - timedelta(days=1)).strftime(
            "%Y-%m-%d"
        )  # GA API's end date is inclusive

        # build dimension filter
        dimension_filter_args = {}
        if len(request_params["dimension_filter"]) == 1:
            for expression, payload in request_params["dimension_filter"].items():
                dimension_filter = self._build_dimension_filter(expression, payload)
                dimension_filter_args["dimension_filter"] = dimension_filter
        elif len(request_params["dimension_filter"]) > 1:
            raise Exception(
                "`dimension_filter` is expected to be a dict with just 1 key value pair"
            )

        Queue("google_analytics_4").queue(function="RunReportRequest", num_operations=1)
        request = RunReportRequest(
            property=f"properties/{self.property_id}",
            dimensions=self._build_dimensions(request_params["dimensions"]),
            metrics=self._build_metrics(request_params["metrics"]),
            date_ranges=[DateRange(start_date=report_start, end_date=report_end)],
            return_property_quota=True,
            **dimension_filter_args,
        )
        response = self.client.run_report(request)
        return response

    def run_report(
        self,
        metrics: list,
        dimensions: list,
        date_ranges: List[dict],
        rename: dict,
        format: str = "dataframe",
        dimension_filter: dict = {},
    ):
        output = []

        all_request_params = [
            {
                "dimensions": dimensions,
                "metrics": metrics,
                "dimension_filter": dimension_filter,
                "job_start_date": d["start_date"],
                "job_end_date": d["end_date"],
            }
            for d in date_ranges
        ]

        for request_params in all_request_params:
            response = self._execute_single_request(request_params)

            start_date = request_params["job_start_date"]
            end_date = request_params["job_end_date"]

            report_output = self._parse_single_report(
                response, start_date, end_date, rename
            )
            output += report_output

        if format == "dataframe":
            df = pd.DataFrame(output)
            print("Query completed. Size of results:")
            print(df.shape)
            return df

        return output


if __name__ == "__main__":
    # GA4
    print("Processing GA4\n")
    metrics = [
        "totalUsers",
        "newUsers",
        "sessions",
        "bounceRate",
        "screenPageViewsPerSession",
        "conversions",
        "transactions",
        "totalRevenue",
    ]
    dimensions = ["sessionMedium", "sessionSource"]
    date_ranges = [
        {"start_date": date(2022, 7, 20), "end_date": date(2022, 7, 21)},
        {"start_date": date(2022, 7, 22), "end_date": date(2022, 7, 23)},
    ]
    rename = {
        "totalUsers": "num_visitors",
        "newUsers": "num_unique_visitors",
        "sessions": "num_sessions",
        "bounceRate": "bounce_rate",
        "screenPageViewsPerSession": "num_page_views_per_session",
        "conversions": "num_all_goals_completed",
        "transactions": "transactions",
        "totalRevenue": "transaction_revenue_excl_shipping_tax",
    }

    client = Analytics4Client(property_id="300267609")
    output = client.run_report(metrics, dimensions, date_ranges, rename)
    print(output)
    print("*****")

    # UA
    # print("Processing UA\n")
    # metrics = [
    #     "ga:users",
    #     "ga:newUsers",
    # ]
    # dimensions = ["ga:sourceMedium"]
    # date_ranges = [
    #     {"start_date": date(2022, 5, 1), "end_date": date(2022, 5, 2)},
    #     {"start_date": date(2022, 5, 2), "end_date": date(2022, 5, 3)},
    # ]
    # rename = {
    #     "ga:users": "num_visitors",
    #     "ga:newUsers": "num_unique_visitors",
    #     "ga:sourceMedium": "source_medium",
    # }

    # client = UniversalAnalyticsClient(view_id="258918636")
    # output = client.run_report(metrics, dimensions, date_ranges, rename, "dataframe")
    # print(output)
    # output.to_csv("output.csv", index=0)
