from datetime import datetime
from typing import List
import pandas as pd


from firestore import FirestoreClient
from constants import DEFAULT_MAPPING
from utils.kaya_yaml import read_yaml
from slack_tools.slack import SlackMessage
from utils.datetimes import get_date_betw_dates
from google.k_analytics.analytics_client import (
    UniversalAnalyticsClient,
    Analytics4Client,
)
from google.gutils.bigquery import run_query


_CONFIGS = read_yaml("reconciliation.yml")["configs"]
_FS = FirestoreClient()


def _extract_ga_account(accounts: List, business_id: str):
    print("Processing", business_id)
    for acc in accounts:
        if not acc["is_primary"]:
            continue

        return acc["id"], acc["version"]


def _send_slack_alert(business_id, table, message):
    blocks = [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f":warning: Mismatch betw GA data returned by API vs DB.\nBusiness: {business_id}\nTable: {table}",
            },
        },
        {
            "type": "section",
            "text": {
                "type": "plain_text",
                "text": message,
                "emoji": True,
            },
        },
    ]

    bot = SlackMessage()
    bot.add_list_of_blocks(blocks)
    bot.create_plain_text("GA data error")
    bot.send_notification(channel="C02SZ4CJNN4")
    return None


def execute(table):
    config = _CONFIGS[table]

    start_date = DEFAULT_MAPPING.get(config["start_date"], config["start_date"])
    end_date = DEFAULT_MAPPING.get(config["end_date"], config["end_date"])

    # get dates to run reconciliation for
    dates = get_date_betw_dates(
        datetime.strptime(start_date, "%Y-%m-%d"),
        datetime.strptime(end_date, "%Y-%m-%d"),
    )
    dates.reverse()
    date_ranges = [
        {"start_date": dates[i], "end_date": dates[i + 1]}
        for i in range(len(dates) - 1)
    ]

    ua_metrics = [m["ga_field"] for m in config["ua"].get("metrics", [])]
    ua_metrics_rename = {
        m["ga_field"]: m["rename"] for m in config["ua"].get("metrics", [])
    }

    ua_dims = [m["ga_field"] for m in config["ua"].get("dimensions", [])]
    ua_dims_rename = {
        m["ga_field"]: m["rename"] for m in config["ua"].get("dimensions", [])
    }

    rename = {**ua_metrics_rename, **ua_dims_rename}
    print(rename.values())

    # get list of businesses with google_analytics_view_id defined

    businesses_ref = (
        _FS.get_collection("businesses").order_by("google_analytics").stream()
    )

    for biz in businesses_ref:
        biz_id = biz.id
        biz_data = biz.to_dict()
        if biz_data["is_deleted"]:
            continue

        ga_id, ga_version = _extract_ga_account(biz_data["google_analytics"], biz_id)
        if ga_id is None:
            _send_slack_alert(biz_id, table, "No GA account found for", biz_id)

        if ga_version == "ua":
            print("Processing UA\n")
            client = UniversalAnalyticsClient(view_id=ga_id)
            output_df = client.run_report(
                ua_metrics, ua_dims, date_ranges, rename, "dataframe"
            )
            if len(output_df) == 0:
                _send_slack_alert(biz_id, table, "No data returned from GA")
                continue

            output_df["start_date"] = output_df["start_date"].dt.strftime("%Y-%m-%d")

            cols_keep = ["start_date"] + list(rename.values())
            truth_df = output_df[cols_keep]
        else:
            # TODO: ADD ANALYTICS 4 CLIENT
            continue

        sql = config["sql"].format(view_id=ga_id)
        observed_df = run_query(sql, "dataframe")
        if len(observed_df) == 0:
            _send_slack_alert(biz_id, table, "No data returned from DB")
            continue

        compare_cols = [
            col.replace("_observed", "")
            for col in observed_df.columns
            if "_observed" in col
        ]

        truth_vs_observed_df = pd.merge(observed_df, truth_df, on="start_date")

        for col in compare_cols:
            abs_diff_col = f"{col}_abs_diff"
            truth_vs_observed_df[abs_diff_col] = (
                truth_vs_observed_df[f"{col}_truth"]
                - truth_vs_observed_df[f"{col}_observed"]
            ).abs()

            row_diff_filter = truth_vs_observed_df[abs_diff_col] > 0
            num_rows_diff = len(truth_vs_observed_df[row_diff_filter])
            if num_rows_diff > 0:
                msg = f"Abs diff in {col}: {truth_vs_observed_df[row_diff_filter][abs_diff_col].sum()}"
                _send_slack_alert(biz_id, table, msg)
                continue

    print()
    return None


if __name__ == "__main__":
    execute("view_stats_by_date")
