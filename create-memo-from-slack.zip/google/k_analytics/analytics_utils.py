import os
import pandas as pd
from datetime import datetime

from utils.kaya_yaml import read_yaml
from constants import DATE_WITHOUT_DASH
from enums.google_analytics import GAVersion

# from google.k_analytics.analytics_universal_client import UniversalAnalyticsClient

_CONFIG_FILENAME = os.path.abspath(os.path.dirname(__file__)) + "/reports.yaml"


def get_config(name: str, version: GAVersion):
    """Read and restructure config for G Analytics ETL"""

    print("Processing config for ", name)
    raw_configs = read_yaml(_CONFIG_FILENAME)
    # print(raw_configs)

    for config in raw_configs:
        config_version = GAVersion[config["version"].upper()]
        # iterate through each config and find the right one
        if (config["name"] != name) or (config_version != version):
            continue

        metrics_raw = {
            m["ga_field"]: m.get("rename", m["ga_field"]) for m in config["metrics"]
        }
        dimensions_raw = {
            m["ga_field"]: m.get("rename", m["ga_field"])
            for m in config.get("dimensions", {})
        }

        rename = {**metrics_raw, **dimensions_raw}

        metrics_fields = list(metrics_raw.values())
        dimensions_fields = list(dimensions_raw.values())

        ga_metrics_fields = list(metrics_raw.keys())
        ga_dimensions_fields = list(dimensions_raw.keys())
        ga_fields = ga_metrics_fields + ga_dimensions_fields

        report = {
            "metrics_raw": metrics_raw,
            "dimensions_raw": dimensions_raw,
            "rename": rename,
            "metrics": metrics_fields,
            "dimensions": dimensions_fields,
            "ga_metrics": ga_metrics_fields,
            "ga_dimensions": ga_dimensions_fields,
            "all_ga_fields": ga_fields,
            "aggfunc": config.get("aggfunc"),
            "days_span": config.get("days_span"),
            "dimension_filter": config.get("dimension_filter", {}),
        }
        return report

    # if loop through entire file and no config is matched, raise error
    raise ValueError(f"Config {name} for version {version} not found")


def process_channel(raw: str):
    """Convert source/medium value from GA to user-friendly representation

    Args:
        raw (str): raw string from google

    Returns: string
    """
    if raw == "(direct) / (none)":
        return "Direct"
    else:
        split_lst = raw.split(" / ")
        source = split_lst[0]
        channel_grp = split_lst[1]
        return f"{channel_grp.capitalize()} - {source.capitalize()}"


def format_ga_date(raw_date):
    raw_date_formatted = datetime.strptime(raw_date, DATE_WITHOUT_DASH)

    return f"{raw_date_formatted.year}-{raw_date_formatted.month:02}-{raw_date_formatted.day:02}"
