import datetime

from setup import setup
from common import validate_inputs, validate_non_empty_list
from nlp.clustering import group_keywords
from firestore import FirestoreClient


_THRESHOLDS = {"optimal": 1.5, "compact": 2}


@setup
def main(data: dict) -> dict:
    """Given a list of keywords, cluster them into groups based on similarity.
    Args:
        data (dict): Payload processed by setup decorator. Contains input from front end client.
    Raises:
        Exception: [description]
    Returns:
        dict
    """

    mandatory_fields = ["business_id", "auth_user_id", "keywords", "google_session_id"]
    validate_inputs(data, mandatory_fields)

    # VALIDATE KEYWORDS
    if not isinstance(data["keywords"], list):
        raise TypeError(
            f"Expecting 'keywords' to be a list of string. Received {data['keywords']} instead."
        )

    validate_non_empty_list(data["keywords"], "keywords")

    google_session_id = data["google_session_id"]

    # If only 1 keyword is provided, return it without clustering
    if len(data["keywords"]) == 1:
        keyword = data["keywords"][0]
        dict_to_return = {keyword: data["keywords"]}
        groups = {name: dict_to_return for name, _ in _THRESHOLDS.items()}
    else:
        # RUN CLUSTERING ALGO
        groups = {
            name: group_keywords(data["keywords"], threshold)
            for name, threshold in _THRESHOLDS.items()
        }

    # STORE RECORD IN FIRESTORE
    fs = FirestoreClient()
    cluster_doc = {**groups, "created_at": datetime.datetime.utcnow()}
    cluster_id = fs.add_subcollection_to_document(
        "google_sessions",
        google_session_id,
        "keyword_clusters",
        cluster_doc,
    )

    # update main session doc
    fs.update_document(
        "google_sessions",
        google_session_id,
        {
            "latest_cluster_id": cluster_id,
            "updated_at": datetime.datetime.utcnow(),
        },
    )

    output = {**groups, "cluster_id": cluster_id}

    return output


if __name__ == "__main__":
    data = {
        "business_id": "SWlTMQLhNmhit98gFu5j",
        "keywords": [
            "barbell",
            "exercise stepper",
            "ez bar",
            "gym malaysia",
            "gym puchong",
            "leg press machine",
            "rubber mat",
            "treadmill",
        ],
        "auth_user_id": "test_local",
        "google_session_id": "jhKERdlxHVSegSh7LOwf",
    }
    main(data)
