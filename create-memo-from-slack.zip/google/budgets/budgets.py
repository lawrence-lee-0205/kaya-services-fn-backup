import random

from setup import setup
from common import validate_inputs
from queries import get_google_account


@setup
def main(data: dict) -> dict:
    mandatory_fields = ["business_id", "audience_id"]
    validate_inputs(data, mandatory_fields)

    google_acc = get_google_account(data["business_id"])
    ccy = google_acc["ccy_code"]

    output = {
        "ccy": ccy,
        "avg_cpc": random.uniform(0.5, 1.5),
        "num_keywords_analysed": random.randint(10000, 20000),
    }
    return output
