from firestore import FirestoreClient

FS = FirestoreClient()


class Session:
    def __init__(self, google_session_id) -> None:
        self._session_raw = FS.get_single_document("google_sessions", google_session_id)

    @property
    def page_urls(self):
        return self._session_raw.get("page_urls", [])

    @property
    def seed_keywords(self):
        return self._session_raw.get("seed_keywords", [])

    @property
    def negative_keywords(self):
        return self._session_raw.get("negative_keywords", [])


if __name__ == "__main__":
    session = Session("007xO1rySDZKZfmPhZ61")
    print(session.page_urls)
