import datetime as dt
from os import environ


from tasks.task import Task
from businesses.business import Business
from common import validate_inputs
from http_function import http_function, process_request_inputs
from noloco.request import call_noloco_api

_COMMENTER_USER_ID = (
    "0GgKmc6CPLGKQUDSjnmv"
    if "PROD" in environ["ENV"].upper()
    else "yQ2bybPjv54pIFkaM3RO"
)
_NOTIFICATION_TYPE = "notify_owner_new_task"

_NOTIFICATION_START_DATE = dt.datetime(
    2023, 10, 23
)  # only execute if task is created after this date


@http_function
def add_comment_to_notify_owners(request_json={}, request_args={}):
    mandatory_fields = ["start_ts", "end_ts"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    start_ts = data["start_ts"][:19] + "Z"
    end_ts = data["end_ts"][:19] + "Z"
    tasks = _query_new_tasks(start_ts=start_ts, end_ts=end_ts)

    if len(tasks) == 0:
        print("No new tasks to process. Terminating..")
        return "Success"

    for task_payload in tasks:
        process_single_task(**task_payload)
    return "Success"


def _query_new_tasks(start_ts, end_ts):
    outputs = {}
    for string in ["created", "updated"]:
        q = f"""
        query MyQuery {{
            taskCollection(where: {{{string}At: {{gte: "{start_ts}", lte: "{end_ts}" }}}}) {{
                edges {{
                    node {{
                        uuid
                        company {{
                            fsId
                        }}
                        taskNotificationsCollection(where: {{type: {{equals: "{_NOTIFICATION_TYPE}"}}}}) {{
                            edges {{
                                node {{
                                    recipientFirestoreId
                                }}
                            }}
                        }}
                        createdAt
                    }}
                }}
            }}
        }}
        """
        outputs[string] = call_noloco_api(body=q)["data"]["taskCollection"]["edges"]
    all_raw_tasks = outputs["created"] + outputs["updated"]

    tasks = []
    processed_task_uuid = []
    for e in all_raw_tasks:
        uuid = e["node"]["uuid"]
        print("Processing ", uuid)
        if uuid in processed_task_uuid:
            print(f"{uuid} already processed. Skipping..")
            continue

        task_created_dt = dt.datetime.strptime(
            e["node"]["createdAt"], "%Y-%m-%dT%H:%M:%S.%fZ"
        )
        if task_created_dt < _NOTIFICATION_START_DATE:
            print(
                f"{uuid} created at {task_created_dt} before {_NOTIFICATION_START_DATE}. Skipping.."
            )
            continue

        notified_user_ids = [
            n["node"]["recipientFirestoreId"]
            for n in e["node"]["taskNotificationsCollection"]["edges"]
        ]
        tasks.append(
            {
                "uuid": uuid,
                "business_id": e["node"]["company"]["fsId"],
                "notified_user_ids": notified_user_ids,
            }
        )
        processed_task_uuid.append(uuid)

    return tasks


def process_single_task(uuid, business_id, notified_user_ids):
    print("Processing task:", uuid)
    # for each task, identify owners who haven't been notified yet
    # owner to notify = owner
    # task watchers will not be notified
    business = Business(business_id=business_id)
    task = Task(uuid=uuid, business=business)

    owners_to_notify = []
    for owner in task.all_owners:
        if owner.user_id in notified_user_ids:
            print(f"{owner.user_id} already notified. Skipping..")
            continue
        owners_to_notify.append(owner.user_id)

    if len(owners_to_notify) == 0:
        print("No owners to notify. Terminating..")
        return None

    print("Owners to notify: ", owners_to_notify)

    # construct comment. exclude Kayabot
    owner_names = ", ".join(
        [
            owner.first_name
            for owner in task.all_owners
            if owner.user_id != "0GgKmc6CPLGKQUDSjnmv"
        ]
    )
    comment_content = f"👋 {owner_names}, a new task is assigned to you. Please review and confirm if you can complete it by the due date."

    # now_str = dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    now_str = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")

    # TODO comment owner should be task creator
    print("Running mutation to create task comment in Noloco")
    q = f"""
        mutation MyMutation {{
            createAppComment(
                commentContent: "{comment_content}"
                commenterOwnerThatsVisibleInApp: "{_COMMENTER_USER_ID}"
                createdAt: "{now_str}"
                isNotReviewed: false
                taskId: "{task.id}"
                customNotificationRecipientIds: "{owners_to_notify}"
            ){{
                id
            }}
        }}
    """
    _ = call_noloco_api(body=q)

    # update task notification table
    # note: task notication table is different from app comment notification table
    for o in owners_to_notify:
        print("Running mutation to create task notification in Noloco")
        nq = f"""
        mutation createTaskNotificationMutation {{
            createTaskNotification(
                comment: "{comment_content}"
                recipientFirestoreId: "{o}"
                taskId: {task.id}
                createdAt: "{now_str}"
                type: "{_NOTIFICATION_TYPE}"
        ){{
            id
            }}
        }}
        """
        _ = call_noloco_api(body=nq)
    return None


if __name__ == "__main__":
    tasks = _query_new_tasks("2024-08-15T00:00:00Z", "2024-08-16T00:00:00Z")
    print(tasks)

    for task_payload in tasks:
        process_single_task(**task_payload)
