import datetime as dt
from os import environ
import re

from tasks.task import Task
from users.user import User
from noloco.request import call_noloco_api

_KAYA_CLIENT_DOMAIN = (
    "app.usekaya.com" if "PROD" in environ["ENV"] else "kaya-apps-staging.web.app"
)

_KAYA_TEAM_DOMAIN = "team.usekaya.com"


class Comment:
    def __init__(
        self,
        id: str,
        content: str,
        commenter_firestore_id: str,
        is_reviewed: bool,
        task: Task,
        last_notification_sent_at: dt.datetime = None,
        custom_notification_recipient_ids: list = [],
    ):
        self.id = id
        self.task = task
        self._content = content
        self.commenter_firestore_id = commenter_firestore_id
        self.last_notification_sent_at = last_notification_sent_at
        self.is_reviewed = is_reviewed
        self.custom_notification_recipient_ids = custom_notification_recipient_ids

    @property
    def commenter(self):
        return User(user_id=self.commenter_firestore_id)

    @property
    def client_app_task_url(self):
        return f"https://{_KAYA_CLIENT_DOMAIN}/tasks/{self.task.uuid}?client={self.task.business_id}"

    @property
    def team_app_task_url(self):
        return f"https://{_KAYA_TEAM_DOMAIN}/tasks/{self.task.uuid}?business={self.task.business_id}"

    @property
    def content(self):
        # remove URI from comment
        processed = re.sub(
            r"\!\[.*?\]\(data:image\/[^;]+;base64,[^\)]+\)",
            "<image attached>",
            self._content,
        )
        return processed

    @property
    def custom_notification_recipients(self):
        return [User(user_id=fs_id) for fs_id in self.custom_notification_recipient_ids]

    def get_users_who_were_notified(self):
        query = f"""
            query MyQuery {{
                appCommentNotificationCollection(where: {{appCommentId: {{equals: "{self.id}"}}}}) {{
                    edges {{
                        node {{
                            userFirestoreId
                        }}
                    }}
                }}
            }}
        """
        output = call_noloco_api(query)
        notifications = output["data"]["appCommentNotificationCollection"]["edges"]
        user_firestore_ids = [n["node"]["userFirestoreId"] for n in notifications]
        return user_firestore_ids


if __name__ == "__main__":
    pass
    # from businesses.business import Business

    # com = Comment(
    #     id="123",
    #     content="Hello",
    #     commenter_firestore_id="123",
    #     is_reviewed=True,
    #     task=Task(uuid="123", business=Business(business_id="lyu6tWbXJlYQmfzi6uGg")),
    #     custom_notification_recipient_ids=None,
    # )
    # print(com.custom_notification_recipients)
