import datetime as dt
import json
from businesses.business import Business

from firestore import FirestoreClient
from utils.kaya_yaml import read_yaml
from noloco.request import call_noloco_api
from utils.jinja import render_template_from_string

_FS = FirestoreClient()

_DEFAULT_DAYS_UNTIL_DUE_DATE = 3


def add_task_template_to_firestore(filename):
    content = read_yaml(
        "/Users/jeeyenpersonal/Documents/kaya-services/services/tasks/task_templates/"
        + filename
        + ".yaml"
    )["content"]
    # print(content)

    if _FS.check_if_document_exist("task_templates", filename):
        print(f"Task template {filename} already exists in Firestore")
        _FS.update_document("task_templates", filename, content)
        print("Updated the task template")
        return None
    _FS.add_document("task_templates", content, filename)
    return None


def create_tix_from_template(business_id, template, **kwargs):
    biz = Business(business_id)

    template = _FS.get_single_document("task_templates", template)

    # populate content with params
    populated_desc = render_template_from_string(template["description"], **kwargs)
    populated_action_item = render_template_from_string(
        template["action_item"], **kwargs
    )

    # add other fields to the task
    due_date = dt.datetime.now() + dt.timedelta(days=_DEFAULT_DAYS_UNTIL_DUE_DATE)
    if "days_until_due_date" in template:
        due_date = dt.datetime.now() + dt.timedelta(
            days=template["days_until_due_date"]
        )

    utc_now = dt.datetime.now()

    additional_query = ""
    if template.get("visibility"):
        additional_query += f"visibility: {template['visibility']}"

    query = f"""
    mutation MyMutation {{
        createTask(
            channel: {template['channel']}
            companyId: {biz.noloco_company_id}
            createdAt: "{utc_now.strftime('%Y-%m-%dT00:00:00Z')}"
            description: {json.dumps(populated_desc.strip())}
            name: {json.dumps(template['title'].strip())}
            status: TO_DO
            updatedAt: "{utc_now.strftime('%Y-%m-%dT00:00:00Z')}"
            dueDate: "{due_date.strftime('%Y-%m-%dT00:00:00Z')}"
            actionItems: {json.dumps(populated_action_item.strip())}
            {additional_query}
        ) {{
            uuid
        }}
    }}
    """
    print(query)
    noloco_output = call_noloco_api(query)
    print(noloco_output)
    task_uuid = noloco_output["data"]["createTask"]["uuid"]
    print(f"📝 View the new task here: https://team.usekaya.com/tasks/{task_uuid}")

    return None


if __name__ == "__main__":
    fn = "designer_to_create_images"
    add_task_template_to_firestore(fn)
    create_tix_from_template("b8vQxN8x0jk5vYlk22MQ", fn)
    # add_task_template_to_firestore(fn)
