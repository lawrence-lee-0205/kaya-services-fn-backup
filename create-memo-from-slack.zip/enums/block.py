from enum import Enum


class DashboardBlockType(Enum):
    TEXT = 1
    METABASE = 2
    PIVOT_TABLE = 3
    TITLE = 4
    IFRAME = 5


if __name__ == "__main__":
    print(type(DashboardBlockType["metabase"]))
    print(DashboardBlockType.PIVOT_TABLE.name.lower())
