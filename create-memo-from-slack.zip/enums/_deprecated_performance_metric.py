import enum


class PerformanceMetric(enum.Enum):
    def __new__(cls, *args, **kwds):
        value = len(cls.__members__) + 1
        obj = object.__new__(cls)
        obj._value_ = value
        return obj

    def __init__(self, type, aggfunc, display_name, family):
        """_summary_

        Args:
            type (_type_): _description_
            aggfunc (_type_): _description_
            display_name (_type_): _description_
            family (_type_): Core - fundamental value coming from database. KPI is a Core metric but can be set as KPI. Derived metric can only be calculated as a function of core metrics.
        """
        self.type = type
        self.aggfunc = aggfunc
        self.display_name = display_name
        self.family = family

    # all of these values must exist in m_core.daily_metric_by_channel table
    NUM_VISITORS = "integer", "sum", "num_visitors", "core"
    NUM_NEW_VISITORS = "integer", "sum", "num_new_visitors", "core"

    AVG_SESSION_DURATION_SEC = "float", "avg", "avg_session_duration_sec", "core"
    NUM_SESSIONS = "integer", "sum", "num_sessions", "core"

    BOUNCE_RATE = "percentage", "avg", "disengagement_rate", "core"

    # GOAL_COMPLETIONS_1 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_2 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_3 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_4 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_5 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_6 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_7 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_8 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_9 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_10 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_11 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_12 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_13 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_14 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_15 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_16 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_17 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_18 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_19 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_20 = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_ALL = "integer", "sum", "goals", "kpi"
    # GOAL_COMPLETIONS_1_6 = "integer", "sum", "goals", "kpi"

    # META_CUSTOM_CONVERSION_1 = "integer", "sum", "conversions (or goals)", "kpi"
    # META_CUSTOM_CONVERSION_2 = "integer", "sum", "conversions (or goals)", "kpi"
    # META_CUSTOM_CONVERSION_3 = "integer", "sum", "conversions (or goals)", "kpi"

    # TOTAL_CONVERSIONS = "integer", "sum", "conversions (or goals)", "kpi"

    # INSTALL_COMPLETED = "integer", "sum", "installs (or goals)", "kpi"
    # NUM_CUSTOM_SIGNUP = "integer", "sum", "num signups", "kpi"

    # TODO: CHECK IF WE CAN REMOVE NUM GOALS
    NUM_GOALS = "integer", "sum", "num_goals", "kpi"
    TOTAL_CONVERSION_VALUE = "integer", "sum", "total_conversion_value", "kpi"

    # COST_ACCOUNT_CCY = "currency", "sum", "cost", "core"
    # REVENUE = "currency", "sum", "revenue", "kpi"

    COST_PER_GOAL = "currency", None, "cost_per_goal", "derived"
    GOAL_PER_USER = "float", None, "num_goal_per_user", "derived"
    RETURN_ON_ADS_SPEND = "integer", None, "return_on_ads_spend", "derived"
    REVENUE_PER_USER = "currency", None, "revenue_per_user", "derived"
    CONVERSION_VALUE_PER_USER = "integer", None, "conversion_value_per_user", "derived"


if __name__ == "__main__":
    print(type(PerformanceMetric["COST"]))
    print(PerformanceMetric.COST_ACCOUNT_CCY.name)
    print(PerformanceMetric.COST_ACCOUNT_CCY.type)

    lst = [PerformanceMetric.COST_ACCOUNT_CCY, PerformanceMetric.NUM_SESSIONS]

    test = {l.name.lower(): l.aggfunc for l in lst}
    print(test)
