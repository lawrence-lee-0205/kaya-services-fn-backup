from enum import Enum


class GAVersion(Enum):
    UA = 1
    GA4 = 2
