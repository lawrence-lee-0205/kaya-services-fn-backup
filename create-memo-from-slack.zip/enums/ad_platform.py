import enum


class AdPlatform(enum.Enum):
    def __new__(cls, *args, **kwds):
        value = len(cls.__members__) + 1
        obj = object.__new__(cls)
        obj._value_ = value
        return obj

    def __init__(self, var_name, display_name):
        self.var_name = var_name
        self.display_name = display_name

    GOOGLE = "google_ads", "Google Ads"
    META = "meta_ads", "Meta Ads"
    LINKEDIN = "linkedin_ads", "LinkedIn Ads"
    BING = "bing_ads", "Bing Ads"
    TIKTOK = "tiktok_ads", "TikTok Ads"


def get_ad_platform_by_var_name(var_name):
    """Return the AdPlatform member based on the var_name."""
    for platform in AdPlatform:
        if platform.var_name == var_name:
            return platform
    return None
