import requests
import datetime as dt
from os import environ

from peopledatalabs import PDLPY

from common import validate_inputs
from firestore import FirestoreClient
from http_function import http_function, process_request_inputs

_FS = FirestoreClient()


@http_function
def enrich_company_from_domain(request_json={}, request_args={}):
    mandatory_fields = ["domain"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    out = _enrich(data["domain"])
    return out


def _enrich(domain):
    peopledatalabs_json = _enrich_with_peopledatalabs_api(domain)
    thecompaniesapi_json = _enrich_with_the_companies_api(domain)
    bigpictureapi_json = _enrich_with_bigpicture_api(domain)

    out = _combine_api_data(
        peopledatalabs_json, thecompaniesapi_json, bigpictureapi_json
    )
    return out


def _enrich_with_peopledatalabs_api(domain):
    data_source = "peopledatalabs"

    print(f"enriching with {data_source} api")
    existing_data = _get_existing_data_from_firestore(domain, data_source)
    if len(existing_data) > 0:
        # TODO: sort by created_at and return the latest one
        response_json = existing_data[0]
        return response_json

    # Create a client, specifying your API key
    CLIENT = PDLPY(
        api_key=environ["PEOPLEDATALABS_API_KEY"],
    )
    # Pass the parameters object to the Company Enrichment API
    resp = CLIENT.company.enrichment(website=domain)

    if resp.status_code != 200:
        print("Error fetching data from peopledatalabs: ", resp.text)
        return {"error": f"Error fetching data from peopledatalabs: {resp.text}"}

    response = resp.json()
    if len(response) == 0 or response.get("status") != 200:
        print("peopledatalabs: No data found for domain ", domain)
        return {}

    # Data exists
    print(response)
    _FS.add_document(
        "companies",
        {**response, "source": data_source, "created_at": dt.datetime.now()},
    )

    social_media = {
        "linkedin": {
            "handle": response.get("linkedin_slug"),
            "id": response.get("linkedin_id"),
        },
        "twitter": {
            "handle": (
                response["twitter_url"].replace("twitter.com/", "")
                if response.get("twitter_url") is not None
                else None
            )
        },
        "facebook": {
            "handle": (
                response.get("facebook_url", "") if "facebook_url" in response else None
            )
        },
    }
    return social_media


def _enrich_with_the_companies_api(domain):
    data_source = "thecompaniesapi"

    existing_data = _get_existing_data_from_firestore(domain, data_source)
    if len(existing_data) > 0:
        # TODO: sort by created_at and return the latest one
        response = existing_data[0]
    else:
        print("enriching with the companies api")
        url = f"https://api.thecompaniesapi.com/v1/companies/{domain}?token={environ['THECOMPANIESAPI_TOKEN']}"
        resp = requests.get(url)
        if resp.status_code != 200:
            print("Error fetching data from The Companies API: ", resp.text)
            return {"error": f"Error fetching data from The Companies API: {resp.text}"}
        response = resp.json()

        if len(response) == 0:
            print("thecompaniesapi: No data found for domain ", domain)
            return {}

        _FS.add_document(
            "companies",
            {**response, "source": data_source, "created_at": dt.datetime.now()},
        )

    # process social network
    social_media = _process_social_network(response.get("socialNetworks", {}))

    # rename technologies to tech
    response["tech"] = response.get("technologies", [])

    # rename domainAlts to domainAliases
    response["domainAliases"] = response.get("domainAlts", [])

    # process tags
    categories = []
    for field in ["industries", "technologyCategories"]:
        categories += [x.replace("-", " ").title() for x in response.get(field, [])]

    response["tags"] = categories

    # clean up duplicated fields
    for field in ["industries", "technologyCategories", "domainAlts", "technologies"]:
        if field in response:
            del response[field]
    return {**response, **social_media}


def _process_social_network(social_network):
    if len(social_network) == 0:
        return {}

    linkedin_dict = {}

    linkedin_handle = social_network.get("linkedinIdAlpha")
    if linkedin_handle:
        linkedin_dict["handle"] = f"company/{linkedin_handle}"

    linkedin_id = social_network.get("linkedinIdNumeric")
    if linkedin_id:
        linkedin_dict["id"] = linkedin_id

    twitter = {}
    twitter_handle = social_network.get("twitterId")
    if twitter_handle:
        twitter["handle"] = twitter_handle

    facebook = {}
    facebook_handle = social_network.get("facebookId")
    if facebook_handle:
        facebook["handle"] = facebook_handle

    instagram = {}
    instagram_handle = social_network.get("instagramId")
    if instagram_handle:
        instagram["handle"] = instagram_handle

    return {
        "linkedin": linkedin_dict,
        "twitter": twitter,
        "facebook": facebook,
        "instagram": instagram,
    }


def _enrich_with_bigpicture_api(domain):
    data_source = "bigpicture"

    print("enriching with bigpicture api")
    existing_data = _get_existing_data_from_firestore(domain, data_source)
    if len(existing_data) > 0:
        # TODO: sort by created_at and return the latest one
        response_json = existing_data[0]
        return response_json

    response = requests.get(
        f"https://company.bigpicture.io/v1/companies/find?domain={domain}",
        headers={"Authorization": environ["BIGPICTURE_TOKEN"]},
    )
    if response.status_code != 200:
        # note: 202 means the data is not yet in their database or stale
        print("Error. Received response ", response.status_code, response.json)
        return {"error": f"Error fetching data from bigpicture: {response.json}"}

    response_json = response.json()

    if len(response_json) == 0:
        return {}

    _FS.add_document(
        "companies",
        {**response_json, "source": "bigpicture", "created_at": dt.datetime.now()},
    )
    return response_json


# Function to combine data from both APIs
def _combine_api_data(api1_data, api2_data, api3_data):
    combined_data = {}

    # List of keys to check and combine
    keys = (
        set(api1_data.keys()).union(set(api2_data.keys())).union(set(api3_data.keys()))
    )

    for key in keys:
        if key == "error":
            continue

        # Use data from API 1 if available, otherwise fallback to API 2
        combined_data[key] = (
            api1_data.get(key) or api2_data.get(key) or api3_data.get(key)
        )

    return combined_data


def _get_existing_data_from_firestore(domain, source):
    # check if we have data in FS for this domain within the last 90 days
    # if so, use that data instead of querying again
    print(f"checking firestore for existing data. source: {source}. domain: {domain}")
    existing_data = _FS.get_filtered_documents(
        "companies",
        [
            {"field_name": "domain", "operator": "==", "value": domain},
            {"field_name": "source", "operator": "==", "value": source},
            {
                "field_name": "created_at",
                "operator": ">=",
                "value": dt.datetime.now() - dt.timedelta(days=90),
            },
        ],
    )
    return existing_data


if __name__ == "__main__":
    o = _enrich("usekaya.com")
    print("----\n")
    print(o)
    # d = {"facebook_url": None}
    # print(d.get("facebook_url", ""))

    #

    # # Create a client, specifying your API key
    # CLIENT = PDLPY(
    #     api_key="a98eef0a12f5d7636889361cce74dcfbdc1ec516d414f7abd587f79434de4466",
    # )

    # # Create a parameters JSON object
    # QUERY_STRING = {"website": "gleamcare.com"}

    # # Pass the parameters object to the Company Enrichment API
    # response = CLIENT.company.enrichment(**QUERY_STRING)

    # # Print the API response
    # print(response.text)

    # out = _enrich("buckeyehealthplan.com")
    # print(out)
