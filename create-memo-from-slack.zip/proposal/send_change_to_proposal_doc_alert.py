from os import environ

from slack_tools.slack import SlackMessage
from businesses.business import Business


def send_change_to_proposal_doc_alert(data, context):
    """
    Triggered when a document is created in users collection
    """
    trigger_resource = context.resource
    print("Function triggered by change to: %s" % trigger_resource)

    # get document id
    document_id = trigger_resource.split("/")[-1]
    url = f"https://console.firebase.google.com/u/0/project/kaya-apps-00/firestore/data/~2Fproposal~2F{document_id}"

    channel = "C03B7MJMZUG" if environ["ENV"].lower() == "prod" else "C02PYBMGLL9"
    # channel = "C02PYBMGLL9"

    print(data)
    execute(data, url, channel)
    return None


def execute(data, url, channel):
    _process_func_mapping = {
        "shared_to_emails.formatted": _process_shared_to_emails_formatted,
        "shared_to_emails.raw": _process_shared_to_emails_raw,
        "requested_competitors.formatted": _process_competitors,
    }

    # actual execution logic
    updated_fields = data["updateMask"]["fieldPaths"]

    for field in updated_fields:
        print("Processing field: ", field)
        if field not in _process_func_mapping:
            print("No function defined for field: ", field)
            print("Skipping...")
            continue

        try:
            _process_func_mapping[field](data, url, channel)
        except Exception as e:
            _send_slack(
                f"Error processing field: {field} from {url}\nError: {e}", channel
            )

    return None


def _process_competitors(data, url, channel):
    old_competitors_formatted = _get_requested_competitors(
        data, "oldValue", "formatted"
    )
    old_competitors_formatted_str = "\n• ".join(old_competitors_formatted)
    new_competitors_formatted = _get_requested_competitors(data, "value", "formatted")
    new_competitors_formatted_str = "\n• ".join(new_competitors_formatted)

    message = f"""
*New Competitors Requested for Existing Proposal*
`requested_competitors` updated

Old:
• {old_competitors_formatted_str}

New:
• {new_competitors_formatted_str}

Action required: Add new competitors, rerun COIN and notify clients
<@U02P4RZDN5P|cal>

<{url}|Link to Firestore →>
"""
    _send_slack(message, channel)
    return None


def _process_shared_to_emails_formatted(data, url, channel):
    business_id = data["value"]["fields"]["business_id"]["stringValue"]
    business = Business(business_id)
    user_emails_under_business = [u["email"] for u in business.get_users()]

    email_dict = {}
    for v in ["oldValue", "value"]:
        email_array = data[v]["fields"]["shared_to_emails"]["mapValue"]["fields"][
            "formatted"
        ]["arrayValue"]["values"]
        email_dict[v] = get_email_from_array(email_array)

    emails_added = list(set(email_dict["value"]) - set(email_dict["oldValue"]))
    emails_removed = list(set(email_dict["oldValue"]) - set(email_dict["value"]))
    emails_to_give_access = list(
        set(email_dict["value"]) - set(user_emails_under_business)
    )

    emails_added = "\n•".join(emails_added)
    emails_removed = "\n•".join(emails_removed)
    emails_to_give_access = "\n• ".join(emails_to_give_access)

    message = f"""
*:jesus: Proposal Share Request detected*
`Shared_to_emails.formatted updated`

Proposal info:
• Business ID: {business_id}
• Business Name: {business.name}
• Firestore URL: {url}

Emails added:
• {emails_added}

Emails removed:
• {emails_removed}

Current users with access:
• {user_emails_under_business}

*Action required: Add users to business*, <@U02P4RZDN5P|cal>.
You should grant access to the following emails:
• {emails_to_give_access}
        """
    _send_slack(message, channel)
    return None


def _process_shared_to_emails_raw(data, url, channel):
    old_emails = data["oldValue"]["fields"]["shared_to_emails"]["mapValue"]["fields"][
        "raw"
    ]["stringValue"]
    new_emails = data["value"]["fields"]["shared_to_emails"]["mapValue"]["fields"][
        "raw"
    ]["stringValue"]

    message = f"""
*Proposal Share Request detected*
Only shared_to_emails.raw updated. Sense check if any emails were added or removed.

Old:
```{old_emails}```

New:
```{new_emails}```

<{url}|Link to Firestore →>
    """
    _send_slack(message, channel)
    return None


def _get_requested_competitors(data, old_or_current_value, formatted_or_raw):
    payload = (
        data[old_or_current_value]["fields"]
        .get("requested_competitors", {})
        .get("mapValue", {})
        .get("fields", {})
    )
    if formatted_or_raw == "raw":
        return payload.get("raw", {}).get("stringValue", "")
    elif formatted_or_raw == "formatted":
        formatted = payload.get("formatted", {}).get("arrayValue", {}).get("values", [])
        return [c["stringValue"] for c in formatted]


def _send_slack(message, channel):
    bot = SlackMessage()
    bot.create_plain_text(message)
    bot.send_notification(channel=channel)
    return None


def get_email_from_array(array_dict):
    return [email_d["stringValue"] for email_d in array_dict]


if __name__ == "__main__":
    pass
    # data = {
    #     "oldValue": {
    #         "createTime": "2024-03-24T00:30:00.007609Z",
    #         "fields": {
    #             "business_id": {"stringValue": "eJFBvUCjrEYSVFB5Lppz"},
    #             "is_published": {"booleanValue": True},
    #             "proposal_company_id": {"stringValue": "eLVUIeWCXAmVgZCtThLV"},
    #             "shared_to_emails": {
    #                 "mapValue": {
    #                     "fields": {
    #                         "formatted": {
    #                             "arrayValue": {
    #                                 "values": [
    #                                     {"stringValue": "wwfwfw@fefef.ff"},
    #                                     {"stringValue": "efe@fwf.cc"},
    #                                     {"stringValue": "efwfwfw@ffwfw.cc"},
    #                                     {"stringValue": "wfwfw@efwf.ff"},
    #                                     {"stringValue": "brian@usekaya.com"},
    #                                     {"stringValue": "jeeyen@usekaya.com"},
    #                                     {"stringValue": "efef@dwd.cs"},
    #                                     {"stringValue": "meow@wwdw.cc"},
    #                                     {"stringValue": "woof@woof.cc"},
    #                                     {"stringValue": "jeeyen+t@usekaya.com"},
    #                                     {"stringValue": "jeeyen+test@usekaya.com"},
    #                                 ]
    #                             }
    #                         },
    #                         "raw": {
    #                             "stringValue": "wwfwfw@fefef.ff\nefefefefef\nefe@fwf.cc, efwfwfw@ffwfw.cc\nwwfwfw@fefef.ff\n\nwfwfw@efwf.ff brian@usekaya.com\nbrian@usekaya.com, jeeyen@usekaya.com brian@usekaya.com\nefef@dwd.cs\nkmkmk meow@wwdw.cc woof@woof.cc jeeyen+t@usekaya.com jeeyen+test@usekaya.com"
    #                         },
    #                     }
    #                 }
    #             },
    #         },
    #         "name": "projects/kaya-apps-00/databases/(default)/documents/proposal/cOAEdEnC0rAMMxCREIgo",
    #         "updateTime": "2024-04-09T12:25:02.553791Z",
    #     },
    #     "updateMask": {"fieldPaths": ["shared_to_emails.raw"]},
    #     "value": {
    #         "createTime": "2024-03-24T00:30:00.007609Z",
    #         "fields": {
    #             "business_id": {"stringValue": "eJFBvUCjrEYSVFB5Lppz"},
    #             "domain": {"stringValue": "rippling.com"},
    #             "is_published": {"booleanValue": True},
    #             "proposal_company_id": {"stringValue": "eLVUIeWCXAmVgZCtThLV"},
    #             "shared_to_emails": {
    #                 "mapValue": {
    #                     "fields": {
    #                         "formatted": {
    #                             "arrayValue": {
    #                                 "values": [
    #                                     {"stringValue": "wwfwfw@fefef.ff"},
    #                                     {"stringValue": "efe@fwf.cc"},
    #                                     {"stringValue": "efwfwfw@ffwfw.cc"},
    #                                     {"stringValue": "wfwfw@efwf.ff"},
    #                                     {"stringValue": "brian@usekaya.com"},
    #                                     {"stringValue": "jeeyen@usekaya.com"},
    #                                     {"stringValue": "efef@dwd.cs"},
    #                                     {"stringValue": "meow@wwdw.cc"},
    #                                     {"stringValue": "woof@woof.cc"},
    #                                     {"stringValue": "jeeyen+t@usekaya.com"},
    #                                     {"stringValue": "jeeyen+test@usekaya.com"},
    #                                 ]
    #                             }
    #                         },
    #                         "raw": {
    #                             "stringValue": "wwfwfw@fefef.ff\nefefefefef\nefe@fwf.cc, efwfwfw@ffwfw.cc\nwwfwfw@fefef.ff\n\nwfwfw@efwf.ff brian@usekaya.com\nbrian@usekaya.com, jeeyen@usekaya.com brian@usekaya.com\nefef@dwd.cs\nkmkmk meow@wwdw.cc woof@woof.cc jeeyen+t@usekaya.com jeeyen+test@usekaya.com jeeyen@usekaya.com"
    #                         },
    #                     }
    #                 }
    #             },
    #         },
    #         "name": "projects/kaya-apps-00/databases/(default)/documents/proposal/cOAEdEnC0rAMMxCREIgo",
    #         "updateTime": "2024-04-09T12:28:45.443503Z",
    #     },
    # }
    # execute(data, "https://source.unsplash.com/random/?dog", "C02PYBMGLL9")
