from emailer.send_email import send_templated_email


def send_received_coin_request_email(to_email, first_name) -> dict:
    payload = {
        "first_name": first_name.title(),
    }

    send_templated_email(
        from_email="admin@usekaya.com",
        from_email_name="Team Kaya",
        to_emails=[to_email],
        dynamic_data=payload,
        template_id="d-743e530e08964805b09bbe086fe138b6",
        subject=f"We're Working on Your Competitor Intelligence Report",
        cc_emails=["jeeyen@usekaya.com"],
    )
    print("sent to " + to_email)
    return None


if __name__ == "__main__":
    to_email = ""
    first_name = ""

    send_received_coin_request_email(
        to_email, first_name, num_working_day_to_ready=3, to_send_calendly=False
    )
