import ast
import inspect

from common import validate_inputs
from http_function import http_function, process_request_inputs

from open_ai.run_chat_completions import run_chat_completions

from scraper.get_web_content import get_web_content
from scraper.get_visible_text_from_page import get_visible_text_from_page


@http_function
def ai_get_tone_of_voice_http(request_json={}, request_args={}):
    mandatory_fields = ["url"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    out = get_tone_of_voice(data["url"], data.get("country", "US"))
    return out


def get_tone_of_voice(url, country="US"):
    html = get_web_content(url, country)
    visible_texts = get_visible_text_from_page(html)

    # remove texts that are too short (most likely for navigation)
    # and limit total input to 1500 words
    scraped_content = []
    num_words = 0
    for t in visible_texts:
        if len(t) <= 3:
            continue

        scraped_content.append(t)
        num_words += len(t.split())

        if num_words > 1500:
            break

    system_prompt = f"""
    As an experienced copywriter, your task is to analyze the provided website content and determine the brand's tone of voice. Please ensure that your analysis covers a range of voice characteristics, such as formal, casual, humorous, authoritative, or any other relevant tones.
    
    You should provide 2 responses:
    1. short_summary: A short summary with keywords. Completes the sentence: "The brand's tone of voice is..."
    2. long_summary: A detailed analysis including a list of voice characteristics, detailing the do's and don'ts for each characteristic, along with relevant examples. Example output quoted in ``:
        `Formal
        - Do: Maintain a professional, respectful tone; use correct grammar and punctuation; avoid slang or colloquialisms. For example, "We understand, first-hand how important it is to secure flexible and bespoke home care for your loved one."
        - Don't: Avoid overly casual language or jargon that may alienate or confuse the audience.`
    """

    content_str = "\n- ".join(scraped_content)
    user_prompt = f"""
    The following is a list of content scraped from their website: 
    - {content_str}
    """

    output_format_prompt = f"""
    Your output must be a RFC8259 compliant JSON response following this format without deviation.
{{
    "short_summary": string,
    "long_summary": string,
}}
    """

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
        {"role": "user", "content": output_format_prompt},
    ]
    out = run_chat_completions(messages)
    inspect.cleandoc(out)
    print(out)
    try:
        out_json = ast.literal_eval(out)
    except Exception as e:
        print("Failed to convert to JSON")
        out_json = {"error": f"Error converting the output to JSON: {e}", "raw": out}

    return out_json


if __name__ == "__main__":
    url = "usekaya.com"
    country = "GB"

    out = get_tone_of_voice(url, country)
    print(out)
