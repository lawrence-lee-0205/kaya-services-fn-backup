from firestore import FirestoreClient

_FS = FirestoreClient()

if __name__ == "__main__":
    desc = {
        "comparison_single_competitor": "A table showing a list of feature comparisons between a single competitor and the client",
        "customer_support_rep": "Shows a customer support representative in an office with a headset looking to the right",
        "app_screenshot_expense_tracking": "Shows a mobile screenshot with bar chart and amount spent",
        "app_screenshot_beverage": "Mobile app screenshot showing an ecommerce store with a range of beverage products with prices and a checkout screen",
        "credit_cards": "Shows a few credit cards. Encouraged to use this for finance products",
        "female_at_cafe_with_phone": "Shows a female looking at her phone at home",
        "glowing_smartphone": "Shows a glowing smartphone with a screen with a popup message",
        "sql_query_ui": "Shows a developer IDE with a SQL query. Encouraged to use this for a data, coding products or developer tools",
        "male_with_phone": "Shows a male holding a phone looking to the right",
        "mockup_ecommerce_book": "Shows an ebook that has a cover with an ecommerce theme",
        "mockup_square_book": "Showsg an ebook which is square in shape",
        "app_screenshot_crypto_balance_with_stacked_coins": "Show mobile app screenshot with a stacked coin icon and user's account balance. Strictly only choose this for crypto product.",
        "ecommerce_dashboard_screenshot": "Shows mockups of product listings and sales data",
        "female_hijab_with_tablet": "Shows a female in a hijab looking at a tablet which screen is not visible",
        "statistics_with_line_bar": "Shows a few metrics and progress bars. Example use cases: survey report and KPI tracking.",
        "flow_diagram_ui": "Shows a flow diagram with a few boxes and arrows",
        "app_screenshot_crypto_balance_with_coins": "Shows mobile app screenshot with user's account balance and charts with crypto prices. Strictly only choose this for crypto product.",
        "customer_support_rep_vB": "Shows a customer support representative with a headset looking straight",
        "smartphone_display": "Screenshot showing a smartphone with a screen showing a company's logo",
        "project_management_screenshot": "Shows the home page of a project management tool",
        "modern_home_office": "Shows a modern home office with a laptop, a plant, and a coffee cup",
    }

    docs = _FS.get_all_documents_within_collection("ad_builder_images")
    for doc in docs:
        doc_id = doc["id"]

        template = doc_id
        description = desc.get(template, "")
        _FS.update_document(
            "ad_builder_images", id=doc_id, content={"description": description}
        )
