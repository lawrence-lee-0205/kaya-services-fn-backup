from setup import setup
from common import validate_inputs
from emailer.send_email import send_templated_email


# @setup
def send_received_proposal_request_email(
    to_email, first_name, num_working_day_to_ready=3, to_send_calendly=False
) -> dict:
    payload = {
        "first_name": first_name.title(),
        "to_send_calendly": to_send_calendly,
        "num_working_day_to_ready": num_working_day_to_ready,
    }

    send_templated_email(
        from_email="admin@usekaya.com",
        from_email_name="Team Kaya",
        to_emails=[to_email],
        dynamic_data=payload,
        template_id="d-fa12ed0f903a4e11a2a543233bc1afec",
        subject=f"We're Working on Your Proposal",
        cc_emails=["jeeyen@usekaya.com"],
    )
    print("sent to " + to_email)
    return None


if __name__ == "__main__":
    to_email = ""
    first_name = ""

    send_received_proposal_request_email(
        to_email, first_name, num_working_day_to_ready=3, to_send_calendly=False
    )
