import ast
from schema import Schema, And, Optional

from common import validate_inputs
from firestore import FirestoreClient
from open_ai.run_chat_completions import run_chat_completions
from http_function import process_request_inputs, http_function


# create custom exception where openai failed to generate image copy
class OpenAIFailedToGenerateImageCopy(Exception):
    pass


_FS = FirestoreClient()

# get the latest image templates
_ALL_IMAGE_TEMPLATES = _FS.get_all_documents_within_collection("ad_builder_images")
_ALL_IMAGE_TEMPLATES = [
    {
        "id": doc["id"],
        "description": doc["description"],
    }
    for doc in _ALL_IMAGE_TEMPLATES
]
_VALID_IMAGE_KEYS = [d["id"] for d in _ALL_IMAGE_TEMPLATES]
_EXCLUDE_IMAGE_TEMPLATES = [
    "woman_profile_dark_background",
    "diverse_people_collage_border",
    "milestone_timeline_gradient",
]


# max number of times an image template can be used
_MAX_IMAGE_TEMPLATE_USES = 2

# define schema to save to FS
_IMAGE_BUILDER_SCHEMA = Schema(
    {
        "headline": str,
        "description": str,
        "title": str,
        "cta": str,
        "image_key": And(str, lambda s: s in _VALID_IMAGE_KEYS),
        Optional("reasoning"): str,
    }
)
_IMAGE_BUILDER_PAYLOAD_KEYS_TO_SAVE_IN_FS = [
    "image_key",
    "headline",
    "description",
    "cta",
]

# auto retry in case openai failed to generate image copy
_SYSTEM_ROLE_PROMPT = f"""
You are a performance marketer who specialized in creating highly converting images for social media ads. Here are the best practices:
- Use short, impactful words and phrases that convey the essence of the ad
- Use Action-Oriented Language: Get, Discover, Start, Claim or Learn
- Emphasize the Value Proposition

"""
_OPENAI_MAX_ATTEMPTS = 2


@http_function
def proposal_generate_ad_examples(request_json={}, request_args={}):
    mandatory_fields = ["proposal_id"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)
    print(data)

    out = generate_ad_examples(data["proposal_id"])
    return out


def generate_ad_examples(proposal_id):
    proposal_doc = _FS.get_single_document("proposal", proposal_id)

    # get data about the company
    business_id = proposal_doc["business_id"]
    business_doc = _FS.get_single_document("businesses", business_id)
    business_profile = business_doc["profile"]

    marketing_idea_by_stage = proposal_doc["marketing_idea_by_stage"]

    count_template_frequency = {}
    image_templates = [
        x for x in _VALID_IMAGE_KEYS if x not in _EXCLUDE_IMAGE_TEMPLATES
    ]

    ad_examples_dict = {}
    for stage, ideas in marketing_idea_by_stage.items():
        print(stage)
        ads_under_stage = []
        for idx, idea in enumerate(ideas, start=1):
            print("Ad idea ", idx)
            print(idea)

            for ad_copy in idea["ad_copies"]:
                print(ad_copy)

                attempt = 0
                while attempt < _OPENAI_MAX_ATTEMPTS:
                    try:
                        print(f"Attempt #{attempt}")
                        ad = process_single_ad_copy(
                            ad_copy,
                            business_doc["name"],
                            business_profile,
                            image_templates,
                        )
                        ads_under_stage.append(ad)

                        # update count for count_template_frequency
                        chosen_image_template = ad["image_builder"]["image_key"]
                        count_template_frequency[chosen_image_template] = (
                            count_template_frequency.get(chosen_image_template, 0) + 1
                        )
                        if (
                            count_template_frequency[chosen_image_template]
                            >= _MAX_IMAGE_TEMPLATE_USES
                        ):
                            print(
                                f"Image template {chosen_image_template} has been used more than 2 times. Consider adding more image templates."
                            )
                            image_templates.remove(chosen_image_template)

                        break
                    except OpenAIFailedToGenerateImageCopy as e:
                        # retry if openai failed to generate image copy. raise exception if it's other errors
                        print(e)
                        attempt += 1

        ad_examples_dict[stage] = ads_under_stage

    _FS.update_document("proposal", proposal_id, {"ad_examples": ad_examples_dict})
    url = "https://app.usekaya.com/proposal?client={}".format(business_id)
    print(url)
    return {"url": url, "status": "success"}


def process_single_ad_copy(
    ad_copy: str,
    business_name: str,
    business_profile: str,
    valid_image_templates: list,
):
    try:
        image_templates = [
            t for t in _ALL_IMAGE_TEMPLATES if t["id"] in valid_image_templates
        ]

        validated_image_builder_payload = get_image_copy_from_openai(
            business_name,
            business_profile,
            ad_copy,
            image_templates,
        )

        ad = {
            "platform": "meta_ads",
            "channels": ["facebook", "instagram"],
            "headline": validated_image_builder_payload["title"],
            "body": ad_copy,
            "format": "image_single",
            "link_description": "",
            "slides": [],
            "cta": "Learn More",
            "image_builder": {
                key: value
                for key, value in validated_image_builder_payload.items()
                if key in _IMAGE_BUILDER_PAYLOAD_KEYS_TO_SAVE_IN_FS
            },
        }
        return ad
    except Exception as e:
        raise OpenAIFailedToGenerateImageCopy(e)


def get_image_copy_from_openai(
    business_name: str, business_profile: str, ad_copy: str, image_templates: list
):
    messages = [
        {
            "role": "system",
            "content": _SYSTEM_ROLE_PROMPT,
        },
        {
            "role": "system",
            "content": f"The company you are creating ads for is called {business_name}. Its profile: \n{business_profile}",
        },
        {
            "role": "user",
            "content": f"""
Your task is to select an image template from the provided list that best suits the following ad copy: '{ad_copy}'. Provide a title, description, headline, and call to action (CTA) for that image, ensuring that the title and headline contain fewer than 45 characters and the description contains fewer than 90 characters and the CTA contains fewer than 20 characters. Do not use exclamation marks in the copy. For each image selection, provide a brief reasoning (fewer than 120 characters) for your choice and start the sentence with 'This image template is chosen to show'.

The selected image template, along with the headline, title, description, and CTA, will be incorporated into the ad to attract the attention of potential customers and encourage them to click.

Here are the list of image templates with their IDs and descriptions: 
{image_templates}

Return your response in a JSON object using the specified schema:
{{
"headline": "headline of the ad",
"description": "Description of the ad",
"title": "Title of the ad",
"cta": "Call to action",
"image_key": "ID of the image template used",
"reasoning": "Reasoning for choosing the image"
}}
Ensure that the JSON object strictly adheres to the provided schema. Avoid including explanations in the JSON object.
""",
        },
    ]
    o = run_chat_completions(messages)
    print(o)
    print("\n\n")

    o = ast.literal_eval(o)
    validated_image_builder_payload = _IMAGE_BUILDER_SCHEMA.validate(o)
    return validated_image_builder_payload


if __name__ == "__main__":
    proposal_id = "hJguSpT4TnqiKuCOWiYs"
    generate_ad_examples(proposal_id)
