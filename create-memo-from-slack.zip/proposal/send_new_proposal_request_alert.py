from os import environ

from users.user import User
from firestore import FirestoreClient
from slack_tools.slack import SlackMessage
from proposal.send_received_proposal_request_email import (
    send_received_proposal_request_email,
)
from proposal.send_received_coin_request_email import send_received_coin_request_email
from relate.deal_ops import update_deal

_FS = FirestoreClient()

########################
#   API ENTRY POINTS   #
########################


def send_new_proposal_request_alert(data, context):
    _execute(data, context, "proposal")
    return None


def send_new_coin_request_alert(data, context):
    _execute(data, context, "coin")
    return None


############################
#   API ENTRY POINTS END   #
############################


def _execute(data, context, request_type):
    trigger_resource = context.resource
    print("Function triggered by change to: %s" % trigger_resource)

    collection = f"{request_type}_requests"
    request_type = request_type.capitalize()
    emoji = ":moneybag:" if request_type == "Coin" else ":jesus:"

    # get document id
    document_id = trigger_resource.split("/")[-1]
    url = f"https://console.firebase.google.com/u/0/project/kaya-apps-00/firestore/data/~2F{collection}~2F{document_id}"

    channel = "C03B7MJMZUG" if environ["ENV"].lower() == "prod" else "C02PYBMGLL9"
    # channel = "C02PYBMGLL9"

    print(data)
    doc = data["value"]["fields"]

    # get person working on the form
    requester_user_id = doc["requested_by"]["stringValue"]
    requester = User(requester_user_id)

    if data["oldValue"] == {} and data["updateMask"] == {}:
        print("New document created")

        message = f"{emoji} *New {request_type.upper()} request received*\n\n{request_type} Request ID: {document_id}\nUser: {requester.full_name} {requester.email}\n\n<{url}|Link to Firestore →>"
        _send_slack(message, channel)
        return None

    # terminate if form hasn't been submitted
    status = doc.get("status", {}).get("stringValue", "")
    if status != "SUBMITTED":
        print("Form hasn't been submitted. Terminating...")
        return None

    # PROCESS DOCUMENT
    business_id = doc.get("business_id", {}).get("stringValue")

    form_value_lst = []
    form_value_lst.append(f"> *Business ID*:\n{business_id}")

    form_values = doc.get("request_content", {}).get("arrayValue", {}).get("values", [])
    for form_ques_dict in form_values:
        qna = form_ques_dict.get("mapValue", {}).get("fields", {})
        ques = qna.get("question", {}).get("stringValue", "")

        # process answer
        answers_raw = qna.get("answer", {})
        if "arrayValue" in answers_raw:
            answers = [str(r) for r in answers_raw["arrayValue"]["values"]]
        elif "stringValue" in answers_raw:
            answers = [answers_raw["stringValue"]]
        else:
            answers = [str(r) for r in answers_raw.values()]
        answer_str = "\n".join(answers)

        form_value_lst.append(f"> *{ques}*\n{answer_str}")

        # check if a meeting is scheduled
        id = qna.get("id", {}).get("stringValue", "")
        if id == "scheduledCall":
            try:
                is_meeting_scheduled = answers_raw["booleanValue"]
            except KeyError:
                is_meeting_scheduled = False
            print(
                f"Is meeting scheduled? {answers_raw}",
            )
            print("Deduced is_meeting_scheduled: ", is_meeting_scheduled)

    form_value_str = "\n\n".join(form_value_lst)

    message = f":cheer: {emoji} *{request_type.upper()} request fully filled and submitted*\n\n{form_value_str}\n\n<{url}|Link to Firestore →>"
    _send_slack(message, channel)

    try:
        _send_email_to_requester(requester, request_type, is_meeting_scheduled)
        _send_slack(f"Sent acknowledgement email to {requester.email}", channel)
        _update_relate_deal_status(business_id, request_type)
    except Exception as e:
        error_notif = f"Failed to send acknowledgement email. Error:\n{str(e)}"
        _send_slack(error_notif, channel)
    return None


def _update_relate_deal_status(business_id, request_type):
    deal_id = _FS.get_single_document("businesses", business_id)["relate_deal_id"]
    value = 100 if request_type.lower() == "coin" else 1800
    update_deal(deal_id, {"pipeline_stage": "Proposal requested", "value": value})
    return None


def _send_email_to_requester(requester, request_type, is_meeting_scheduled):
    if request_type.lower() == "proposal":
        # need to send calendly link if meeting is not scheduled
        to_send_calendly = not is_meeting_scheduled
        send_received_proposal_request_email(
            to_email=requester.email,
            first_name=requester.first_name,
            to_send_calendly=to_send_calendly,
        )
    elif request_type.lower() == "coin":
        send_received_coin_request_email(requester.email, requester.first_name)
    else:
        raise Exception("Invalid request type: ", request_type)
    return None


def _send_slack(message, channel):
    bot = SlackMessage()
    bot.create_plain_text(message)
    bot.send_notification(channel=channel)
    return None


if __name__ == "__main__":
    # data = {}

    # class context:
    #     resource = (
    #         "projects/kaya-apps-00/databases/(default)/documents/proposal_requests/xxx"
    #     )

    # send_new_proposal_request_alert(data, context)
    from firestore import FirestoreClient
    import datetime as dt

    fs = FirestoreClient()
    doc = fs.get_single_document("coin_requests", "ij1OfPskS6r25sIKQsJb")
    print(doc)
    doc["created_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
    new_id = fs.add_document("coin_requests", doc, "test")
    print(new_id)
