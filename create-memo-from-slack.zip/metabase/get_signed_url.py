import os
import jwt
import time

from setup import setup
from common import validate_inputs

METABASE_SITE_URL = "https://kaya.metabaseapp.com"


@setup
def get_signed_url(data: dict) -> dict:
    mandatory_fields = [
        "dashboard_id",
        "auth_user_id",
        "metabase_params",
    ]
    validate_inputs(data, mandatory_fields)

    show_metabase_title = data.get("show_metabase_title", False)

    url = get_url(
        dashboard_id=data["dashboard_id"],
        show_metabase_title=show_metabase_title,
        **data["metabase_params"],
    )
    return {"url": url}


def get_url(dashboard_id: int, bordered=False, show_metabase_title=True, **params):
    # dashboard must be integer
    if not isinstance(dashboard_id, int):
        dashboard_id = int(dashboard_id)

    payload = {
        "resource": {"dashboard": dashboard_id},
        "params": params,
        "exp": round(time.time()) + (60 * 60),  # 60 minute expiration
    }
    token = jwt.encode(payload, os.environ["METABASE_SECRET"], algorithm="HS256")

    url = f"{METABASE_SITE_URL}/embed/dashboard/{token}#bordered={str(bordered).lower()}&titled={str(show_metabase_title).lower()}"
    return url
