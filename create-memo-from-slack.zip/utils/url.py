import tldextract
from urllib.parse import urlparse


def get_url_without_params(full_url):
    parsed_url = urlparse(full_url)
    # Construct URL without query parameters or fragment
    url_without_params = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
    url_without_params = url_without_params.rstrip("/")
    return url_without_params


def get_path_from_url(url):
    """Return the path component of a URL. Eg for 'https://www.example.com/path/to/page', return '/path/to/page'"""
    url_parts = urlparse(url)

    # Return the path component
    return url_parts.path


def extract_domain(url):
    try:
        # If the URL doesn't start with a scheme, prepend 'http://'
        if not url.startswith(("http://", "https://")):
            url = "http://" + url

        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        # Remove 'www.' if present
        domain = domain.replace("www.", "")
        return domain
    except Exception as e:
        return f"Error: {e}"


def is_valid_domain(domain):
    extracted = tldextract.extract(domain)
    # Check if both domain and suffix (like .com, .org) are present
    return bool(extracted.domain and extracted.suffix)


if __name__ == "__main__":
    print(is_valid_domain("https://www.dailybot.com"))
