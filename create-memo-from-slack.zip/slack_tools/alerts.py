import os
import datetime

from setup import setup
from common import validate_inputs
from firestore import FirestoreClient
from slack_tools.slack import send_notification


@setup
def send_task_for_shared_channel(data: dict) -> dict:
    mandatory_fields = ["business_id", "user_id", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    channel = "C036RCTV145" if os.environ["ENV"].upper() == "PROD" else "C02PYBMGLL9"
    assignee = "U02NBHYDFKR" if os.environ["ENV"].upper() == "PROD" else "U02P4RZDN5P"
    fields_to_copy = ["first_name", "last_name", "email", "business_name"]

    # get business and user details from Firestore
    fs = FirestoreClient()
    user_doc = fs.get_single_document("users", data["user_id"])
    biz_doc = fs.get_single_document("businesses", data["business_id"])

    details = {**user_doc, "business_name": biz_doc["name"]}

    # set up title block
    title_txt = ":bellhop_bell: New Task to create Slack Channel"
    title_block = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": title_txt,
                "emoji": True,
            },
        },
        {"type": "divider"},
    ]

    # set up detail block
    detail_str = "\n".join(
        [f"{key.replace('_', ' ')}: {details[key]}" for key in fields_to_copy]
    )
    detail_blocks = [
        {
            "type": "section",
            "text": {
                "type": "plain_text",
                "text": detail_str,
                "emoji": True,
            },
        }
    ]

    # set up final block
    end_block = [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"<@{assignee}>, mark :white_check_mark: when completed.",
            },
        },
        {"type": "divider"},
        {
            "type": "context",
            "elements": [
                {
                    "type": "plain_text",
                    "text": f"Created at {datetime.datetime.now()}",
                    "emoji": True,
                }
            ],
        },
    ]

    blocks = title_block + detail_blocks + end_block

    send_notification(blocks=blocks, channel=channel, text=title_txt)
    return {}


if __name__ == "__main__":
    data = {
        "user_id": "P9YisGuZPTvz4Acs11sT",
        "business_id": "DMoINLWFiEC5YcQUYVcb",
        "auth_user_id": "local",
    }

    send_task_for_shared_channel(data)
