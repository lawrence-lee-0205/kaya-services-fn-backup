import re


def convert_to_slack_markdown(comment):
    # adapt markdown links to slack links
    comment = re.sub(r"\[([^\]]+)\]\(([^\)]+)\)", r"<\2|\1>", comment)

    # Replace lists
    comment = re.sub(r"^\*\s+(.*?)\s*$", r"• \1", comment, flags=re.MULTILINE)
    comment = re.sub(r"^\d+\.\s+(.*?)\s*$", r"1. \1", comment, flags=re.MULTILINE)

    return comment
