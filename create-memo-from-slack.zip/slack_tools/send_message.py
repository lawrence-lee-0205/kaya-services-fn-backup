from http_function import http_function, process_request_inputs
from common import validate_inputs

from slack_tools.slack import SlackMessage

# Pre-requisites:
# - Slack channel is acessible
# - Kayabot has been invited to the channel with command "/invite" -> "Add apps to this channel"

_TEST_CHANNEL_ID = "C078T6QLRR8"  # channel: test-channel


@http_function
def send_slack_message(request_json={}, request_args={}):
    mandatory_fields = ["message", "channel", "env"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    output = execute(message=data["message"], channel=data["channel"], env=data["env"])
    return output


def execute(message, channel, env="dev"):
    bot = SlackMessage()
    bot.create_plain_text(message)
    _channel = channel if env.upper() == "PROD" else _TEST_CHANNEL_ID
    bot.send_notification(channel=_channel)
    return "Slack message sent!"


if __name__ == "__main__":
    message = "helloworld"
    channel = _TEST_CHANNEL_ID  # channel: coin-dev C07BCQA4C5U
    env = "dev"
    output = execute(message, channel, env)

    print(output)
