from datetime import datetime, timedelta

from firestore import FirestoreClient
from businesses.business import Business
from slack_tools.slack import SlackMessage
from google.gutils.bigquery import run_query
from http_function import http_function, process_request_inputs


_FS = FirestoreClient()

_EXCLUDE_BUSINESS_IDS = ["eJFBvUCjrEYSVFB5Lppz", "H7LfqWsJcmC4sBXtXws0"]


@http_function
def check_businesses_without_memo(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)

    execute(data.get("env", "dev"))
    return "Success"


def execute(env="dev"):
    slack_channel = "C07C1A9SQBV" if env.upper() == "PROD" else "C02PYBMGLL9"

    # get the monday from last week
    start_date = (
        datetime.now() - timedelta(days=datetime.now().weekday() + 7)
    ).replace(hour=0, minute=0, second=0, microsecond=0)
    end_date_plus_one = datetime.now().replace(
        hour=0, minute=0, second=0, microsecond=0
    ) + timedelta(days=1)

    businesses_doc = _FS.get_filtered_documents(
        "businesses",
        [
            {
                "field_name": "status",
                "operator": "==",
                "value": "ACTIVE",
            },
        ],
        "records",
    )
    active_biz_ids = [b["id"] for b in businesses_doc]

    memos = _FS.get_filtered_documents(
        "memos",
        [
            {
                "field_name": "is_internal",
                "operator": "==",
                "value": False,
            },
        ],
        "records",
    )

    # Filter memos that are created this week
    memo_biz_ids = []
    for m in memos:
        memo_date = datetime.strptime(m["memo_date"], "%Y-%m-%dT%H:%M:%S.%fZ")
        # only include memos that are within the start and end dates
        if memo_date >= start_date and memo_date <= end_date_plus_one:
            memo_biz_ids.append(m["business"])

    # get business with ad spend
    sql = f"""
    with b as (
        select 
            business_id,
            sum(cost_usd) as cost
        from kaya-apps-00.m_core.daily_kpi_by_channel
        where date >= CURRENT_DATE - INTERVAL 7 DAY
        group by 1
        having cost > 10
    )
    select distinct business_id from b
    """
    res = run_query(sql)
    business_with_ad_spend = [r["business_id"] for r in res]
    print(res)

    # get business that has ad spend but no memo
    businesses_without_memo = [
        Business(b)
        for b in business_with_ad_spend
        if b not in memo_biz_ids
        and b not in _EXCLUDE_BUSINESS_IDS
        and b in active_biz_ids
    ]

    # send slack notification
    if len(businesses_without_memo) == 0:
        message_blocks = [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"All businesses have memo in the past 2 weeks :tada:",
                },
            }
        ]
    else:
        messages = [
            f"· <https://team.usekaya.com/businesses/{b.business_id}/memos|{b.name}>"
            for b in businesses_without_memo
        ]
        message_blocks = [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"> Businesses without any memo since last Monday, {start_date.strftime('%Y-%m-%d')}:",
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "\n".join(messages),
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "*Action required: Add at least 1 memo before Monday.*",
                },
            },
        ]

    bot = SlackMessage()
    bot.add_list_of_blocks(message_blocks)
    bot.send_notification(channel=slack_channel)
    return None


if __name__ == "__main__":
    execute()
