import pandas as pd
from datetime import datetime, timedelta

from common import validate_inputs
from firestore import FirestoreClient
from businesses.business import Business
from open_ai.run_chat_completions import run_chat_completions
from http_function import http_function, process_request_inputs

from slack_tools.slack import SlackMessage
from slack_tools.convert_slack_markdown import convert_to_slack_markdown


_FS = FirestoreClient()


@http_function
def send_client_weekly_memo_via_slack(request_json={}, request_args={}):
    mandatory_fields = ["business_id", "env"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    # get the last monday and sunday
    last_monday = (
        datetime.now() - timedelta(days=datetime.now().weekday() + 7)
    ).replace(hour=0, minute=0, second=0, microsecond=0)
    last_sunday = last_monday + timedelta(days=6)

    process_single_business(data["business_id"], last_monday, last_sunday, data["env"])
    return "Success"


def process_single_business(business_id, start_date, end_date, env="dev"):
    business = Business(business_id)

    end_date_plus_one = (end_date + timedelta(days=1)).replace(
        hour=0, minute=0, second=0, microsecond=0
    )

    print(f"Processing memos for {business.name}, from {start_date} to {end_date}")

    memos = _FS.get_filtered_documents(
        "memos",
        [
            {
                "field_name": "business",
                "operator": "==",
                "value": business_id,
            },
            {
                "field_name": "is_internal",
                "operator": "==",
                "value": False,
            },
        ],
        "records",
    )

    # Filter memos that are within the week and summarize if necessary
    processed_memos = []
    for m in memos:
        memo_date = datetime.strptime(m["memo_date"], "%Y-%m-%dT%H:%M:%S.%fZ")
        # exclude memos that are not within the week
        if memo_date < start_date or memo_date > end_date_plus_one:
            continue

        # use summary if it exists
        if "summary" in m:
            processed_memos.append(m)
            continue

        # if "summary" doesnt exist in the doc:
        m["summary"] = _generate_and_save_summary(m["content"], m["id"])
        processed_memos.append(m)

    if len(processed_memos) == 0:
        print("No memos for the week")
        return None

    # CONSTRUCT SLACK MESSAGE
    slack_channel = (
        business.slack_channel_id if env.lower() == "prod" else "C02PYBMGLL9"
    )

    df = pd.DataFrame(processed_memos).sort_values("memo_date", ascending=False)
    df["memo_date"] = pd.to_datetime(df["memo_date"]).dt.strftime("%Y-%m-%d")

    change_blocks = []
    for dt, group in df.groupby("memo_date"):
        # create a list item for each memo
        bullets = []
        for _, row in group.iterrows():
            text_within_bullet = [
                {
                    "type": "text",
                    "text": convert_to_slack_markdown(row["summary"]).strip(),
                },
            ]
            if row.get("related_task_noloco_uuid", ""):
                text_within_bullet.append(
                    {
                        "type": "link",
                        "url": f"https://app.usekaya.com/tasks/{row['related_task_noloco_uuid']}?client={business_id}",
                        "text": " Related Task",
                    }
                )

            bullets.append(
                {
                    "type": "rich_text_section",
                    "elements": text_within_bullet,
                },
            )

        # show date
        change_blocks.append(
            {
                "type": "rich_text",
                "elements": [
                    {
                        "type": "rich_text_section",
                        "elements": [
                            {
                                "type": "text",
                                "text": f"{dt[:10]}:",
                                "style": {"bold": True},
                            }
                        ],
                    },
                    {"type": "rich_text_list", "style": "bullet", "elements": bullets},
                ],
            }
        )
        change_blocks.append(
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": " ",
                },
            },
        )

    action_blocks = [
        {"type": "divider"},
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"See more details in the app",
            },
            "accessory": {
                "type": "button",
                "text": {"type": "plain_text", "text": "Go to App"},
                "url": f"https://app.usekaya.com/memos?client={business_id}",
            },
        },
    ]

    bot = SlackMessage()
    bot.add_list_of_blocks(
        [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"Here are the changes made to *{business.name}*'s campaigns for the w/c *{start_date.strftime('%Y-%m-%d')}*\n",
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": " ",
                },
            },
        ]
        + change_blocks
        + action_blocks
    )
    bot.send_notification(channel=slack_channel)
    return None


def _generate_and_save_summary(content, memo_id):
    if len(content) > 100:
        messages = [
            {
                "role": "system",
                "content": "You are an executive at a marketing agency. In the next message, you'll be given a text that describes changes that have been done to an ad account. Your task is to summarise in maximum 3 sentences. Make sure your summary is grammatically correct and concise.",
            },
            {"role": "user", "content": "Here is the text:\n" + content},
        ]
        summary = run_chat_completions(messages)
    elif len(content) <= 100:
        summary = content

    _FS.update_document("memos", id=memo_id, content={"summary": summary})
    return summary


if __name__ == "__main__":
    env = "prod"
    # businesses_doc = _FS.get_filtered_documents(
    #     "businesses",
    #     [
    #         {
    #             "field_name": "status",
    #             "operator": "==",
    #             "value": "ACTIVE",
    #         },
    #     ],
    #     "records",
    # )
    # for b in businesses_doc:
    #     try:
    #         process_single_business(b["id"], env)
    #     except Exception as e:
    #         print(f"Error processing {b['name']}: {str(e)}")
    #         continue
    process_single_business("PTp2NpFQfJAKH6KRp2Ef", env)
