import requests
import datetime as dt

from http_function import http_function, process_request_inputs
from firestore import FirestoreClient
from businesses.get_business_by_slack_channel_id import (
    get_business_id_by_slack_channel_id,
)

_FS = FirestoreClient()


@http_function
def create_memo_from_slack(request_json={}, request_args={}):
    data = process_request_inputs(request_json, request_args)
    channel = data["channel"]["id"]
    business_id = get_business_id_by_slack_channel_id(channel)

    print(data["message_ts"])
    # convert message_ts to datetime
    memo_datetime = dt.datetime.fromtimestamp(float(data["message_ts"])).strftime(
        "%Y-%m-%dT%H:%M:%S.%fZ"
    )

    message = data["message"]["text"]

    # create task description
    slack_msg_url = f"https://usekaya.slack.com/archives/{channel}/p{data['message_ts'].replace('.', '')}"
    content = f"""
{message} 

[Link to Slack ->]({slack_msg_url})
"""

    memo_id = create_memo(
        content, business_id, memo_datetime, related_slack_url=slack_msg_url
    )

    public_msg_to_send = f"""
:lower_left_fountain_pen: A new memo has been created based on the message above:
> {message[:150]}


<https://app.usekaya.com/memos?client={business_id}|View all memos →>
"""
    _reply_to_slack_thread(public_msg_to_send, data)

    return memo_id


def _reply_to_slack_thread(msg, data):
    input = {
        "text": msg,
        "response_type": "in_channel",
        "replace_original": False,
    }
    if "message_ts" in data:
        input["thread_ts"] = data["message_ts"]

    request_reply_slack = requests.post(
        data["response_url"],
        json=input,
    )
    print(request_reply_slack.text)
    return None


def create_memo(content, business_id, memo_datetime, **kwargs):
    utc_now_dt = dt.datetime.now(dt.timezone.utc)

    memo_id = _FS.add_document(
        "memos",
        {
            "business": business_id,
            "content": content,
            "created_at": utc_now_dt,
            "created_by": "0GgKmc6CPLGKQUDSjnmv",
            "is_internal": False,
            "memo_date": memo_datetime,
            "related_task_noloco_uuid": "",
            **kwargs,
        },
    )
    print(f"Memo created with ID: {memo_id}")
    return memo_id


if __name__ == "__main__":
    data = {
        "channel": {"id": "C076PPE49V1"},
        "user": {"id": "U063V01L6GG"},
        "message": {"text": "hello"},
        "message_ts": "1634118799.000",
    }
    create_memo_from_slack(data)
