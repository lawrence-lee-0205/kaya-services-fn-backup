from http_function import http_function, process_request_inputs
from slack_tools.slack import SlackMessage
from google.cloud_functions.call_cloud_function import call_cloud_function


@http_function
def test_webhook(request_json={}, request_args={}):
    print(f"request_json:\n{request_json}")
    print(f"request_args:\n{request_args}")
    data = process_request_inputs(request_json, request_args)
    print(f"final data:\n{data}")

    bot = SlackMessage()
    bot.send_notification(text=f"data: {data}", channel="C02PYBMGLL9")
    return "Success"


@http_function
def test_webhook_2(request_json={}, request_args={}):
    print(f"request_json:\n{request_json}")
    print(f"request_args:\n{request_args}")
    data = process_request_inputs(request_json, request_args)
    print(f"final data:\n{data}")

    call_cloud_function("/test-webhook", {"test_key": "test_value"})
    return "Success"
