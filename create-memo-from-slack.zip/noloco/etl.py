import ast
import pandas as pd
from pathlib import Path

from utils.list import remove_duplicates
from common import validate_inputs
from utils.kaya_yaml import read_yaml
from noloco.request import call_noloco_api
from utils.string_ops import convert_to_snake_case
from databases.bigquery.upload_to_bq import upload_dataframe
from http_function import http_function, process_request_inputs

_DIR = Path(__file__).resolve().parent


@http_function
def etl_noloco(request_json={}, request_args={}):
    mandatory_fields = ["table"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    return etl_collection(data["table"])


def etl_collection(table_name):
    config_fp = _DIR / "etl.yaml"
    configs = read_yaml(config_fp)
    config = configs[table_name]

    if table_name == "tasks_and_task_owners":
        # task owners are nested in tasks, so we need to do a separate query
        _etl_task(config)
    else:
        collection = config["collection"]

        resp = call_noloco_api(config["query"])
        if "errors" in resp:
            raise Exception(f"Received error from Noloco: {resp['errors']}")

        edges = resp["data"][collection]["edges"]

        data = [_process_node(edge["node"]) for edge in edges]
        df = pd.DataFrame(data)

        # convert data format in df based on confg['data_format']
        df = _process_dataframe(df, config)
        upload_dataframe(df, table_name, "src_noloco", "replace")
    return None


def _etl_task(config):
    output = call_noloco_api(config["query"])

    task_nodes = output["data"]["taskCollection"]["edges"]
    tasks = [node["node"] for node in task_nodes]

    # We'll have 2 tasks table: 1 for tasks, 1 for task_owners
    tasks = []
    task_owners = []
    for node in task_nodes:
        task = node["node"]

        # copy data for selected fields and convert field name to snake case
        task_to_add = {
            convert_to_snake_case(key): value
            for key, value in task.items()
            if key not in ["owner", "company", "ownerThatsVisibleOnApp"]
        }
        task_to_add["business_id"] = (
            None if task.get("company") is None else task["company"]["fsId"]
        )
        tasks.append(task_to_add)

        # add task owners
        # task["owner"] =
        owner_visible_on_app_firestore_ids = (
            ast.literal_eval(task["ownerThatsVisibleOnApp"])
            if task["ownerThatsVisibleOnApp"] is not None
            else []
        )
        owner_noloco_native_firestore_ids = [
            owner["node"]["firestoreId"] for owner in task["owner"]["edges"]
        ]
        owners = remove_duplicates(
            owner_visible_on_app_firestore_ids + owner_noloco_native_firestore_ids
        )

        task_owners += [
            {
                "firestore_id": o,
                "task_uuid": task_to_add["uuid"],
                "task_id": task_to_add["id"],
            }
            for o in owners
        ]

    dataframes = {
        "tasks": pd.DataFrame(tasks),
        "task_owners": pd.DataFrame(task_owners),
    }

    for table, df in dataframes.items():
        if table == "tasks":
            df = _process_dataframe(df, config)
        upload_dataframe(df, table, "src_noloco", "replace")
    return None


def _process_node(node: dict):
    # unnest dict
    ori_node = node.copy()
    for key, value in ori_node.items():
        if isinstance(value, dict):
            for k, v in value.items():
                node[f"{key}_{k}"] = v

    # convert key to snake case
    node = {convert_to_snake_case(key): value for key, value in node.items()}
    return node


def _process_dataframe(df, config):
    for format, cols in config["data_format"].items():
        for col in cols:
            if format == "datetime":
                df[col] = pd.to_datetime(df[col])
            elif format == "date":
                df[col] = pd.to_datetime(df[col]).dt.date
            elif format == "float":
                df[col] = pd.to_numeric(df[col], downcast="float")
            elif format == "int":
                df[col] = pd.to_numeric(df[col], downcast="integer")
            elif format == "bool":
                df[col] = df[col].lower() == "true"
            elif format == "string":
                df[col] = str(df[col])
            else:
                raise Exception(f"Unknown data format: {format}")

    # rename cols
    if "rename" in config:
        df.rename(columns=config["rename"], inplace=True)
    return df


if __name__ == "__main__":
    etl_collection(table_name="fee_event")
    etl_collection(table_name="fee_structure")
    # etl_collection(table_name="company")
    etl_collection(table_name="fee_cost_structure")
    # etl_collection(table_name="tasks_and_task_owners")
    etl_collection(table_name="fee_adhoc_charge")
    etl_collection(table_name="plan")
