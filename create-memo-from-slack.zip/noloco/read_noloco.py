import re

from setup import setup
from common import validate_inputs
from noloco.request import call_noloco_api


@setup
def read_noloco(data: dict) -> dict:
    mandatory_fields = ["business_id", "collection", "where", "body", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    resp = _read_noloco(
        business_id=data["business_id"],
        collection=data["collection"],
        where=data["where"],
        body=data["body"],
    )
    return resp


def _read_noloco(business_id, collection, where, body):
    # check if business ID is used as a filter
    biz_id_filter = f'fsId:\s?{{equals:\s?"{business_id}"}}'

    regexp = re.compile(biz_id_filter)
    if not regexp.search(where):
        raise Exception("Business ID must be provided as a filter")

    # make sure 'where' keyword exists
    if "where" not in where:
        raise Exception("the word `where` must be provided in param `where`")

    # format query
    query = f"""
    query get{collection} {{
        {collection}({where}) {{
            {body}
        }}
    }}
    """
    print(query)
    resp = call_noloco_api(query)
    return resp


if __name__ == "__main__":
    # out = execute(body=query)
    # print(out)

    business_id = "lyu6tWbXJlYQmfzi6uGg"
    where = 'where: {fsId: {equals: "lyu6tWbXJlYQmfzi6uGg"}}'
    collection = "companyCollection"
    body = """
    edges {
      node {
        id
        name
        tasksCollection(where: {isInternal: {equals: false}}) {
          edges {
            node {
              id
              name
              owner {
                edges {
                  node {
                    firstName
                    lastName
                    company {
                      name
                    }
                    id
                  }
                }
              }
            }
          }
        }
      }
    }
    """
    resp = _read_noloco(business_id, collection=collection, where=where, body=body)
    print(resp)
