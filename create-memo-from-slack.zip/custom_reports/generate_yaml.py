from jinja2 import Environment, FileSystemLoader
import os

from setup import setup
from common import validate_inputs
from google.gutils.bigquery import run_query
from databases.airtable.airtable import Airtable

_DASHBOARD_TABLE = "dashboard"
_BASE_ID = "appJ2tNNGtM0O70OS"


def filter_list_of_id(ids):
    formula_lst = [f"RECORD_ID()='{id}'" for id in ids]
    formula = ",".join(formula_lst)
    formula = "Or(" + formula + ")"
    return formula


def get_filters(filter_inputs, business_id):
    filter_table = Airtable("filter", base_id=_BASE_ID)
    filter_formula = filter_list_of_id(filter_inputs)
    filters_lst = filter_table.get_all_rows(formula=filter_formula)
    print(filters_lst)

    filters = {}
    for f in filters_lst:
        filter_var = f["name"]
        if f["type"] == "dropdown_dynamic":
            sql = f["sql"].format(business_id=business_id)
            results = run_query(sql)
            f["options"] = [res["value"] for res in results]
            f["default_value"] = f["options"][0]
            f["type"] = "dropdown"

        filters[filter_var] = {
            col: f[col]
            for col in ["display_name", "type", "default_value", "options"]
            if col in f
        }

    # print(filters)
    return filters


def get_config_from_airtable(dashboard_id):
    file_loader = FileSystemLoader(".")
    env = Environment(loader=file_loader)
    template = env.get_template("config_template.yml")

    formula = "{id}='" + dashboard_id + "'"
    dashboard_table = Airtable(_DASHBOARD_TABLE, base_id=_BASE_ID)

    dashboard_config = dashboard_table.get_all_rows(formula=formula)[0]
    print(dashboard_config)
    print("^^^^^")

    for biz_id in dashboard_config["business_ids"]:
        ############################
        #     PROCESS FILTERS      #
        ############################
        filters = get_filters(dashboard_config["filters"], biz_id)

        ###########################
        #     PROCESS BLOCKS      #
        ###########################
        block_table = Airtable("block", base_id=_BASE_ID)
        block_formula = filter_list_of_id(dashboard_config["block"])
        print(block_formula)
        blocks_lst = block_table.get_all_rows(formula=block_formula)

        blocks = []
        for b_dict in blocks_lst:
            block = {
                "type": b_dict["type"],
                "setting": {
                    key: value for key, value in b_dict.items() if key != "type"
                },
            }
            blocks.append(block)
        print(blocks)

        cols_to_copy = ["id", "loading_screen_ms", "hidden_load_delay_ms"]
        fields_copy = {col: dashboard_config[col] for col in cols_to_copy}

        processed = {
            "id": dashboard_config["id"],
            "business_id": biz_id,
            "filters": filters,
            "blocks": blocks,
            **fields_copy,
        }

        # render shell script to deploy
        output = template.render(**processed)

        # to save the results
        output_fp = f"{biz_id}_generated_dashboard.yml"

        with open(output_fp, "w") as fh:
            fh.write(output)

    return None


if __name__ == "__main__":
    get_config_from_airtable("tiktok-ads-compare")
