from firestore import FirestoreClient

_FS = FirestoreClient()

if __name__ == "__main__":
    """
    Param example:
    {
        "name": "business_id",
        "is_required": True,
        "format": "%Y-%m-%d",
    },
    """
    # TODO: UPDATE MB DASHBOARD ID WITH THE NEW DASHBOARD YOU WANT TO ADD
    mb_dashboard_id = 1949
    # TODO: ADD PARAMS ACCORDING TO THE FILTERS THAT EXIST ON THE MB DASHBOARD
    content = {
        "description": "This is a test dashboard",
        "params": [
            {
                "name": "business_id",
                "is_required": True,
            },
            {
                "name": "start_date",
                "is_required": True,
                "format": "%Y-%m-%d",
            },
            {
                "name": "end_date",
                "is_required": True,
                "format": "%Y-%m-%d",
            },
            {
                "name": "aggregate_by",
                "is_required": True,
            },
        ],
    }
    _FS.add_document("metabase_dashboards", content, str(mb_dashboard_id))


# This script migrates the dashboard config from local file to Firestore
# if __name__ == "__main__":
#     from utils.kaya_yaml import read_yaml
#     mb_dash_config = read_yaml(
#         "/Users/jeeyenpersonal/Documents/kaya-services/services/custom_reports/metabase_configs/metabase.yml"
#     )
#     mb_dash_dct = mb_dash_config["dashboards"]

#     for mb_id, content in mb_dash_dct.items():
#         _FS.add_document("metabase_dashboards", content, str(mb_id))
