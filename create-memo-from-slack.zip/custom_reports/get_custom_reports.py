from setup import setup
from common import validate_inputs
from collections import defaultdict

from firestore import FirestoreClient

_FS = FirestoreClient()
_MANDATORY_FIELDS = [
    "dashboard_id",
    "title",
    "image_url",
    "data_sources",
    "metrics",
    "description",
    "long_description",
    "type",
]


@setup
def get_custom_reports(data: dict) -> dict:
    mandatory_fields = ["business_id", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    business_id = data["business_id"]
    reports_list = execute(business_id)

    return {"reports": reports_list}


def execute(business_id):
    reports = _FS.get_filtered_documents(
        "custom_reports",
        [
            {"field_name": "business_id", "operator": "==", "value": business_id},
            {"field_name": "is_live", "operator": "==", "value": True},
        ],
        orders=[
            {"field_name": "category", "is_ascending": True},
            {"field_name": "title", "is_ascending": True},
        ],
        output_fmt="records",
    )

    grouped = defaultdict(list)
    for r in reports:
        processed = {k: v for k, v in r.items() if k in _MANDATORY_FIELDS}

        processed.setdefault("data_sources", [])
        processed.setdefault("metrics", [])
        grouped[r["category"]].append(processed)

    reports_list = [{"category": cat, "files": files} for cat, files in grouped.items()]
    return reports_list


if __name__ == "__main__":
    # data = {"business_id": "H7LfqWsJcmC4sBXtXws0", "auth_user_id": "test"}
    # data = {"business_id": "lyu6tWbXJlYQmfzi6uGg", "auth_user_id": "test"}
    # main(data)
    print("\n********\n")

    reports = execute("G28ayyMdb3NpFTpmnDDx")
    print({"reports": reports})

    print()
    # print()
