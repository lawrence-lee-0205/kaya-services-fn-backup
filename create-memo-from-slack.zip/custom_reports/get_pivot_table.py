import os

from setup import setup
from common import validate_inputs
from utils.kaya_yaml import read_yaml
from google.gutils.bigquery import run_query

if "LOCAL" in os.environ["ENV"].upper():
    _CONFIG_DIR = "./pivot_configs"
else:
    _CONFIG_DIR = "custom_reports/pivot_configs"


@setup
def get_pivot_table(data: dict) -> dict:
    mandatory_fields = ["auth_user_id", "table_id", "business_id"]
    validate_inputs(data, mandatory_fields)

    filter_provided = {}
    for f_dict in data.get("filters", []):
        for key, value in f_dict.items():
            filter_provided[key] = value

    out = execute(data["table_id"], data["business_id"], **filter_provided)

    return out


def execute(table_id, business_id, **filters):
    config_all = read_yaml(_CONFIG_DIR + "/pivot.yml")
    config = config_all["tables"][table_id]

    # TODO: CHECK IF INPUT REQUIRED FOR SQL IS IN FILTER
    sql = config["sql"].format(business_id=business_id, **filters)
    data = run_query(sql)
    print(len(data))

    out = {
        "data": data,
        "rows": config.get("rows", []),
        "columns": config.get("columns", []),
        "values": config["values"],
        "format_settings": config.get("format_settings", []),
        "calculated_field_settings": config.get("calculated_field_settings", []),
    }
    return out


if __name__ == "__main__":
    data = {
        "table_id": "revenue-by-channel-source-medium",
        "business_id": "q7RQxPR7p0U8P6uKm8Do",
        "filters": {
            "start_date": "2022-07-01",
            "end_date": "2022-08-01",
            "aggregate_by": "daily",
        },
    }
    out = execute(
        table_id=data["table_id"], business_id=data["business_id"], **data["filters"]
    )
    print(out)
