from os import environ, path
from uuid import uuid4
from abc import ABC, abstractmethod

from utils.kaya_yaml import read_yaml
from enums.block import DashboardBlockType

from metabase.get_signed_url import get_url
from custom_reports.eval_str_as_func import eval_str_as_func
from firestore import FirestoreClient

if "LOCAL" in environ["ENV"].upper():
    _CURRENT_FILEPATH = path.realpath(__file__)
    _CONFIG_DIR = path.dirname(_CURRENT_FILEPATH) + "/"
else:
    _CONFIG_DIR = "custom_reports/"

_GSHEET_CONFIG = read_yaml(_CONFIG_DIR + "gsheet_configs/gsheet.yml")
_FS = FirestoreClient()


class Block(ABC):
    def __init__(self) -> None:
        self.dashboard_filters = {}
        self.extra_params = {}
        self.conditions = None
        self.caption = ""
        self.title = ""
        self.block_id = "b" + str(uuid4())

    def _process_extra_param(self, payload):
        if payload["type"] == "calculated":
            return eval_str_as_func(
                payload["value"], self.business_id, **self.dashboard_filters
            )
        elif payload["type"] == "static":
            return payload["value"]
        else:
            raise Exception(f"Type '{payload['type']}' is not acceptable")

    @property
    def processed_extra_params(self):
        return {
            name: self._process_extra_param(payload)
            for name, payload in self.extra_params.items()
        }

    @property
    def all_params(self):
        # combine values from dashboard filters and extra params passed to the block
        # if same key exists in both dicts, overwrite value with those passed in extra_params
        return {**self.dashboard_filters, **self.processed_extra_params}

    @property
    def caption_formatted(self):
        return self.caption.format(**self.all_params)

    @property
    def title_formatted(self):
        return self.title.format(**self.all_params)

    @abstractmethod
    def create(self):
        pass

    def _check_conditions(self, **kwargs):
        """Loop through each condition provided. If any condition evaluate to False, raise Error

        Raises:
            ValueError: _description_

        Returns:
            _type_: _description_
        """
        if self.conditions is not None:
            for condition in self.conditions:
                if not eval(
                    condition,
                    {"business_id": self.business_id, **self.all_params, **kwargs},
                ):
                    raise ValueError("Condition is not satisfied")
        return None


class TextBlock(Block):
    def __init__(self, business_id: str, filter_: dict = {}, **kwargs) -> None:
        super().__init__()
        self.content = kwargs.get("content", "")
        self.conditions = kwargs.get("conditions")
        self.dashboard_filters = filter_

        self.is_default_collapsed = None
        self.include_in_toc = kwargs.get("include_in_toc", False)
        self.type = DashboardBlockType.TEXT.name.lower()
        self.business_id = business_id
        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    # @profile
    def create(self):
        try:
            self._check_conditions()
        except ValueError:
            return None

        content = self.content.format(**self.all_params)

        output = {
            "content": content,
            "type": self.type,
            "title": self.title_formatted,
            "caption": self.caption_formatted,
            "include_in_toc": self.include_in_toc,
            "block_id": self.block_id,
        }

        if self.is_default_collapsed is not None:
            output["is_default_collapsed"] = self.is_default_collapsed
        return output


class TitleBlock(Block):
    def __init__(self, business_id: str, filter_: dict = {}, **kwargs) -> None:
        super().__init__()
        self.title = kwargs["title"]
        self.caption = kwargs.get("caption", "")
        self.business_id = business_id
        self.dashboard_filters = filter_

        self.type = DashboardBlockType.TITLE.name.lower()
        self.include_in_toc = kwargs.get("include_in_toc", False)
        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    # @profile
    def create(self):
        try:
            self._check_conditions()
        except ValueError:
            return None

        output = {
            "title": self.title_formatted,
            "caption": self.caption_formatted,
            "type": self.type,
            "include_in_toc": self.include_in_toc,
        }
        return output


class MetabaseBlock(Block):
    def __init__(self, business_id: str, filter_: dict = {}, **kwargs) -> None:
        """_summary_

        Args:
            business_id (str): _description_
            filter_ (dict, optional): include dashboard filter and hidden filters. eg {'as_of_date': '2022-08-14'}
        """
        super().__init__()
        self.dashboard_id = kwargs["dashboard_id"]
        self.title = kwargs.get("title", "")
        self.caption = kwargs.get("caption", "")
        self.is_default_collapsed = kwargs.get("is_default_collapsed", False)
        self.conditions = kwargs.get("conditions")
        self.mb_filters = self._get_mb_dashboard_params(kwargs["dashboard_id"])

        self.dashboard_filters = filter_

        self.business_id = business_id
        self.include_in_toc = kwargs.get("include_in_toc", False)

        self.show_metabase_title = False
        self.type = DashboardBlockType.METABASE.name.lower()
        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    @staticmethod
    def _get_mb_dashboard_params(dashboard_id: int) -> dict:
        """Get metabase dashboard params from config file

        Args:
            dashboard_id (int): MB dashboard ID

        Returns:
            dict: config for a particular MB dashboard
        """
        dashboard_config = _FS.get_single_document(
            "metabase_dashboards", str(dashboard_id)
        )
        return dashboard_config.get("params", [])

    def _get_param(self, metric_name):
        if metric_name == "business_id":
            return self.business_id

        try:
            return self.all_params[metric_name]
        except KeyError:
            raise Exception(
                f"{metric_name} is required for the dashboard but is not provided when calling the API"
            )

    def _prepare_params_for_metabase(self):
        return {
            mb_filter["name"]: self._get_param(mb_filter["name"])
            for mb_filter in self.mb_filters
        }

    def create(self):
        mb_params = self._prepare_params_for_metabase()
        try:
            self._check_conditions(**mb_params)
        except ValueError:
            return None

        output = {
            "type": self.type,
            "title": self.title_formatted,
            "is_default_collapsed": self.is_default_collapsed,
            "dashboard_id": self.dashboard_id,
            "caption": self.caption_formatted,
            "url": get_url(
                dashboard_id=self.dashboard_id,
                show_metabase_title=self.show_metabase_title,
                **mb_params,
            ),
            "show_metabase_title": self.show_metabase_title,
            "metabase_params": mb_params,
            "include_in_toc": self.include_in_toc,
            "block_id": self.block_id,
        }
        return output


class PivotTableBlock(Block):
    def __init__(self, **kwargs) -> None:
        super().__init__()
        self.table_id = kwargs["table_id"]
        self.title = kwargs.get("title", "")
        self.caption = kwargs.get("caption", "")
        self.type = DashboardBlockType.PIVOT_TABLE.name.lower()
        self.include_in_toc = kwargs.get("include_in_toc", False)

        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    def create(self):
        output = {
            "table_id": self.table_id,
            "type": self.type,
            "title": self.title_formatted,
            "caption": self.caption_formatted,
            "include_in_toc": self.include_in_toc,
        }
        return output


class IframeBlock(Block):
    def __init__(self, business_id: str, filter_: dict = {}, **kwargs) -> None:
        super().__init__()
        self.title = kwargs.get("title", "")
        self.caption = kwargs.get("caption", "")
        self.gsheet_id = kwargs["gsheet_id"]
        self.business_id = business_id
        self.dashboard_filters = filter_

        self.type = DashboardBlockType.IFRAME.name.lower()
        self.include_in_toc = kwargs.get("include_in_toc", False)
        self.is_default_collapsed = kwargs.get("is_default_collapsed", False)

        self.__dict__.update(kwargs)  # kwargs will overwrite properties above

    def _get_url(self):
        url_by_biz_id_map = _GSHEET_CONFIG["links"][self.gsheet_id]
        url = url_by_biz_id_map.get(self.business_id, None)
        return url

    def create(self):
        url = self._get_url()

        if url is None:
            return None

        # add additional info to caption
        ori_caption = self.caption_formatted
        if "[md]" not in ori_caption:
            ori_caption = "[md]" + ori_caption
        caption = (
            ori_caption
            + f"<br />ℹ️ The gsheet below may not render properly on smaller screens. For better experience, please click [here]({url}) to view and edit the content on another tab..</p>"
        )

        output = {
            "src": url,
            "type": self.type,
            "title": self.title_formatted,
            "caption": caption,
            "include_in_toc": self.include_in_toc,
            "is_default_collapsed": self.is_default_collapsed,
        }
        return output


if __name__ == "__main__":
    d1 = {"test": 1, "hi": 2}
    d2 = {"test": 10}
    print({**d1, **d2})
