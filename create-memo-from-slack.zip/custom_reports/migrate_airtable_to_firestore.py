import os
from databases.airtable.airtable import Airtable
from firestore import FirestoreClient

_FS = FirestoreClient()

_BASE_ID = (
    "appJ2tNNGtM0O70OS" if "PROD" not in os.environ["ENV"] else "applq0qqCgkEYaxzQ"
)
_CUSTOM_REPORTS_TABLE = "business_dashboard"

if __name__ == "__main__":
    custom_report_table = Airtable(_CUSTOM_REPORTS_TABLE, base_id=_BASE_ID)

    # query airtable
    all_rows = custom_report_table.get_all_rows(sort=["category", "title"])

    failed = []

    for i, row in enumerate(all_rows):
        if row["id"] == "_":
            continue

        print(i)
        try:
            d = {
                "title": row["title"],
                "description": row["description"][0],
                "long_description": row["long_description"][0],
                "type": row["type"][0],
                "dashboard_id": row["dashboard_id"][0],
                "data_sources": row["data_sources"],
                "metrics": row.get("metrics", []),
                "is_live": row.get("is_live", False),
                "business_id": row["business_id"],
                "category": row["category"],
                "image_url": row["image_url"][0],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            }
            _FS.add_document(
                "custom_reports", d, f"{d['business_id']}_{d['dashboard_id']}"
            )
        except Exception as e:
            print(e)
            print(row)
            print("\n\n")
            failed.append(row)

    print(failed)

    # print(all_rows)
