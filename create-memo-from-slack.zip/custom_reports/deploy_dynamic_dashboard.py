import os

from schema import Schema, Optional, And

from utils.jinja import render_template
from utils.kaya_yaml import read_yaml, validate_yaml
from enums.block import DashboardBlockType
from firestore import FirestoreClient

CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))
PIVOT_YML_FP = CURRENT_DIR + "/pivot_configs/pivot.yml"
DASHBOARD_YML_FOLDER = CURRENT_DIR + "/../dashboard_configs/"

VALID_FILTER_TYPES = ["date", "dropdown", "dropdown_bq"]
VALID_HIDDEN_FILTER_TYPES = ["static", "calculated"]

_FS = FirestoreClient()


def get_schema():
    # get list of valid block types
    valid_blocks = [b.name.lower() for b in DashboardBlockType]

    # get list of valid metabase dashboard id
    valid_mb_dashboard_ids = _FS.get_all_document_ids("metabase_dashboards")

    # get list of valid pivot table id
    pivot_config = read_yaml(PIVOT_YML_FP)
    valid_pivot_ids = pivot_config["tables"].keys()

    schema = Schema(
        {
            "business_ids": [str],
            "loading_screen_ms": int,
            "hidden_load_delay_ms": int,
            "title": str,
            "description": str,
            Optional("filters"): {
                object: {
                    "display_name": str,
                    "type": And(str, lambda s: s in VALID_FILTER_TYPES),
                    "default_value": str,
                    Optional("options"): [str],
                    Optional("sql"): str,
                }
            },
            Optional("filters_hidden"): {
                object: {
                    "value": str,
                    "type": And(str, lambda s: s in VALID_HIDDEN_FILTER_TYPES),
                }
            },
            "blocks": [
                {
                    "type": And(str, lambda s: s in valid_blocks),
                    Optional("title"): str,
                    Optional("caption"): str,
                    Optional("dashboard_id"): And(
                        int,
                        lambda s: str(s) in valid_mb_dashboard_ids,
                        error="dashboard_id must be int and exist in metabase config",
                    ),
                    Optional("is_default_collapsed"): bool,
                    Optional("include_in_toc"): bool,
                    Optional("content"): str,
                    Optional("src"): str,
                    Optional("block_id"): str,
                    Optional("table_id"): And(
                        str,
                        lambda s: s in valid_pivot_ids,
                        error="table_id must be str and exist in pivot table config",
                    ),
                    Optional("conditions"): [str],
                    Optional("gsheet_id"): str,
                    Optional("extra_params"): {
                        object: {
                            "value": str,
                            "type": And(str, lambda s: s in VALID_HIDDEN_FILTER_TYPES),
                        }
                    },
                }
            ],
        }
    )
    return schema


def deploy_yaml_to_storage(dashboard_id):
    print("Processing ", dashboard_id)
    # construct yml filepath
    yml_src_filename = dashboard_id + ".yml"

    if "__template" in dashboard_id:
        output_file = render_template(DASHBOARD_YML_FOLDER, yml_src_filename)
        yml_out_filename = yml_src_filename.replace("__template", "")
        yml_out_fullpath = DASHBOARD_YML_FOLDER + yml_out_filename

        with open(yml_out_fullpath, "w") as f:
            f.write(output_file)
    else:
        yml_out_filename = yml_src_filename

    yml_out_fullpath = DASHBOARD_YML_FOLDER + yml_out_filename

    # validate yml schema
    schema = get_schema()
    validate_yaml(schema, yml_out_fullpath)

    # upload config content to firestore
    config = read_yaml(yml_out_fullpath)
    _FS.upsert_document("dynamic_dashboards", dashboard_id, config)
    return None


if __name__ == "__main__":
    ids = [
        # "test-dynamic-1",
        # "google-ads",
        # "google-ads-overview",
        # "google-ads-campaigns"
        # "google-ads-rippling",
        # "google-ads-keywords",
        # "linkedin-ads",
        # "linkedin-ads-country",
        # "linkedin-ads-jobfunction",
        # "linkedin-ads-industry",
        # "linkedin-ads-seniority",
        # "facebook-ads",
        # "tiktok-ads-mes",
        # "tiktok-ads",
        # "tiktok-ads-compare",
        # "tiktok-ads-compare-mes",
        # "month-to-date-cost-per-lead-mes",
        # "storefront-content",
        # "storefront-roas",
        # "storefront-cost-per-lead",
        # "google-search-console",
        # "single-page-analytics",
        # "single-page-analytics-bristle",
        # "single-page-analytics-numero",
        # "overview-roas",
        # "overview-cost-per-lead",
        # "metric-revenue",
        # "metric-cost",
        # "metric-leads",
        # "company-kpi-roas",
        # "company-kpi-yara",
        # "metric-acquisitions",
        # "overview-cost-per-acquisition",
        # "numero-deal-dashboard",
        # "month-end-report-liveflow",
        # "month-end-report-safely-finance",
        # "month-end-report-uol",
        # "month-end-report-fella",
        # "month-end-report-numero",
        # "month-to-date-cost-per-lead-fella",
        # "company-kpi-mes",
        # "month-end-report-mes"
        # "month-end-report-bristle",
        # "month-to-date-roas",
        # "month-to-date-paid-ads-roas",
        # "month-to-date-cost-per-acq",
        # "month-to-date-cost-per-lead",
        # "month-to-date-roas-main",
        # "month-to-date-roas-bristle",
        # "data-source-bristle",
        # "funnel-analysis-numero",
        # "funnel-analysis-bristle",
        # "funnel-comparison-bristle",
        # "funnel-analysis-liveflow",
        # "snapchat-ads",
        "fella-single-user",
        "fella-sales",
        "fella-cohort",
        # "subscription-cohort-analysis-wyndly",
        # "testyml",
        # "single-page-analytics-encord",
        # "cohort-analysis-mes",
        # "encord",
        # "company-kpi-rippling",
    ]
    for dashboard_id in ids:
        deploy_yaml_to_storage(dashboard_id)
