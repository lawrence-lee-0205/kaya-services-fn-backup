import datetime as dt


def calculate_date(date, calculation):
    if calculation == "Week to Date":
        return (dt.datetime.strptime(date, "%Y-%m-%d") - dt.timedelta(days=6)).strftime(
            "%Y-%m-%d"
        )
    elif calculation == "Year to Date":
        return str(date)[:-5] + "01-01"
    elif calculation == "Month to Date":
        return str(date)[:-2] + "01"
    raise Exception("Calculation {calculation} is not implemented")


def eval_str_as_func(string, business_id, **kwargs):
    return eval(
        string,
        {
            "business_id": business_id,
            "dt": dt,
            "calculate_date": calculate_date,
            **kwargs,
        },
    )
