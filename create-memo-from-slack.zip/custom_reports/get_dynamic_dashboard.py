from os import environ
from typing import List

# from utils.profiling import profile
# import time
from setup import setup
from common import validate_inputs
from firestore import FirestoreClient
from metabase.get_signed_url import get_url
from google.gutils.bigquery import run_query
from custom_reports.get_block import get_block
from custom_reports.constants import DEFAULT_MAPPING
from custom_reports.eval_str_as_func import eval_str_as_func


_FS = FirestoreClient()


@setup
def get_dynamic_dashboard(data: dict) -> dict:
    mandatory_fields = ["business_id", "dashboard_id", "auth_user_id"]
    validate_inputs(data, mandatory_fields)

    resp = execute(
        business_id=data["business_id"],
        dashboard_type=data.get("type", "metabase"),
        dashboard_id=data["dashboard_id"],
        filters=data.get("filters", []),
    )
    return resp


def execute(
    business_id: str, dashboard_type: str, dashboard_id: str, filters: List = []
) -> dict:
    if dashboard_type == "metabase":
        resp = _process_static(dashboard_id, business_id)
    elif dashboard_type == "dynamic":
        resp = _process_dynamic(
            business_id=business_id,
            dashboard_id=dashboard_id,
            filters_input=filters,
        )
    else:
        raise ValueError(
            f"Invalid value for param 'type'. Only accept type 'metabase' or 'dynamic'. Received '{dashboard_type}.'"
        )
    return resp


def _process_static(dashboard_id, business_id):
    # TODO: REMOVE THIS
    if business_id == "lyu6tWbXJlYQmfzi6uGg":
        business_id = "NtV6Ynivm40Ip4h2LmaO"

    output = {
        "blocks": [
            {
                "url": get_url(
                    dashboard_id=dashboard_id,
                    show_metabase_title=True,
                    business_id=business_id,
                ),
                "dashboard_id": dashboard_id,
                "type": "metabase",
                "show_metabase_title": True,
                "metabase_params": {"business_id": business_id},
            }
        ],
        "filters": [],
    }
    return output


def _process_dynamic(
    business_id: str, dashboard_id: str, filters_input: List[dict] = []
):
    """

    How filters and params should work:
    - Hidden dashboard filters will be able to access non-hidden filters. They will be calculated first and passed into each block.
    - Extra params in 'block' will have access to variables that are dashboard filter and hidden filters


    Args:
        business_id (str): _description_
        dashboard_id (str): _description_
        filters_input (List[dict], optional): _description_. Defaults to [].

    Raises:
        Exception: _description_

    Returns:
        _type_: _description_
    """
    config = _FS.get_single_document("dynamic_dashboards", dashboard_id)

    if business_id not in config["business_ids"]:
        raise Exception(
            f"Dashboard {dashboard_id} is not enabled for business {business_id}"
        )

    # TODO: REMOVE THIS
    if environ["ENV"].upper() == "DEV":
        business_id = "NtV6Ynivm40Ip4h2LmaO"

    ##########################
    #     PROCESS FILTER     #
    ##########################

    raise_alert = ""
    # unpack filter provided by API
    filter_provided = {
        key: value for f_dict in filters_input for key, value in f_dict.items()
    }

    filters_to_display_dict = config.get("filters", {})
    for metric_name, setting in filters_to_display_dict.items():
        # if default value is a str representation, replace with actual value
        ori_value = setting["default_value"]
        if ori_value in DEFAULT_MAPPING.keys():
            setting["default_value"] = DEFAULT_MAPPING[ori_value]

        # populate 'selected' key with values provided by API
        setting["selected"] = (
            filter_provided[metric_name]
            if metric_name in filter_provided
            else setting["default_value"]
        )

        # query BQ for options for dropdown
        if setting["type"] == "dropdown_bq":
            sql = setting["sql"].format(business_id=business_id)
            res_list = run_query(sql)
            setting["options"] = [res["option"] for res in res_list]
            setting["type"] = "dropdown"

        # if input provided is not acceptable value for drop down, replace with default
        if (setting["type"] == "dropdown") and (
            setting["selected"] not in setting["options"]
        ):
            setting["selected"] = setting["default_value"]

            options = [str(x) for x in setting["options"]]
            raise_alert += f"{metric_name} provided is invalid. Acceptable values are {', '.join(options)}. We've automatically replace its value to default value.\n"

    # CHECK DATE FORMAT, for eg "YYYY-MM" should revert to using default param
    # VALIDATE FILTER VALUE
    if ("start_date" in filters_to_display_dict) and (
        "end_date" in filters_to_display_dict
    ):
        start_date = filters_to_display_dict["start_date"]["selected"]
        end_date = filters_to_display_dict["end_date"]["selected"]

        if start_date > end_date:
            # swap values
            filters_to_display_dict["start_date"]["selected"] = end_date
            filters_to_display_dict["end_date"]["selected"] = start_date
            raise_alert += "Start date provided is after end date. We've automatically swapped their values.\n"

    # get selected values from filters to display
    selected_filter_values = {
        k: v["selected"] for k, v in filters_to_display_dict.items()
    }

    # PROCESS HIDDEN FILTERS
    hidden_filters = {}
    if "filters_hidden" in config:
        hidden_filters_input = config["filters_hidden"]

        for filter_name, setting in hidden_filters_input.items():
            if setting["type"] == "calculated":
                value = eval_str_as_func(
                    setting["value"], business_id, **selected_filter_values
                )
            else:
                value = setting["value"]
            hidden_filters[filter_name] = value

    # combine filters provided in the API and hidden filters
    all_filters = {**hidden_filters, **selected_filter_values}

    # PROCESS BLOCK
    outputs = [
        _process_single_block(block_setting, business_id, all_filters)
        for block_setting in config["blocks"]
    ]
    outputs = list(filter(lambda item: item is not None, outputs))

    # filters to return as API response, so FE can display it
    filters_to_display_output = [
        {"metric_name": key, **value} for key, value in filters_to_display_dict.items()
    ]
    resp = {
        "blocks": outputs,
        "filters": filters_to_display_output,
        "loading_screen_ms": config.get("loading_screen_ms", 2600),
        "hidden_load_delay_ms": config.get("loading_screen_ms", 3000),
        "title": config.get("title", "Dashboard").format(**all_filters),
        "description": config.get("description", "").format(**all_filters),
    }
    if len(raise_alert) > 0:
        resp["raise_alert"] = raise_alert
    return resp


def _process_single_block(block_setting, business_id, all_filters):
    type_ = block_setting["type"].upper()

    block_obj = get_block(type_)
    block_obj = block_obj(
        business_id=business_id,
        filter_=all_filters,
        **block_setting,
    )
    block = block_obj.create()
    return block


if __name__ == "__main__":
    # dashboard_id = "month-to-date-roas-bristle"
    dashboard_id = "google-ads-keywords"
    data = {
        "business_id": "82cutQRlx6gagQFMKjPa",
        "dashboard_id": dashboard_id,
        "dashboard_type": "dynamic",
        "filters": [
            # {"as_of_date": "2022-08-14"},
            # {"days_to_show": "30"},
            # {"aggregate_by": "daily"},
        ],
    }
    # data["dashboard_type"] = data["type"]
    # del data["type"]
    out = execute(**data)
    print(out)
