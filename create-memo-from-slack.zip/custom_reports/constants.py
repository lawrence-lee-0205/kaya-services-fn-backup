import os
import datetime

from dateutil.relativedelta import relativedelta

# TODO: USE constants from root dir
TODAY = datetime.date.today()
DEFAULT_MAPPING = {
    "start_of_last_month": (TODAY - relativedelta(months=1, day=1)).strftime(
        "%Y-%m-%d"
    ),
    "start_of_three_months_ago": (TODAY - relativedelta(months=3, day=1)).strftime(
        "%Y-%m-%d"
    ),
    "today": TODAY.strftime("%Y-%m-%d"),
    "7d_ago": (TODAY - relativedelta(days=7)).strftime("%Y-%m-%d"),
    "8d_ago": (TODAY - relativedelta(days=8)).strftime("%Y-%m-%d"),
    "30d_ago": (TODAY - relativedelta(days=30)).strftime("%Y-%m-%d"),
    "yesterday": (TODAY - relativedelta(days=1)).strftime("%Y-%m-%d"),
    "this_month_start": TODAY.replace(day=1).strftime("%Y-%m-%d"),
    "start_of_twelve_months_ago": (TODAY - relativedelta(months=12, day=1)).strftime(
        "%Y-%m-%d"
    ),
    "this_year_first_monday": datetime.date.fromisocalendar(TODAY.year, 1, 1).strftime(
        "%Y-%m-%d"
    ),
}


CLOUD_STORAGE_BUCKET = (
    "kaya-dynamic-dashboard-prod"
    if os.environ["ENV"].upper() in ("PROD", "LOCAL_PROD")
    else "kaya-dynamic-dashboard-dev"
)

if __name__ == "__main__":
    print(type(datetime.date.fromisocalendar(TODAY.year, 1, 1)))
