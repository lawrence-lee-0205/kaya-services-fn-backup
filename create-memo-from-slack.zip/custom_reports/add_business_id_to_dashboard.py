import os
import yaml

from utils.kaya_yaml import read_yaml


_CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))
_DASHBOARD_YML_FOLDER = _CURRENT_DIR + "/../dashboard_configs/"


def add_business_id_to_dashboard(dashboard_id, business_id):
    file_path = _DASHBOARD_YML_FOLDER + dashboard_id + ".yml"
    original_content = read_yaml(file_path)

    if business_id in original_content["business_ids"]:
        print(f"Business ID `{business_id}` already exists in `{file_path}`.")
        return None

    original_content["business_ids"].append(business_id)
    print(f"Rewriting `{file_path}`...")
    with open(file_path, "w") as file:
        yaml.dump(original_content, file, sort_keys=False, default_flow_style=False)
    return None


if __name__ == "__main__":
    # read yaml file, add business_id to business_ids list and rewrite yaml file
    dashboard_id = "google-ads-overview"
    business_id = "05YbIXRfIYlPGCsKW5qe"
    add_business_id_to_dashboard(dashboard_id, business_id)
