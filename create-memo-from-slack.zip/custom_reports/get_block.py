from custom_reports.block import (
    TextBlock,
    MetabaseBlock,
    PivotTableBlock,
    TitleBlock,
    IframeBlock,
)
from enums.block import DashboardBlockType

_BLOCK_MAPPING = {
    DashboardBlockType.TEXT: TextBlock,
    DashboardBlockType.METABASE: MetabaseBlock,
    DashboardBlockType.PIVOT_TABLE: PivotTableBlock,
    DashboardBlockType.TITLE: TitleBlock,
    DashboardBlockType.IFRAME: IframeBlock,
}


def get_block(name: DashboardBlockType):
    block_enum = DashboardBlockType[name]
    return _BLOCK_MAPPING[block_enum]
