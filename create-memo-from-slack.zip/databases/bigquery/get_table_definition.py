import os
from utils.kaya_yaml import read_yaml


_CONFIG_FILENAME = os.path.abspath(os.path.dirname(__file__)) + "/tables.yaml"


def get_table_definition(schema, table):
    print(f"Processing config for schema {schema} table {table}")
    raw_configs = read_yaml(_CONFIG_FILENAME)

    definition = raw_configs[schema][table]
    return definition


if __name__ == "__main__":
    get_table_definition("google_analytics_staging", "ga_metrics_by_dates")
