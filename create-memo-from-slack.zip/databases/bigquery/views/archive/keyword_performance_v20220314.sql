SELECT 
  acc.AccountDescriptiveName,
  acc.AccountCurrencyCode,
  c.CampaignName,
  c.CampaignStatus,
  ag.AdGroupName,
  ag.AdGroupType,
  k.CpcBid AS CpcBidMicros,
  k.BiddingStrategyName,
  k.CreativeQualityScore,
  k.HasQualityScore,
  k.QualityScore,
  k.PostClickQualityScore,
  k.SearchPredictedCtr,
  k.IsNegative,
  k.Status,
  k.TopOfPageCpc,
  k.KeywordMatchType,
  t.Criteria,
  t.DisplayName,
  ks.AdGroupId,
  ks.BaseAdGroupId,
  ks.BaseCampaignId,
  ks.CampaignId,
  ks.CriterionId,
  ks.ExternalCustomerId,
  ks.ActiveViewImpressions,
  ks.ActiveViewMeasurability,
  ks.ActiveViewMeasurableCost,
  ks.ActiveViewMeasurableImpressions,
  ks.ActiveViewViewability,
  ks.AdNetworkType1,
  ks.AdNetworkType2,
  ks.AveragePosition,
  ks.Clicks,
  ks.ConversionValue,
  ks.Conversions,
  ks.Cost / 1e6 AS Cost,
  ks.Impressions,
  ks.Date,
  ks.Device,
  ks.Slot
FROM
  `kaya-apps-00.google_ads.keywords` k
JOIN
  `kaya-apps-00.google_ads.campaigns` c
USING
  (CampaignId, ExternalCustomerId)
JOIN
  `kaya-apps-00.google_ads.ad_groups` ag
USING
  (CampaignId, AdGroupId, ExternalCustomerId)
JOIN
  `kaya-apps-00.google_ads.keyword_stats` ks
USING
  (CriterionId, CampaignId, AdGroupId, ExternalCustomerId)
JOIN
  `kaya-apps-00.google_ads.criteria` t
USING
  (CriterionId, CampaignId, AdGroupId, ExternalCustomerId, Criteria)
JOIN
  `kaya-apps-00.google_ads.client_accounts` acc
ON
  ks.ExternalCustomerId = acc.ExternalCustomerId
;