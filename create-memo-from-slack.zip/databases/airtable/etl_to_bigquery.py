import pandas as pd
from google.cloud import bigquery

from google.gutils.bigquery import load_local_file
from databases.airtable.airtable import Airtable


def upload_channel_mapping():
    filename = "channel_mappings_df.csv"
    columns = ["id", "channel", "source_medium", "business_id"]
    table = Airtable("channel_mapping")

    channel_mappings = table.get_all_rows()
    channel_mappings_df = pd.DataFrame(channel_mappings)
    channel_mappings_df[columns].to_csv(filename, index=0)

    schema = [
        bigquery.SchemaField(col, bigquery.enums.SqlTypeNames.STRING) for col in columns
    ]

    load_local_file(
        filename,
        f"kaya-apps-00.airtable_raw.ga_source_medium_mappings",
        write_disposition="WRITE_TRUNCATE",
        schema=schema,
    )
    return None


def upload_transactions():
    filename = "/tmp/transactions_df.csv"
    columns = {
        "id": bigquery.enums.SqlTypeNames.STRING,
        "business_id": bigquery.enums.SqlTypeNames.STRING,
        "subscriptions": bigquery.enums.SqlTypeNames.STRING,
        "currency": bigquery.enums.SqlTypeNames.STRING,
        "amount_absolute": bigquery.enums.SqlTypeNames.FLOAT64,
        "description": bigquery.enums.SqlTypeNames.STRING,
        "payment_date": bigquery.enums.SqlTypeNames.TIMESTAMP,
        "is_credit": bigquery.enums.SqlTypeNames.BOOL,
    }

    table = Airtable("transactions")
    all_data = table.get_all_rows()

    data_df = pd.DataFrame(all_data)
    data_df["amount_absolute"] = pd.to_numeric(data_df["amount_absolute"])
    data_df["is_credit"].fillna(False, inplace=True)
    data_df[columns.keys()].to_csv(filename, index=0)

    schema = [bigquery.SchemaField(col, dtype) for col, dtype in columns.items()]

    load_local_file(
        filename,
        f"kaya-apps-00.airtable_raw.transactions",
        write_disposition="WRITE_TRUNCATE",
        schema=schema,
    )
    return None


def upload_payments():
    filename = "/tmp/payments.csv"
    columns = {
        "charge_id": bigquery.enums.SqlTypeNames.STRING,
        "payment_date": bigquery.enums.SqlTypeNames.DATE,
        "payment_ts": bigquery.enums.SqlTypeNames.TIMESTAMP,
        "booked_date": bigquery.enums.SqlTypeNames.DATE,
        "name": bigquery.enums.SqlTypeNames.STRING,
        "description": bigquery.enums.SqlTypeNames.STRING,
        "ccy": bigquery.enums.SqlTypeNames.STRING,
        "business_id": bigquery.enums.SqlTypeNames.STRING,
        "ccy": bigquery.enums.SqlTypeNames.STRING,
        "revenue": bigquery.enums.SqlTypeNames.FLOAT64,
        "revenue_usd": bigquery.enums.SqlTypeNames.FLOAT64,
    }

    table = Airtable("payments")
    all_data = table.get_all_rows()

    data_df = pd.DataFrame(all_data)
    for col in ["revenue", "revenue_usd"]:
        data_df[col] = pd.to_numeric(data_df[col])

    data_df[columns.keys()].to_csv(filename, index=0)

    schema = [bigquery.SchemaField(col, dtype) for col, dtype in columns.items()]

    load_local_file(
        filename,
        f"kaya-apps-00.airtable_raw.payments",
        write_disposition="WRITE_TRUNCATE",
        schema=schema,
    )
    return None


def upload_goal_definitions():
    filename = "goals_df.csv"
    columns = [
        "id",
        "goal",
        "platform",
        "campaign_id",
        "business_id",
        "goal_calculation",
        "action_type_onsite_conversion",
        "action_type_offsite_conversion",
    ]

    table = Airtable("goal_definitions")
    all_data = table.get_all_rows()
    data_df = pd.DataFrame(all_data)
    data_df[columns].to_csv(filename, index=0)

    schema = [
        bigquery.SchemaField(col, bigquery.enums.SqlTypeNames.STRING) for col in columns
    ]

    load_local_file(
        filename,
        f"kaya-apps-00.airtable_raw.goal_definitions",
        write_disposition="WRITE_TRUNCATE",
        schema=schema,
    )
    return None


def upload_hubspot_accounts():
    filename = "hubspot_accounts.csv"

    table = Airtable("hubspot_accounts")
    all_data = table.get_all_rows()
    data_df = pd.DataFrame(all_data)
    data_df[["portal_id", "business_id"]].to_csv(filename, index=0)

    schema = [
        bigquery.SchemaField("portal_id", bigquery.enums.SqlTypeNames.INT64),
        bigquery.SchemaField("business_id", bigquery.enums.SqlTypeNames.STRING),
    ]

    load_local_file(
        filename,
        f"kaya-apps-00.airtable_raw.hubspot_accounts",
        write_disposition="WRITE_TRUNCATE",
        schema=schema,
    )
    return None


def upload_meta_ads_custom_conversion_mapping():
    table_name = "meta_ads_custom_conversion_mapping"
    filename = f"/tmp/{table_name}.csv"
    cols = ["custom_conversion_history_id", "account_id", "name", "kaya_generic_id"]

    table = Airtable(table_name)
    all_data = table.get_all_rows()
    data_df = pd.DataFrame(all_data)
    data_df[cols].to_csv(filename, index=0)

    schema = [
        bigquery.SchemaField(
            "custom_conversion_history_id", bigquery.enums.SqlTypeNames.INT64
        ),
        bigquery.SchemaField("account_id", bigquery.enums.SqlTypeNames.INT64),
        bigquery.SchemaField("name", bigquery.enums.SqlTypeNames.STRING),
        bigquery.SchemaField("kaya_generic_id", bigquery.enums.SqlTypeNames.INT64),
    ]

    load_local_file(
        filename,
        f"kaya-apps-00.airtable_raw.{table_name}",
        write_disposition="WRITE_TRUNCATE",
        schema=schema,
    )
    return None


if __name__ == "__main__":
    # upload_transactions()
    # upload_goal_definitions()
    # upload_hubspot_accounts()
    # upload_channel_mapping()
    # upload_meta_ads_custom_conversion_mapping()
    upload_payments()
