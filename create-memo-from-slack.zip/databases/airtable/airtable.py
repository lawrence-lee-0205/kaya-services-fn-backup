import os
from typing import List
from pyairtable import Table

from utils.kaya_yaml import read_yaml

_CONFIG_FILENAME = os.path.abspath(os.path.dirname(__file__)) + "/bases.yaml"
_API_KEY = os.environ["AIRTABLE_API_KEY"]

if os.environ["ENV"].upper() in ["PROD", "LOCAL_PROD"]:
    _ENV = "prod"
else:
    _ENV = "dev"


class Airtable:
    def __init__(self, table: str, base_id: str = None) -> None:
        if base_id is None:
            base_config = read_yaml(_CONFIG_FILENAME)
            self.base_id = base_config[_ENV]["id"]
        else:
            self.base_id = base_id

        self.table_name = table
        self.table = Table(_API_KEY, self.base_id, self.table_name)

    @staticmethod
    def _parse_output_to_dict(raw: dict) -> dict:
        return {"id": raw["id"], **raw["fields"]}

    def get_all_rows(self, **kwargs) -> List[dict]:
        print(f"Getting data from {self.table_name} in {_ENV}")
        all_rows = self.table.all(**kwargs)

        processed = []
        for row in all_rows:
            processed.append(self._parse_output_to_dict(row))
        return processed

    def get_single_row(self, id: str) -> dict:
        print(f"Getting record {id} from {self.table_name} in {_ENV}")
        row = self.table.get(id)
        output = self._parse_output_to_dict(row)
        return output

    def get_rows(self, ids: list) -> List[dict]:
        return [self.get_single_row(id) for id in ids]


if __name__ == "__main__":
    # formula = "AND(NOT({homepage_channel_highlight} = ''),{business_id}='lyu6tWbXJlYQmfzi6uGg')"
    # table = Airtable("custom_reports")
    # data = table.get_all_rows(formula=formula)
    # print(data)
    airtable = Airtable(table="business_dashboard", base_id="applq0qqCgkEYaxzQ")
    airtable.table.create(
        {
            "business_id": "05YbIXRfIYlPGCsKW5qe",
            "category": "📡 Paid Ads",
            "title": "Google Ads",
            "dashboard": ["recKrZCHDkv981STi"],
            "homepage_channel_highlight": "Google CPC",
            "is_live": True,
        },
    )
