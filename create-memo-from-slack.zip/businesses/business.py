from firestore import FirestoreClient
from constants import CCY_SYMBOLS
from utils.url import extract_domain

FS = FirestoreClient()


class Business:
    def __init__(self, business_id: str) -> None:
        self.business_id = business_id
        self._data = FS.get_single_document("businesses", business_id)
        self.url = self._data.get("url")

    @property
    def name(self):
        return self._data["name"]

    @property
    def ccy(self):
        return self._data["ccy"]

    @property
    def home_dashboard_id(self):
        return self._data.get("home_dashboard_id")

    @property
    def communication_preference(self):
        return self._data["communication_preference"]

    @property
    def communication_hour_utc(self):
        return self._data["communication_hour_utc"]

    @property
    def slack_channel_id(self):
        return self._data["slack_channel_id"]

    @property
    def ccy(self):
        return self._data["ccy"]

    @property
    def ccy_symbol(self):
        return CCY_SYMBOLS[self.ccy]

    @property
    def kpi_name(self):
        return self._data["kpi_name"]

    @property
    def cost_per_kpi_name(self):
        name = self._data.get("cost_per_kpi_name", "Cost per " + self.kpi_name.title())
        return name

    @property
    def analytic_features(self):
        return self._data.get("analytic_features", {})

    @property
    def noloco_company_id(self):
        return self._data.get("noloco_company_id")

    @property
    def stripe_customer_id(self):
        return self._data.get("stripe_customer_id")

    @property
    def domain(self):
        return extract_domain(self.url)

    @property
    def gdrive_url(self):
        return self._data.get("drive_url")

    @property
    def relate_organization_id(self):
        return self._data.get("relate_organization_id")

    @property
    def profile(self):
        return self._data.get("profile")

    @property
    def value_props(self):
        return self._data.get("value_props")

    def set_url(self, url):
        self.url = url
        FS.update_document("businesses", self.business_id, {"url": url})
        return None

    def get_users(self):
        users_ref = FS.get_collection("users")
        docs = users_ref.where(
            "businesses", "array_contains", self.business_id
        ).stream()
        list_of_dict = [{"id": doc.id, **doc.to_dict()} for doc in docs]
        return list_of_dict

    def get_marketers(self):
        users_ref = FS.get_collection("users")
        docs = (
            users_ref.where("role", "==", "KAYA_INTERNAL")
            .where("businesses", "array_contains", self.business_id)
            .stream()
        )
        list_of_dict = [{"id": doc.id, **doc.to_dict()} for doc in docs]
        return list_of_dict

    def get_admins(self):
        users_ref = FS.get_collection("users")
        docs = (
            users_ref.where("role", "==", "KAYA_ADMIN")
            .where("businesses", "array_contains", self.business_id)
            .stream()
        )
        list_of_dict = [{"id": doc.id, **doc.to_dict()} for doc in docs]
        return list_of_dict

    def validate_business_details_for_onboarded_companies(self):
        """Make sure all mandatory fields are present in business doc"""
        mandatory_fields = [
            "name",
            "ccy",
            "communication_preference",
            "communication_hour_utc",
        ]
        for field in mandatory_fields:
            if (
                field not in self._data
                or self._data[field] is None
                or self._data[field] == ""
            ):
                raise ValueError(f"{field} not found in business details")
        return None

    def get_property_values(self):
        """
        Retrieves all property values of the current class instance.

        Returns:
            dict: A dictionary where the keys are property names and
                  the values are the current values of those properties.
        """
        property_dict = {}
        for name, obj in self.__class__.__dict__.items():
            if isinstance(obj, property):  # Check if the attribute is a property
                property_dict[name] = getattr(self, name)  # Get the property value
        return property_dict


if __name__ == "__main__":
    biz = Business("ghUYDr9B4q1gGk8xuq0b")
    # print(biz.get_marketers())
    print(biz.get_property_values())
