import os

from utils.kaya_yaml import read_yaml

_CONFIG_FILENAME = os.path.abspath(os.path.dirname(__file__)) + "/collections.yaml"


def get_collection(cls, category):
    config = read_yaml(_CONFIG_FILENAME)
    collection = config[cls][category]["collection"]
    return collection


if __name__ == "__main__":
    o = get_collection("google", "sessions")
    print(o)
