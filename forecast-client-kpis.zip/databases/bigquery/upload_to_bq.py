import pandas as pd
import pandas_gbq as pd_gbq
import os

from databases.bigquery.get_table_definition import get_table_definition
from storage.upload_blob import upload_blob

_CSV_FOLDER = "/tmp/"


def upload_csv(schema, table, filepath, project_id, if_exists="append"):
    df = pd.read_csv(filepath)
    df.columns = [c.lower().replace(" ", "_") for c in df.columns]

    bq_table = f"{project_id}.{schema}.{table}"
    df.to_gbq(bq_table, project_id, if_exists=if_exists)
    return None


def upload_dataframe(
    df: pd.DataFrame,
    table_name: str,
    schema: str,
    if_exists: str = "append",
    gcs: dict = None,
    **kwargs,
):
    """Upload DataFrame to BQ. Providing `gcs` means file will be uploaded to
    Cloud Storage before being uploaded to BQ.

    Args:
        df (pd.DataFrame): data to upload
        table_name (str): destination table
        schema (str): BQ schema
        if_exists (str, optional): what to do if BQ table already exists. Defaults to "append".
        gcs (dict, optional): {"bucket": str, "destination_blob_folder": str, filename: str}. Defaults to None.

    Returns:
        _type_: _description_
    """
    table = f"{os.environ['GCP_PROJECT_NAME']}.{schema}.{table_name}"
    table_schema = get_table_definition(schema, table_name)["columns"]
    columns = [c["name"] for c in table_schema]

    df = df[columns]

    if gcs is not None:
        gcs_bucket = gcs["bucket"]
        gcs_destination_blob_folder = gcs["destination_blob_folder"]
        gcs_filename = gcs["filename"]

        # load to cloud storage
        local_filepath = _CSV_FOLDER + gcs_filename
        df.to_csv(local_filepath, index=0)

        upload_blob(
            gcs_bucket,
            local_filepath,
            f"{gcs_destination_blob_folder}/{gcs_filename}",
            is_public=False,
        )

    print(f"Uploading {df.shape} to {table}")
    pd_gbq.to_gbq(
        df,
        table,
        os.environ["GCP_PROJECT_NAME"],
        if_exists=if_exists,
        table_schema=table_schema,
        **kwargs,
    )
    print("Upload completed")
    return None


if __name__ == "__main__":
    project_id = "kaya-apps-00"
    schema = "google_ads"
    table = "geotargets"
    filepath = (
        "/Users/jeeyenpersonal/Documents/kaya-services/csv/geotargets-2021-10-11.csv"
    )

    df = pd.read_csv(filepath)
    df.columns = [c.lower().replace(" ", "_") for c in df.columns]

    bq_table = f"{project_id}.{schema}.{table}"
    pd_gbq.to_gbq(df, bq_table, project_id)
