from google.cloud import bigquery_datatransfer


def create_scheduled_query(
    dataset_id,
    display_name,
    query_string,
    table_name,
    schedule,
    project_id="kaya-apps-00",
    **kwargs,
):
    print(
        f"Processing job '{display_name}'...",
    )
    transfer_client = bigquery_datatransfer.DataTransferServiceClient()

    print(f"WARNING! These kwargs are ignored: {kwargs}")
    # The project where the query job runs is the same as the project
    # containing the destination dataset.
    parent = transfer_client.common_project_path(project_id)

    transfer_config = bigquery_datatransfer.TransferConfig(
        destination_dataset_id=dataset_id,
        display_name=display_name,
        data_source_id="scheduled_query",
        params={
            "query": query_string,
            "destination_table_name_template": table_name,
            "write_disposition": "WRITE_TRUNCATE",
            "partitioning_field": "",
        },
        schedule=schedule,
    )

    transfer_config = transfer_client.create_transfer_config(
        bigquery_datatransfer.CreateTransferConfigRequest(
            parent=parent,
            transfer_config=transfer_config,
            # service_account_name=service_account_name,
        )
    )

    print(f"Created scheduled query '{transfer_config.name}'\n")
    return None


if __name__ == "__main__":
    from utils.kaya_yaml import read_yaml

    configs = read_yaml("queries.yaml")
    for config in configs:
        if not config["upload"]:
            continue

        create_scheduled_query(**config)
