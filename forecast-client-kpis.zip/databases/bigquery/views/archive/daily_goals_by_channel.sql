WITH analytics_raw as (
    select d.*, v.business_id, m.channel
    FROM `kaya-apps-00.google_analytics.ga_metrics_by_dates_channels` d
    LEFT JOIN `kaya-apps-00.google_analytics.view_id` v
        using (view_id)
    LEFT JOIN `kaya-apps-00.google_analytics.ga_source_medium_mappings` m
        using (source_medium, business_id)
    WHERE TRUE
        AND days_span = 1
), analytics_goals as (
    SELECT
        start_date,
        channel,
        view_id,
        business_id,
        sum(bounce_rate*num_visitors)/sum(num_visitors) as bounce_rate,
        sum(num_visitors) as num_visitors,
        sum(num_unique_visitors) as num_new_visitors,
        avg(avg_session_duration_sec) as avg_session_duration_sec,
        sum(num_sessions) as num_sessions,
        sum(transaction_revenue_excl_shipping_tax) as revenue
    FROM analytics_raw d
    GROUP BY 1, 2, 3, 4
), google_cpc_raw as (
    SELECT c.*, a.business_id, a.ccy_code as ccy 
    FROM `kaya-apps-00.google_ads_raw.campaign_stats`   c
    LEFT JOIN `kaya-apps-00.google_ads.accounts` a
        on c.customer_id = a.client_id
), paid_ads as (
    SELECT 
        Date as start_date, 
        'Google CPC' as channel, 
        business_id, 
        ccy,
        sum(cost_micros)/1e6 as cost,
        sum(clicks) as google_cpc_clicks, 
        sum(conversions_value) as google_cpc_conversion_value,
        sum(conversions) as google_cpc_conversions
    FROM google_cpc_raw
    GROUP BY 1, 2, 3, 4

    UNION ALL 

    select 
        date as start_date, 
        'Facebook' as channel, 
        business_id, 
        ccy,
        sum(spend) as cost,
        null as google_cpc_clicks,
        null as google_cpc_conversion_value,
        null as google_cpc_conversions
    from `kaya-apps-00.meta_ads.insights_basic`
    group by 1, 2, 3, 4
), main as (
    select 
        coalesce(a.start_date, p.start_date) as start_date,
        coalesce(a.channel, p.channel) as channel,
        coalesce(a.business_id, p.business_id) as business_id,
        a.view_id,
        a.num_visitors,
        a.num_new_visitors,
        a.avg_session_duration_sec,
        a.num_sessions,
        a.bounce_rate,
        a.revenue,
        p.ccy,
        coalesce(p.cost, 0) as cost,
        coalesce(p.google_cpc_clicks, 0) as google_cpc_clicks,
        coalesce(p.google_cpc_conversion_value, 0) as google_cpc_conversion_value,
        coalesce(p.google_cpc_conversions, 0) as google_cpc_conversions,
    from analytics_goals a
    full outer join paid_ads p
        on a.start_date = p.start_date
            and a.channel = p.channel
            and a.business_id = p.business_id
)
select 
    m.*, 
    google_cpc_clicks as total_clicks, 
    google_cpc_conversion_value as total_conversion_value, 
    google_cpc_conversions as total_conversions
from main m