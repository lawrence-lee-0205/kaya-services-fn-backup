from google.cloud import bigquery

_CLIENT = bigquery.Client()


def _delete_dataset(project_id, dataset_id):
    to_delete = project_id + "." + dataset_id

    # Use the delete_contents parameter to delete a dataset and its contents.
    # Use the not_found_ok parameter to not receive an error if the dataset has already been deleted.
    _CLIENT.delete_dataset(
        to_delete,
        delete_contents=True,
        # not_found_ok=True
    )

    print("Deleted dataset '{}'.".format(dataset_id))
    return None


if __name__ == "__main__":
    project_id = "kaya-apps-00"
    dataset_id = "google_analytics_staging"
    ids = [
        "ga_events_by_dates_copy",
        "ga_metrics_by_dates_copy",
        "ga_metrics_by_dates_geo_copy",
        "ga_metrics_by_dates_pages_channels_copy",
        "ga_goal_completion_location_1_copy",
        "ga_events_by_dates_channels_copy",
        "ga_goal_completions_by_dates_locations_copy",
        "ga_metrics_by_dates_channels_campaigns_copy",
        "ga_events_by_dates_countries_copy",
        "ga_metrics_by_dates_channels_campaigns_adgroups_copy",
        "ga_goal_completions_by_dates_channels_copy",
        "ga_metrics_by_dates_pagepaths_copy",
        "ga_metrics_by_dates_channels_copy",
        "ga_metrics_by_dates_pages_countries_copy",
    ]

    # DELETE DATASET
    # _ = [_delete_dataset(project_id, dataset_id) for dataset_id in dataset_ids]

    # DELETE TABLE
    for id in ids:
        _CLIENT.delete_table(f"{project_id}.{dataset_id}.{id}")  # Make an API request.
        print("Deleted table '{}'.".format(id))
