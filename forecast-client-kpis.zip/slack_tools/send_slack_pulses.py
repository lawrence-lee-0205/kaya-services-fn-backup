"""This is the newer iteration from create_pulses.py (to be deprecated)"""

from common import validate_inputs
from utils.kaya_yaml import read_yaml_as_str
from slack_tools.create_pulses import send_slack_message
from storage.download_blob import download_blob_into_string
from http_function import http_function, process_request_inputs


@http_function
def send_client_slack_pulse_from_storage(request_json={}, request_args={}):
    mandatory_fields = ["bucket", "blob_name", "env"]

    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    return main(bucket=data["bucket"], blob_name=data["blob_name"], env=data["env"])


def main(bucket, blob_name, env="dev"):
    print("Processing from", blob_name)
    config_str = download_blob_into_string(bucket, blob_name)
    config = read_yaml_as_str(config_str)["report"]
    channels = config["channel"] if env.upper() == "PROD" else ["C02PYBMGLL9"]

    if len(channels) == 0:
        raise ValueError(
            f"No channels found for this business ({config['business_id']}). Please check the config: {bucket}/{blob_name}."
        )

    # construct slack msg
    send_slack_message(
        channels=channels,
        blocks=config["contents"],
        business_id=config["business_id"],
        notification_text=config["notification_text"],
    )

    return "Success"


if __name__ == "__main__":
    bucket = "kaya-pulses-dev"
    blob = "meta_ads_daily/F4U881rxMbysuWVStQRj.yml"
    main(
        bucket,
        blob,
    )
