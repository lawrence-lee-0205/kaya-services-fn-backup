from slack_tools.slack import SlackMessage

_SLACK_CHANNEL = "C079SVB5DGR"


def send_failed_forecast_kpi_alert(data):
    dag_id = "p_forecast_client_kpis"
    airflow_link = f"https://1486bdd29f24457f937274cfaa784e54-dot-us-central1.composer.googleusercontent.com/tree?dag_id={dag_id}"
    cloudfunction_link = "https://console.cloud.google.com/functions/details/us-central1/forecast-client-kpis?env=gen2&hl=en&project=kaya-apps-00&tab=logs"

    kpi_id = data["kpi_id"]
    business_id = data["business_id"]
    business_name = data["business_name"]
    run_timestamp = data["run_timestamp"]
    error_message = data["error_message"]

    message = ""
    message += f":x: *Forecast KPI airflow task failed for `{business_name}`*\n\n"
    message += f"• KPI ID: {kpi_id}\n"
    message += f"• Business ID: {business_id}\n"
    message += f"• Timestamp: {run_timestamp}\n"
    message += f"• Error: {error_message}\n\n"
    message += f"• Links: <{airflow_link}|Airflow DAG> | <{cloudfunction_link}| Cloud Function log>\n"

    try:
        _send_slack(message, _SLACK_CHANNEL)

    except Exception as e:
        error_notif = f"Failed to send alert for {business_name} (kpi_id: {kpi_id}). Error:\n{str(e)}"
        _send_slack(error_notif, _SLACK_CHANNEL)

    return None


def send_anomaly_kpi_alert(d):
    try:
        message = ""
        message += (
            f":large_red_square: *KPI anomaly reported for `{d['business_name']}`*\n\n"
        )
        message += f"`{d['kpi_metric_name']}` is {d['anomaly_direction']} than historical interquartile range of {d['iqr_range']}\n"
        message += f"Current month: *{round(d['kpi_achieved'])}* vs Previous month: {round(d['last_month_kpi'])}\n\n"

        message += f"• Forecast value: {round(d['forecasted_value'])}, at range {round(d['forecasted_value_lower'])} to {round(d['forecasted_value_upper'])}\n"
        message += f"• KPI ID: {d['kpi_id']}\n"
        message += f"• Business ID: {d['business_id']}\n"
        message += f"• Timestamp: {d['run_timestamp']}\n"

        if d["is_primary_kpi"]:
            alert_users = ["<@U06EX1MUKPV>", "<@U02P4RZDN5P>"]
            alert_users_str = ", ".join(alert_users)

            message += f"• Attention: Primary KPI. {alert_users_str}"

        _send_slack(message, _SLACK_CHANNEL)

    except Exception as e:
        error_notif = f"Failed to send alert for {d['business_name']} (kpi_id: {d['kpi_id']}). Error:\n{str(e)}"
        _send_slack(error_notif, _SLACK_CHANNEL)

    return None


def _send_slack(message, channel):
    bot = SlackMessage()
    bot.create_plain_text(message)
    bot.send_notification(channel=channel)
    return None


# if __name__ == "__main__":
#     data = {
#         "kpi_id": "test_kpi_id",
#         "business_id": "test_business_id",
#         "business_name": "test_business_name",
#         "run_timestamp": "test_run_timestamp",
#         "error_message": "test_error_message",
#     }
#     send_failed_forecast_kpi_alert(data)

if __name__ == "__main__":
    kpi_achieved = 1
    anomaly_direction = "lower"
    iqr_range = "10 to 100"
    last_month_kpi = 20

    data = {
        "kpi_id": "test_kpi_id",
        "business_id": "test_business_id",
        "business_name": "test_business_name",
        "kpi_metric_name": "test_kpi_metric_name",
        "kpi_aggregate_by": "monthly",
        "kpi_achieved": kpi_achieved,
        "forecasted_value": 20,
        "forecasted_value_lower": 50,
        "forecasted_value_upper": 100,
        "is_primary_kpi": True,
        "anomaly_direction": anomaly_direction,
        "iqr_range": iqr_range,
        "last_month_kpi": last_month_kpi,
        "run_timestamp": "test_run_timestamp",
        "error_message": "test_error_message",
    }
    send_anomaly_kpi_alert(data)
