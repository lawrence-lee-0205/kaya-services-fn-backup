from google.gutils.bigquery import run_query
from common import validate_inputs
from setup import setup


@setup
def get_client_kpis(data: dict) -> dict:
    mandatory_fields = [
        "month",
        "auth_user_id",
    ]
    validate_inputs(data, mandatory_fields)
    print(data)
    resp = _execute(
        month=data["month"],
        user_id=data.get("user_id"),
        business_id=data.get("business_id"),
    )
    return resp


def _execute(month=None, user_id=None, business_id=None):
    # filter sql
    filter_sqls = []
    filter_sqls_str = ""

    if month:
        filter_month_sql = f"cast(period as date) = '{month}'"
        filter_sqls.append(filter_month_sql)

    if user_id:
        filter_user_sql = f"business_id in (select business_id from kaya-apps-00.m_core.users_businesses where id = '{user_id}')"
        filter_sqls.append(filter_user_sql)

    if business_id:
        filter_business_sql = f"business_id = '{business_id}'"
        filter_sqls.append(filter_business_sql)

    filter_sqls_str = "where "
    filter_sqls_str += " and ".join(filter_sqls)

    # query data
    sql = f"""
    select 
        cast(period as date) as period,
        kpi_metric_name,
        kpi_id,
        cast(kpi_target_value as numeric) as kpi_target_value,
        cast(kpi as numeric) as kpi_achieved,
        cast(kpi_incl_forecast as numeric) as forecasted_value,
        cast(kpi_incl_forecast_lower as numeric) as forecasted_value_lower,
        cast(kpi_incl_forecast_upper as numeric) as forecasted_value_upper,
        kpi_aggregate_by,
        cast(is_kpi_achieved as boolean) as is_kpi_achieved,
        cast(coalesce(is_primary_kpi, False) as boolean) as is_primary_kpi,
        business_id,
        business_name
    from m_core.client_kpi
    {filter_sqls_str}
    """
    out = run_query(sql)
    print(out)
    return out


# if __name__ == "__main__":
#     month = "2024-02-01"
#     user_id="45Vh3xi4oxe6R7hmhFps"
#     out = _execute(month, user_id=user_id)
#     print(out)


if __name__ == "__main__":
    business_id = "ghUYDr9B4q1gGk8xuq0b"
    out = _execute(business_id=business_id)
    print(out)
