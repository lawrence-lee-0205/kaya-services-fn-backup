import pandas as pd
import numpy as np
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
import logging

from common import validate_inputs
from http_function import http_function, process_request_inputs
from kpi.get_client_kpis import _execute as get_client_kpis
from kpi.send_kpi_alert import send_anomaly_kpi_alert

_DATETIME_NOW = datetime.now(timezone.utc)
_TIME_NOW = _DATETIME_NOW.strftime("%Y-%m-%d %H:%M:%S")
_MONTH = _DATETIME_NOW.strftime("%Y-%m") + "-01"
_LAST_MONTH = (_DATETIME_NOW - relativedelta(months=1)).strftime("%Y-%m") + "-01"


@http_function
def detect_anomaly_client_kpis(request_json={}, request_args={}):
    mandatory_fields = ["business_id"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    res = execute(business_id=data["business_id"])
    return res


def detect_anomaly(df, month, factor=1.5):
    # get latest month kpi
    latest_month_kpi = df[df["period"] == month]["kpi_achieved"].iloc[0]

    # calculate iqr
    q1, q3 = np.percentile(df["kpi_achieved"], [25, 75])
    iqr_range = f"{round(q1)} to {round(q3)}"
    iqr = q3 - q1

    lower_bound = q1 - factor * iqr
    upper_bound = q3 + factor * iqr

    # detect outlier based on outlier
    if latest_month_kpi < lower_bound:
        return "lower", iqr_range

    elif latest_month_kpi > upper_bound:
        return "higher", iqr_range

    return None


def execute(business_id):
    try:
        # get latest kpi data from BQ
        bq_data = get_client_kpis(business_id=business_id)

        bq_df = pd.DataFrame(bq_data)
        bq_df["period"] = bq_df["period"].astype(str)
        bq_df["kpi_achieved"] = bq_df["kpi_achieved"].astype(float)
        bq_df = bq_df.sort_values(by=["kpi_id", "period"])

        kpis = bq_df["kpi_id"].unique().tolist()

        for kpi in kpis:
            kpi_df = bq_df[bq_df["kpi_id"] == kpi]
            anomaly_direction, iqr_range = detect_anomaly(kpi_df, month=_MONTH)

            # send slack alert if found anomaly
            if anomaly_direction:
                latest_month_d = bq_df[bq_df["period"] == _MONTH].to_dict("records")[0]
                last_month_kpi = (
                    bq_df[bq_df["period"] == _LAST_MONTH]
                    .to_dict("records")[0]
                    .get("kpi_achieved")
                )

                add_info = {
                    "anomaly_direction": anomaly_direction,
                    "iqr_range": iqr_range,
                    "last_month_kpi": last_month_kpi,
                    "run_timestamp": _TIME_NOW,
                }
                alert_info = {**latest_month_d, **add_info}

                send_anomaly_kpi_alert(alert_info)

                print(
                    f"Anomaly found for kpi_id: {kpi}. It is currently at {round(latest_month_d['kpi_achieved'])}, {anomaly_direction} than historical IQR range of {iqr_range}"
                )
                return "Anomaly"

            else:
                continue

    except Exception as e:
        logging.warning(
            f"KPI anomaly detection failed for business_id {business_id}. Error: {e}"
        )
        return "Error"


if __name__ == "__main__":
    business_id = "ghUYDr9B4q1gGk8xuq0b"
    execute(business_id)
