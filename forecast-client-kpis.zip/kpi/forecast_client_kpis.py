import pandas as pd
import datetime as dt
import calendar
from datetime import datetime, timezone
import time

from prophet import Prophet
from sklearn.metrics import mean_absolute_error

import logging

from common import validate_inputs
from http_function import http_function, process_request_inputs
from google.gutils.bigquery import run_query
from databases.bigquery.upload_to_bq import upload_dataframe
from kpi.send_kpi_alert import send_failed_forecast_kpi_alert

from firestore import FirestoreClient

_FS = FirestoreClient()
_SCHEMA = "m_core"


_RAW_COLS_TO_KEEP = [
    "date",
    "kpi_id",
    "kpi_metric_name",
    "kpi_aggregate_by",
    "kpi_calculation_method",
    "business_id",
    "kpi",
    "kpi_incl_forecast",
    "kpi_incl_forecast_upper",
    "kpi_incl_forecast_lower",
    "is_primary_kpi",
    "updated_timestamp",
]
_AGG_COLS_TO_KEEP = [
    "kpi",
    "kpi_incl_forecast",
    "kpi_incl_forecast_lower",
    "kpi_incl_forecast_upper",
    "period",
    "kpi_id",
    "kpi_end_date",
    "kpi_metric_name",
    "kpi_target_value",
    "kpi_aggregate_by",
    "business_id",
    "kpi_start_date",
    "is_kpi_achieved",
    "business_name",
    "kpi_calculation_method",
    "is_primary_kpi",
    "updated_timestamp",
]

_DEFAULT_AGGFUNC = "sum"
_TODAY = dt.date.today()
_, _NUM_DAYS_THIS_MONTH = calendar.monthrange(_TODAY.year, _TODAY.month)
_LAST_DAY_OF_MONTH_STR = dt.date(
    _TODAY.year, _TODAY.month, _NUM_DAYS_THIS_MONTH
).strftime("%Y-%m-%d")
_TIME_NOW = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
_LOOKBACK_PERIOD = 28
_FORECAST_PERIOD = 90
_VALIDATION_PERIOD = 7

_MAX_RETRY = 3


class ForecastKPI:
    def __init__(self, method, df, mae=0):
        self.method = method
        self.df = df
        self.mae = mae


@http_function
def forecast_client_kpis(request_json={}, request_args={}):
    mandatory_fields = ["business_id"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    execute(business_id=data["business_id"])
    return "Success"


@http_function
def forecast_single_client_kpi(request_json={}, request_args={}):
    mandatory_fields = ["kpi_id"]
    data = process_request_inputs(request_json, request_args)
    validate_inputs(data, mandatory_fields)

    execute_single_kpi(kpi_id=data["kpi_id"])
    return "Success"


def run_forecast(df):
    # prepare base df
    df_renamed = df.rename(columns={"date": "ds", "kpi": "y"}).copy()

    start_date = _TODAY - pd.Timedelta(days=_LOOKBACK_PERIOD + 1)
    end_date = _TODAY - pd.Timedelta(days=1)

    base_df = pd.DataFrame({"ds": pd.date_range(start=start_date, end=end_date)})
    base_df = pd.merge(base_df, df_renamed, on="ds", how="left").fillna(0)

    # prepare training and validation data
    validation_data = base_df.tail(_VALIDATION_PERIOD)
    train_data = base_df.drop(validation_data.index)

    train_data.reset_index(drop=True, inplace=True)
    validation_data.reset_index(drop=True, inplace=True)

    ## forecast and calculate mean average error for different methods, output as obj
    # forecast method 1: prophet
    forecast_prophet = run_forecast_prophet(train_data, validation_data, "prophet")

    # forecast method 2: daily average
    forecast_mean = extrapolate_daily_kpi(train_data, validation_data, method="mean")

    # forecast method 3: daily median
    forecast_median = extrapolate_daily_kpi(
        train_data, validation_data, method="median"
    )

    # get ForecastKPI object with lowest mean average error score
    forecast_kpis = [forecast_prophet, forecast_mean, forecast_median]

    selected_forecast = min(forecast_kpis, key=lambda x: x.mae)
    selected_forecast_df = selected_forecast.df

    # post process forecast_df
    selected_forecast_df = selected_forecast_df[
        ["ds", "yhat", "yhat_upper", "yhat_lower"]
    ]
    selected_forecast_df.rename(columns={"ds": "date"}, inplace=True)

    selected_forecast_df = selected_forecast_df[
        selected_forecast_df["date"] > df["date"].max()
    ]

    # final forecast_df
    final_forecast_df = pd.concat([df, selected_forecast_df], ignore_index=True)

    for yhat_colname in ["yhat", "yhat_upper", "yhat_lower"]:
        final_col_name = yhat_colname.replace("yhat", "kpi_incl_forecast")

        final_forecast_df.loc[final_forecast_df[yhat_colname] < 0, yhat_colname] = 0

        final_forecast_df[final_col_name] = final_forecast_df["kpi"].fillna(
            final_forecast_df[yhat_colname]
        )

    final_forecast_df["kpi"] = final_forecast_df["kpi"].fillna(0)
    final_forecast_df = final_forecast_df.sort_values(by="date")

    return final_forecast_df


def evaluate_forecast_results(validation_df, forecasted_df, method):
    forecasted_val_df = forecasted_df[
        (forecasted_df["ds"] >= validation_df["ds"].min())
        & (forecasted_df["ds"] <= validation_df["ds"].max())
    ]

    # calculate mean average error
    y_actual = validation_df["y"]
    y_pred = forecasted_val_df["yhat"]
    mae = mean_absolute_error(y_actual, y_pred)

    # calculate upper and lower forecast
    if method in ("mean", "median"):
        forecasted_df["yhat_upper"] = forecasted_df["yhat"] + mae
        forecasted_df["yhat_lower"] = forecasted_df["yhat"] - mae

    # store in obj
    forecast_obj = ForecastKPI(method, forecasted_df, mae)

    print(f"Forecast method: {method}")
    print("MAE: %.3f" % mae)

    return forecast_obj


def extrapolate_daily_kpi(train_data, validation_data, method):
    # extrapolate to upcoming n days
    start_extrapolation = train_data["ds"].max() + pd.Timedelta(days=1)
    end_extrapolation = start_extrapolation + pd.Timedelta(days=_FORECAST_PERIOD)
    extrapolated_df = pd.DataFrame(
        {"ds": pd.date_range(start_extrapolation, end_extrapolation)}
    )

    # extrapolate based on method
    if method == "mean":
        extrapolated_df["yhat"] = train_data["y"].mean()
    elif method == "median":
        extrapolated_df["yhat"] = train_data["y"].median()

    # evaluate
    forecast_obj = evaluate_forecast_results(validation_data, extrapolated_df, method)

    return forecast_obj


def run_forecast_prophet(train_data, validation_data, method):
    # run prophet prediction
    model = Prophet()

    # fit model to df
    model.fit(train_data)

    # create a df to hold the future dates you want to predict
    future_dates = model.make_future_dataframe(periods=_FORECAST_PERIOD)

    # make the forecast
    forecasted_df = model.predict(future_dates)

    # evaluate
    forecast_obj = evaluate_forecast_results(validation_data, forecasted_df, method)

    return forecast_obj


def forecast_kpi(doc, kpi_id):
    attempt = 1
    while attempt <= _MAX_RETRY:
        try:
            # get business details
            business_id = doc["business_id"]
            business_doc = _FS.get_single_document("businesses", business_id)
            business_name = business_doc["name"]

            # end date will be used to filter data after running forecast
            start_date = doc["start_date"]
            end_date = (
                _LAST_DAY_OF_MONTH_STR if doc["end_date"] is None else doc["end_date"]
            )

            raw_out = run_query(doc["sql"])
            raw_df = pd.DataFrame(raw_out)
            raw_df["date"] = pd.to_datetime(raw_df["date"])
            raw_df = raw_df.sort_values(by="date")
            print("raw_df: ", raw_df.shape)

            # run forecast if there are more than 28 days of historical data and is configured to run
            config_run_forecast = not doc.get("skip_forecast", False)
            to_run_forecast = raw_df.shape[0] >= 28 and config_run_forecast

            if to_run_forecast:
                try:
                    forecasted_df = run_forecast(raw_df)
                    df_to_use = forecasted_df.copy()

                except Exception as e:
                    print("Error running forecast..")
                    print(e)
                    to_run_forecast = False
                    df_to_use = raw_df.copy()
            else:
                df_to_use = raw_df.copy()
                print(
                    f"Not running forecast. Config: {config_run_forecast}. Number of historical data points: {raw_df.shape[0]}"
                )

            # filter based on start and end dates
            df = df_to_use[
                (df_to_use["date"] >= start_date) & (df_to_use["date"] <= end_date)
            ]
            print("df after filtering start and end dates: ", df.shape)

            if df.shape[0] == 0:
                print(
                    f"Forecast KPI stopped for business_id {business_id}, kpi_id {kpi_id} as no data left after filtering start and end dates. Terminating.."
                )
                return None

            df["daily"] = df["date"]
            df["monthly"] = df["daily"].dt.to_period("M")
            df["weekly"] = df["daily"].dt.to_period("W")

            # aggregate
            aggregate_by = doc["aggregate_by"].lower()
            cols_to_agg = [
                x
                for x in df.columns
                if x
                in [
                    "kpi",
                    "kpi_incl_forecast",
                    "kpi_incl_forecast_upper",
                    "kpi_incl_forecast_lower",
                ]
            ]
            try:
                for col in cols_to_agg:
                    df[col] = pd.to_numeric(df[col], errors="coerce")
            except pd.errors.ParserError:
                print("Error: Some values could not be converted to numeric.")

            aggfunc = doc.get("calculation_method", _DEFAULT_AGGFUNC)
            agg_df = pd.pivot_table(
                df, index=aggregate_by, aggfunc=aggfunc, values=cols_to_agg
            )

            # create period col
            # by default, df['monthly'] shows the last day of the month, we change it to the first day of the month
            period_str = "%Y-%m-01" if aggregate_by == "monthly" else "%Y-%m-%d"
            agg_df["period"] = agg_df.index
            agg_df["period"] = agg_df["period"].dt.strftime(period_str)
            for key, value in doc.items():
                # add cols from the KPI doc to dataframe
                if key not in [
                    "metric_name",
                    "target_value",
                    "aggregate_by",
                    "business_id",
                    "start_date",
                    "end_date",
                ]:
                    continue

                col_name = key if key == "business_id" else "kpi_" + key
                agg_df[col_name] = value
                df[col_name] = value

            # check if kpi is achieved
            is_kpi_achieved_when_value_is_higher = doc.get(
                "is_kpi_achieved_when_value_is_higher", True
            )
            if is_kpi_achieved_when_value_is_higher:
                agg_df["is_kpi_achieved"] = agg_df["kpi"] >= agg_df[
                    "kpi_target_value"
                ].astype(float)
            else:
                agg_df["is_kpi_achieved"] = agg_df["kpi"] <= agg_df[
                    "kpi_target_value"
                ].astype(float)

            # add business info
            add_info = {
                "business_name": business_name,
                "kpi_id": kpi_id,
                "kpi_calculation_method": aggfunc,
                "is_primary_kpi": doc.get("is_primary_kpi", False),
                "updated_timestamp": pd.to_datetime(_TIME_NOW),
            }
            for key, value in add_info.items():
                agg_df[key] = value
                df[key] = value

            # upload to BQ raw table
            del_sql = f"""
                DELETE FROM m_core.client_kpi_raw WHERE kpi_id = '{kpi_id}'
            """
            run_query(del_sql)
            print("Deleted")

            # create col if doesn't exist so we can upload w/o error
            for c in _RAW_COLS_TO_KEEP:
                if c not in df.columns:
                    df.loc[:, c] = None

            if len(df) > 0:
                upload_dataframe(
                    df[_RAW_COLS_TO_KEEP],
                    table_name="client_kpi_raw",
                    schema=_SCHEMA,
                    if_exists="append",
                    api_method="load_csv",
                )
            else:
                print("No data found. Skipping upload.")

            # upload to BQ actual table
            del_sql = f"""
                DELETE FROM m_core.client_kpi WHERE kpi_id = '{kpi_id}'
            """
            run_query(del_sql)
            print("Deleted")

            agg_df.reset_index(drop=True, inplace=True)
            for c in ["period", "kpi_start_date", "kpi_end_date"]:
                agg_df[c] = pd.to_datetime(agg_df[c])

            # create col if doesn't exist so we can upload w/o error
            for c in _AGG_COLS_TO_KEEP:
                if c not in agg_df.columns:
                    agg_df[c] = None

            if len(agg_df) > 0:
                upload_dataframe(
                    agg_df[_AGG_COLS_TO_KEEP],
                    table_name="client_kpi",
                    schema=_SCHEMA,
                    if_exists="append",
                    api_method="load_csv",
                )
            else:
                print("No data found. Skipping upload.")

            return None

        except Exception as e:
            if attempt != _MAX_RETRY:
                time.sleep(20)
                attempt += 1

            else:
                logging.info(
                    f"Forecast KPI failed for business_id {business_id}, kpi_id {kpi_id} due to error {e}."
                )

                # send slack alert
                alert_info = {
                    "kpi_id": kpi_id,
                    "business_id": business_id,
                    "business_name": business_name,
                    "run_timestamp": _TIME_NOW,
                    "error_message": e,
                }
                send_failed_forecast_kpi_alert(alert_info)

                return None


def execute(business_id):
    kpi_docs = _FS.get_filtered_documents(
        "kpi_definition",
        filters=[{"field_name": "business_id", "operator": "==", "value": business_id}],
        output_fmt="records",
    )

    if kpi_docs:
        for doc in kpi_docs:
            kpi_id = doc["id"]
            print("Processing ", kpi_id)

            forecast_kpi(doc, kpi_id)

    else:
        logging.warning(f"No KPIs found for business_id {business_id}.")

    return None


def execute_single_kpi(kpi_id):
    doc = _FS.get_single_document("kpi_definition", kpi_id)

    if doc:
        forecast_kpi(doc, kpi_id)

    else:
        logging.warning(f"KPI not found for kpi_id {kpi_id}.")

    return None


# if __name__ == "__main__":
#     business_id = "G28ayyMdb3NpFTpmnDDx"
#     execute(business_id)


if __name__ == "__main__":
    kpi_id = "QNKhak4GglNW2TNGugZD"
    execute_single_kpi(kpi_id)
