class Money:
    def __init__(self, ccy, amount) -> None:
        self.ccy = ccy
        self.amount_nominal = amount
        self.amount_micros = int(amount * 1e6)
