import os
import datetime

from typing import List


def get_options_headers():
    # Allows GET requests from any origin with the Content-Type
    # header and caches preflight response for an 3600s
    return {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET",
        "Access-Control-Allow-Headers": "Authorization, Content-Type",
        "Access-Control-Max-Age": "3600",
    }


def get_main_headers():
    return {"Access-Control-Allow-Origin": "*", "Content-Type": "application/json"}


def handle_googleads_exception(exception):
    from exceptions import GoogleAdsException

    error_msg = []

    error_msg.append(
        f"""
    Request with ID "{exception.request_id}" failed with status {exception.error.code().name}" and includes the following errors:
    """
    )

    for error in exception.failure.errors:
        error_msg.append(f'\tError with message "{error.message}".')

        if error.location:
            for field_path_element in error.location.field_path_elements:
                error_msg.append(f"\t\tOn field: {field_path_element.field_name}")
    print("\n".join(error_msg))
    raise GoogleAdsException("\n".join(error_msg))


def init_firebase():
    import firebase_admin
    from firebase_admin import credentials

    if not firebase_admin._apps:
        print("Initialising Firebase")
        cred = credentials.ApplicationDefault()
        firebase_admin.initialize_app(
            cred,
            {
                "projectId": os.environ["GCP_PROJECT_NAME"],
            },
        )


def validate_auth(request):
    from firebase_admin import auth

    init_firebase()
    print("Validating auth")
    authorization = request.headers.get("Authorization")

    id_token = None
    if authorization and authorization.startswith("Bearer "):
        id_token = authorization.split("Bearer ")[1]
    else:
        print("Authorization or bearer token is not found")
        raise Exception("Unauthorized")

    try:
        decoded_token = auth.verify_id_token(id_token)
        uid = decoded_token["uid"]
        print(f"User {uid} is authorised successfully")
        return uid
    except Exception as e:
        print(e)
        raise Exception("Unauthorized")


# ----------- VALIDATION -----------#


def validate_inputs(payload, mandatory_fields):
    for key in mandatory_fields:
        if (key not in payload) or (payload[key] is None):
            raise KeyError(
                f"'{key}'' not provided. Expecting the following fields: {mandatory_fields}"
            )


def validate_datetime(
    datetime_str: str,
    param: str,
    format: str = "%Y-%m-%d %H:%M:%S",
    return_type: str = "datetime",
) -> datetime.datetime:
    if not isinstance(datetime_str, str):
        raise TypeError(
            "Expecting type 'str' for argument 'datetime_str'. Received ",
            type(datetime_str),
        )

    try:
        dt = datetime.datetime.strptime(datetime_str, format)

        if return_type == "date":
            dt = dt.date()
    except Exception:
        raise ValueError(
            f"Invalid datetime format for param '{param}', expecting '{format}' but received {datetime_str}"
        )
    return dt


def validate_and_fix_bid(bid_micros: int, param: str = "bid") -> int:
    from constants import MILLION

    # calc min amount acceptable for bid in micro unit
    # TODO: GET THIS FROM FIRESTORE/GOOGLE
    min_billable_amount_micros = 0.01 * MILLION

    if not isinstance(bid_micros, int):
        bid_micros = int(bid_micros)

    if bid_micros < min_billable_amount_micros:
        raise ValueError(
            f"Provided {param} amount is too small. Min value acceptable: {min_billable_amount_micros}, received {bid_micros}."
        )

    # bid must be a multiple of minimum unit
    if bid_micros % min_billable_amount_micros > 0:
        bid_micros = round(bid_micros, -4)
    return bid_micros


def validate_non_empty_string(string, name):
    if (string is None) or (string.replace(" ", "") == ""):
        raise ValueError(f"Expecting non empty string for param {name}")


def validate_non_empty_list(lst, name):
    if not isinstance(lst, list):
        raise TypeError(
            f"Expecting param '{name}' to be a list. Received type: {type(lst)}"
        )

    if len(lst) == 0:
        raise ValueError(f"Expecting non empty list for param {name}")


def validate_positive_number(number, name):
    if number <= 0:
        raise ValueError(f"Expecting param '{name}' to have value more than 0")


# ----------- MATHS ----------- #


def prettify_float_to_str(num: float) -> str:
    """Convert a number to its string representation with convention of K, M, G etc.

    Examples:
    prettify_float_to_str(1040) --> '1.04K'
    prettify_float_to_str(990)  --> '0.99K'
    prettify_float_to_str(100000)  --> '100K'

    Args:
        num (float): number to convert
        precision (int, optional): decimal number. Defaults to 2.
        suffixes (List[str], optional): Defaults to ["", "K", "M", "G", "T", "P"].

    Returns: str
    """
    suffixes = ["", "K", "M", "G", "T", "P"]

    power_of_thousand = sum(
        [abs(round(num / 1000.0 ** x)) >= 1 for x in range(1, len(suffixes))]
    )
    num_with_2_dp = f"{num/1000.0**power_of_thousand:.2f}"

    num_split = num_with_2_dp.split(".")
    whole_part = num_split[0]
    decimal = num_split[1]

    if (int(decimal) == 0) or (int(whole_part) >= 10):
        # don't show decimal if decimal value is 0 or whole part has more than 2 digits
        converted_num = whole_part
    else:
        converted_num = num_with_2_dp

    return f"{converted_num}{suffixes[power_of_thousand]}"


# ------- DATA STRUCTURE ------- #


def get_unique_list_of_dict(list_of_dict: List[dict]) -> List[dict]:
    unique_dict_values = {
        frozenset(item.items()): item for item in list_of_dict
    }.values()
    return list(unique_dict_values)


if __name__ == "__main__":
    # test = [{"a": 1, "b": 2, "a": 1, "a": "1"}]
    # print(get_unique_list_of_dict(test))

    validate_non_empty_list("test", "test")
