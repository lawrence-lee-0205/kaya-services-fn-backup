class NoDefaultSerpLocationError(Exception):
    pass


class GoogleAdsException(Exception):
    pass


class UserNotFoundException(Exception):
    pass
