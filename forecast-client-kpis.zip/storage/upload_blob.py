from google.cloud import storage


def upload_blob(bucket_name, source_file_name, destination_blob_name, is_public=False):
    """Uploads a file to the bucket."""
    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"
    # The path to your file to upload
    # source_file_name = "local/path/to/file"
    # The ID of your GCS object
    # destination_blob_name = "storage-object-name"

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)

    blob.upload_from_filename(source_file_name)
    if is_public:
        print("WARNING, FILE WILL BE MADE PUBLIC!")
        blob.make_public()

    print(
        "File {} uploaded to {}/{}.".format(
            source_file_name, bucket_name, destination_blob_name
        )
    )

    return blob.public_url


def upload_blob_from_string(
    bucket_name, data, content_type, destination_blob_name, is_public=False
):
    """Uploads a file to the bucket."""
    # The ID of your GCS bucket
    # bucket_name = "your-bucket-name"
    # The path to your file to upload
    # source_file_name = "local/path/to/file"
    # The ID of your GCS object
    # destination_blob_name = "storage-object-name"

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)

    blob.upload_from_string(data, content_type=content_type)
    if is_public:
        print("WARNING, FILE WILL BE MADE PUBLIC!")
        blob.make_public()

    print("File uploaded to {}/{}.".format(bucket_name, destination_blob_name))

    return blob.public_url


# https://storage.googleapis.com/kaya-apps-staging-public/analytics-images/page_analytics.png
if __name__ == "__main__":
    bucket_name = "kaya-apps-staging-public"
    business_id = "analytics-images"
    filenames = [
        # "blog_performance.png",
        # "gsem.png",
        # "gsearch_org.png",
        # "tiktok.png",
        # "linkedin.png",
        # "email.png",
        # "mee_summary.png",
        # "fb.png",
        # "mof.png",
        # "mtd_overview.png",
        # "page_analytics.png",
        # "placeholder.png",
        # "sales_funnel.png",
        # "tof.png",
        # "traffic_analysis.png",
        # "yoy_comparison.png",
        "snapchat.png",
    ]

    for f in filenames:
        # destination_blob_name = f"month-end/{business_id}/{f}"
        destination_blob_name = f"{business_id}/{f}"
        source_file_name = "/Users/jeeyenpersonal/Downloads/dashboards_imgs_new/" + f
        upload_blob(
            bucket_name, source_file_name, destination_blob_name, is_public=True
        )

        file_url = f"""
        <img style="max-width: 50%; box-shadow: rgba(0, 0, 0, 0.18) 0px 2px 4px; margin: 1rem 0;" src="https://storage.googleapis.com/kaya-apps-staging-public/{destination_blob_name}"/>
        """
        print(file_url)
        print()
