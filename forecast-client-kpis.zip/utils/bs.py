# write a beautifulsoup function that takes a url and returns all urls on that page
from os import environ

import http.client
from bs4 import BeautifulSoup


def get_web_content(url, country):
    # todo: change to input
    print(f"Scrapping {url} with proxy country as {country}")
    conn = http.client.HTTPSConnection("api.scrapingant.com")
    conn.request(
        "GET",
        f"/v2/general?url=https%3A%2F%2F{url}%2F&x-api-key={environ['SCRAPING_ANT_API_KEY']}&proxy_country={country}&return_page_source=true",
    )
    res = conn.getresponse()
    html = res.read().decode("utf-8")
    return html


def get_urls(url):
    # get the html
    html = get_web_content(url, "GB")
    print(html)

    # create a soup
    soup = BeautifulSoup(html, "html.parser")

    # find all the links
    links = soup.find_all("a")

    print(links)
    # get the hrefs
    hrefs = [link.get("href") for link in links]
    # return the hrefs
    return hrefs


if __name__ == "__main__":
    urls = get_urls("go.myedspace.co.uk/mes-affordable-maths-course-fbkt3")
    url_str = "\n".join(urls)
    print(f"\nURLs:\n{url_str}")
