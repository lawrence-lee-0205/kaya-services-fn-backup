from utils.mathematics import round_to_n_significant_digits


def remove_duplicated_index_from_pivot(df, drop_index=True):
    new_df = df.copy()

    for i in range(df.index.nlevels, 0, -1):
        new_df = new_df.sort_index(level=i - 1)

    replace_cols = dict()

    for i in range(new_df.index.nlevels):
        idx = new_df.index.get_level_values(i)

        new_df.insert(i, idx.name, idx)

        replace_cols[idx.name] = new_df[idx.name].where(
            ~new_df.duplicated(subset=new_df.index.names[: i + 1])
        )

    for col, ser in replace_cols.items():
        new_df[col] = ser

    if drop_index:
        return new_df.reset_index(drop=True)
    return new_df


def round_dataframe(df, n):
    """Apply n significant digits rounding to all numeric values in the DataFrame."""
    return df.applymap(lambda x: round_to_n_significant_digits(x, n) if isinstance(x, (int, float)) else x)
