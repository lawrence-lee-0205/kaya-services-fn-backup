def remove_duplicates(lst: list):
    return list(set(lst))


def remove_duplicates_from_list_of_dict(dict_list):
    """Remove duplicates from a list of dictionaries."""
    # Create a set to store unique tuples
    unique_tuples = set()
    # Convert each dictionary into a tuple of sorted items and add to the set
    for d in dict_list:
        # Convert dictionary to a tuple (key, value) sorted by key
        dict_tuple = tuple(sorted(d.items()))
        unique_tuples.add(dict_tuple)

    # Convert the set of tuples back to a list of dictionaries
    unique_dicts = [dict(t) for t in unique_tuples]
    return unique_dicts


def chunk_list(lst: list, size: int) -> list:
    """Chunk list into 'list of list' where each sub list has a length of 'size'

    Args:
        lst (list): _description_
        size (int): _description_

    Returns:
        list: _description_
    """

    return [lst[i : i + size] for i in range(0, len(lst), size)]


def join_list_of_str_with_and(string_list, delim):
    if len(string_list) == 0:
        return ""
    elif len(string_list) == 1:
        return string_list[0]
    elif len(string_list) == 2:
        return f" and ".join(string_list)
    else:
        return f"{delim} ".join(string_list[:-1]) + f"{delim} and " + string_list[-1]


if __name__ == "__main__":
    lst = ["a", "b", "c"]
    print(chunk_list(lst, 2))
